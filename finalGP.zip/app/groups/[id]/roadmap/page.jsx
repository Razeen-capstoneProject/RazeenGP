"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { MapPin, Plus, ChevronLeft, MoreHorizontal, Filter, X, AlertCircle } from "lucide-react"
import RoadmapModal from "@/app/instructorComponents/roadmap-modal"
import { supabase } from "@/lib/supabase"

export default function RoadmapPage() {
  const router = useRouter()
  const params = useParams()
  const entranceId = params.id // This is actually the entrance_id, not the group_id
  const [groupId, setGroupId] = useState(null) // Store the actual group_id
  const [group, setGroup] = useState(null)
  const [roadmap, setRoadmap] = useState([])
  const [filteredRoadmap, setFilteredRoadmap] = useState([])
  const [isRoadmapModalOpen, setIsRoadmapModalOpen] = useState(false)
  const [selectedMilestone, setSelectedMilestone] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [statusFilter, setStatusFilter] = useState("All")
  const [priorityFilter, setPriorityFilter] = useState("All")
  const [showFilters, setShowFilters] = useState(false)
  const [numericGroupId, setNumericGroupId] = useState(null)

  useEffect(() => {
    if (entranceId) {
      fetchGroupByEntranceId()
    }
  }, [entranceId])

  // Apply filters whenever roadmap or filters change
  useEffect(() => {
    applyFilters()
  }, [roadmap, statusFilter])

  const applyFilters = () => {
    let filtered = [...roadmap]

    // Apply status filter
    if (statusFilter !== "All") {
      filtered = filtered.filter((milestone) => milestone.status === statusFilter)
    }

    setFilteredRoadmap(filtered)
  }

  // First, fetch the group using the entrance_id
  const fetchGroupByEntranceId = async () => {
    try {
      setLoading(true)
      console.log("Fetching group with entrance_id:", entranceId)

      // Try to find the group with this entrance_id
      const { data: groupData, error: groupError } = await supabase
        .from("projectgroup")
        .select("*")
        .eq("enterance_id", entranceId)
        .single()

      if (groupError) {
        // If entrance_id doesn't exist, try using it as a groupid directly
        console.log("No group found with entrance_id, trying as groupid")
        const { data: groupByGroupId, error: groupIdError } = await supabase
          .from("projectgroup")
          .select("*")
          .eq("groupid", entranceId)
          .single()

        if (groupIdError) {
          console.error("Error fetching group:", groupIdError)
          setError("Could not find the group. Please check the URL and try again.")
          setLoading(false)
          return
        } else {
          setGroup(groupByGroupId)
          setGroupId(groupByGroupId.groupid)
          console.log("Found group by groupid:", groupByGroupId)
        }
      } else {
        // We found the group using entrance_id
        setGroup(groupData)
        setGroupId(groupData.groupid)
        console.log("Found group by entrance_id:", groupData)
      }

      // Now try to find the numeric group ID from the task table
      try {
        const { data: taskData, error: taskError } = await supabase
          .from("task")
          .select("group_id")
          .eq("group_uuid", groupId || groupData?.groupid)
          .limit(1)
          .single()

        if (!taskError && taskData) {
          setNumericGroupId(taskData.group_id)
          console.log("Found numeric group ID from task table:", taskData.group_id)

          // Now fetch the milestones using the numeric ID
          await fetchMilestonesWithNumericId(taskData.group_id)
        } else {
          console.log("No tasks found for this group, trying alternative approach")
          // Try to fetch milestones directly with the UUID
          await fetchMilestonesWithUuid(groupId || groupData?.groupid)
        }
      } catch (taskErr) {
        console.log("Could not find numeric group ID from task table:", taskErr)
        // Try to fetch milestones directly with the UUID
        await fetchMilestonesWithUuid(groupId || groupData?.groupid)
      }
    } catch (err) {
      console.error("Error in fetchGroupByEntranceId:", err)
      setError("An error occurred while loading the group: " + (err.message || "Unknown error"))
      setLoading(false)
    }
  }

  // Fetch milestones using numeric ID
  const fetchMilestonesWithNumericId = async (numericId) => {
    try {
      console.log("Fetching milestones with numeric ID:", numericId)

      const { data: milestonesData, error: milestonesError } = await supabase
        .from("milestone")
        .select("*")
        .eq("group_id", numericId)
        .order("deadline", { ascending: true })

      if (milestonesError) {
        console.error("Error fetching milestones with numeric ID:", milestonesError)
        // Try with UUID as fallback
        await fetchMilestonesWithUuid(groupId)
      } else {
        console.log("Found milestones with numeric ID:", milestonesData?.length || 0)
        setRoadmap(milestonesData || [])
        setFilteredRoadmap(milestonesData || [])
        setError(null)
        setLoading(false)
      }
    } catch (err) {
      console.error("Error in fetchMilestonesWithNumericId:", err)
      // Try with UUID as fallback
      await fetchMilestonesWithUuid(groupId)
    }
  }

  // Fetch milestones using UUID
  const fetchMilestonesWithUuid = async (uuid) => {
    try {
      if (!uuid) {
        console.log("No UUID available, cannot fetch milestones")
        setRoadmap([])
        setFilteredRoadmap([])
        setLoading(false)
        return
      }

      console.log("Fetching milestones with UUID:", uuid)

      const { data: milestonesData, error: milestonesError } = await supabase
        .from("milestone")
        .select("*")
        .eq("group_id", uuid)
        .order("deadline", { ascending: true })

      if (milestonesError) {
        console.error("Error fetching milestones with UUID:", milestonesError)
        setError("Could not load milestones for this group.")
        setRoadmap([])
        setFilteredRoadmap([])
      } else {
        console.log("Found milestones with UUID:", milestonesData?.length || 0)
        setRoadmap(milestonesData || [])
        setFilteredRoadmap(milestonesData || [])
        setError(null)
      }
    } catch (err) {
      console.error("Error in fetchMilestonesWithUuid:", err)
      setError("An error occurred while loading the milestones: " + (err.message || "Unknown error"))
      setRoadmap([])
      setFilteredRoadmap([])
    } finally {
      setLoading(false)
    }
  }

  const handleAddMilestone = () => {
    if (!numericGroupId && !groupId) {
      setError("Cannot add milestones for this group. Please contact support.")
      return
    }

    setSelectedMilestone(null)
    setIsRoadmapModalOpen(true)
  }

  const handleEditMilestone = (milestone) => {
    setSelectedMilestone(milestone)
    setIsRoadmapModalOpen(true)
  }

  const handleSaveMilestone = async (milestoneData) => {
    try {
      // Prefer numeric ID if available, otherwise use UUID
      const idToUse = numericGroupId || groupId

      if (!idToUse) {
        throw new Error("Cannot save milestone: No group ID available")
      }

      if (selectedMilestone) {
        // Edit existing milestone
        const { error } = await supabase
          .from("milestone")
          .update({
            name: milestoneData.name,
            deadline: milestoneData.deadline,
            status: milestoneData.status,
          })
          .eq("milestone_id", selectedMilestone.milestone_id)

        if (error) throw error
      } else {
        // Add new milestone
        const { error } = await supabase.from("milestone").insert([
          {
            group_id: idToUse,
            name: milestoneData.name,
            deadline: milestoneData.deadline,
            status: milestoneData.status,
          },
        ])

        if (error) throw error
      }

      // Refresh milestones after save
      if (numericGroupId) {
        await fetchMilestonesWithNumericId(numericGroupId)
      } else {
        await fetchMilestonesWithUuid(groupId)
      }
    } catch (err) {
      console.error("Error saving milestone:", err)
      throw err
    }
  }

  const handleDeleteMilestone = async (milestoneId) => {
    try {
      const { error } = await supabase.from("milestone").delete().eq("milestone_id", milestoneId)

      if (error) throw error

      // Refresh milestones after delete
      if (numericGroupId) {
        await fetchMilestonesWithNumericId(numericGroupId)
      } else {
        await fetchMilestonesWithUuid(groupId)
      }
    } catch (err) {
      console.error("Error deleting milestone:", err)
      throw err
    }
  }

  const handleFilterToggle = () => {
    setShowFilters(!showFilters)
  }

  const handleStatusFilterChange = (status) => {
    setStatusFilter(status)
  }

  const handlePriorityFilterChange = (priority) => {
    setPriorityFilter(priority)
  }

  const clearFilters = () => {
    setStatusFilter("All")
    setPriorityFilter("All")
  }

  // Get count of milestones by status
  const getStatusCounts = () => {
    const counts = {
      "To Do": roadmap.filter((m) => m.status === "To Do").length,
      "On Progress": roadmap.filter((m) => m.status === "On Progress").length,
      Done: roadmap.filter((m) => m.status === "Done").length,
    }
    return counts
  }

  // Get count of milestones by priority
  const getPriorityCounts = () => {
    const counts = {
      High: roadmap.filter((m) => m.priority === "High").length,
      Medium: roadmap.filter((m) => m.priority === "Medium").length,
      Low: roadmap.filter((m) => m.priority === "Low").length,
    }
    return counts
  }

  const statusCounts = getStatusCounts()
  const priorityCounts = getPriorityCounts()

  // Count active filters
  const getActiveFilterCount = () => {
    let count = 0
    if (statusFilter !== "All") count++
    if (priorityFilter !== "All") count++
    return count
  }

  const activeFilterCount = getActiveFilterCount()

  // Check if we can add milestones (need a group ID)
  const canAddMilestones = () => {
    return numericGroupId !== null || groupId !== null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href={`/groups/${entranceId}`} passHref>
                <button className="mr-4 text-gray-600 hover:text-gray-900">
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </Link>
              <h1 className="text-3xl font-bold text-gray-900">{group?.groupname || "Group"} Roadmap</h1>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={handleFilterToggle}
                className={`px-4 py-2 border text-sm font-medium rounded-md ${
                  showFilters || activeFilterCount > 0
                    ? "bg-indigo-100 text-indigo-700 border-indigo-300"
                    : "text-gray-700 border-gray-300 bg-white hover:bg-gray-50"
                }`}
              >
                <Filter className="w-5 h-5 mr-2 inline-block" />
                Filter
                {activeFilterCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 bg-indigo-200 text-indigo-800 rounded-full text-xs">
                    {activeFilterCount}
                  </span>
                )}
              </button>
              <button
                onClick={handleAddMilestone}
                className="px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                disabled={!canAddMilestones()}
              >
                <Plus className="w-5 h-5 mr-2 inline-block" />
                Add Milestone
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filter Panel */}
        {showFilters && (
          <div className="bg-white p-4 rounded-lg shadow mb-6 border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Filter Milestones</h3>
              <button onClick={handleFilterToggle} className="text-gray-500 hover:text-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Status</h4>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleStatusFilterChange("All")}
                  className={`px-3 py-1.5 text-sm rounded-md ${
                    statusFilter === "All"
                      ? "bg-indigo-100 text-indigo-800 border border-indigo-200"
                      : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                  }`}
                >
                  All ({roadmap.length})
                </button>
                <button
                  onClick={() => handleStatusFilterChange("To Do")}
                  className={`px-3 py-1.5 text-sm rounded-md ${
                    statusFilter === "To Do"
                      ? "bg-blue-100 text-blue-800 border border-blue-200"
                      : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                  }`}
                >
                  To Do ({statusCounts["To Do"] || 0})
                </button>
                <button
                  onClick={() => handleStatusFilterChange("On Progress")}
                  className={`px-3 py-1.5 text-sm rounded-md ${
                    statusFilter === "On Progress"
                      ? "bg-yellow-100 text-yellow-800 border border-yellow-200"
                      : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                  }`}
                >
                  On Progress ({statusCounts["On Progress"] || 0})
                </button>
                <button
                  onClick={() => handleStatusFilterChange("Done")}
                  className={`px-3 py-1.5 text-sm rounded-md ${
                    statusFilter === "Done"
                      ? "bg-green-100 text-green-800 border border-green-200"
                      : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                  }`}
                >
                  Done ({statusCounts["Done"] || 0})
                </button>
              </div>
            </div>

            {activeFilterCount > 0 && (
              <div className="flex justify-end">
                <button onClick={clearFilters} className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900">
                  Clear filters
                </button>
              </div>
            )}
          </div>
        )}

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : error ? (
          <div className="bg-white shadow overflow-hidden sm:rounded-md p-6">
            <div className="flex flex-col items-center justify-center text-center">
              <AlertCircle className="h-12 w-12 text-amber-500 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Error Loading Roadmap</h3>
              <p className="text-gray-500 mb-6 max-w-md">{error}</p>
              <div className="flex space-x-4">
                <button
                  onClick={() => fetchGroupByEntranceId()}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Try Again
                </button>
                <Link href={`/groups/${entranceId}`} passHref>
                  <button className="px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                    Back to Group
                  </button>
                </Link>
              </div>
            </div>
          </div>
        ) : filteredRoadmap.length === 0 ? (
          <div className="bg-white shadow overflow-hidden sm:rounded-md p-6 text-center">
            <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {roadmap.length === 0 ? "No milestones yet" : "No milestones match your filters"}
            </h3>
            <p className="text-gray-500 mb-4">
              {roadmap.length === 0
                ? "Get started by adding your first project milestone."
                : "Try changing your filter criteria or clear filters to see all milestones."}
            </p>
            {roadmap.length === 0 && canAddMilestones() ? (
              <button
                onClick={handleAddMilestone}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Milestone
              </button>
            ) : (
              <button
                onClick={clearFilters}
                className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className="bg-white shadow overflow-hidden sm:rounded-md">
            {activeFilterCount > 0 && (
              <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-500 flex flex-wrap gap-2 items-center">
                    Filtered by:
                    {statusFilter !== "All" && (
                      <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-xs font-medium">
                        Status: {statusFilter}
                      </span>
                    )}
                  </div>
                  <button onClick={clearFilters} className="text-sm text-indigo-600 hover:text-indigo-800">
                    Clear
                  </button>
                </div>
              </div>
            )}
            <ul className="divide-y divide-gray-200">
              {filteredRoadmap.map((milestone) => (
                <li key={milestone.milestone_id}>
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <MapPin className="w-5 h-5 text-gray-400 mr-2" />
                        <p className="text-sm font-medium text-indigo-600 truncate">{milestone.name}</p>
                      </div>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                          ${
                            milestone.status === "Done"
                              ? "bg-green-100 text-green-800"
                              : milestone.status === "To Do"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {milestone.status}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                        <p>
                          Deadline:{" "}
                          {milestone.deadline ? new Date(milestone.deadline).toLocaleDateString() : "No deadline"}
                        </p>
                        <button
                          onClick={() => handleEditMilestone(milestone)}
                          className="ml-2 text-indigo-600 hover:text-indigo-900"
                        >
                          <MoreHorizontal className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </main>

      <RoadmapModal
        isOpen={isRoadmapModalOpen}
        onClose={() => setIsRoadmapModalOpen(false)}
        onSave={handleSaveMilestone}
        onDelete={selectedMilestone ? () => handleDeleteMilestone(selectedMilestone.milestone_id) : undefined}
        editMilestone={selectedMilestone}
      />
    </div>
  )
}
