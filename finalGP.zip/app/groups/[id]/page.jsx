"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Calendar, ChevronDown, Filter, Plus, MessageSquare, Users, Clock, CheckCircle, Circle } from "lucide-react"
import { supabase } from "@/lib/supabase"
import TaskFormModal from "@/app/instructorComponents/task-form-modal"
import ChatModal from "@/app/instructorComponents/chat-modal"
import Link from "next/link"
import Sidebar from "@/app/instructorComponents/sidebar"
import GroupRoadmap from "@/app/instructorComponents/group-roadmap"
import {
  hasUnreadMessages,
  subscribeToNewMessages,
  markAllMessagesAsRead,
  markMessagesAsViewedInSession,
} from "@/lib/chat-notification-utils"
import { hasUnreadFeedbackFiles, markFeedbackFilesAsRead } from "@/lib/feedback-notification-utils"

export default function GroupDetailPage() {
  const router = useRouter()
  const params = useParams()
  const entranceId = params.id
  const [group, setGroup] = useState(null)
  const [loading, setLoading] = useState(true)
  const [tasks, setTasks] = useState({
    todo: [],
    inProgress: [],
    done: [],
  })
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false)
  const [selectedTask, setSelectedTask] = useState(null)
  const [isCurrentUserLeader, setIsCurrentUserLeader] = useState(false)
  const [isChatModalOpen, setIsChatModalOpen] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)
  const [members, setMembers] = useState([])
  const [milestones, setMilestones] = useState([]) // Store milestone data
  const [roadmapLoading, setRoadmapLoading] = useState(true)
  // Store the actual group ID to use across functions
  const [actualGroupId, setActualGroupId] = useState(null)
  // Add state for unread chat messages
  const [hasUnreadChatMessages, setHasUnreadChatMessages] = useState(false)
  // Add state for unread feedback files
  const [hasUnreadFeedback, setHasUnreadFeedback] = useState(false)
  // Add state for chat ID
  const [chatId, setChatId] = useState(null)
  // Add state for unread message count
  const [unreadMessageCount, setUnreadMessageCount] = useState(0)

  // Add a success notification state
  const [successNotification, setSuccessNotification] = useState(null)

  const [priorityFilter, setPriorityFilter] = useState("All")
  const [showFilterPanel, setShowFilterPanel] = useState(false)

  // Track viewed files at the page level
  const [viewedFiles, setViewedFiles] = useState({})

  // Handle file viewed event from child components
  const handleFileViewed = (taskId, fileId) => {
    setViewedFiles((prev) => ({
      ...prev,
      [taskId]: {
        ...(prev[taskId] || {}),
        [fileId]: true,
      },
    }))

    // Also update localStorage to maintain consistency
    const storedViewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
    storedViewedFiles[fileId] = true
    localStorage.setItem("viewedFiles", JSON.stringify(storedViewedFiles))

    // Check if we need to update the feedback notification status
    checkUnreadFeedbackFiles()
  }

  const handleFilterClick = () => {
    setShowFilterPanel(!showFilterPanel)
  }

  const handlePriorityFilter = (priority) => {
    setPriorityFilter(priority)
  }

  const clearFilters = () => {
    setPriorityFilter("All")
  }

  // Navigation handlers
  const handleNavigation = (path) => {
    router.push(path)
  }

  // Update the checkUnreadChatMessages function to use session storage
  const checkUnreadChatMessages = async () => {
    if (actualGroupId && currentUser?.user_id) {
      try {
        // First, get the chat ID for this group
        const { data: chatData, error: chatError } = await supabase
          .from("chat")
          .select("chatid")
          .eq("group_id", actualGroupId)
          .ilike("chatname", "supervisor_students_chats_%")
          .single()

        if (chatError) {
          console.error("Error getting chat for group:", chatError)
          return
        }

        // Store the chat ID for later use
        setChatId(chatData.chatid)

        // Mark messages as viewed in the current session
        // This prevents notifications from reappearing after minor changes
        await markMessagesAsViewedInSession(chatData.chatid, currentUser.user_id)

        // Check for unread messages
        const hasUnread = await hasUnreadMessages(actualGroupId, currentUser.user_id)
        setHasUnreadChatMessages(hasUnread)

        // Get unread count
        if (hasUnread) {
          const { data: messages, error } = await supabase
            .from("message")
            .select("messageid")
            .eq("chatid", chatData.chatid)
            .neq("user_id", currentUser.user_id)
            .order("messagetime", { ascending: false })

          if (!error && messages) {
            // Get read messages from localStorage
            const readKey = `chat_${chatData.chatid}_read_messages_${currentUser.user_id}`
            const readMessages = JSON.parse(localStorage.getItem(readKey) || "[]")

            // Get session viewed messages
            const sessionKey = `session_viewed_messages_${chatData.chatid}_${currentUser.user_id}`
            let sessionViewed = []
            try {
              const sessionData = sessionStorage.getItem(sessionKey)
              sessionViewed = sessionData ? JSON.parse(sessionData) : []
            } catch (e) {
              sessionViewed = []
            }

            // Count unread messages, excluding session viewed
            const unreadCount = messages.filter(
              (msg) => !readMessages.includes(msg.messageid) && !sessionViewed.includes(msg.messageid),
            ).length

            setUnreadMessageCount(unreadCount)
          }
        } else {
          setUnreadMessageCount(0)
        }
      } catch (error) {
        console.error("Error checking for unread messages:", error)
      }
    }
  }

  // Check for unread feedback files
  const checkUnreadFeedbackFiles = async () => {
    if (actualGroupId && currentUser?.user_id) {
      const hasUnread = await hasUnreadFeedbackFiles(actualGroupId, currentUser.user_id)
      setHasUnreadFeedback(hasUnread)
    }
  }

  // Update fetchMilestones to use actualGroupId
  const fetchMilestones = async (groupId) => {
    try {
      setRoadmapLoading(true)

      // Use the passed groupId parameter if available, otherwise use the state
      const groupIdToUse = groupId || actualGroupId

      // Check if groupIdToUse is null or undefined
      if (!groupIdToUse) {
        console.error("Actual group ID is null or undefined")
        setMilestones([])
        return
      }

      const { data, error } = await supabase
        .from("milestone")
        .select("*")
        .eq("group_id", groupIdToUse)
        .order("deadline", { ascending: true })
        .limit(3) // Limit to 3 milestones for the preview

      if (error) throw error
      setMilestones(data || [])
    } catch (err) {
      console.error("Error fetching milestones:", err)
      // For demo purposes, set some mock data if fetch fails
    } finally {
      setRoadmapLoading(false)
    }
  }

  const fetchGroupData = async () => {
    setLoading(true)
    try {
      // First, fetch the group using entrance_id
      const { data: groupData, error: groupError } = await supabase
        .from("projectgroup")
        .select("*")
        .eq("enterance_id", entranceId)
        .single()

      if (groupError) throw groupError

      // Store the actual group ID for use in other functions
      setActualGroupId(groupData.groupid)

      // Check if current user is the leader
      const isLeader = !!groupData.leader_id
      setIsCurrentUserLeader(isLeader)

      // Fetch tasks for this group using the actual group ID
      const { data: tasksData, error: tasksError } = await supabase
        .from("task")
        .select("*")
        .eq("groupid", groupData.groupid)

      if (tasksError) throw tasksError

      // Fetch subtasks for all tasks
      const taskIds = tasksData.map((task) => task.taskid)
      if (taskIds.length > 0) {
        const { data: subtasksData, error: subtasksError } = await supabase
          .from("sub_task")
          .select("*")
          .in("main_task", taskIds)

        if (subtasksError) {
          console.error("Error fetching subtasks:", subtasksError)
        } else {
          // Group subtasks by task ID
          const subtasksByTaskId = {}
          subtasksData.forEach((subtask) => {
            if (!subtasksByTaskId[subtask.main_task]) {
              subtasksByTaskId[subtask.main_task] = []
            }
            subtasksByTaskId[subtask.main_task].push(subtask)
          })

          // Attach subtasks to their parent tasks
          tasksData.forEach((task) => {
            task.subtasks = subtasksByTaskId[task.taskid] || []
          })
        }
      }

      // Organize tasks by status
      const todoTasks = tasksData.filter((task) => task.status === "todo" || task.status === "To Do")
      const inProgressTasks = tasksData.filter((task) => task.status === "in_progress" || task.status === "On Progress")
      const doneTasks = tasksData.filter((task) => task.status === "done" || task.status === "Done")

      setGroup(groupData)
      if (groupData) {
        const { data: students, error: studentsError } = await supabase
          .from("student")
          .select("*, users!inner(*)")
          .eq("groupid", groupData.groupid)

        if (!studentsError && students) {
          const formattedMembers = students.map((student) => ({
            id: student.student_id,
            name: student.users.userName || `Student ${student.student_id.substring(0, 8)}`,
            isLeader: student.student_id === groupData.leader_id,
          }))
          setMembers(formattedMembers)
        }
      }
      setTasks({
        todo: todoTasks || [],
        inProgress: inProgressTasks || [],
        done: doneTasks || [],
      })

      // Fetch current user (for demo, we'll use the supervisor)
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("user_id", "863f0f67-0a17-4ede-96d8-6fe15d746c64")
        .single()

      if (!userError) {
        setCurrentUser({
          ...userData,
          // Ensure userName is set
          userName: userData.userName || "Supervisor",
          role: "Supervisor", // Force role to be Supervisor for testing
        })
      } else {
        // Mock user for demo with better name
        setCurrentUser({
          user_id: "863f0f67-0a17-4ede-96d8-6fe15d746c64",
          userName: "Supervisor",
          role: "Supervisor",
        })
      }

      // Fetch milestones after setting the actual group ID
      fetchMilestones(groupData.groupid)
    } catch (error) {
      console.error("Error fetching group details:", error)
      setGroup({
        groupid: null,
        groupname: "Error loading group",
        group_progress: 0,
      })
      setTasks({
        todo: [],
        inProgress: [],
        done: [],
      })

      // Set default supervisor user for testing
      setCurrentUser({
        user_id: "863f0f67-0a17-4ede-96d8-6fe15d746c64",
        userName: "Supervisor",
        role: "Supervisor",
      })
    } finally {
      setLoading(false)
    }
  }

  // Call fetchGroupData in the useEffect
  useEffect(() => {
    if (entranceId) {
      fetchGroupData()
    }
  }, [entranceId])

  // Check for unread messages and feedback files periodically
  useEffect(() => {
    let intervalId

    if (actualGroupId && currentUser?.user_id) {
      // Check immediately
      checkUnreadChatMessages()
      checkUnreadFeedbackFiles()

      // Set up interval to check periodically
      intervalId = setInterval(() => {
        checkUnreadChatMessages()
        checkUnreadFeedbackFiles()
      }, 30000) // Check every 30 seconds
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId)
      }
    }
  }, [actualGroupId, currentUser])

  // Set up real-time subscription for new messages
  useEffect(() => {
    let subscription = null

    if (chatId && currentUser?.user_id) {
      subscription = subscribeToNewMessages(chatId, currentUser.user_id)
    }

    return () => {
      if (subscription) {
        supabase.removeChannel(subscription)
      }
    }
  }, [chatId, currentUser])

  // Listen for chat message events
  useEffect(() => {
    // Listen for the custom event when chat messages are read
    const handleChatMessagesRead = () => {
      setHasUnreadChatMessages(false)
      setUnreadMessageCount(0)
    }

    // Listen for new chat messages
    const handleNewChatMessage = () => {
      checkUnreadChatMessages()
    }

    window.addEventListener("chatMessagesAllRead", handleChatMessagesRead)
    window.addEventListener("newChatMessage", handleNewChatMessage)

    return () => {
      window.removeEventListener("chatMessagesAllRead", handleChatMessagesRead)
      window.removeEventListener("newChatMessage", handleNewChatMessage)
    }
  }, [])

  // Listen for subtask changes to detect new feedback files
  useEffect(() => {
    let subscription

    if (actualGroupId) {
      subscription = supabase
        .channel(`subtasks-${actualGroupId}`)
        .on(
          "postgres_changes",
          {
            event: "*", // Listen for all changes (INSERT, UPDATE, DELETE)
            schema: "public",
            table: "sub_task",
          },
          () => {
            // When any subtask changes, check for new feedback files
            checkUnreadFeedbackFiles()
          },
        )
        .subscribe()
    }

    return () => {
      if (subscription) {
        supabase.removeChannel(subscription)
      }
    }
  }, [actualGroupId])

  // Listen for changes to viewedFiles in localStorage
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === "viewedFiles") {
        // When viewedFiles changes in localStorage, check if we need to update the notification
        checkUnreadFeedbackFiles()
      }
    }

    window.addEventListener("storage", handleStorageChange)

    // Custom event for file viewed
    const handleFileViewedEvent = () => {
      checkUnreadFeedbackFiles()
    }

    window.addEventListener("fileViewed", handleFileViewedEvent)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("fileViewed", handleFileViewedEvent)
    }
  }, [])

  // Handle creating a new task
  const handleAddTask = () => {
    setSelectedTask(null) // Ensure we're in create mode
    setIsTaskModalOpen(true)
  }

  // Handle editing an existing task
  const handleEditTask = (task) => {
    setSelectedTask(task)
    setIsTaskModalOpen(true)
  }

  // Handle opening chat
  const handleOpenChat = async () => {
    setIsChatModalOpen(true)

    // Mark messages as read when opening chat
    if (chatId && currentUser?.user_id) {
      try {
        // Update local state immediately for better UX
        setHasUnreadChatMessages(false)
        setUnreadMessageCount(0)

        // Mark all messages as read in storage
        await markAllMessagesAsRead(chatId, currentUser.user_id)
      } catch (error) {
        console.error("Error marking messages as read:", error)
      }
    }
  }

  // Handle navigating to feedback page
  const handleNavigateToFeedback = () => {
    // Mark feedback files as read
    if (actualGroupId && currentUser?.user_id) {
      markFeedbackFilesAsRead(actualGroupId, currentUser.user_id)
      setHasUnreadFeedback(false)
    }

    // Navigate to feedback page
    router.push(`/groups/${entranceId}/feedback`)
  }

  // Handle chat modal close
  const handleChatModalClose = () => {
    setIsChatModalOpen(false)
    // Check for any new messages that might have arrived while the modal was open
    checkUnreadChatMessages()
  }

  // Handle task created
  const handleTaskCreated = () => {
    // Show success notification
    setSuccessNotification("Task created successfully!")

    // Hide notification after 3 seconds
    setTimeout(() => {
      setSuccessNotification(null)
    }, 3000)

    // Refresh the task list
    fetchGroupData()
  }

  // Handle task updated
  const handleTaskUpdated = () => {
    setSuccessNotification("Task updated successfully!")

    setTimeout(() => {
      setSuccessNotification(null)
    }, 3000)

    fetchGroupData()
  }

  // Handle modal close
  const handleModalClose = () => {
    setIsTaskModalOpen(false)
    setSelectedTask(null)
  }

  // Filter tasks based on search query and priority
  const filterTasks = (taskList) => {
    return taskList.filter((task) => {
      const matchesPriority = priorityFilter === "All" || task.priority === priorityFilter
      return matchesPriority
    })
  }

  // Get all tasks for list/grid view
  const getAllTasks = () => {
    return [...tasks.todo, ...tasks.inProgress, ...tasks.done]
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  // Helper function to get status label
  const getProgressStatus = (progress) => {
    if (progress < 30) return "late"
    if (progress < 70) return "on progress"
    return "on track"
  }

  // Helper function to get status icon
  const getStatusIcon = (status) => {
    switch (status) {
      case "Done":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "On Progress":
        return <Clock className="w-5 h-5 text-blue-500" />
      default:
        return <Circle className="w-5 h-5 text-gray-400" />
    }
  }

  // Helper function to get status color
  const getStatusColor = (status) => {
    switch (status) {
      case "Done":
        return "bg-green-50"
      case "On Progress":
        return "bg-blue-50"
      default:
        return "bg-gray-50"
    }
  }

  // Format date to display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"
    const date = new Date(dateString)
    return `Due: ${date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white p-4 border-b border-gray-200 flex justify-end items-center shadow-sm">
          <div className="flex items-center">
            <div className="mr-3 text-right">
              <div className="font-medium">{currentUser?.userName || "Supervisor"}</div>
              <div className="text-sm text-gray-500">{currentUser?.role || "Supervisor"}</div>
            </div>
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                <span>{currentUser?.userName?.charAt(0) || "S"}</span>
              </div>
              <ChevronDown className="w-4 h-4 absolute -right-4 top-3 text-gray-600" />
            </div>
          </div>
        </header>

        {/* Group Header */}
        <div className="bg-white p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                <Users className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">{group?.groupname || "Mobile App Group"}</h1>
                <div className="text-amber-500 text-sm font-medium mt-1">
                  {getProgressStatus(group?.group_progress || 50)}
                </div>
              </div>
            </div>

            <div className="flex space-x-2">
              <button
                onClick={handleFilterClick}
                className={`flex items-center px-3 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 ${
                  priorityFilter !== "All" ? "bg-blue-50 border-blue-200 text-blue-600" : ""
                }`}
              >
                <Filter className="w-4 h-4 mr-2" />
                <span>Filter</span>
                {priorityFilter !== "All" && (
                  <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs">
                    {priorityFilter}
                  </span>
                )}
              </button>

              <button
                onClick={handleNavigateToFeedback}
                className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 relative"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                <span>Feedback</span>
                {hasUnreadFeedback && (
                  <span className="absolute top-1 left-1 flex h-2 w-2">
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                  </span>
                )}
              </button>
              <button
                className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
                onClick={handleAddTask}
              >
                <Plus className="w-4 h-4 mr-2" />
                <span>Add Task</span>
              </button>
              <button
                className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 relative"
                onClick={handleOpenChat}
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                <span>Chat</span>
                {hasUnreadChatMessages && (
                  <span className="absolute top-1 left-1 flex h-5 w-5 items-center justify-center">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-5 w-5 bg-red-500 text-white text-xs font-bold items-center justify-center">
                      {unreadMessageCount > 9 ? "9+" : unreadMessageCount}
                    </span>
                  </span>
                )}
              </button>
              <Link href={`/groups/${entranceId}/gantt`} passHref>
                <button className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>Gantt Chart</span>
                </button>
              </Link>
            </div>
          </div>
        </div>

        {showFilterPanel && (
          <div className="mb-6 mt-4 p-4 mx-6 bg-white rounded-lg border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-medium text-gray-700">Filter by Priority</h3>
              <button onClick={clearFilters} className="text-sm text-blue-600 hover:text-blue-700">
                Clear filters
              </button>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handlePriorityFilter("High")}
                className={`px-3 py-1.5 text-sm rounded-md ${
                  priorityFilter === "High"
                    ? "bg-red-100 text-red-700 border border-red-200"
                    : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"
                }`}
              >
                High
              </button>
              <button
                onClick={() => handlePriorityFilter("Medium")}
                className={`px-3 py-1.5 text-sm rounded-md ${
                  priorityFilter === "Medium"
                    ? "bg-amber-100 text-amber-700 border border-amber-200"
                    : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"
                }`}
              >
                Medium
              </button>
              <button
                onClick={() => handlePriorityFilter("Low")}
                className={`px-3 py-1.5 text-sm rounded-md ${
                  priorityFilter === "Low"
                    ? "bg-blue-100 text-blue-700 border border-blue-200"
                    : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"
                }`}
              >
                Low
              </button>
              <button
                onClick={() => handlePriorityFilter("All")}
                className={`px-3 py-1.5 text-sm rounded-md ${
                  priorityFilter === "All"
                    ? "bg-gray-200 text-gray-800 border border-gray-300"
                    : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"
                }`}
              >
                All
              </button>
            </div>
          </div>
        )}

        {successNotification && (
          <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 m-4 rounded shadow-sm">
            <div className="flex items-center">
              <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                ></path>
              </svg>
              <p>{successNotification}</p>
            </div>
          </div>
        )}

        {/* Task Display - Kanban Board View */}
        <div className="flex-1 p-6 overflow-auto bg-gray-50">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-800 flex items-center">
              <svg
                className="w-6 h-6 mr-2 text-blue-500"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                <line x1="12" y1="22.08" x2="12" y2="12"></line>
              </svg>
              Group Tasks
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* To Do Column */}
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
              <div className="flex justify-between items-center p-4 border-b border-gray-100">
                <div className="flex items-center">
                  <div className="w-5 h-5 rounded-full flex items-center justify-center border border-gray-300 mr-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-gray-500"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                  </div>
                  <h3 className="font-medium text-gray-800">To Do</h3>
                </div>
                <span className="bg-gray-100 text-gray-700 text-xs font-medium px-2.5 py-0.5 rounded-full">
                  {filterTasks(tasks.todo).length}
                </span>
              </div>

              <div className="p-2 space-y-2">
                {filterTasks(tasks.todo).length > 0 ? (
                  filterTasks(tasks.todo).map((task) => (
                    <div
                      key={task.taskid}
                      className="flex justify-between items-center p-3 hover:bg-gray-50 border border-gray-100 rounded-md cursor-pointer transition-colors"
                      onClick={() => handleEditTask(task)}
                    >
                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-gray-400 mr-2"
                        >
                          <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                        <div className="flex items-center">
                          <span className="text-sm text-gray-700">{task.taskname}</span>
                          {task.priority && (
                            <span
                              className={`ml-2 text-xs px-1.5 py-0.5 rounded-full ${
                                task.priority === "High"
                                  ? "bg-red-100 text-red-700"
                                  : task.priority === "Medium"
                                    ? "bg-amber-100 text-amber-700"
                                    : "bg-blue-100 text-blue-700"
                              }`}
                            >
                              {task.priority}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <p className="text-sm">No tasks to display</p>
                  </div>
                )}
              </div>
            </div>

            {/* In Progress Column */}
            <div className="bg-blue-50 rounded-lg border border-blue-100 shadow-sm overflow-hidden">
              <div className="flex justify-between items-center p-4 border-b border-blue-100">
                <div className="flex items-center">
                  <div className="w-5 h-5 rounded-full flex items-center justify-center border border-blue-300 mr-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-blue-500"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                  </div>
                  <h3 className="font-medium text-gray-800">In Progress</h3>
                </div>
                <span className="bg-blue-100 text-blue-700 text-xs font-medium px-2.5 py-0.5 rounded-full">
                  {filterTasks(tasks.inProgress).length}
                </span>
              </div>

              <div className="p-2 space-y-2">
                {filterTasks(tasks.inProgress).length > 0 ? (
                  filterTasks(tasks.inProgress).map((task) => (
                    <div
                      key={task.taskid}
                      className="flex justify-between items-center p-3 hover:bg-blue-100 border border-blue-100 rounded-md cursor-pointer transition-colors"
                      onClick={() => handleEditTask(task)}
                    >
                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-blue-500 mr-2"
                        >
                          <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                        <div className="flex items-center">
                          <span className="text-sm text-gray-700">{task.taskname}</span>
                          {task.priority && (
                            <span
                              className={`ml-2 text-xs px-1.5 py-0.5 rounded-full ${
                                task.priority === "High"
                                  ? "bg-red-100 text-red-700"
                                  : task.priority === "Medium"
                                    ? "bg-amber-100 text-amber-700"
                                    : "bg-blue-100 text-blue-700"
                              }`}
                            >
                              {task.priority}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <p className="text-sm">No tasks in progress</p>
                  </div>
                )}
              </div>
            </div>

            {/* Completed Column */}
            <div className="bg-green-50 rounded-lg border border-green-100 shadow-sm overflow-hidden">
              <div className="flex justify-between items-center p-4 border-b border-green-100">
                <div className="flex items-center">
                  <div className="w-5 h-5 rounded-full flex items-center justify-center border border-green-300 mr-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>
                  <h3 className="font-medium text-gray-800">Completed</h3>
                </div>
                <span className="bg-green-100 text-green-700 text-xs font-medium px-2.5 py-0.5 rounded-full">
                  {filterTasks(tasks.done).length}
                </span>
              </div>

              <div className="p-2 space-y-2">
                {filterTasks(tasks.done).length > 0 ? (
                  filterTasks(tasks.done).map((task) => (
                    <div
                      key={task.taskid}
                      className="flex justify-between items-center p-3 hover:bg-green-100 border border-green-100 rounded-md cursor-pointer transition-colors"
                      onClick={() => handleEditTask(task)}
                    >
                      <div className="flex items-center">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-green-500 mr-2"
                        >
                          <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                        <div className="flex items-center">
                          <span className="text-sm text-gray-700">{task.taskname}</span>
                          {task.priority && (
                            <span
                              className={`ml-2 text-xs px-1.5 py-0.5 rounded-full ${
                                task.priority === "High"
                                  ? "bg-red-100 text-red-700"
                                  : task.priority === "Medium"
                                    ? "bg-amber-100 text-amber-700"
                                    : "bg-blue-100 text-blue-700"
                              }`}
                            >
                              {task.priority}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <p className="text-sm">No completed tasks</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Roadmap Section */}
        <div className="px-6 pb-6">
          {/* Pass the entrance_id to GroupRoadmap */}
          <GroupRoadmap entranceId={entranceId} />
        </div>
      </div>

      {/* Task Form Modal - Used for both creating and editing tasks */}
      <TaskFormModal
        isOpen={isTaskModalOpen}
        onClose={handleModalClose}
        groupId={actualGroupId}
        onTaskCreated={handleTaskCreated}
        onTaskUpdated={handleTaskUpdated}
        editTask={selectedTask}
        isLeader={isCurrentUserLeader}
        userRole={currentUser?.role}
      />

      {/* Chat Modal */}
      <ChatModal
        isOpen={isChatModalOpen}
        onClose={handleChatModalClose}
        groupId={actualGroupId}
        currentUser={currentUser}
      />
    </div>
  )
}
