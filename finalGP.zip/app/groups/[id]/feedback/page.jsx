"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { ChevronLeft, Search, Filter, MessageSquare, Save, X, File } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { isFileNewAndUnviewed, markFileAsViewed } from "@/lib/file-utils"
import { useAuth } from "@/context/auth-context" // Import the auth context

export default function FeedbackPage() {
  const router = useRouter()
  const params = useParams()
  const entranceId = params.id
  const [actualGroupId, setActualGroupId] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [group, setGroup] = useState(null)
  const [subtasks, setSubtasks] = useState([])
  const [tasks, setTasks] = useState({})
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("All")
  const [showFilters, setShowFilters] = useState(false)
  const [selectedSubtask, setSelectedSubtask] = useState(null)
  const [feedback, setFeedback] = useState({
    comment: "",
  })
  const [savingFeedback, setSavingFeedback] = useState(false)
  const [successMessage, setSuccessMessage] = useState(null)
  const [rejectingFile, setRejectingFile] = useState(false)
  const [rejectionReason, setRejectionReason] = useState("")
  const [showRejectionModal, setShowRejectionModal] = useState(false)
  const [fileToReject, setFileToReject] = useState(null)
  const [viewedFiles, setViewedFiles] = useState(new Set())

  // Add auth context and supervisor state
  const { user, isLoading: authLoading } = useAuth()
  const [supervisorId, setSupervisorId] = useState(null)

  useEffect(() => {
    // First check if we have a valid user from auth context
    if (!authLoading) {
      if (user && user.user_id) {
        // Set the supervisor ID from the authenticated user
        setSupervisorId(user.user_id)

        // Then fetch the actual group ID using entrance_id
        fetchGroupId()
      } else {
        setError("User not authenticated. Please log in.")
        setLoading(false)
      }
    }
  }, [user, authLoading, entranceId])

  const fetchGroupId = async () => {
    if (!entranceId) return

    try {
      const { data, error } = await supabase
        .from("projectgroup")
        .select("groupid, groupname")
        .eq("enterance_id", entranceId)
        .single()

      if (error) throw error

      setActualGroupId(data.groupid)
      setGroup(data)

      // Now fetch subtasks and other data using the actual group ID
      await fetchGroupAndSubtasks(data.groupid)

      // Load viewed files from localStorage
      const storedViewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
      setViewedFiles(new Set(Object.keys(storedViewedFiles).filter((id) => storedViewedFiles[id])))
    } catch (err) {
      console.error("Error fetching group:", err)
      setError("Failed to load group data")
      setLoading(false)
    }
  }

  // Update the fetchGroupAndSubtasks function to also fetch files associated with subtasks
  const fetchGroupAndSubtasks = async (groupId) => {
    if (!groupId) {
      setError("Group ID is missing")
      setLoading(false)
      return
    }

    try {
      setLoading(true)

      // Fetch all tasks for this group
      const { data: tasksData, error: tasksError } = await supabase.from("task").select("*").eq("groupid", groupId)

      if (tasksError) throw tasksError

      // Create a map of task IDs to task objects
      const taskMap = {}
      tasksData.forEach((task) => {
        taskMap[task.taskid] = task
      })
      setTasks(taskMap)

      // Fetch all subtasks for all tasks in this group
      const taskIds = tasksData.map((task) => task.taskid)

      if (taskIds.length > 0) {
        // First fetch all subtasks
        const { data: subtasksData, error: subtasksError } = await supabase
          .from("sub_task")
          .select("*")
          .in("main_task", taskIds)
          .order("subTaskName")

        if (subtasksError) throw subtasksError

        // Then fetch feedback for these subtasks
        const subtaskIds = subtasksData.map((subtask) => subtask.sub_task_id)

        const { data: feedbackData, error: feedbackError } = await supabase
          .from("feedback")
          .select("*")
          .in("sub_task_id", subtaskIds)

        if (feedbackError) throw feedbackError

        // Process subtasks with their feedback and attachments
        const subtasksWithData = subtasksData.map((subtask) => {
          const subtaskFeedback = feedbackData?.filter((f) => f.sub_task_id === subtask.sub_task_id) || []

          // Process attachment from the JSONB column if it exists
          let files = []
          if (subtask.attachment) {
            // If attachment is a string, try to parse it
            if (typeof subtask.attachment === "string") {
              try {
                const parsedAttachment = JSON.parse(subtask.attachment)
                files = Array.isArray(parsedAttachment) ? parsedAttachment : [parsedAttachment]
              } catch (e) {
                console.error("Error parsing attachment JSON:", e)
              }
            } else if (typeof subtask.attachment === "object") {
              // If it's already an object, use it directly
              files = Array.isArray(subtask.attachment) ? subtask.attachment : [subtask.attachment]
            }
          }

          // Check if any files are new or recently uploaded
          // Use the imported isFileNewAndUnviewed function
          const storedViewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
          const viewedFilesSet = new Set(Object.keys(storedViewedFiles).filter((id) => storedViewedFiles[id]))

          const hasNewFiles = files.some((file) => {
            const fileId = file.id || file.name
            return isFileNewAndUnviewed(file) && !viewedFilesSet.has(fileId)
          })

          return {
            ...subtask,
            feedback: subtaskFeedback,
            files: files,
            hasNewFiles: hasNewFiles,
          }
        })

        setSubtasks(subtasksWithData || [])
      } else {
        setSubtasks([])
      }
    } catch (err) {
      console.error("Error fetching data:", err)
      setError("Failed to load data. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleFilterToggle = () => {
    setShowFilters(!showFilters)
  }

  const handleStatusFilterChange = (status) => {
    setStatusFilter(status)
  }

  const clearFilters = () => {
    setStatusFilter("All")
    setSearchQuery("")
  }

  const getFilteredSubtasks = () => {
    return subtasks.filter((subtask) => {
      // Apply search filter
      const matchesSearch =
        searchQuery === "" ||
        subtask.subTaskName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (tasks[subtask.main_task]?.taskname || "").toLowerCase().includes(searchQuery.toLowerCase())

      // Apply status filter
      const matchesStatus = statusFilter === "All" || subtask.status === statusFilter

      return matchesSearch && matchesStatus
    })
  }

  const handleSelectSubtask = (subtask) => {
    setSelectedSubtask(subtask)

    // Always reset feedback form to empty, regardless of existing feedback
    setFeedback({
      comment: "",
    })
  }

  const handleCommentChange = (e) => {
    setFeedback((prev) => ({
      ...prev,
      comment: e.target.value,
    }))
  }

  const handleFileViewed = async (subtaskId, fileId) => {
    // Mark file as viewed in the database
    const success = await markFileAsViewed(subtaskId, fileId)

    if (success) {
      // Update local state
      setViewedFiles((prev) => {
        const newSet = new Set(prev)
        newSet.add(fileId)
        return newSet
      })

      // Store in localStorage
      const viewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
      viewedFiles[fileId] = true
      localStorage.setItem("viewedFiles", JSON.stringify(viewedFiles))

      // Update subtasks to reflect the change
      setSubtasks((prev) =>
        prev.map((subtask) => {
          if (subtask.sub_task_id === subtaskId) {
            // Update the files array
            const updatedFiles = subtask.files.map((file) => {
              if ((file.id && file.id === fileId) || (file.name && file.name === fileId)) {
                return { ...file, viewedAt: new Date().toISOString() }
              }
              return file
            })

            // Recalculate if there are any new files
            const storedViewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
            const viewedFilesSet = new Set(Object.keys(storedViewedFiles).filter((id) => storedViewedFiles[id]))

            const hasNewFiles = updatedFiles.some((file) => {
              const fileId = file.id || file.name
              return isFileNewAndUnviewed(file) && !viewedFilesSet.has(fileId)
            })

            return {
              ...subtask,
              files: updatedFiles,
              hasNewFiles,
            }
          }
          return subtask
        }),
      )
    }
  }

  const handleSubmitFeedback = async () => {
    if (!selectedSubtask) return

    // Check if we have a valid supervisor ID
    if (!supervisorId) {
      setError("Unable to submit feedback: Supervisor ID not available")
      return
    }

    try {
      setSavingFeedback(true)

      // Get the student_id from the selected subtask
      const studentId = selectedSubtask.student_id

      // Check if feedback already exists for this subtask
      const { data: existingFeedback, error: checkError } = await supabase
        .from("feedback")
        .select("feedbackid")
        .eq("sub_task_id", selectedSubtask.sub_task_id)
        .single()

      if (checkError && checkError.code !== "PGRST116") {
        throw checkError
      }

      if (existingFeedback) {
        // Update existing feedback
        const { error } = await supabase
          .from("feedback")
          .update({
            comment: feedback.comment,
            student_id: studentId, // Include student_id in the update
            instructor_supervisor_id: supervisorId, // Use dynamic supervisor ID
          })
          .eq("feedbackid", existingFeedback.feedbackid)

        if (error) throw error
      } else {
        // Create new feedback
        const { error } = await supabase.from("feedback").insert([
          {
            sub_task_id: selectedSubtask.sub_task_id,
            comment: feedback.comment,
            instructor_supervisor_id: supervisorId, // Use dynamic supervisor ID
            student_id: studentId, // Include student_id from the subtask
          },
        ])

        if (error) throw error
      }

      // Show success message
      setSuccessMessage("Feedback saved successfully!")
      setTimeout(() => setSuccessMessage(null), 3000)

      // Refresh data
      await fetchGroupAndSubtasks(actualGroupId)
    } catch (err) {
      console.error("Error saving feedback:", err)
      setError(`Failed to save feedback: ${err.message}`)
    } finally {
      setSavingFeedback(false)
    }
  }

  const handleRejectFile = (file, subtaskId) => {
    setFileToReject(file)
    setShowRejectionModal(true)
  }

  const submitFileRejection = async () => {
    if (!fileToReject || !selectedSubtask || !rejectionReason.trim()) return

    // Check if we have a valid supervisor ID
    if (!supervisorId) {
      setError("Unable to reject file: Supervisor ID not available")
      return
    }

    try {
      setRejectingFile(true)

      // Get the current attachment data
      const currentAttachment = selectedSubtask.attachment || []

      // Find the file in the attachment array and mark it as rejected
      let updatedAttachment = []

      if (typeof currentAttachment === "string") {
        try {
          updatedAttachment = JSON.parse(currentAttachment)
        } catch (e) {
          updatedAttachment = []
        }
      } else if (Array.isArray(currentAttachment)) {
        updatedAttachment = [...currentAttachment]
      } else if (typeof currentAttachment === "object") {
        updatedAttachment = [currentAttachment]
      }

      // Find and update the rejected file
      updatedAttachment = updatedAttachment.map((file) => {
        if (
          (file.name === fileToReject.name && file.url === fileToReject.url) ||
          (file.filename === fileToReject.filename && file.file_url === fileToReject.file_url)
        ) {
          return {
            ...file,
            rejected: true,
            rejectionReason,
            rejectedAt: new Date().toISOString(),
            rejectedBy: supervisorId, // Use dynamic supervisor ID
          }
        }
        return file
      })

      // Update the subtask with the modified attachment
      const { error } = await supabase
        .from("sub_task")
        .update({ attachment: updatedAttachment })
        .eq("sub_task_id", selectedSubtask.sub_task_id)

      if (error) throw error

      // Show success message
      setSuccessMessage("File rejected successfully. Student will be notified.")
      setTimeout(() => setSuccessMessage(null), 3000)

      // Reset rejection form
      setRejectionReason("")
      setFileToReject(null)
      setShowRejectionModal(false)

      // Refresh data
      await fetchGroupAndSubtasks(actualGroupId)
    } catch (err) {
      console.error("Error rejecting file:", err)
      setError(`Failed to reject file: ${err.message}`)
    } finally {
      setRejectingFile(false)
    }
  }

  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-50 text-red-700 border-red-200"
      case "medium":
        return "bg-yellow-50 text-yellow-700 border-yellow-200"
      case "low":
        return "bg-blue-50 text-blue-700 border-blue-200"
      default:
        return "bg-gray-50 text-gray-700 border-gray-200"
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "Done":
        return "bg-green-100 text-green-800"
      case "On Progress":
        return "bg-yellow-100 text-yellow-800"
      case "To Do":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Show loading state while authentication is in progress
  if (authLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        <p className="ml-3 text-blue-500">Authenticating...</p>
      </div>
    )
  }

  // Show error if user is not authenticated
  if (!user && !authLoading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-red-50">
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Authentication Required</h2>
          <p className="text-gray-700 mb-6">You must be logged in to view this page.</p>
          <Link href="/auth" passHref>
            <button className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors">
              Go to Login
            </button>
          </Link>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  const filteredSubtasks = getFilteredSubtasks()

  const renderFileAttachments = (files) => {
    if (!files || files.length === 0) return null

    // Sort files to show newest first and highlight new files
    const sortedFiles = [...files].sort((a, b) => {
      // If a file has uploadedAt, use it for sorting
      const aTime = a.uploadedAt ? new Date(a.uploadedAt).getTime() : 0
      const bTime = b.uploadedAt ? new Date(b.uploadedAt).getTime() : 0
      return bTime - aTime // Newest first
    })

    return (
      <div className="mt-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Attached Files</h4>
        <div className="space-y-2">
          {sortedFiles.map((file, index) => {
            // Extract file information from the attachment object
            const fileName = file.name || file.filename || `File ${index + 1}`
            const fileUrl = file.url || file.file_url
            const fileDescription = file.description
            const isRejected = file.rejected === true
            const rejectionReason = file.rejectionReason

            // Check if this is a new file (uploaded after a rejection)
            const isNewFile = file.isNewVersion || file.uploadedAfterRejection

            // Check if file was uploaded recently (within last 24 hours)
            const isRecentlyUploaded =
              file.uploadedAt && new Date().getTime() - new Date(file.uploadedAt).getTime() < 24 * 60 * 60 * 1000

            // Check if file is new and hasn't been viewed yet
            const fileId = file.id || file.name
            const storedViewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
            const isNewAndUnviewed = isFileNewAndUnviewed(file) && !storedViewedFiles[fileId]

            return (
              <div
                key={index}
                className={`flex flex-col p-3 rounded border ${
                  isRejected
                    ? "bg-red-50 border-red-200"
                    : isNewFile || isRecentlyUploaded
                      ? "bg-green-50 border-green-200"
                      : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <div className="relative mr-2">
                        <div
                          className="cursor-pointer"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleFileViewed(selectedSubtask.sub_task_id, fileId)
                          }}
                        >
                          <File className="w-4 h-4 text-gray-500" />
                          {isNewAndUnviewed && (
                            <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></div>
                          )}
                        </div>
                      </div>
                      <p className="text-sm font-medium text-gray-800">{fileName}</p>
                      {(isNewFile || isRecentlyUploaded) && (
                        <span className="ml-2 px-2 py-0.5 text-xs bg-green-100 text-green-800 rounded-full font-medium">
                          New
                        </span>
                      )}
                      {isRejected && (
                        <span className="ml-2 px-2 py-0.5 text-xs bg-red-100 text-red-800 rounded-full font-medium">
                          Rejected
                        </span>
                      )}
                    </div>
                    {fileDescription && <p className="text-xs text-gray-500 mt-1">{fileDescription}</p>}
                    {file.uploadedAt && (
                      <p className="text-xs text-gray-500 mt-1">
                        Uploaded: {new Date(file.uploadedAt).toLocaleString()}
                      </p>
                    )}
                  </div>
                  <div className="flex space-x-2">
                    {fileUrl ? (
                      <a
                        href={fileUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1 text-xs bg-blue-50 text-blue-700 rounded-full hover:bg-blue-100"
                        onClick={() => handleFileViewed(selectedSubtask.sub_task_id, fileId)}
                      >
                        View File
                      </a>
                    ) : (
                      <span className="px-3 py-1 text-xs bg-gray-100 text-gray-500 rounded-full">No URL</span>
                    )}
                  </div>
                </div>

                {isRejected && rejectionReason && (
                  <div className="mt-2 text-xs text-red-700 bg-red-50 p-2 rounded">
                    <span className="font-medium">Rejection reason:</span> {rejectionReason}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href={`/groups/${entranceId}`} passHref>
                <button className="mr-4 text-gray-600 hover:text-gray-900">
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </Link>
              <h1 className="text-3xl font-bold text-gray-900">{group?.groupname || "Group"} Feedback</h1>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={handleFilterToggle}
                className={`px-4 py-2 border text-sm font-medium rounded-md ${
                  showFilters || statusFilter !== "All"
                    ? "bg-indigo-100 text-indigo-700 border-indigo-300"
                    : "text-gray-700 border-gray-300 bg-white hover:bg-gray-50"
                }`}
              >
                <Filter className="w-5 h-5 mr-2 inline-block" />
                Filter
                {statusFilter !== "All" && (
                  <span className="ml-1 px-1.5 py-0.5 bg-indigo-200 text-indigo-800 rounded-full text-xs">1</span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border-l-4 border-red-400 p-4 text-red-700">
            <p>{error}</p>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 bg-green-50 border-l-4 border-green-400 p-4 text-green-700">
            <p>{successMessage}</p>
          </div>
        )}

        {/* Search and Filter Bar */}
        <div className="mb-6">
          <div className="relative w-full mb-4">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="w-5 h-5 text-gray-500" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white border border-gray-300 text-gray-700 text-sm rounded-lg block w-full pl-10 p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              placeholder="Search subtasks..."
            />
          </div>

          {showFilters && (
            <div className="bg-white p-4 rounded-lg shadow mb-6 border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Filter Subtasks</h3>
                <button onClick={handleFilterToggle} className="text-gray-500 hover:text-gray-700">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Status</h4>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => handleStatusFilterChange("All")}
                    className={`px-3 py-1.5 text-sm rounded-md ${
                      statusFilter === "All"
                        ? "bg-indigo-100 text-indigo-800 border border-indigo-200"
                        : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                    }`}
                  >
                    All ({subtasks.length})
                  </button>
                  <button
                    onClick={() => handleStatusFilterChange("To Do")}
                    className={`px-3 py-1.5 text-sm rounded-md ${
                      statusFilter === "To Do"
                        ? "bg-blue-100 text-blue-800 border border-blue-200"
                        : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                    }`}
                  >
                    To Do ({subtasks.filter((s) => s.status === "To Do").length})
                  </button>
                  <button
                    onClick={() => handleStatusFilterChange("On Progress")}
                    className={`px-3 py-1.5 text-sm rounded-md ${
                      statusFilter === "On Progress"
                        ? "bg-yellow-100 text-yellow-800 border border-yellow-200"
                        : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                    }`}
                  >
                    On Progress ({subtasks.filter((s) => s.status === "On Progress").length})
                  </button>
                  <button
                    onClick={() => handleStatusFilterChange("Done")}
                    className={`px-3 py-1.5 text-sm rounded-md ${
                      statusFilter === "Done"
                        ? "bg-green-100 text-green-800 border border-green-200"
                        : "bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200"
                    }`}
                  >
                    Done ({subtasks.filter((s) => s.status === "Done").length})
                  </button>
                </div>
              </div>

              {statusFilter !== "All" && (
                <div className="flex justify-end">
                  <button onClick={clearFilters} className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900">
                    Clear filters
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Subtasks List */}
          <div className="md:col-span-1 bg-white rounded-lg shadow overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-medium text-gray-900">Subtasks</h2>
              <p className="text-sm text-gray-500">Select a subtask to provide feedback</p>
            </div>

            <div className="overflow-y-auto max-h-[calc(100vh-300px)]">
              {filteredSubtasks.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  {subtasks.length === 0 ? "No subtasks found" : "No subtasks match your filters"}
                </div>
              ) : (
                <ul className="divide-y divide-gray-200">
                  {filteredSubtasks.map((subtask) => (
                    <li
                      key={subtask.sub_task_id}
                      className={`hover:bg-gray-50 cursor-pointer ${
                        selectedSubtask?.sub_task_id === subtask.sub_task_id
                          ? "bg-blue-50"
                          : subtask.hasNewFiles
                            ? "bg-green-50 border-l-4 border-green-500"
                            : ""
                      }`}
                      onClick={() => handleSelectSubtask(subtask)}
                    >
                      <div className="p-4">
                        <div className="flex justify-between items-start mb-1">
                          <h3 className="text-sm font-medium text-gray-900">{subtask.subTaskName}</h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${getPriorityColor(subtask.priority)}`}>
                            {subtask.priority}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 mb-2">
                          Task: {tasks[subtask.main_task]?.taskname || "Unknown Task"}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(subtask.status)}`}>
                            {subtask.status}
                          </span>
                          {subtask.files && subtask.files.length > 0 && (
                            <div className="flex items-center text-xs">
                              <div className="relative mr-1">
                                <File className="w-3 h-3 text-gray-500" />
                                {subtask.hasNewFiles && (
                                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></div>
                                )}
                              </div>
                              <span className="text-gray-500">
                                {subtask.files.length} file{subtask.files.length !== 1 ? "s" : ""}
                              </span>
                              {subtask.hasNewFiles && (
                                <span className="ml-1 px-1.5 py-0.5 text-xs bg-green-100 text-green-800 rounded-full font-medium">
                                  NEW
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Feedback Form */}
          <div className="md:col-span-2 bg-white rounded-lg shadow">
            {selectedSubtask ? (
              <div className="p-6">
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">{selectedSubtask.subTaskName}</h2>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${getPriorityColor(selectedSubtask.priority)}`}>
                      {selectedSubtask.priority}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(selectedSubtask.status)}`}>
                      {selectedSubtask.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">
                    <span className="font-medium">Task:</span>{" "}
                    {tasks[selectedSubtask.main_task]?.taskname || "Unknown Task"}
                  </p>
                  {tasks[selectedSubtask.main_task]?.taskdescription && (
                    <p className="text-sm text-gray-600 mb-4">
                      <span className="font-medium">Task Description:</span>{" "}
                      {tasks[selectedSubtask.main_task]?.taskdescription}
                    </p>
                  )}

                  {/* Add file attachments display here */}
                  {renderFileAttachments(selectedSubtask.files)}
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Provide Feedback</h3>

                  <div className="mb-6">
                    <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
                      Comments
                    </label>
                    <textarea
                      id="comment"
                      rows={5}
                      value={feedback.comment}
                      onChange={handleCommentChange}
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Provide detailed feedback on this subtask..."
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={handleSubmitFeedback}
                      disabled={savingFeedback || !supervisorId}
                      className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                    >
                      {savingFeedback ? (
                        <>
                          <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 mr-2" />
                          Save Feedback
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {selectedSubtask.feedback && selectedSubtask.feedback.length > 0 && (
                  <div className="mt-8 pt-6 border-t border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Previous Feedback</h3>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center mb-2">
                        <span className="text-xs text-gray-500">From: Supervisor</span>
                        <span className="ml-auto text-xs text-gray-500">
                          {selectedSubtask.feedback[0].updated_at
                            ? `Last updated: ${new Date(selectedSubtask.feedback[0].updated_at).toLocaleDateString()}`
                            : ""}
                        </span>
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">
                        {selectedSubtask.feedback[0].comment || "No comments provided."}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full p-10 text-center">
                <MessageSquare className="w-16 h-16 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Subtask</h3>
                <p className="text-gray-500 max-w-md">
                  Choose a subtask from the list to provide feedback. Your feedback helps students improve their work.
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
      {/* Add the rejection modal at the end of the return statement, just before the closing </div> of the main container */}
      {showRejectionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="text-xl font-semibold text-gray-800">Reject File</h2>
              <button
                onClick={() => {
                  setShowRejectionModal(false)
                  setFileToReject(null)
                  setRejectionReason("")
                }}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4">
              <p className="mb-4 text-sm text-gray-600">
                Please provide a reason for rejecting this file. The student will be notified and can upload a new
                version.
              </p>

              <div className="mb-4">
                <label htmlFor="rejectionReason" className="block text-sm font-medium text-gray-700 mb-2">
                  Rejection Reason
                </label>
                <textarea
                  id="rejectionReason"
                  rows={3}
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Explain why this file is being rejected..."
                  required
                />
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowRejectionModal(false)
                    setFileToReject(null)
                    setRejectionReason("")
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={submitFileRejection}
                  disabled={rejectingFile || !rejectionReason.trim() || !supervisorId}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 disabled:opacity-50"
                >
                  {rejectingFile ? (
                    <>
                      <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full inline-block"></div>
                      Rejecting...
                    </>
                  ) : (
                    "Reject File"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
