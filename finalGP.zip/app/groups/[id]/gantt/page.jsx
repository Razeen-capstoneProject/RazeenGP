"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { supabase } from "@/lib/supabase"
import GanttChart from "@/app/instructorComponents/gantt-chart"

export default function GanttChartPage() {
  const router = useRouter()
  const params = useParams()
  const entranceId = params.id
  const [actualGroupId, setActualGroupId] = useState(null)
  const [group, setGroup] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchGroupData = async () => {
      try {
        setLoading(true)
        // First fetch the actual group ID using entrance_id
        const { data, error } = await supabase
          .from("projectgroup")
          .select("groupid, groupname")
          .eq("enterance_id", entranceId)
          .single()

        if (error) throw error

        setActualGroupId(data.groupid)
        setGroup(data)
        setLoading(false)
      } catch (err) {
        console.error("Error fetching group:", err)
        setError("Failed to load group data")
        setLoading(false)
      }
    }

    if (entranceId) {
      fetchGroupData()
    }
  }, [entranceId])

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center">
            <Link href={`/groups/${entranceId}`} passHref>
              <div className="mr-4 text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100 cursor-pointer">
                <ChevronLeft className="w-5 h-5" />
              </div>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
              {group?.groupname || "Group"} Gantt Chart
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error ? (
          <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-400 dark:border-red-700 p-4 mb-6">
            <div className="flex">
              <div className="ml-3">
                <p className="text-sm text-red-700 dark:text-red-400">{error}</p>
              </div>
            </div>
          </div>
        ) : (
          <GanttChart groupId={actualGroupId} />
        )}
      </main>
    </div>
  )
}
