"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { validatePassword } from "@/utils/supabase/password-utils"
import { checkUserExists, createUser } from "@/utils/supabase/signup-service"

export default function SignupPage() {
  const [email, setEmail] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [passwordValidation, setPasswordValidation] = useState({
    isValid: false,
    requirements: {
      uppercase: false,
      lowercase: false,
      number: false,
      special: false,
      length: false,
    },
  })
  const [emailExists, setEmailExists] = useState(false)
  const [usernameExists, setUsernameExists] = useState(false)
  const [signingUp, setSigningUp] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  // Validate password on change
  useEffect(() => {
    if (password) {
      setPasswordValidation(validatePassword(password))
    } else {
      setPasswordValidation({
        isValid: false,
        requirements: {
          uppercase: false,
          lowercase: false,
          number: false,
          special: false,
          length: false,
        },
      })
    }
  }, [password])

  // Check if email or username exists when they change
  useEffect(() => {
    const checkEmailExistence = async () => {
      if (email.trim()) {
        const { emailExists, error } = await checkUserExists(email, username)

        if (error) {
          setError(error)
          return
        }

        setEmailExists(emailExists)
      }
    }

    // Debounce the check to avoid too many requests
    const timer = setTimeout(checkEmailExistence, 200)
    return () => clearTimeout(timer)
  }, [email, username])

  useEffect(() => {
    const checkUsernameExistence = async () => {
      if (username.trim()) {
        const { usernameExists, error } = await checkUserExists(email, username)

        if (error) {
          setError(error)
          return
        }

        setUsernameExists(usernameExists)
      }
    }

    // Debounce the check to avoid too many requests
    const timer = setTimeout(checkUsernameExistence, 200)
    return () => clearTimeout(timer)
  }, [username, email])

  const handleSubmit = async (e) => {
    e.preventDefault()

    // Prevent multiple submissions
    if (signingUp) return

    // Validate form
    if (!email || !username || !password) {
      setError("All fields are required")
      return
    }

    if (!passwordValidation.isValid) {
      setError("Password does not meet all requirements")
      return
    }

    if (emailExists) {
      setError("Email already exists")
      return
    }

    if (usernameExists) {
      setError("Username already exists")
      return
    }

    setSigningUp(true)
    setError("")

    try {
      const { success, error, warning } = await createUser(email, username, password)

      if (error) {
        setError(error)
        setSigningUp(false)
        return
      }

      if (warning) {
        // Show warning but still consider signup successful
        setError(warning)
      }

      if (success) {
        setSuccess(true)
        // Redirect to login page after 2 seconds
        setTimeout(() => {
          router.push("/auth")
        }, 2000)
      }
    } catch (err) {
      console.error("Signup error:", err)
      setError(err.message || "An unexpected error occurred")
      setSigningUp(false)
    }
  }

  const isFormValid = email && username && password && passwordValidation.isValid && !emailExists && !usernameExists

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white">
      <div className="w-full max-w-md p-6">
        <div className="flex justify-center mb-8">
          <Image src="/images/razeen-logo.png" alt="Razeen Logo" width={180} height={120} />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">Create your account</h2>

        {success ? (
          <div className="p-4 bg-green-100 text-green-800 rounded-md mb-4 text-center">
            <p className="font-medium mb-2">Account created successfully!</p>
            <p className="text-sm">Please check your email to verify your account.</p>
            <p className="text-sm mt-2">Redirecting to login page...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="email" className="block mb-2 text-base font-medium text-gray-700">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={signingUp}
                className={`w-full px-3 py-3 border ${
                  emailExists ? "border-red-500" : "border-gray-300"
                } rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500`}
              />
              {emailExists && <p className="mt-1 text-sm text-red-600">This email is already registered</p>}
            </div>

            <div className="mb-6">
              <label htmlFor="username" className="block mb-2 text-base font-medium text-gray-700">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={signingUp}
                className={`w-full px-3 py-3 border ${
                  usernameExists ? "border-red-500" : "border-gray-300"
                } rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500`}
              />
              {usernameExists && <p className="mt-1 text-sm text-red-600">This username is already taken</p>}
            </div>

            <div className="mb-6">
              <label htmlFor="password" className="block mb-2 text-base font-medium text-gray-700">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={signingUp}
                className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
              />

              <div className="mt-4 space-y-2">
                <div className="flex items-center">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center ${
                      passwordValidation.requirements.uppercase ? "bg-green-100 text-green-500" : "bg-gray-200"
                    }`}
                  >
                    {passwordValidation.requirements.uppercase && "✓"}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">One uppercase letter</span>
                </div>
                <div className="flex items-center">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center ${
                      passwordValidation.requirements.lowercase ? "bg-green-100 text-green-500" : "bg-gray-200"
                    }`}
                  >
                    {passwordValidation.requirements.lowercase && "✓"}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">One lowercase letter</span>
                </div>
                <div className="flex items-center">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center ${
                      passwordValidation.requirements.number ? "bg-green-100 text-green-500" : "bg-gray-200"
                    }`}
                  >
                    {passwordValidation.requirements.number && "✓"}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">One number</span>
                </div>
                <div className="flex items-center">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center ${
                      passwordValidation.requirements.special ? "bg-green-100 text-green-500" : "bg-gray-200"
                    }`}
                  >
                    {passwordValidation.requirements.special && "✓"}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">One special character</span>
                </div>
                <div className="flex items-center">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center ${
                      passwordValidation.requirements.length ? "bg-green-100 text-green-500" : "bg-gray-200"
                    }`}
                  >
                    {passwordValidation.requirements.length && "✓"}
                  </div>
                  <span className="ml-2 text-sm text-gray-600">At least 6 characters</span>
                </div>
              </div>
            </div>

            {error && <div className="p-3 mb-6 bg-red-100 text-red-800 rounded-md">{error}</div>}

            <button
              type="submit"
              disabled={signingUp || !isFormValid}
              className="w-full py-3 px-4 bg-black text-white border-none rounded-md text-base mb-6 transition-all hover:bg-opacity-90 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {signingUp ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  <span>Creating account...</span>
                </div>
              ) : (
                "Sign up"
              )}
            </button>

            <div className="text-center text-sm">
              Already have an account?{" "}
              <Link href="/auth" className="text-black font-medium hover:underline">
                Sign in
              </Link>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}
