"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { User, Mail, Book, Calendar, Award, Edit, Save, X } from "lucide-react"
import { supabase } from "@/utils/supabase/client"

export default function ProfilePage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [profileData, setProfileData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    userName: "",
    bio: "",
  })

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/auth")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    async function fetchProfileData() {
      if (!user?.user_id) return

      try {
        setLoading(true)
        setError(null)

        // Fetch user data from Supabase
        const { data, error } = await supabase
          .from("users")
          .select("*, student:student_masked(student_id, groupid, grade)")
          .eq("user_id", user.user_id)
          .single()

        if (error) throw error

        // Fetch group data if the user is a student
        let groupData = null
        if (data?.student?.groupid) {
          const { data: group, error: groupError } = await supabase
            .from("projectgroup")
            .select("groupid, groupname")
            .eq("groupid", data.student.groupid)
            .single()

          if (!groupError) {
            groupData = group
          }
        }

        setProfileData({ ...data, group: groupData })
        setFormData({
          userName: data.userName || "",
          bio: data.bio || "",
        })
      } catch (err) {
        console.error("Error fetching profile data:", err)
        setError("Failed to load profile information")
      } finally {
        setLoading(false)
      }
    }

    fetchProfileData()
  }, [user])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSave = async () => {
    try {
      setLoading(true)

      const { error } = await supabase
        .from("users")
        .update({
          userName: formData.userName,
          bio: formData.bio,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", user.user_id)

      if (error) throw error

      // Update local state
      setProfileData((prev) => ({
        ...prev,
        userName: formData.userName,
        bio: formData.bio,
      }))

      setIsEditing(false)
    } catch (err) {
      console.error("Error updating profile:", err)
      setError("Failed to update profile information")
    } finally {
      setLoading(false)
    }
  }

  const handleCancel = () => {
    setFormData({
      userName: profileData?.userName || "",
      bio: profileData?.bio || "",
    })
    setIsEditing(false)
  }

  if (isLoading || loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">My Profile</h1>
          <p className="text-gray-600">View and manage your profile information</p>
        </div>

        {error && <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md text-red-700">{error}</div>}

        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Profile Header */}
          <div className="bg-blue-50 p-6 flex flex-col md:flex-row items-center gap-6 border-b border-gray-200">
            <div className="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-3xl font-bold">
              {profileData?.userName?.[0]?.toUpperCase() || profileData?.email?.[0]?.toUpperCase() || "U"}
            </div>
            <div className="text-center md:text-left">
              <h2 className="text-xl font-bold">{profileData?.userName || "User"}</h2>
              <p className="text-gray-600">{profileData?.email}</p>
              <p className="text-gray-600 mt-1">
                {profileData?.role?.charAt(0).toUpperCase() + profileData?.role?.slice(1) || "Student"}
              </p>
            </div>
            {!isEditing && (
              <button
                onClick={() => setIsEditing(true)}
                className="ml-auto bg-blue-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-blue-700 transition-colors"
              >
                <Edit size={16} />
                Edit Profile
              </button>
            )}
          </div>

          {/* Profile Content */}
          <div className="p-6">
            {isEditing ? (
              <div className="space-y-6">
                <div>
                  <label htmlFor="userName" className="block text-sm font-medium text-gray-700 mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    id="userName"
                    name="userName"
                    value={formData.userName}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">
                    Bio
                  </label>
                  <textarea
                    id="bio"
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex gap-3 justify-end">
                  <button
                    onClick={handleCancel}
                    className="px-4 py-2 border border-gray-300 rounded-md flex items-center gap-2 hover:bg-gray-50 transition-colors"
                  >
                    <X size={16} />
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md flex items-center gap-2 hover:bg-blue-700 transition-colors"
                  >
                    <Save size={16} />
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">About Me</h3>
                  <p className="mt-2 text-gray-600">{profileData?.bio || "No bio information available."}</p>
                </div>

                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-medium mb-4">Account Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3">
                      <User className="text-blue-600 mt-1" size={20} />
                      <div>
                        <p className="text-sm text-gray-500">Full Name</p>
                        <p>
                          {profileData?.first_name && profileData?.last_name
                            ? `${profileData.first_name} ${profileData.last_name}`
                            : "Not provided"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Mail className="text-blue-600 mt-1" size={20} />
                      <div>
                        <p className="text-sm text-gray-500">Email</p>
                        <p>{profileData?.email || "Not provided"}</p>
                      </div>
                    </div>
                    {profileData?.student && (
                      <>
                        <div className="flex items-start gap-3">
                          <Book className="text-blue-600 mt-1" size={20} />
                          <div>
                            <p className="text-sm text-gray-500">Group</p>
                            <p>{profileData?.group?.groupname || "Not assigned to a group"}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <Award className="text-blue-600 mt-1" size={20} />
                          <div>
                            <p className="text-sm text-gray-500">Grade</p>
                            <p>{profileData?.student?.grade || "Not graded yet"}</p>
                          </div>
                        </div>
                      </>
                    )}
                    <div className="flex items-start gap-3">
                      <Calendar className="text-blue-600 mt-1" size={20} />
                      <div>
                        <p className="text-sm text-gray-500">Joined</p>
                        <p>
                          {profileData?.created_at ? new Date(profileData.created_at).toLocaleDateString() : "Unknown"}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
