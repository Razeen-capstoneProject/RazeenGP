"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { VotingCard } from "@/components/meeting/voting-card"
import { getVotingOptions, getStudentVotes } from "@/utils/supabase/voting-service"
import { getCurrentUserGroup } from "@/utils/supabase/queries"
import { Video } from "lucide-react"
import { ScheduledMeetings } from "@/components/meeting/scheduled-meetings"

export default function MeetingPage() {
  const { user } = useAuth()
  const [votingGroups, setVotingGroups] = useState([])
  const [studentVotes, setStudentVotes] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [groupId, setGroupId] = useState(null)
  const [lastUpdated, setLastUpdated] = useState(new Date())

  useEffect(() => {
    async function fetchData() {
      if (!user?.user_id) return

      try {
        setLoading(true)
        setError(null)

        // Get the user's group
        const { groupId: userGroupId, error: groupError } = await getCurrentUserGroup(user.user_id)

        if (groupError || !userGroupId) {
          throw new Error(groupError || "Failed to get user group")
        }

        setGroupId(userGroupId)

        // Get voting options for the group
        const { votingGroups: groups, error: optionsError } = await getVotingOptions(userGroupId)

        if (optionsError) {
          throw new Error(optionsError)
        }

        setVotingGroups(groups)

        // Get student's current votes
        const { studentVotes: votes, error: votesError } = await getStudentVotes(user.user_id)

        if (votesError) {
          throw new Error(votesError)
        }

        setStudentVotes(votes)
        setLastUpdated(new Date())
      } catch (err) {
        console.error("Error fetching meeting data:", err)
        setError(err.message || "Failed to load meeting data")
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // Set up an interval to refresh data every 5 minutes
    const refreshInterval = setInterval(
      () => {
        fetchData()
      },
      5 * 60 * 1000,
    ) // 5 minutes

    return () => clearInterval(refreshInterval)
  }, [user])

  const handleVoteChange = async () => {
    if (!user?.user_id) return

    try {
      // Refresh student votes
      const { studentVotes: votes, error: votesError } = await getStudentVotes(user.user_id)

      if (votesError) {
        throw new Error(votesError)
      }

      setStudentVotes(votes)

      // Refresh voting options to get updated counts and filter expired options
      const { votingGroups: groups, error: optionsError } = await getVotingOptions(groupId)

      if (optionsError) {
        throw new Error(optionsError)
      }

      setVotingGroups(groups)
      setLastUpdated(new Date())
    } catch (err) {
      console.error("Error refreshing votes:", err)
    }
  }

  if (!user) {
    return null // Will be handled by auth redirect in DashboardLayout
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Video className="text-blue-600" />
          <span>Meeting Scheduler</span>
        </h1>
      </div>

      {loading ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 flex justify-center items-center h-64">
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-gray-500">Loading meeting options...</p>
          </div>
        </div>
      ) : error ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="p-4 bg-red-50 text-red-800 rounded-lg flex items-start gap-3">
            <div className="mt-0.5">⚠️</div>
            <div>
              <p className="font-medium">Error Loading Meeting Data</p>
              <p>{error}</p>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-6">
            {/* Voting Card */}
            <VotingCard
              votingGroups={votingGroups}
              studentId={user.user_id}
              studentVotes={studentVotes}
              onVoteChange={handleVoteChange}
            />

            {/* Group Meeting Info */}
            <ScheduledMeetings groupId={groupId} />
          </div>
        </>
      )}
    </DashboardLayout>
  )
}
