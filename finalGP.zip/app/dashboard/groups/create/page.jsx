"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { CreateGroupForm } from "@/components/create-group-form"

export default function CreateGroupPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.push("/auth")
      } else if (user.role !== "instructor") {
        // Redirect non-instructors away from group creation
        router.push("/dashboard")
      }
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return <div>Loading...</div>
  }

  if (user.role !== "instructor") {
    return null // Will redirect via useEffect
  }

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold mb-6">Create New Group</h1>
      <div className="flex justify-center">
        <CreateGroupForm />
      </div>
    </DashboardLayout>
  )
}
