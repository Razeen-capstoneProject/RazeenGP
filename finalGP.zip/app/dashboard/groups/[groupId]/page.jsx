"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { supabase } from "@/utils/supabase/client"

export default function GroupDetailsPage() {
  const { groupId } = useParams()
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [group, setGroup] = useState(null)
  const [students, setStudents] = useState([])
  const [instructor, setInstructor] = useState(null)
  const [chats, setChats] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/auth")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    async function fetchGroupDetails() {
      if (!groupId) return

      try {
        setLoading(true)
        setError(null)

        // Fetch group details
        const { data: groupData, error: groupError } = await supabase
          .from("projectgroup")
          .select("*")
          .eq("groupid", groupId)
          .single()

        if (groupError) {
          setError("Failed to fetch group details")
          setLoading(false)
          return
        }

        setGroup(groupData)

        // Fetch instructor details
        if (groupData.instructor_supervisor_id) {
          const { data: instructorData, error: instructorError } = await supabase
            .from("users")
            .select("*")
            .eq("user_id", groupData.instructor_supervisor_id)
            .single()

          if (!instructorError) {
            setInstructor(instructorData)
          }
        }

        // Fetch students in this group
        const { data: studentsData, error: studentsError } = await supabase
          .from("student_masked")
          .select(`
            student_id,
            users!student_id(user_id, userName, email, role)
          `)
          .eq("groupid", groupId)

        if (!studentsError) {
          const studentsList = studentsData.map((item) => item.users).filter(Boolean)

          setStudents(studentsList)
        }

        // Fetch associated chats
        const { data: chatsData, error: chatsError } = await supabase.from("chat").select("*").eq("group_id", groupId)

        if (!chatsError) {
          setChats(chatsData)
        }
      } catch (err) {
        console.error("Error fetching group details:", err)
        setError("An unexpected error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchGroupDetails()
  }, [groupId])

  if (isLoading || loading) {
    return <div>Loading...</div>
  }

  if (error) {
    return (
      <DashboardLayout>
        <div className="text-red-500">{error}</div>
      </DashboardLayout>
    )
  }

  if (!group) {
    return (
      <DashboardLayout>
        <div>Group not found</div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold mb-6">Group: {group.groupname}</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Group Details */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Group Details</h2>
          <div className="space-y-2">
            <p>
              <span className="font-medium">ID:</span> {group.groupid}
            </p>
            <p>
              <span className="font-medium">Status:</span> {group.group_status}
            </p>
            <p>
              <span className="font-medium">Progress:</span> {group.group_progress}%
            </p>
          </div>
        </div>

        {/* Instructor */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Instructor</h2>
          {instructor ? (
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                <span className="text-purple-600 font-semibold">
                  {instructor.userName?.[0]?.toUpperCase() || instructor.email?.[0]?.toUpperCase() || "I"}
                </span>
              </div>
              <div>
                <p className="font-medium">{instructor.userName}</p>
                <p className="text-sm text-gray-500">{instructor.email}</p>
              </div>
            </div>
          ) : (
            <p className="text-gray-500">No instructor assigned</p>
          )}
        </div>

        {/* Students */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Students</h2>
          {students.length > 0 ? (
            <ul className="space-y-3">
              {students.map((student) => (
                <li key={student.user_id} className="flex items-center">
                  <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                    <span className="text-gray-600 font-semibold">
                      {student.userName?.[0]?.toUpperCase() || student.email?.[0]?.toUpperCase() || "S"}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{student.userName}</p>
                    <p className="text-xs text-gray-500">{student.email}</p>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No students in this group</p>
          )}
        </div>

        {/* Associated Chats */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Associated Chats</h2>
          {chats.length > 0 ? (
            <ul className="space-y-3">
              {chats.map((chat) => (
                <li key={chat.chatid} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">
                      {chat.chatname.includes("supervisor") ? "Instructor & Students Chat" : "Student Group Chat"}
                    </p>
                    {chat.chatname.includes("supervisor") && (
                      <span className="bg-purple-100 text-purple-800 text-xs px-2 py-0.5 rounded-full">
                        Instructor Present
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Chat ID: {chat.chatid}</p>
                  <p className="text-xs text-gray-500">Original name: {chat.chatname}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">No chats associated with this group</p>
          )}

          <div className="mt-4">
            <a href="/dashboard/chat" className="text-blue-500 hover:underline text-sm flex items-center gap-1">
              Go to Chat Interface
            </a>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
