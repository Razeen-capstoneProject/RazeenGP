"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { getSupervisorTasks } from "@/utils/supabase/task-service"
import { isGroupLeader, getLeaderGroupInfo, getCurrentUserGroup } from "@/utils/supabase/user-service"
import { AssignTaskForm } from "@/components/supervisor-tasks/assign-task-form"
import { TaskDescriptionModal } from "@/components/task-description-modal"
import { Search, Filter, Calendar, FileText, UserPlus, Flag, ShieldAlert, CheckCircle } from "lucide-react"
import { ChangeStatusModal } from "@/components/supervisor-tasks/change-status-modal"

export default function SupervisorTasksPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [isLeader, setIsLeader] = useState(false)
  const [groupInfo, setGroupInfo] = useState(null)
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTask, setSelectedTask] = useState(null)
  const [showAssignForm, setShowAssignForm] = useState(false)
  const [showDescriptionModal, setShowDescriptionModal] = useState(false)
  const [userGroupId, setUserGroupId] = useState(null)
  // Add the state for the status change modal
  const [showStatusModal, setShowStatusModal] = useState(false)
  const [taskForStatusChange, setTaskForStatusChange] = useState(null)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/auth")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    async function loadUserData() {
      if (!user?.user_id) return

      try {
        setLoading(true)

        // Check if user is a group leader
        const leaderStatus = await isGroupLeader(user.user_id)
        setIsLeader(leaderStatus)

        let groupId = null

        if (leaderStatus) {
          // Get group information for leaders
          const { group } = await getLeaderGroupInfo(user.user_id)
          setGroupInfo(group)
          if (group) {
            groupId = group.groupid
          }
        } else {
          // For non-leaders, get their current group
          const { groupId: userGroupId, error: groupError } = await getCurrentUserGroup(user.user_id)
          if (!groupError && userGroupId) {
            groupId = userGroupId
            setUserGroupId(userGroupId)
          }
        }

        // Fetch supervisor tasks if we have a group ID
        if (groupId) {
          const { tasks: supervisorTasks, error: tasksError } = await getSupervisorTasks(groupId)
          if (tasksError) {
            throw new Error(tasksError)
          }
          setTasks(supervisorTasks)
        } else {
          setError("No group found for this user")
        }
      } catch (error) {
        console.error("Error loading data:", error)
        setError("Failed to load supervisor tasks")
      } finally {
        setLoading(false)
      }
    }

    loadUserData()
  }, [user])

  const handleViewDescription = (task) => {
    setSelectedTask(task)
    setShowDescriptionModal(true)
  }

  const handleAssignTask = (task) => {
    if (!isLeader) return // Extra safety check
    setSelectedTask(task)
    setShowAssignForm(true)
  }

  const handleAssignSuccess = () => {
    setShowAssignForm(false)
    setSelectedTask(null)
  }

  // Add the handler for opening the status change modal
  const handleChangeStatus = (task) => {
    if (!isLeader) return // Extra safety check
    setTaskForStatusChange(task)
    setShowStatusModal(true)
  }

  // Add the handler for status change success
  const handleStatusChangeSuccess = (taskId, newStatus) => {
    setTasks((prevTasks) => prevTasks.map((task) => (task.taskid === taskId ? { ...task, status: newStatus } : task)))
    setShowStatusModal(false)
    setTaskForStatusChange(null)
  }

  // Filter tasks based on search query
  const filteredTasks = tasks.filter(
    (task) =>
      task.taskname?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.taskdescription?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.milestone?.name?.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Count tasks by status
  const todoCount = tasks.filter((t) => t.status?.toLowerCase() === "to do").length
  const inProgressCount = tasks.filter((t) => t.status?.toLowerCase() === "on progress").length
  const completedCount = tasks.filter((t) => t.status?.toLowerCase() === "done").length

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Get status badge color
  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case "to do":
        return "bg-gray-100 text-gray-800"
      case "on progress":
        return "bg-blue-100 text-blue-800"
      case "done":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (isLoading || loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-64">
          <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold mb-1">Supervisor Tasks</h1>

          {/* Role indicator */}
          {isLeader && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full text-sm bg-blue-100 text-blue-800">
              <ShieldAlert size={16} />
              <span>Group Leader</span>
            </div>
          )}
        </div>

        <p className="text-gray-500 mb-6">
          {isLeader
            ? "View and assign tasks from supervisors to your team members"
            : "View tasks assigned by supervisors to your group"}
        </p>

        {error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
            <p className="font-medium">Error</p>
            <p>{error}</p>
          </div>
        ) : tasks.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-8 text-center">
            <p className="text-gray-500">No supervisor tasks available for your group.</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <div className="flex items-center gap-2 mb-6">
              <UserPlus size={20} className="text-gray-700" />
              <h2 className="text-lg font-semibold">Supervisor Tasks Management</h2>
            </div>

            {/* Search bar */}
            <div className="flex items-center gap-4 mb-6">
              <div className="relative flex-grow">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search size={16} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search tasks by name, description, or milestone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors">
                <Filter size={16} />
                <span>Filters</span>
              </button>
            </div>

            {/* Task count summary */}
            <div className="text-sm text-gray-500 mb-4">
              <span>
                Showing {filteredTasks.length} of {tasks.length} tasks
              </span>
              <div className="flex gap-4 mt-1">
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2 h-2 bg-gray-400 rounded-full"></span>
                  To Do: {todoCount}
                </span>
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2 h-2 bg-blue-400 rounded-full"></span>
                  In Progress: {inProgressCount}
                </span>
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2 h-2 bg-green-400 rounded-full"></span>
                  Completed: {completedCount}
                </span>
              </div>
            </div>

            {/* Tasks table */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Task
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Status
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Priority
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Deadline
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      Milestone
                    </th>
                    {isLeader && (
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Actions
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTasks.map((task) => (
                    <tr key={task.taskid} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-gray-900">{task.taskname}</div>
                        <button
                          onClick={() => handleViewDescription(task)}
                          className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1 mt-1"
                        >
                          <FileText size={12} />
                          <span>View Description</span>
                        </button>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(task.status)}`}
                          >
                            {task.status || "To Do"}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 py-1 inline-flex text-xs leading-5 font-medium rounded-full ${getPriorityColor(
                            task.priority,
                          )}`}
                        >
                          {task.priority || "Medium"}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar size={14} className="mr-1" />
                          {formatDate(task.deadline)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {task.milestone ? (
                          <div className="flex items-center gap-2">
                            <Flag size={14} className="text-purple-500" />
                            <div>
                              <span className="text-sm font-medium text-gray-900">{task.milestone.name}</span>
                            </div>
                          </div>
                        ) : (
                          <span className="text-gray-400 text-sm">No milestone</span>
                        )}
                      </td>
                      {isLeader && (
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleAssignTask(task)}
                              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                            >
                              <UserPlus size={14} />
                              <span>Assign to</span>
                            </button>
                            <button
                              onClick={() => handleChangeStatus(task)}
                              className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
                            >
                              <CheckCircle size={14} />
                              <span>Change Status</span>
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Status Change Modal */}
      {isLeader && showStatusModal && taskForStatusChange && (
        <ChangeStatusModal
          isOpen={showStatusModal}
          onClose={() => setShowStatusModal(false)}
          task={taskForStatusChange}
          onStatusChange={handleStatusChangeSuccess}
        />
      )}

      {/* Task Description Modal */}
      <TaskDescriptionModal
        isOpen={showDescriptionModal}
        onClose={() => setShowDescriptionModal(false)}
        task={
          selectedTask
            ? {
                sub_task_id: selectedTask.taskid,
                subTaskName: selectedTask.taskname,
                description: selectedTask.taskdescription,
                task: { taskname: selectedTask.taskname },
              }
            : null
        }
        groupId={isLeader ? groupInfo?.groupid : userGroupId}
        currentUser={user}
        readOnly={true}
      />

      {/* Assign Task Form - Only shown for leaders */}
      {isLeader && showAssignForm && selectedTask && (
        <AssignTaskForm
          task={selectedTask}
          groupId={groupInfo?.groupid}
          onClose={() => setShowAssignForm(false)}
          onSuccess={handleAssignSuccess}
        />
      )}
    </DashboardLayout>
  )
}
