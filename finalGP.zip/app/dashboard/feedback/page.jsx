"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { FeedbackTaskList } from "@/components/feedback/feedback-task-list"
import { AlertCircle } from "lucide-react"

export default function FeedbackPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [mounted, setMounted] = useState(false)

  // Use useEffect to handle client-side operations
  useEffect(() => {
    setMounted(true)

    if (!isLoading && !user) {
      router.push("/auth")
    } else if (!isLoading) {
      setLoading(false)
    }
  }, [user, isLoading, router])

  // Don't render anything until after client-side hydration
  if (!mounted) {
    return null
  }

  if (isLoading || loading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-64">
          <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      </DashboardLayout>
    )
  }

  if (error) {
    return (
      <DashboardLayout>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <div className="flex items-center gap-2 text-red-600 mb-4">
            <AlertCircle size={20} />
            <h2 className="text-lg font-semibold">Error</h2>
          </div>
          <p className="text-gray-600">{error}</p>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Task Feedback</h1>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6 overflow-auto">
        <FeedbackTaskList userId={user?.user_id} />
      </div>
    </DashboardLayout>
  )
}
