"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { GroupTaskList } from "@/components/group-tasks/group-task-list"
import { CreateSubTaskForm } from "@/components/create-subtask-form"
import { GroupSubTasksModal } from "@/components/group-tasks/group-sub-tasks-modal"
import { isGroupLeader, getLeaderGroupInfo, getCurrentUserGroup } from "@/utils/supabase/user-service"
import { PlusCircle } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { GanttChart } from "@/components/gantt-chart"
import { Roadmap } from "@/components/roadmap"
import { JoinGroupForm } from "@/components/join-group-form"

export default function DashboardPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [isLeader, setIsLeader] = useState(false)
  const [groupInfo, setGroupInfo] = useState(null)
  const [groupId, setGroupId] = useState(null)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [showGroupSubTasksModal, setShowGroupSubTasksModal] = useState(false)
  const [checkingLeader, setCheckingLeader] = useState(true)
  const [hasGroup, setHasGroup] = useState(true)
  const [checkingGroup, setCheckingGroup] = useState(true)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/auth")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    async function checkUserGroup() {
      if (!user?.user_id) {
        console.log("No user ID available:", user)
        setCheckingGroup(false)
        return
      }

      try {
        setCheckingGroup(true)
        console.log("Checking if user has a group:", user.user_id)

        // Get the user's current group
        const { groupId: userGroupId, error } = await getCurrentUserGroup(user.user_id)

        if (error) {
          console.error("Error getting current group:", error)
          setHasGroup(false)
        } else if (userGroupId) {
          console.log("User has group ID:", userGroupId)
          setGroupId(userGroupId)
          setHasGroup(true)
        } else {
          console.log("No group ID found for user")
          setHasGroup(false)
        }
      } catch (error) {
        console.error("Error checking user group:", error)
        setHasGroup(false)
      } finally {
        setCheckingGroup(false)
      }
    }

    checkUserGroup()
  }, [user])

  useEffect(() => {
    async function checkLeaderStatus() {
      if (!user?.user_id) {
        console.log("No user ID available:", user)
        setCheckingLeader(false)
        return
      }

      try {
        setCheckingLeader(true)
        console.log("Checking leader status for user:", user.user_id)

        // Check if user is a group leader
        const leaderStatus = await isGroupLeader(user.user_id)
        setIsLeader(leaderStatus)

        if (leaderStatus) {
          // Get group information
          const { group } = await getLeaderGroupInfo(user.user_id)
          setGroupInfo(group)
          if (group) {
            console.log("Setting group ID from leader info:", group.groupid)
            setGroupId(group.groupid)
            setHasGroup(true)
          }
        }
      } catch (error) {
        console.error("Error checking leader status:", error)
      } finally {
        setCheckingLeader(false)
      }
    }

    checkLeaderStatus()
  }, [user])

  const handleCreateSubTaskSuccess = () => {
    // Refresh the page or update the task list
    router.refresh()
  }

  if (isLoading || checkingLeader || checkingGroup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  // If student doesn't have a group, show join group form
  if (!hasGroup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <JoinGroupForm />
      </div>
    )
  }

  // Determine the components to render in order
  const dashboardComponents = []

  // 1. Group Tasks with Sub-tasks
  if (groupId) {
    dashboardComponents.push(
      <div key="group-tasks" className="mb-6">
        <GroupTaskList groupId={groupId} userId={user.user_id} />
      </div>,
    )
  }

  // 2. Project Roadmap
  dashboardComponents.push(
    <div key="project-roadmap" className="mb-6">
      <Roadmap />
    </div>,
  )

  // 3. Project Timeline
  if (groupId) {
    dashboardComponents.push(
      <div key="project-timeline" className="mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Project Timeline</h2>
          <GanttChart groupId={groupId} />
        </div>
      </div>,
    )
  } else {
    dashboardComponents.push(
      <div key="project-timeline-placeholder" className="mb-6">
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-md">
          <p>You haven't joined a group yet. Please join a group to see your project timeline.</p>
        </div>
      </div>,
    )
  }

  return (
    <DashboardLayout>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>

        {isLeader && (
          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowCreateForm(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              <PlusCircle size={18} />
              <span>Create Sub-Task</span>
            </motion.button>
          </div>
        )}
      </div>

      {/* Render components in the specified order */}
      {dashboardComponents}

      <AnimatePresence>
        {showCreateForm && groupInfo && (
          <CreateSubTaskForm
            groupId={groupInfo.groupid}
            onClose={() => setShowCreateForm(false)}
            onSuccess={handleCreateSubTaskSuccess}
            userId={user.user_id}
          />
        )}
      </AnimatePresence>

      {/* Group Sub-tasks Modal */}
      <GroupSubTasksModal
        isOpen={showGroupSubTasksModal}
        onClose={() => setShowGroupSubTasksModal(false)}
        groupId={groupId}
        user={user}
      />
    </DashboardLayout>
  )
}
