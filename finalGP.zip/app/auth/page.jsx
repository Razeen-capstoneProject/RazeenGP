"use client"

import { useState, useEffect } from "react"
import { signIn, getCurrentUser } from "@/utils/supabase/auth"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"

export default function AuthPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("student")
  const [signingIn, setSigningIn] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  // Check if user is already logged in
  useEffect(() => {
    const user = getCurrentUser()
    if (user) {
      redirectBasedOnRole(user)
    }
  }, [])

  // Direct redirection function
  const redirectBasedOnRole = (user) => {
    if (!user) return

    const userRole = user.role.toLowerCase().trim()
    console.log(`AUTH PAGE: Redirecting user with role "${userRole}"`)

    // Very explicit role checking
    if (userRole === "instructor") {
      console.log("AUTH PAGE: ✓ Redirecting INSTRUCTOR to /home")
      router.push("/home")
    } else if (userRole === "projectcommittee") {
      console.log("AUTH PAGE: ✓ Redirecting COMMITTEE to /committee")
      router.push("/committee")
    } else {
      console.log("AUTH PAGE: ✓ Redirecting STUDENT to /dashboard")
      router.push("/dashboard")
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSigningIn(true)
    setError("")

    try {
      console.log(`AUTH PAGE: Login attempt as ${role} with email ${email}`)
      const { user, error: signInError } = await signIn(email, password, role)

      if (signInError) {
        console.error("Sign in error:", signInError)
        setError(signInError)
        setSigningIn(false)
        return
      }

      if (!user) {
        setError("Failed to sign in. Please try again.")
        setSigningIn(false)
        return
      }

      console.log(`AUTH PAGE: Login successful for user with role "${user.role}"`)

      // Direct redirection based on role
      redirectBasedOnRole(user)
    } catch (err) {
      console.error("Login error:", err)
      setError(err.message || "An unexpected error occurred")
      setSigningIn(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="w-full max-w-md p-6">
        <div className="flex justify-center mb-8">
          <Image src="/images/razeen-logo.png" alt="Razeen Logo" width={180} height={120} />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">Log In</h2>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="email" className="block mb-2 text-base font-medium text-gray-700">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={signingIn}
              className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
            />
          </div>

          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="password" className="block text-base font-medium text-gray-700">
                Password
              </label>
              <Link href="/forgot-password" className="text-sm text-gray-600 hover:underline">
                Forgot your password?
              </Link>
            </div>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={signingIn}
              className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
              placeholder="Enter your password"
            />
          </div>

          <div className="mb-6">
            <label htmlFor="role" className="block mb-2 text-base font-medium text-gray-700">
              Role
            </label>
            <select
              id="role"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              disabled={signingIn}
              className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
            >
              <option value="student">Student</option>
              <option value="instructor">Instructor</option>
              <option value="projectcommittee">Project Committee</option>
            </select>
          </div>

          {error && <div className="p-3 mb-6 bg-red-100 text-red-800 rounded-md">{error}</div>}

          <button
            type="submit"
            disabled={signingIn}
            className="w-full py-3 px-4 bg-black text-white border-none rounded-md text-base mb-6 transition-opacity disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {signingIn ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                <span>Signing in...</span>
              </div>
            ) : (
              "Log In"
            )}
          </button>
        </form>
        <p className="text-center text-sm">
          Don&apos;t have an account?{" "}
          <Link href="/signup" className="text-black font-medium hover:underline">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  )
}
