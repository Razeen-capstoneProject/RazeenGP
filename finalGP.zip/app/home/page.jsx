"use client"

import React from "react"

import { useState, useEffect, useRef, useMemo, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Calendar, ChevronDown, Plus, MoreHorizontal, Info, Loader2 } from "lucide-react"
import { fetchProjects, fetchSupervisor } from "@/lib/data"
import { testConnection } from "@/lib/supabase"
import CreateGroupModal from "../instructorComponents/create-group-modal"
import GroupInfoModal from "../instructorComponents/group-info-modal"
import Sidebar from "../instructorComponents/sidebar"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"

// Skeleton loader for project cards
const ProjectCardSkeleton = () => (
  <div className="bg-white rounded-xl p-5 shadow-md border border-gray-100 animate-pulse">
    <div className="flex justify-between items-center mb-4">
      <div className="flex items-center">
        <div className="w-5 h-5 bg-gray-200 rounded mr-2"></div>
        <div className="h-4 bg-gray-200 rounded w-32"></div>
      </div>
      <div className="h-6 bg-gray-200 rounded w-16"></div>
    </div>
    <div className="mb-4">
      <div className="flex justify-between text-xs mb-1">
        <div className="h-3 bg-gray-200 rounded w-20"></div>
        <div className="h-3 bg-gray-200 rounded w-8"></div>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div className="bg-gray-300 h-2 rounded-full w-1/3"></div>
      </div>
    </div>
    <div className="space-y-3">
      {[1, 2].map((i) => (
        <div key={i} className="flex items-center">
          <div className="w-7 h-7 bg-gray-200 rounded-full mr-2"></div>
          <div className="flex-1">
            <div className="h-3 bg-gray-200 rounded w-24 mb-1"></div>
            <div className="h-2 bg-gray-200 rounded w-16"></div>
          </div>
        </div>
      ))}
    </div>
  </div>
)

export default function Dashboard() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth() // Get authenticated user from context
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [connectionStatus, setConnectionStatus] = useState(null)
  const [supervisor, setSupervisor] = useState(null)
  const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false)
  const dataFetchedRef = useRef(false)

  // Extract user ID from auth context - check multiple possible properties
  const userId = useMemo(() => {
    if (user?.id) return user.id
    if (user?.user_id) return user.user_id
    return null
  }, [user])

  // Log user information for debugging
  useEffect(() => {
    if (!authLoading) {
      if (user) {
        console.log("Authenticated user:", {
          id: user.id,
          user_id: user.user_id,
          username: user.username,
          role: user.role,
        })
      } else {
        console.log("No authenticated user")
      }
    }
  }, [user, authLoading])

  // Optimized batch fetching of projects with entrance IDs
  const fetchProjectsWithEntranceIds = useCallback(async (supervisorId) => {
    if (!supervisorId) return []

    try {
      // Fetch projects for the supervisor
      const projectsData = await fetchProjects(supervisorId)

      if (!projectsData || projectsData.length === 0) {
        return []
      }

      // Extract all project IDs for batch query
      const projectIds = projectsData.map((project) => project.id)

      // Batch fetch entrance IDs for all projects
      const { data: entranceData, error: entranceError } = await supabase
        .from("projectgroup")
        .select("groupid, enterance_id")
        .in("groupid", projectIds)

      if (entranceError) {
        console.error("Error fetching entrance IDs:", entranceError)
        // Continue with projects without entrance IDs
        return projectsData
      }

      // Create a lookup map for quick access
      const entranceMap = {}
      entranceData?.forEach((item) => {
        entranceMap[item.groupid] = item.enterance_id
      })

      // Merge entrance IDs with project data
      return projectsData.map((project) => ({
        ...project,
        entranceId: entranceMap[project.id] || project.id, // Fallback to project.id if no entrance ID
      }))
    } catch (error) {
      console.error("Error in fetchProjectsWithEntranceIds:", error)
      throw error
    }
  }, [])

  // Load supervisor data and projects in parallel
  const loadSupervisorAndProjects = useCallback(async () => {
    if (!userId) {
      setError("User not authenticated")
      setLoading(false)
      return
    }

    setLoading(true)

    try {
      // Fetch connection status, supervisor data, and projects in parallel
      const [connectionResult, supervisorData] = await Promise.all([testConnection(), fetchSupervisor(userId)])

      setConnectionStatus(connectionResult)

      if (!connectionResult.success) {
        setError("Failed to connect to Supabase")
        return
      }

      // Merge supervisor data with user data from auth context for completeness
      const mergedSupervisorData = {
        ...supervisorData,
        username: supervisorData?.username || user?.username || "Instructor",
        role: supervisorData?.role || user?.role || "Supervisor",
        user_id: supervisorData?.user_id || userId,
      }

      setSupervisor(mergedSupervisorData)
      console.log("Supervisor data loaded:", mergedSupervisorData)

      // Fetch projects with entrance IDs
      const projectsWithIds = await fetchProjectsWithEntranceIds(userId)
      setProjects(projectsWithIds)
    } catch (error) {
      console.error("Error loading supervisor and projects:", error)
      setError("Failed to load data. Please try again.")
    } finally {
      setLoading(false)
    }
  }, [userId, user, fetchProjectsWithEntranceIds])

  // Effect to load data when user is authenticated
  useEffect(() => {
    // Skip if still loading auth or if we've already fetched data
    if (authLoading || dataFetchedRef.current) return

    // If user is authenticated, load data
    if (userId) {
      dataFetchedRef.current = true
      loadSupervisorAndProjects()
    }
    // If auth is done loading and no user, set error
    else if (!authLoading) {
      setError("User not authenticated. Please log in.")
      setLoading(false)
    }
  }, [userId, authLoading, loadSupervisorAndProjects])

  // Helper function to get initials from name
  const getInitials = useCallback((name) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }, [])

  // Handle click on a project card
  const handleProjectClick = useCallback(
    (project) => {
      // Use entrance_id for navigation if available
      const idToUse = project.entranceId || project.id
      router.push(`/groups/${idToUse}`)
    },
    [router],
  )

  // Handle group creation
  const handleGroupCreated = useCallback(
    (newGroup) => {
      // Refresh the projects list after a new group is created
      if (userId) {
        dataFetchedRef.current = false // Reset to trigger a refetch
        loadSupervisorAndProjects()
      }
    },
    [userId, loadSupervisorAndProjects],
  )

  // Handle group deletion
  const handleGroupDeleted = useCallback((groupId) => {
    // Remove the deleted group from the projects list
    setProjects((projects) => projects.filter((project) => project.id !== groupId))
  }, [])

  // Handle group update
  const handleGroupUpdated = useCallback((updatedGroup) => {
    // Update the projects list with the updated group
    setProjects((projects) =>
      projects.map((project) =>
        project.id === updatedGroup.id
          ? {
              ...project,
              title: updatedGroup.title,
              status: updatedGroup.status,
              members: updatedGroup.members || project.members,
            }
          : project,
      ),
    )
  }, [])

  // Determine if we should show loading state
  const isLoadingState = authLoading || loading

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white p-4 border-b border-gray-200 flex justify-between items-center shadow-sm">
          <div></div> {/* Empty div to maintain flex layout */}
          <div className="flex items-center space-x-4">
            {/* Calendar icon button */}
            <button
              onClick={() => router.push("/meetings?view=calendar")}
              className="text-gray-600 hover:bg-gray-100 p-2 rounded-full transition-all"
            >
              <Calendar className="w-5 h-5" />
            </button>

            {/* User profile section */}
            {isLoadingState ? (
              <div className="flex items-center ml-4">
                <div className="mr-3 text-right">
                  <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                </div>
              </div>
            ) : user ? (
              <div className="flex items-center ml-4">
                <div className="mr-3 text-right">
                  <div className="font-medium">{supervisor?.userName || user.userName}</div>
                  <div className="text-sm text-gray-500">{supervisor?.role || user.role}</div>
                </div>
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                    <span>{getInitials(supervisor?.userName || user?.userName)}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 absolute -right-4 top-3 text-gray-600" />
                </div>
              </div>
            ) : (
              <button
                onClick={() => router.push("/auth")}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Log In
              </button>
            )}
          </div>
        </header>

        {/* Main Content */}
        <main className="p-6">
          {/* Connection Status Messages */}
          {connectionStatus && !connectionStatus.success && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              <p className="font-bold">Connection Error</p>
              <p>Failed to connect to Supabase. Please check your credentials.</p>
              <p className="text-sm mt-2">Error details: {connectionStatus.error?.message || "Unknown error"}</p>
            </div>
          )}

          {connectionStatus && connectionStatus.success && !connectionStatus.tablesExist && (
            <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">
              <p className="font-bold">Database Tables Not Found</p>
              <p>Successfully connected to Supabase, but the required database tables are not set up yet.</p>
              <p>Please run the SQL setup script below to create the necessary tables.</p>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <p>{error}</p>
              {error.includes("authenticated") && (
                <button
                  onClick={() => router.push("/auth")}
                  className="mt-2 sm:mt-0 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 text-sm"
                >
                  Go to Login
                </button>
              )}
            </div>
          )}

          {/* Loading State or Content */}
          {isLoadingState ? (
            <div className="space-y-6">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                <div className="h-8 bg-gray-200 rounded w-48"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <ProjectCardSkeleton key={i} />
                ))}
              </div>
            </div>
          ) : (
            <>
              {/* Supervisor Section */}
              <div className="mb-10">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                      <div className="w-6 h-6 text-blue-600">👤</div>
                    </div>
                    <h2 className="text-2xl font-semibold text-gray-800">AS SUPERVISOR:</h2>
                  </div>

                  {/* Add Create Group Button */}
                  <button
                    onClick={() => setIsCreateGroupModalOpen(true)}
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Group
                  </button>
                </div>

                {projects.length === 0 ? (
                  <div className="bg-blue-50 text-blue-700 p-6 rounded-lg text-center">
                    <p className="mb-4">No supervisor projects found.</p>
                    <button
                      onClick={() => setIsCreateGroupModalOpen(true)}
                      className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Group
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {projects.map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onClick={() => handleProjectClick(project)}
                        onGroupDeleted={handleGroupDeleted}
                        onGroupUpdated={handleGroupUpdated}
                      />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </main>

        {/* Create Group Modal - Pass the userId explicitly */}
        <CreateGroupModal
          isOpen={isCreateGroupModalOpen}
          onClose={() => setIsCreateGroupModalOpen(false)}
          onGroupCreated={handleGroupCreated}
          instructorId={userId} // Explicitly pass the instructor ID
        />
      </div>
    </div>
  )
}

// Memoized ProjectCard component to prevent unnecessary re-renders
const ProjectCard = React.memo(function ProjectCard({ project, onClick, onGroupDeleted, onGroupUpdated }) {
  const { id, title, progress, members, status } = project
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false)
  const menuRef = useRef(null)
  const [showMenu, setShowMenu] = useState(false)

  // Get color based on status only (not progress)
  const getStatusColor = (status) => {
    switch (status) {
      case "late":
        return "bg-red-500 text-white"
      case "on track":
        return "bg-green-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  // Get progress bar color based on status first, then progress value
  const getProgressBarColor = (status, progress) => {
    // If status is late, always show red progress bar
    if (status === "late") return "bg-red-500"

    // Otherwise, color based on progress
    if (progress < 30) return "bg-red-500"
    if (progress < 70) return "bg-amber-400"
    return "bg-green-500"
  }

  const statusColor = getStatusColor(status)
  const progressBarColor = getProgressBarColor(status, progress)

  // Handle opening the info modal directly
  const handleViewDetails = (e) => {
    e.stopPropagation() // Prevent card click
    setIsInfoModalOpen(true)
    setShowMenu(false)
  }

  // Toggle the menu
  const toggleMenu = (e) => {
    e.stopPropagation() // Prevent card click
    setShowMenu(!showMenu)
  }

  const handleGroupUpdated = (updatedGroup) => {
    if (onGroupUpdated) {
      onGroupUpdated(updatedGroup)
    }
  }

  // Close menu when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(false)
      }
    }

    // Add event listener
    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      // Remove event listener on cleanup
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [menuRef])

  return (
    <>
      <div
        className="bg-white rounded-xl p-5 shadow-md hover:shadow-lg transition-all border border-gray-100 cursor-pointer relative"
        onClick={onClick}
      >
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <div className="w-5 h-5 border border-gray-300 rounded mr-2 flex-shrink-0"></div>
            <h3 className="font-medium text-gray-800">{title}</h3>
          </div>
          <div className="flex items-center">
            <span className={`text-xs px-2 py-1 rounded-full ${statusColor} mr-2 font-medium`}>{status || "late"}</span>

            {/* Three dots menu with improved functionality */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={toggleMenu}
                className="p-1.5 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
                aria-label="View group options"
              >
                <MoreHorizontal className="w-5 h-5 text-gray-500" />
              </button>

              {showMenu && (
                <div className="absolute right-0 mt-1 w-40 bg-white rounded-md shadow-lg overflow-hidden z-50 border border-gray-200">
                  <div className="py-1">
                    <button
                      className="flex items-center w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                      onClick={handleViewDetails}
                    >
                      <Info className="w-4 h-4 mr-2" />
                      View Details
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Progress Bar - Now shows task completion progress */}
        <div className="mb-4">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>Task Completion</span>
            <span>{progress || 0}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={`${progressBarColor} h-2 rounded-full transition-all duration-500`}
              style={{ width: `${progress || 0}%` }}
            ></div>
          </div>
        </div>

        <div className="space-y-3 mb-5">
          {members &&
            members.map((member) => (
              <div key={member.id} className="flex items-center">
                <div className="w-7 h-7 bg-gradient-to-br from-gray-100 to-gray-50 rounded-full flex items-center justify-center mr-2 border border-gray-200">
                  <div className="w-3 h-3 text-gray-600">👤</div>
                </div>
                <div className="flex-1">
                  <span className="text-sm mr-2 text-gray-700">{member.name}</span>
                  <span className="text-xs text-gray-500">{member.role || "Student"}</span>
                </div>
                {member.isLeader && (
                  <span className="text-sm text-gray-500 ml-auto bg-gray-100 px-2 py-0.5 rounded-full">Leader</span>
                )}
              </div>
            ))}
        </div>
      </div>

      {/* Group Info Modal */}
      <GroupInfoModal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
        group={project}
        onGroupUpdated={handleGroupUpdated}
        onGroupDeleted={onGroupDeleted}
      />
    </>
  )
})
