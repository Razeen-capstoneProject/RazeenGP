"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Search, Download, Clock, Users, RefreshCw, CheckCircle } from "lucide-react"
import { fetchAnnouncementsForRole, markAnnouncementAsRead, markAllAnnouncementsAsRead } from "@/lib/announcement-utils"
import { useAuth } from "@/context/auth-context" // Import auth context to check user role

export default function AnnouncementsPage() {
  const [announcements, setAnnouncements] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [lastUpdated, setLastUpdated] = useState(null)
  const { user } = useAuth() // Get the current user to determine role
  const userRole = user?.role || "instructor" // Default to instructor if role not available

  // Determine the correct return path based on user role
  const getReturnPath = () => {
    const role = (userRole || "").toLowerCase()
    if (role === "instructor" || role.includes("instructor") || role === "teacher" || role === "professor") {
      return "/home"
    } else if (role === "projectcommittee" || role.includes("committee")) {
      return "/committee"
    } else {
      return "/dashboard" // Default for students
    }
  }

  useEffect(() => {
    fetchAnnouncements()
  }, [])

  const fetchAnnouncements = async () => {
    try {
      setLoading(true)

      // Fetch announcements for instructors with read status
      const data = await fetchAnnouncementsForRole(userRole)

      // Process the announcements data
      const processedAnnouncements = data.map((announcement) => {
        // Format the created_at date
        const createdAt = new Date(announcement.created_at)
        const timeAgo = getTimeAgo(createdAt)

        // Extract any attachments from the announ_content if they exist
        let attachments = []
        let content = announcement.announ_content

        // Handle if announ_content is in JSONB format
        if (typeof announcement.announ_content === "object") {
          if (announcement.announ_content.attachments) {
            attachments = Array.isArray(announcement.announ_content.attachments)
              ? announcement.announ_content.attachments
              : [announcement.announ_content.attachments]
          }
          content =
            announcement.announ_content.text ||
            announcement.announ_content.content ||
            JSON.stringify(announcement.announ_content)
        } else if (typeof announcement.announ_content === "string") {
          try {
            const parsedContent = JSON.parse(announcement.announ_content)
            if (parsedContent.attachments) {
              attachments = Array.isArray(parsedContent.attachments)
                ? parsedContent.attachments
                : [parsedContent.attachments]
            }
            content = parsedContent.text || parsedContent.content || announcement.announ_content
          } catch (e) {
            // Not JSON, use as is
            content = announcement.announ_content
          }
        }

        return {
          ...announcement,
          formattedDate: timeAgo,
          displayContent: content,
          attachments: attachments,
        }
      })

      setAnnouncements(processedAnnouncements)
      setLastUpdated(new Date())
    } catch (err) {
      console.error("Error fetching announcements:", err)
      setError("Failed to load announcements. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  // Helper function to format time ago
  const getTimeAgo = (date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now - date) / 1000)

    if (diffInSeconds < 60) {
      return "less than a minute ago"
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60)
      return `about ${minutes} ${minutes === 1 ? "minute" : "minutes"} ago`
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600)
      return `about ${hours} ${hours === 1 ? "hour" : "hours"} ago`
    } else {
      const days = Math.floor(diffInSeconds / 86400)
      return `about ${days} ${days === 1 ? "day" : "days"} ago`
    }
  }

  // Handle announcement click - mark as read
  const handleAnnouncementClick = (announcementId) => {
    markAnnouncementAsRead(announcementId, userRole)

    // Update the local state to reflect the read status
    setAnnouncements((prevAnnouncements) =>
      prevAnnouncements.map((announcement) =>
        announcement.announcement_id === announcementId ? { ...announcement, isRead: true } : announcement,
      ),
    )
  }

  // Handle mark all as read
  const handleMarkAllAsRead = async () => {
    const success = await markAllAnnouncementsAsRead(userRole)
    if (success) {
      // Update all announcements in the local state to be marked as read
      setAnnouncements((prevAnnouncements) =>
        prevAnnouncements.map((announcement) => ({ ...announcement, isRead: true })),
      )
    }
  }

  // Filter announcements based on search query
  const filteredAnnouncements = announcements.filter((announcement) =>
    announcement.displayContent.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Check if there are any unread announcements
  const hasUnreadAnnouncements = announcements.some((announcement) => !announcement.isRead)

  // Get the correct return path based on user role
  const returnPath = getReturnPath()

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center">
            {/* Updated Link to use dynamic return path based on user role */}
            <Link href={returnPath} className="mr-4 text-blue-600 hover:text-blue-800">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z"
                  clipRule="evenodd"
                />
              </svg>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Announcements</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 mr-2 text-blue-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"
                  />
                </svg>
                Announcements
              </h2>
              <div className="flex space-x-2">
                {hasUnreadAnnouncements && (
                  <button
                    onClick={handleMarkAllAsRead}
                    className="flex items-center px-3 py-1.5 text-sm bg-blue-50 text-blue-700 rounded-md hover:bg-blue-100"
                    title="Mark all as read"
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Mark all as read
                  </button>
                )}
                <button
                  onClick={fetchAnnouncements}
                  className="p-2 text-gray-500 hover:text-gray-700 rounded-full hover:bg-gray-100"
                  title="Refresh announcements"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="relative mb-6">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                placeholder="Search announcements..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                <button
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setSearchQuery("")}
                >
                  <span className="text-gray-400 hover:text-gray-500">
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </span>
                </button>
              )}
            </div>

            {lastUpdated && (
              <div className="flex items-center text-sm text-gray-500 mb-4">
                <Clock className="w-4 h-4 mr-1" />
                <span>Last updated: {getTimeAgo(lastUpdated)}</span>
                <span className="ml-auto">Showing {filteredAnnouncements.length} announcements</span>
              </div>
            )}

            {loading ? (
              <div className="flex justify-center items-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : error ? (
              <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            ) : filteredAnnouncements.length === 0 ? (
              <div className="text-center py-12">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1}
                    d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                  />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No announcements found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  {searchQuery
                    ? `No announcements match "${searchQuery}"`
                    : "There are no announcements available at this time."}
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {filteredAnnouncements.map((announcement) => (
                  <div
                    key={announcement.announcement_id}
                    className={`bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden cursor-pointer transition-colors ${
                      announcement.isRead ? "bg-gray-50" : "hover:bg-blue-50"
                    }`}
                    onClick={() => handleAnnouncementClick(announcement.announcement_id)}
                  >
                    <div className="p-4 sm:p-6">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <div className="flex-shrink-0">
                            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                              <Users className="h-6 w-6 text-blue-600" />
                            </div>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {announcement.user_name || "System Announcement"}
                            </p>
                            <p className="text-xs text-gray-500">{announcement.formattedDate}</p>
                          </div>
                        </div>
                        <div className="flex items-center">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            {announcement.user_role || "System"}
                          </span>
                          {!announcement.isRead && (
                            <span className="ml-2 inline-flex h-2 w-2 rounded-full bg-red-500"></span>
                          )}
                        </div>
                      </div>
                      <div className="mt-4 text-sm text-gray-700 whitespace-pre-line">
                        {announcement.displayContent}
                      </div>
                      {announcement.attachments && announcement.attachments.length > 0 && (
                        <div className="mt-4 border-t border-gray-200 pt-4">
                          <h4 className="text-sm font-medium text-gray-900 mb-2">Attachments</h4>
                          <div className="space-y-2">
                            {announcement.attachments.map((attachment, index) => (
                              <div key={index} className="flex items-center">
                                <a
                                  href={attachment.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                                  onClick={(e) => e.stopPropagation()} // Prevent triggering the parent onClick
                                >
                                  <Download className="h-4 w-4 mr-1" />
                                  {attachment.name || `Attachment ${index + 1}`}
                                </a>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
