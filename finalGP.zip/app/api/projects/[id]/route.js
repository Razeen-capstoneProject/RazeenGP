import { NextResponse } from "next/server"
import { deleteProject, updateProjectProgress } from "@/lib/data"

// DELETE a project
export async function DELETE(request, { params }) {
  try {
    const id = Number.parseInt(params.id)
    await deleteProject(id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ error: "Failed to delete project" }, { status: 500 })
  }
}

// PATCH to update project progress
export async function PATCH(request, { params }) {
  try {
    const id = Number.parseInt(params.id)
    const body = await request.json()
    const { progress } = body

    if (progress === undefined) {
      return NextResponse.json({ error: "Missing progress field" }, { status: 400 })
    }

    const updatedProject = await updateProjectProgress(id, progress)
    return NextResponse.json(updatedProject)
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ error: "Failed to update project" }, { status: 500 })
  }
}
