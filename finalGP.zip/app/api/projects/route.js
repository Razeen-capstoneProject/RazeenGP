import { NextResponse } from "next/server"
import { fetchProjects, addProject } from "@/lib/data"

// GET all projects
export async function GET() {
  try {
    const projects = await fetchProjects()
    return NextResponse.json(projects)
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}

// POST a new project
export async function POST(request) {
  try {
    const body = await request.json()
    const newProject = await addProject(body)
    return NextResponse.json(newProject, { status: 201 })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}
