import { NextResponse } from "next/server"
import { getOrCreateChatByRole } from "@/lib/chat-utils"

export async function GET(request, { params }) {
  try {
    const chatId = Number(params.id)

    if (isNaN(chatId)) {
      return NextResponse.json({ error: "Invalid chat ID" }, { status: 400 })
    }

    // Determine if this is a supervisor chat (chatId = groupId + 1)
    const isSupervisor = chatId % 2 === 0 // Simple heuristic, adjust as needed
    const groupId = isSupervisor ? chatId - 1 : chatId

    const chat = await getOrCreateChatByRole(groupId, isSupervisor)

    return NextResponse.json(chat)
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ error: "Failed to fetch chat" }, { status: 500 })
  }
}
