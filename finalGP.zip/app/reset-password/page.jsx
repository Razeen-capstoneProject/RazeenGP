"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { supabase } from "@/utils/supabase/client"
import { hashPassword, validatePassword } from "@/utils/supabase/password-utils"

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [token, setToken] = useState("")
  const [passwordValidation, setPasswordValidation] = useState({
    isValid: false,
    requirements: {
      uppercase: false,
      lowercase: false,
      number: false,
      special: false,
      length: false,
    },
  })
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Get token from URL
    const accessToken = searchParams.get("access_token")
    if (accessToken) {
      setToken(accessToken)
    }
  }, [searchParams])

  // Validate password on change - same as signup
  useEffect(() => {
    if (password) {
      setPasswordValidation(validatePassword(password))
    } else {
      setPasswordValidation({
        isValid: false,
        requirements: {
          uppercase: false,
          lowercase: false,
          number: false,
          special: false,
          length: false,
        },
      })
    }
  }, [password])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")

    // Validate password
    if (!passwordValidation.isValid) {
      setError("Password does not meet all requirements")
      return
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match")
      return
    }

    setIsSubmitting(true)

    try {
      // If we don't have a token in preview mode, just simulate success
      if (!token) {
        setTimeout(() => {
          setSuccess(true)
          setIsSubmitting(false)
          // Simulate redirect after 3 seconds
          setTimeout(() => {
            router.push("/auth")
          }, 3000)
        }, 1500)
        return
      }

      // First, get the user email from the token
      const { data: userData, error: userError } = await supabase.auth.getUser(token)

      if (userError || !userData?.user?.email) {
        throw new Error("Invalid or expired token")
      }

      const email = userData.user.email

      // Hash the password - same as signup
      const hashedPassword = hashPassword(password)

      // Update the password in the users table
      const { error: updateError } = await supabase
        .from("users")
        .update({ password: hashedPassword })
        .eq("email", email)

      if (updateError) {
        console.error("Error updating password in users table:", updateError)
        throw new Error("Failed to update password")
      }

      // Also update the password in Supabase Auth
      const { error: authError } = await supabase.auth.updateUser({
        password: password,
      })

      if (authError) {
        console.error("Error updating auth password:", authError)
        // Continue anyway since we updated the custom users table
      }

      // Password updated successfully
      setSuccess(true)

      // Redirect to login page after 3 seconds
      setTimeout(() => {
        router.push("/auth")
      }, 3000)
    } catch (err) {
      console.error("Error resetting password:", err)
      setError(err.message || "Failed to reset password. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="w-full max-w-md p-6">
        <div className="flex justify-center mb-8">
          <Image src="/images/razeen-logo.png" alt="Razeen Logo" width={180} height={120} />
        </div>

        {!token && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-md text-blue-800">
            <p className="text-sm">
              <strong>Design Preview Mode:</strong> You are viewing this page without a reset token. In actual use, this
              page would be accessed via an email link.
            </p>
          </div>
        )}

        <h2 className="text-3xl font-bold text-center mb-4">Reset Password</h2>
        <p className="text-center text-gray-600 mb-8">Please enter your new password below</p>

        {success ? (
          <div className="p-4 bg-green-50 border border-green-200 rounded-md text-green-800 mb-6">
            <p className="font-medium">Password reset successful!</p>
            <p className="text-sm mt-1">You will be redirected to the login page shortly.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label htmlFor="password" className="block mb-2 text-base font-medium text-gray-700">
                New Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isSubmitting}
                className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
                placeholder="Enter your new password"
              />
            </div>

            <div className="mb-6">
              <label htmlFor="confirmPassword" className="block mb-2 text-base font-medium text-gray-700">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                disabled={isSubmitting}
                className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
                placeholder="Confirm your new password"
              />
            </div>

            <div className="mt-4 mb-6 space-y-2">
              <div className="flex items-center">
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center ${
                    passwordValidation.requirements.uppercase ? "bg-green-100 text-green-500" : "bg-gray-200"
                  }`}
                >
                  {passwordValidation.requirements.uppercase && "✓"}
                </div>
                <span className="ml-2 text-sm text-gray-600">One uppercase letter</span>
              </div>
              <div className="flex items-center">
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center ${
                    passwordValidation.requirements.lowercase ? "bg-green-100 text-green-500" : "bg-gray-200"
                  }`}
                >
                  {passwordValidation.requirements.lowercase && "✓"}
                </div>
                <span className="ml-2 text-sm text-gray-600">One lowercase letter</span>
              </div>
              <div className="flex items-center">
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center ${
                    passwordValidation.requirements.number ? "bg-green-100 text-green-500" : "bg-gray-200"
                  }`}
                >
                  {passwordValidation.requirements.number && "✓"}
                </div>
                <span className="ml-2 text-sm text-gray-600">One number</span>
              </div>
              <div className="flex items-center">
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center ${
                    passwordValidation.requirements.special ? "bg-green-100 text-green-500" : "bg-gray-200"
                  }`}
                >
                  {passwordValidation.requirements.special && "✓"}
                </div>
                <span className="ml-2 text-sm text-gray-600">One special character</span>
              </div>
              <div className="flex items-center">
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center ${
                    passwordValidation.requirements.length ? "bg-green-100 text-green-500" : "bg-gray-200"
                  }`}
                >
                  {passwordValidation.requirements.length && "✓"}
                </div>
                <span className="ml-2 text-sm text-gray-600">At least 6 characters</span>
              </div>
            </div>

            {error && <div className="p-3 mb-6 bg-red-100 text-red-800 rounded-md">{error}</div>}

            <button
              type="submit"
              disabled={isSubmitting || !passwordValidation.isValid || password !== confirmPassword}
              className="w-full py-3 px-4 bg-black text-white border-none rounded-md text-base mb-6 transition-opacity disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  <span>Resetting password...</span>
                </div>
              ) : (
                "Reset Password"
              )}
            </button>
          </form>
        )}

        <p className="text-center text-sm">
          Remember your password?{" "}
          <Link href="/auth" className="text-black font-medium hover:underline">
            Back to login
          </Link>
        </p>
      </div>
    </div>
  )
}
