"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { DatabaseInitializer } from "@/components/admin/database-initializer"
import { DatabaseSetupGuide } from "@/components/admin/database-setup-guide"

export default function DatabaseManagementPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.push("/auth")
      } else if (user.role !== "projectcommittee" && user.role !== "admin") {
        // Only allow project committee members or admins to access this page
        router.push("/dashboard")
      }
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return <div>Loading...</div>
  }

  if (user.role !== "projectcommittee" && user.role !== "admin") {
    return null // Will redirect via useEffect
  }

  return (
    <DashboardLayout>
      <h1 className="text-2xl font-bold mb-6">Database Management</h1>
      <div className="space-y-6">
        <DatabaseInitializer />
        <DatabaseSetupGuide />
      </div>
    </DashboardLayout>
  )
}
