"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { StorageDebug } from "@/components/admin/storage-debug"

export default function StorageDebugPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.push("/auth")
      } else if (user.role !== "instructor") {
        // Only allow instructors to access this page
        router.push("/dashboard")
      } else {
        setIsAdmin(true)
      }
    }
  }, [user, isLoading, router])

  if (isLoading || !isAdmin) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-64">
          <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Storage Management</h1>
      </div>

      <StorageDebug />
    </DashboardLayout>
  )
}
