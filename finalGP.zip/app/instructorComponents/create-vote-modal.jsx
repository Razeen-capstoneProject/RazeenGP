"use client"

import { useState } from "react"
import { X, Plus, Trash, Calendar } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function CreateVoteModal({ isOpen, onClose, group, onVoteCreated }) {
  const [formData, setFormData] = useState({
    title: "",
    deadline: "",
    options: [
      { date: "", startTime: "09:00", endTime: "10:00" },
      { date: "", startTime: "14:00", endTime: "15:00" },
    ],
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  // Set default deadline to tomorrow
  const getTomorrow = () => {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    return tomorrow.toISOString().split("T")[0]
  }

  const resetForm = () => {
    setFormData({
      title: "",
      deadline: getTomorrow(),
      options: [
        { date: "", startTime: "09:00", endTime: "10:00" },
        { date: "", startTime: "14:00", endTime: "15:00" },
      ],
    })
    setError(null)
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleOptionChange = (index, field, value) => {
    const updatedOptions = [...formData.options]
    updatedOptions[index] = {
      ...updatedOptions[index],
      [field]: value,
    }
    setFormData((prev) => ({
      ...prev,
      options: updatedOptions,
    }))
  }

  const addOption = () => {
    setFormData((prev) => ({
      ...prev,
      options: [...prev.options, { date: "", startTime: "09:00", endTime: "10:00" }],
    }))
  }

  const removeOption = (index) => {
    if (formData.options.length <= 2) {
      setError("You must provide at least two meeting options")
      return
    }

    const updatedOptions = [...formData.options]
    updatedOptions.splice(index, 1)
    setFormData((prev) => ({
      ...prev,
      options: updatedOptions,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Validate form
      if (!formData.title.trim()) {
        throw new Error("Title is required")
      }

      if (!formData.deadline) {
        throw new Error("Voting deadline is required")
      }

      // Validate options
      if (formData.options.length < 2) {
        throw new Error("You must provide at least two meeting options")
      }

      for (const option of formData.options) {
        if (!option.date) {
          throw new Error("All meeting options must have a date")
        }
        if (!option.startTime || !option.endTime) {
          throw new Error("All meeting options must have start and end times")
        }

        // Fix the time comparison logic
        const startTimeParts = option.startTime.split(":").map(Number)
        const endTimeParts = option.endTime.split(":").map(Number)

        const startTimeMinutes = startTimeParts[0] * 60 + startTimeParts[1]
        const endTimeMinutes = endTimeParts[0] * 60 + endTimeParts[1]

        if (startTimeMinutes >= endTimeMinutes) {
          throw new Error("End time must be after start time")
        }
      }

      // Combine deadline date with end of day time (23:59)
      const deadlineDateTime = new Date(`${formData.deadline}T23:59:00`)

      // Get the current user ID (supervisor ID)
      const supervisorId = "863f0f67-0a17-4ede-96d8-6fe15d746c64"

      // Generate a unique vote_id for this vote
      const { data: maxVoteIdData, error: maxVoteIdError } = await supabase
        .from("voting")
        .select("vote_id")
        .order("vote_id", { ascending: false })
        .limit(1)

      if (maxVoteIdError) {
        console.error("Error getting max vote_id:", maxVoteIdError)
        throw new Error("Failed to generate vote ID")
      }

      const nextVoteId = maxVoteIdData && maxVoteIdData.length > 0 ? maxVoteIdData[0].vote_id + 1 : 1

      // Insert each meeting option as a separate row in the voting table
      const insertPromises = formData.options.map(async (option) => {
        // Create the start and end datetime objects
        const startDateTime = new Date(`${option.date}T${option.startTime}:00`)
        const endDateTime = new Date(`${option.date}T${option.endTime}:00`)

        // Insert the suggestion with proper error handling
        const { data: voteData, error: voteError } = await supabase
          .from("voting")
          .insert([
            {
              vote_id: nextVoteId,
              group_id: group.id,
              suggestion_time: startDateTime.toISOString(),
              end_time: endDateTime.toISOString(),
              deadline: deadlineDateTime.toISOString(),
              vote_title: formData.title,
              num_voters: 0,
            },
          ])
          .select()

        if (voteError) {
          console.error("Error inserting vote:", voteError)
          throw voteError
        }

        return voteData
      })

      try {
        // Wait for all options to be inserted
        const voteResults = await Promise.all(insertPromises)
        console.log("Successfully inserted votes:", voteResults)

        // Call the onVoteCreated callback
        if (onVoteCreated) {
          onVoteCreated({
            vote_id: nextVoteId,
            title: formData.title,
            deadline: deadlineDateTime.toISOString(),
          })
        }

        // Close the modal
        onClose()
      } catch (err) {
        console.error("Error inserting votes:", err)
        throw new Error(`Failed to create meeting options: ${err.message}`)
      }
    } catch (err) {
      console.error("Error creating vote:", err)
      setError(err.message || "Failed to create vote. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Create Meeting Vote</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-4 max-h-[calc(90vh-120px)]">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Vote Title*
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="e.g., Weekly Progress Meeting"
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div className="mb-6">
              <label htmlFor="deadline" className="block text-sm font-medium text-gray-700 mb-1">
                Voting Deadline Date*
              </label>
              <div className="relative">
                <input
                  type="date"
                  id="deadline"
                  name="deadline"
                  value={formData.deadline}
                  onChange={handleChange}
                  min={new Date().toISOString().split("T")[0]}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                  required
                />
                <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              </div>
              <p className="text-xs text-gray-500 mt-1">Voting will close at the end of this day (23:59).</p>
            </div>

            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-gray-700">Meeting Options*</label>
                <button
                  type="button"
                  onClick={addOption}
                  className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Option
                </button>
              </div>

              <div className="space-y-3">
                {formData.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2 bg-gray-50 p-3 rounded-md">
                    <div className="flex-1">
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">Date</label>
                          <input
                            type="date"
                            value={option.date}
                            onChange={(e) => handleOptionChange(index, "date", e.target.value)}
                            min={new Date().toISOString().split("T")[0]}
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">Start Time</label>
                          <input
                            type="time"
                            value={option.startTime}
                            onChange={(e) => handleOptionChange(index, "startTime", e.target.value)}
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">End Time</label>
                          <input
                            type="time"
                            value={option.endTime}
                            onChange={(e) => handleOptionChange(index, "endTime", e.target.value)}
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                          />
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeOption(index)}
                      className="p-1 text-gray-400 hover:text-red-500"
                      title="Remove option"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              <p className="text-xs text-gray-500 mt-2">
                Add at least two options for meeting times. Students will vote on their preferred options.
              </p>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                disabled={loading}
              >
                {loading ? "Creating..." : "Create Vote"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
// Modal component for creating voting polls
