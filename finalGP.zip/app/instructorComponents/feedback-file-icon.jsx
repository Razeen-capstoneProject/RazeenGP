"use client"

import { useState, useEffect } from "react"
import { File } from "lucide-react"
import { supabase } from "@/lib/supabase" // Make sure this import matches your project structure

export default function FeedbackFileIcon({ file, subtaskId, onFileViewed }) {
  const [isNew, setIsNew] = useState(false)
  const [hasBeenViewed, setHasBeenViewed] = useState(false)

  // Check if file is new when component mounts
  useEffect(() => {
    // Check if file has been viewed in this session from localStorage
    const viewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
    const wasViewedLocally = viewedFiles[file.id || file.name] || false

    // Determine if file is new based on various conditions
    const isNewFile =
      (file.isNewVersion ||
        file.uploadedAfterRejection ||
        !file.viewedAt || // If viewedAt is null or undefined, it's new
        (file.uploadedAt && new Date(file.uploadedAt) > new Date(file.viewedAt || 0))) && // If uploaded after last viewed
      !wasViewedLocally // Also check local storage

    setIsNew(isNewFile)
    setHasBeenViewed(wasViewedLocally)
  }, [file])

  // Handle file click - mark as viewed
  const handleFileClick = async (e) => {
    e.stopPropagation() // Prevent event bubbling

    if (isNew && !hasBeenViewed) {
      // Immediately update local state to hide the red dot
      setIsNew(false)
      setHasBeenViewed(true)

      // Store in localStorage to persist across page refreshes in this session
      const viewedFiles = JSON.parse(localStorage.getItem("viewedFiles") || "{}")
      const fileId = file.id || file.name // Use name as fallback
      viewedFiles[fileId] = true
      localStorage.setItem("viewedFiles", JSON.stringify(viewedFiles))

      // Update the file's viewedAt timestamp in the database
      try {
        // Get the current attachment data
        const { data: subtaskData, error: fetchError } = await supabase
          .from("sub_task")
          .select("attachment")
          .eq("sub_task_id", subtaskId)
          .single()

        if (fetchError) throw fetchError

        let attachments = []
        if (typeof subtaskData.attachment === "string") {
          try {
            attachments = JSON.parse(subtaskData.attachment)
          } catch (e) {
            attachments = []
          }
        } else if (Array.isArray(subtaskData.attachment)) {
          attachments = [...subtaskData.attachment]
        } else if (subtaskData.attachment) {
          attachments = [subtaskData.attachment]
        }

        // Update the viewedAt timestamp for this file
        const updatedAttachments = attachments.map((attachment) => {
          if (
            attachment.id === fileId ||
            attachment.name === fileId ||
            (attachment.name === file.name && attachment.url === file.url)
          ) {
            return {
              ...attachment,
              viewedAt: new Date().toISOString(),
            }
          }
          return attachment
        })

        // Save the updated attachments back to the database
        const { error: updateError } = await supabase
          .from("sub_task")
          .update({ attachment: updatedAttachments })
          .eq("sub_task_id", subtaskId)

        if (updateError) throw updateError

        // Call the callback to notify parent components
        if (onFileViewed) {
          onFileViewed(fileId)
        }
      } catch (error) {
        console.error("Error updating file viewed status:", error)
        // Even if the database update fails, keep the UI updated
      }
    }
  }

  return (
    <div className="relative inline-flex cursor-pointer" onClick={handleFileClick}>
      <File className="w-4 h-4 text-gray-500" />
      {isNew && !hasBeenViewed && (
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></div>
      )}
    </div>
  )
}
