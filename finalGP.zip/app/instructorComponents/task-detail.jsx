"use client"
import { Calendar, Clock } from "lucide-react"
import FileList from "./file-list"

export default function TaskDetail({ task, onFileViewed }) {
  // Format the deadline date if it exists
  const formatDeadline = (deadline) => {
    if (!deadline) return "No deadline set"

    try {
      const date = new Date(deadline)
      return date.toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    } catch (error) {
      return "Invalid date"
    }
  }

  // Handle file viewed
  const handleFileViewed = (fileId) => {
    if (onFileViewed) {
      onFileViewed(task.taskid, fileId)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{task.taskname}</h2>

        <div className="flex flex-wrap gap-2 mb-4">
          <span
            className={`text-xs px-2 py-1 rounded-full ${
              task.priority?.toLowerCase() === "high"
                ? "bg-red-100 text-red-800"
                : task.priority?.toLowerCase() === "medium"
                  ? "bg-amber-100 text-amber-800"
                  : "bg-blue-100 text-blue-800"
            }`}
          >
            {task.priority}
          </span>

          <span
            className={`text-xs px-2 py-1 rounded-full ${
              task.status === "Done"
                ? "bg-green-100 text-green-800"
                : task.status === "On Progress"
                  ? "bg-amber-100 text-amber-800"
                  : "bg-blue-100 text-blue-800"
            }`}
          >
            {task.status}
          </span>
        </div>

        <div className="bg-gray-50 p-4 rounded-md mb-4">
          <p className="text-gray-700">{task.taskdescription || "No description provided."}</p>
        </div>

        <div className="flex items-center text-sm text-gray-600 mb-4">
          <Calendar className="w-4 h-4 mr-2" />
          <span>Deadline: {formatDeadline(task.deadline)}</span>
        </div>

        {task.created_at && (
          <div className="flex items-center text-sm text-gray-600 mb-4">
            <Clock className="w-4 h-4 mr-2" />
            <span>Created: {new Date(task.created_at).toLocaleDateString()}</span>
          </div>
        )}
      </div>

      {/* File list */}
      {task.files && task.files.length > 0 && (
        <div className="mb-6">
          <FileList files={task.files} subtaskId={task.subtaskId || task.taskid} onFileViewed={handleFileViewed} />
        </div>
      )}

      {/* Subtasks */}
      {task.subtasks && task.subtasks.length > 0 && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-3">Subtasks</h3>
          <div className="space-y-2">
            {task.subtasks.map((subtask) => (
              <div key={subtask.sub_task_id} className="p-3 bg-gray-50 rounded-md border border-gray-200">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-medium text-gray-800">{subtask.subTaskName}</h4>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      subtask.priority?.toLowerCase() === "high"
                        ? "bg-red-100 text-red-800"
                        : subtask.priority?.toLowerCase() === "medium"
                          ? "bg-amber-100 text-amber-800"
                          : "bg-blue-100 text-blue-800"
                    }`}
                  >
                    {subtask.priority}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      subtask.status === "Done"
                        ? "bg-green-100 text-green-800"
                        : subtask.status === "On Progress"
                          ? "bg-amber-100 text-amber-800"
                          : "bg-blue-100 text-blue-800"
                    }`}
                  >
                    {subtask.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
