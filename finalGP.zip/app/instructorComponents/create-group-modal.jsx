"use client"

import { useState, useEffect, useMemo } from "react"
import { X, Copy, Check, Info, AlertCircle, Loader2 } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"

// Update the component to include better authentication and error handling
export default function CreateGroupModal({ isOpen, onClose, onGroupCreated, instructorId = null }) {
  const { user, isLoading: authLoading } = useAuth()
  const [groupName, setGroupName] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  const [newGroupEnteranceId, setNewGroupEnteranceId] = useState(null)
  const [newGroupId, setNewGroupId] = useState(null)
  const [copiedEntranceId, setCopiedEntranceId] = useState(false)
  const [copiedGroupId, setCopiedGroupId] = useState(false)
  const [showIdInfo, setShowIdInfo] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  // Derive effective supervisor ID using useMemo
  const effectiveSupervisorId = useMemo(() => {
    // First priority: use the instructorId prop if provided
    if (instructorId) {
      return instructorId
    }

    // Second priority: use user.id from auth context
    if (user?.id) {
      return user.id
    }

    // Third priority: use user.user_id from auth context (some auth providers use this format)
    if (user?.user_id) {
      return user.user_id
    }

    // If none of the above, return null
    return null
  }, [instructorId, user])

  // Check authentication status when component mounts or user changes
  useEffect(() => {
    if (!authLoading) {
      const isUserAuthenticated = !!user
      setIsAuthenticated(isUserAuthenticated)

      if (!isUserAuthenticated) {
        setError("Authentication required. Please log in.")
      } else if (!effectiveSupervisorId) {
        setError("Unable to determine supervisor ID. Please try again or contact support.")
      } else {
        // Clear any previous authentication errors
        if (
          error === "Authentication required. Please log in." ||
          error === "Unable to determine supervisor ID. Please try again or contact support."
        ) {
          setError(null)
        }
      }
    }
  }, [user, authLoading, effectiveSupervisorId, error])

  // Log supervisor ID for debugging
  useEffect(() => {
    if (effectiveSupervisorId) {
      console.log("Using supervisor ID:", effectiveSupervisorId)
    } else if (!authLoading && user) {
      console.warn("User is authenticated but supervisor ID could not be determined:", user)
    }
  }, [effectiveSupervisorId, authLoading, user])

  const handleSubmit = async (e) => {
    e.preventDefault()

    // Check authentication first
    if (!isAuthenticated) {
      setError("Authentication required. Please log in.")
      return
    }

    // Validate supervisor ID
    if (!effectiveSupervisorId) {
      setError("Unable to determine supervisor ID. Please try again or contact support.")
      return
    }

    if (!groupName.trim()) {
      setError("Group name is required")
      return
    }

    setLoading(true)
    setError(null)

    try {
      console.log("Creating group with supervisor ID:", effectiveSupervisorId)

      // Check if a group with the same name already exists
      const { data: existingGroups, error: checkError } = await supabase
        .from("projectgroup")
        .select("groupid,enterance_id")
        .eq("groupname", groupName.trim())

      if (checkError) {
        console.error("Error checking existing groups:", checkError)
        throw new Error(`Database error: ${checkError.message}`)
      }

      if (existingGroups && existingGroups.length > 0) {
        setError("A group with this name already exists")
        setLoading(false)
        return
      }

      // Insert the new group
      const { data, error: insertError } = await supabase
        .from("projectgroup")
        .insert([
          {
            groupname: groupName.trim(),
            instructor_supervisor_id: effectiveSupervisorId,
            group_progress: 0,
            group_status: "late",
          },
        ])
        .select()

      if (insertError) {
        console.error("Error inserting new group:", insertError)
        throw new Error(`Database error: ${insertError.message}`)
      }

      if (!data || data.length === 0) {
        throw new Error("No data returned after creating group")
      }

      const created = data[0]
      setNewGroupEnteranceId(created.enterance_id)
      setNewGroupId(created.groupid)
      setSuccess(true)
      setShowIdInfo(true)

      // Notify parent component
      onGroupCreated?.({
        enterance_id: created.enterance_id,
        groupid: created.groupid,
        groupname: created.groupname,
      })
    } catch (err) {
      console.error("Error creating group:", err)
      setError(`Failed to create group: ${err.message}`)
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = (text, setCopied) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleClose = () => {
    setGroupName("")
    setError(null)
    setSuccess(false)
    setNewGroupEnteranceId(null)
    setNewGroupId(null)
    setCopiedEntranceId(false)
    setCopiedGroupId(false)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b sticky top-0 bg-white z-10 rounded-t-lg">
          <h2 className="text-xl font-semibold text-gray-800">Create New Group</h2>
          <button onClick={handleClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-4 flex-1">
          {/* Authentication error */}
          {!isAuthenticated && !authLoading && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm flex items-center">
              <AlertCircle className="w-5 h-5 mr-2 text-red-500" />
              Authentication required. Please log in.
            </div>
          )}

          {/* Loading state for auth */}
          {authLoading && (
            <div className="mb-4 p-3 bg-blue-50 text-blue-700 rounded-md text-sm flex items-center">
              <Loader2 className="w-5 h-5 mr-2 text-blue-500 animate-spin" />
              Verifying authentication...
            </div>
          )}

          {/* Supervisor ID error */}
          {isAuthenticated && !authLoading && !effectiveSupervisorId && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm flex items-center">
              <AlertCircle className="w-5 h-5 mr-2 text-red-500" />
              Unable to determine supervisor ID. Please try again or contact support.
            </div>
          )}

          {/* Other errors */}
          {error && !authLoading && isAuthenticated && effectiveSupervisorId && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm flex items-center">
              <AlertCircle className="w-5 h-5 mr-2 text-red-500" />
              {error}
            </div>
          )}

          {success && newGroupEnteranceId ? (
            <div>
              <div className="p-3 bg-green-50 text-green-700 rounded-md text-sm mb-4 flex items-center">
                <Info className="w-5 h-5 mr-2 text-green-600" />
                Group "{groupName}" created successfully!
              </div>

              {/* Identifiers Card */}
              <div className="mb-6 bg-blue-50 rounded-lg border border-blue-100 overflow-hidden">
                <div
                  className="flex items-center justify-between p-3 bg-blue-100 cursor-pointer"
                  onClick={() => setShowIdInfo(!showIdInfo)}
                >
                  <div className="flex items-center">
                    <Info className="w-4 h-4 text-blue-600 mr-2" />
                    <h3 className="font-medium text-blue-700">Group Identifiers</h3>
                  </div>
                  <div className="text-blue-600">
                    {showIdInfo ? (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polyline points="18 15 12 9 6 15" />
                      </svg>
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    )}
                  </div>
                </div>

                {showIdInfo && (
                  <div className="p-4 space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Group ID</label>
                      <div className="flex items-center">
                        <div className="flex-1 p-2 border border-gray-300 rounded-l-md bg-white text-gray-700 text-sm truncate">
                          {newGroupId}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy(newGroupId, setCopiedGroupId)}
                          className="p-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-100 hover:bg-gray-200"
                        >
                          {copiedGroupId ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Entrance ID</label>
                      <div className="flex items-center">
                        <div className="flex-1 p-2 border border-gray-300 rounded-l-md bg-white text-gray-700 text-sm truncate">
                          {newGroupEnteranceId}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy(newGroupEnteranceId, setCopiedEntranceId)}
                          className="p-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-100 hover:bg-gray-200"
                        >
                          {copiedEntranceId ? (
                            <Check className="w-4 h-4 text-green-600" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">Share this ID to give access to this group</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleClose}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="groupName" className="block text-sm font-medium text-gray-700 mb-1">
                  Group Name*
                </label>
                <input
                  type="text"
                  id="groupName"
                  value={groupName}
                  onChange={(e) => setGroupName(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter group name"
                  required
                  disabled={!isAuthenticated || authLoading || !effectiveSupervisorId}
                />
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={handleClose}
                  disabled={loading}
                  className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading || !isAuthenticated || authLoading || !effectiveSupervisorId}
                  className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                    !isAuthenticated || authLoading || !effectiveSupervisorId ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                >
                  {loading ? (
                    <span className="flex items-center">
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </span>
                  ) : (
                    "Create Group"
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
