"use client"

import { useState, useEffect } from "react"
import { Clock, CheckCircle, Circle } from "lucide-react"
import { supabase } from "@/lib/supabase"
import Link from "next/link"

export default function GroupRoadmap({ entranceId, groupId }) {
  const [milestones, setMilestones] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [actualGroupId, setActualGroupId] = useState(null)
  const [numericGroupId, setNumericGroupId] = useState(null)

  // Fetch the actual group ID using entrance_id
  const fetchGroupId = async (entranceId) => {
    try {
      // If we already have the actual group ID, use it
      if (actualGroupId) return actualGroupId

      // If entranceId is provided, use it to fetch the group
      if (entranceId) {
        // Note: Using groupid instead of id since that's the correct column name
        const { data, error } = await supabase
          .from("projectgroup")
          .select("groupid")
          .eq("enterance_id", entranceId)
          .single()

        if (error) {
          console.error("Error fetching group by entrance_id:", error)
          // If there's an error but groupId is provided as a fallback, use it
          if (groupId) {
            setActualGroupId(groupId)
            return groupId
          }
          throw error
        }

        // Store the UUID
        setActualGroupId(data.groupid)

        // Now fetch the numeric group ID from the task table
        try {
          const { data: taskData, error: taskError } = await supabase
            .from("task")
            .select("group_id")
            .eq("group_uuid", data.groupid)
            .limit(1)
            .single()

          if (!taskError && taskData) {
            setNumericGroupId(taskData.group_id)
            console.log("Found numeric group ID from task table:", taskData.group_id)
          }
        } catch (taskErr) {
          console.log("Could not find numeric group ID from task table:", taskErr)
          // This is not a critical error, we can continue
        }

        return data.groupid
      }

      // If groupId is provided directly (legacy support), use it
      if (groupId) {
        setActualGroupId(groupId)

        // Try to find the numeric ID from the task table
        try {
          const { data: taskData, error: taskError } = await supabase
            .from("task")
            .select("group_id")
            .eq("group_uuid", groupId)
            .limit(1)
            .single()

          if (!taskError && taskData) {
            setNumericGroupId(taskData.group_id)
            console.log("Found numeric group ID from task table:", taskData.group_id)
          }
        } catch (taskErr) {
          console.log("Could not find numeric group ID from task table:", taskErr)
          // This is not a critical error, we can continue
        }

        return groupId
      }

      return null
    } catch (err) {
      console.error("Error fetching group ID:", err)
      return null
    }
  }

  // Fetch milestones using the actual group ID
  const fetchMilestones = async () => {
    try {
      setLoading(true)

      // Get the actual group ID first
      const groupIdToUse = await fetchGroupId(entranceId)

      // If we couldn't get a group ID, return early
      if (!groupIdToUse) {
        console.warn("Cannot fetch milestones: no valid group ID available")
        setMilestones([])
        setLoading(false)
        return
      }

      // Try to fetch milestones using the numeric ID if available
      let milestonesData = []

      if (numericGroupId) {
        console.log("Trying to fetch milestones with numeric ID:", numericGroupId)
        const { data: numericData, error: numericError } = await supabase
          .from("milestone")
          .select("*")
          .eq("group_id", numericGroupId)
          .order("deadline", { ascending: true })
          .limit(5) // Limit to 5 milestones for the preview

        if (!numericError && numericData && numericData.length > 0) {
          milestonesData = numericData
          console.log("Found milestones with numeric ID:", milestonesData.length)
        } else {
          console.log("No milestones found with numeric ID, trying with string ID")
        }
      }

      // If no milestones found with numeric ID, try with the string ID
      if (milestonesData.length === 0) {
        console.log("Trying to fetch milestones with string ID:", groupIdToUse)
        const { data, error } = await supabase
          .from("milestone")
          .select("*")
          .eq("group_id", groupIdToUse)
          .order("deadline", { ascending: true })
          .limit(5) // Limit to 5 milestones for the preview

        if (error) throw error
        milestonesData = data || []
        console.log("Found milestones with string ID:", milestonesData.length)
      }

      setMilestones(milestonesData)
    } catch (err) {
      console.error("Error fetching milestones:", err)
      setError("Failed to load roadmap data")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMilestones()
  }, [entranceId, groupId])

  // Helper function to get status icon
  const getStatusIcon = (status) => {
    switch (status) {
      case "Done":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "On Progress":
        return <Clock className="w-5 h-5 text-blue-500" />
      default:
        return <Circle className="w-5 h-5 text-gray-400" />
    }
  }

  // Helper function to get status color
  const getStatusColor = (status) => {
    switch (status) {
      case "Done":
        return "bg-green-50"
      case "On Progress":
        return "bg-blue-50"
      default:
        return "bg-gray-50"
    }
  }

  // Format date to display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"
    const date = new Date(dateString)
    return `Due: ${date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`
  }

  if (loading) {
    return (
      <div className="mt-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Project Roadmap</h2>
        <div className="bg-white rounded-lg p-6 shadow-sm animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-20 bg-gray-100 rounded mb-3"></div>
          <div className="h-20 bg-gray-100 rounded mb-3"></div>
          <div className="h-20 bg-gray-100 rounded"></div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="mt-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Project Roadmap</h2>
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <p className="text-red-500">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Project Roadmap</h2>
        <Link href={`/groups/${entranceId || groupId}/roadmap`} passHref>
          <button className="text-sm text-blue-600 hover:text-blue-800">View all</button>
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        {milestones.length === 0 ? (
          <div className="p-6 text-center">
            <p className="text-gray-500">No milestones found</p>
            <Link href={`/groups/${entranceId || groupId}/roadmap`} passHref>
              <button className="mt-2 text-sm text-blue-600 hover:text-blue-800">Add milestones to your project</button>
            </Link>
          </div>
        ) : (
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-2.5 top-6 bottom-0 w-0.5 bg-gray-200"></div>

            {/* Milestones */}
            <div className="space-y-6">
              {milestones.map((milestone) => (
                <div
                  key={milestone.milestone_id}
                  className={`relative pl-10 py-4 px-6 rounded-lg ${getStatusColor(milestone.status)}`}
                >
                  <div className="absolute left-0 top-5">{getStatusIcon(milestone.status)}</div>
                  <h3 className="text-base font-medium text-gray-800">{milestone.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">{formatDate(milestone.deadline)}</p>
                  <p className="text-sm text-blue-500 mt-1">Status: {milestone.status}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
