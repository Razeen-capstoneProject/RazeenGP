"use client"

import { useState, useEffect } from "react"
import { X, Trash } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function VoteDetailsModal({ isOpen, onClose, vote, group, onVoteUpdated }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [voteSuggestions, setVoteSuggestions] = useState([])
  const [studentVotes, setStudentVotes] = useState({})
  const [voteCounts, setVoteCounts] = useState({})
  const [remainingTime, setRemainingTime] = useState("")

  useEffect(() => {
    if (isOpen && vote) {
      fetchVoteSuggestions()
      fetchStudentVotes()
      calculateRemainingTime()
    }
  }, [isOpen, vote])

  // Update remaining time every minute
  useEffect(() => {
    if (!isOpen || !vote) return

    const timer = setInterval(() => {
      calculateRemainingTime()
    }, 60000)

    return () => clearInterval(timer)
  }, [isOpen, vote])

  const calculateRemainingTime = () => {
    if (!vote || !vote.deadline) return

    const now = new Date()
    const deadline = new Date(vote.deadline)
    const diff = deadline - now

    if (diff <= 0) {
      setRemainingTime("Voting ended")
      return
    }

    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    setRemainingTime(`${hours}h ${minutes}m remaining`)
  }

  const fetchVoteSuggestions = async () => {
    if (!vote || !vote.vote_id) return

    try {
      setLoading(true)

      // Fetch all suggestions for this vote
      const { data, error } = await supabase
        .from("voting")
        .select("*")
        .eq("vote_id", vote.vote_id)
        .order("suggestion_time", { ascending: true })

      if (error) {
        console.error("Error fetching vote suggestions:", error)
        return
      }

      setVoteSuggestions(data || [])

      // Fetch actual vote counts for each suggestion
      await fetchActualVoteCounts(data || [])
    } catch (error) {
      console.error("Error in fetchVoteSuggestions:", error)
      setVoteSuggestions([])
    } finally {
      setLoading(false)
    }
  }

  // Fetch the actual vote counts for each suggestion
  const fetchActualVoteCounts = async (suggestions) => {
    if (!suggestions || suggestions.length === 0) return

    const counts = {}

    for (const suggestion of suggestions) {
      try {
        const { data, error, count } = await supabase
          .from("student_voting")
          .select("student_id", { count: "exact" })
          .eq("vote_id", suggestion.vote_id)
          .eq("suggestion_time", suggestion.suggestion_time)

        if (error) {
          console.error("Error fetching vote count:", error)
          counts[suggestion.suggestion_time] = suggestion.num_voters || 0
          continue
        }

        // If we have count, use it directly
        if (count !== null) {
          counts[suggestion.suggestion_time] = count
          continue
        }

        // Otherwise, count unique student_ids
        if (data) {
          const uniqueVoters = new Set(data.map((vote) => vote.student_id))
          counts[suggestion.suggestion_time] = uniqueVoters.size
        }
      } catch (error) {
        console.error("Error counting votes for suggestion:", error)
        counts[suggestion.suggestion_time] = suggestion.num_voters || 0
      }
    }

    setVoteCounts(counts)
  }

  const fetchStudentVotes = async () => {
    if (!vote || !vote.vote_id) return

    try {
      // Step 1: Fetch all student votes for this vote from the student_voting table
      const { data: votesData, error: votesError } = await supabase
        .from("student_voting")
        .select("*")
        .eq("vote_id", vote.vote_id)

      if (votesError) {
        console.error("Error fetching student votes:", votesError)
        return
      }

      if (!votesData || votesData.length === 0) {
        setStudentVotes({})
        return
      }

      // Step 2: Extract all unique student IDs
      const studentIds = [...new Set(votesData.map((vote) => vote.student_id))]

      // Step 3: Fetch user information for these student IDs
      const { data: usersData, error: usersError } = await supabase
        .from("users")
        .select("user_id, userName, email")
        .in("user_id", studentIds)

      if (usersError) {
        console.error("Error fetching user data:", usersError)
      }

      // Step 4: Create a map of user data by user_id for easy lookup
      const userMap = {}
      if (usersData) {
        usersData.forEach((user) => {
          userMap[user.user_id] = user
        })
      }

      // Step 5: Group votes by suggestion_time and attach user information
      const votesByOption = {}

      // First, get all unique suggestion_times for this vote
      const uniqueSuggestionTimes = [...new Set(votesData.map((vote) => vote.suggestion_time))]

      // Initialize empty arrays for each suggestion_time
      uniqueSuggestionTimes.forEach((suggestionTime) => {
        // Convert to string for use as object key
        const timeKey = suggestionTime.toString()
        votesByOption[timeKey] = []
      })

      // Now process the votes
      votesData.forEach((vote) => {
        // Skip if suggestion_time is not valid
        if (!vote.suggestion_time) return

        // Convert to string for use as object key
        const timeKey = vote.suggestion_time.toString()

        // Create a unique voter object with user info
        const voterObj = {
          ...vote,
          user: userMap[vote.student_id] || { userName: `User ${vote.student_id.substring(0, 8)}` },
        }

        // Check if this student has already been added to this suggestion_time
        const existingVoterIndex = votesByOption[timeKey]?.findIndex((v) => v.student_id === vote.student_id)

        // Only add if not already present
        if (existingVoterIndex === -1) {
          if (!votesByOption[timeKey]) {
            votesByOption[timeKey] = []
          }
          votesByOption[timeKey].push(voterObj)
        }
      })

      setStudentVotes(votesByOption)
    } catch (error) {
      console.error("Error in fetchStudentVotes:", error)
    }
  }

  const formatDateTime = (dateTimeString) => {
    if (!dateTimeString) return "N/A"

    const date = new Date(dateTimeString)
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  const handleDeleteVote = async () => {
    if (!vote) return

    try {
      setDeleting(true)

      // First delete all student votes for this vote
      const { error: studentVotesError } = await supabase.from("student_voting").delete().eq("vote_id", vote.vote_id)

      if (studentVotesError) {
        console.error("Error deleting student votes:", studentVotesError)
        // Continue with deletion even if this fails
      }

      // Delete all voting records with this vote_id
      const { error: votingError } = await supabase.from("voting").delete().eq("vote_id", vote.vote_id)

      if (votingError) throw votingError

      if (onVoteUpdated) {
        onVoteUpdated()
      }

      onClose()
    } catch (err) {
      console.error("Error deleting vote:", err)
      setError("Failed to delete vote. Please try again.")
    } finally {
      setDeleting(false)
      setConfirmDelete(false)
    }
  }

  if (!isOpen || !vote) return null

  const isVotingActive = new Date(vote.deadline) > new Date()

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Meeting Vote Details</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 max-h-[calc(90vh-120px)]">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}

          {/* Vote header */}
          <div className="mb-6">
            <div className="flex justify-between items-start">
              <h3 className="text-2xl font-bold text-gray-800">{vote.vote_title || `Vote #${vote.vote_id || ""}`}</h3>
              <div className="flex items-center">
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700 mr-2">
                  Hide Options
                </button>
              </div>
            </div>

            <div className="text-sm text-gray-500 mt-1">{isVotingActive ? remainingTime : "Voting ended"}</div>
          </div>

          {/* Vote options */}
          <div className="space-y-4">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : voteSuggestions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">No voting options available</div>
            ) : (
              voteSuggestions.map((suggestion) => {
                // Convert suggestion_time to string for use as object key
                const timeKey = suggestion.suggestion_time.toString()

                // Get voters for this specific suggestion_time
                const voters = studentVotes[timeKey] || []

                // Get the vote count either from our counts or from the suggestion
                const voteCount = voteCounts[suggestion.suggestion_time] || voters.length || suggestion.num_voters || 0

                return (
                  <div key={timeKey} className="bg-white border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id={`option-${timeKey}`}
                          name="vote-option"
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                          disabled={true}
                        />
                        <label htmlFor={`option-${timeKey}`} className="ml-3 block text-gray-700">
                          {formatDateTime(suggestion.suggestion_time)}
                        </label>
                      </div>
                      <div className="text-sm text-gray-500">
                        {voteCount} {voteCount === 1 ? "vote" : "votes"}
                      </div>
                    </div>

                    {voters.length > 0 && (
                      <div className="mt-3 pl-7">
                        <div className="text-xs text-gray-500 mb-1">Voted by:</div>
                        <div className="flex flex-wrap gap-1">
                          {voters.map((vote) => (
                            <span
                              key={vote.student_id}
                              className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                            >
                              {vote.user?.userName || `Student ${vote.student_id.substring(0, 8)}`}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )
              })
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-between items-center mt-8">
            {confirmDelete ? (
              <div className="flex items-center space-x-3">
                <span className="text-sm text-red-600">Are you sure you want to delete this vote?</span>
                <button
                  onClick={() => setConfirmDelete(false)}
                  className="px-3 py-1 border border-gray-300 rounded text-gray-700 text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteVote}
                  className="px-3 py-1 bg-red-600 text-white rounded text-sm"
                  disabled={deleting}
                >
                  {deleting ? "Deleting..." : "Confirm Delete"}
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmDelete(true)}
                className="flex items-center text-red-600 hover:text-red-800"
              >
                <Trash className="w-4 h-4 mr-1" />
                Delete Vote
              </button>
            )}

            <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
