"use client"

import { useState } from "react"
import { Calendar, Clock, ChevronDown, ChevronUp, MoreHorizontal, CheckCircle } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu"

const TaskCard = ({ task, isLeader, onEditTask, milestoneName, onFileViewed }) => {
  const [expanded, setExpanded] = useState(false)

  // Get priority styling
  const getPriorityStyles = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return {
          bg: "bg-red-50",
          text: "text-red-700",
          border: "border-red-200",
          badge: "bg-red-100 text-red-800",
          label: "High",
        }
      case "medium":
        return {
          bg: "bg-amber-50",
          text: "text-amber-700",
          border: "border-amber-200",
          badge: "bg-amber-100 text-amber-800",
          label: "Medium",
        }
      case "low":
        return {
          bg: "bg-blue-50",
          text: "text-blue-700",
          border: "border-blue-200",
          badge: "bg-blue-100 text-blue-800",
          label: "Low",
        }
      default:
        return {
          bg: "bg-gray-50",
          text: "text-gray-700",
          border: "border-gray-200",
          badge: "bg-gray-100 text-gray-800",
          label: priority || "Normal",
        }
    }
  }

  // Get status styling
  const getStatusStyles = (status) => {
    switch (status) {
      case "Done":
        return {
          bg: "bg-green-100",
          text: "text-green-800",
          icon: <CheckCircle className="w-3 h-3 mr-1" />,
        }
      case "On Progress":
        return {
          bg: "bg-amber-100",
          text: "text-amber-800",
          icon: <Clock className="w-3 h-3 mr-1" />,
        }
      case "To Do":
        return {
          bg: "bg-blue-100",
          text: "text-blue-800",
          icon: null,
        }
      default:
        return {
          bg: "bg-gray-100",
          text: "text-gray-800",
          icon: null,
        }
    }
  }

  // Format the deadline date if it exists
  const formatDeadline = (deadline) => {
    if (!deadline) return null

    try {
      const date = new Date(deadline)
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    } catch (error) {
      return null
    }
  }

  const deadlineDate = formatDeadline(task.deadline)
  const priorityStyles = getPriorityStyles(task.priority)
  const statusStyles = getStatusStyles(task.status)

  // Check if deadline is approaching (within 3 days) or overdue
  const isDeadlineApproaching = () => {
    if (!task.deadline) return false
    const deadline = new Date(task.deadline)
    const today = new Date()
    const diffTime = deadline - today
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays <= 3 && diffDays >= 0
  }

  const isDeadlineOverdue = () => {
    if (!task.deadline) return false
    const deadline = new Date(task.deadline)
    const today = new Date()
    return deadline < today && task.status !== "Done"
  }

  const deadlineApproaching = isDeadlineApproaching()
  const deadlineOverdue = isDeadlineOverdue()

  // Calculate progress based on subtasks
  const calculateProgress = () => {
    if (!task.subtasks || task.subtasks.length === 0) return 0
    const completedSubtasks = task.subtasks.filter((subtask) => subtask.status === "Done").length
    return Math.round((completedSubtasks / task.subtasks.length) * 100)
  }

  const progress = calculateProgress()

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-all duration-200">
      <div className="p-3">
        {/* Priority badge */}
        <div className="flex justify-between items-start mb-2">
          <div className={`text-xs px-2 py-1 rounded-full ${priorityStyles.badge}`}>{priorityStyles.label}</div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full p-1 transition-colors">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEditTask(task)}>Edit Task</DropdownMenuItem>
              <DropdownMenuItem>View Details</DropdownMenuItem>
              {isLeader && <DropdownMenuItem>Change Status</DropdownMenuItem>}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Task title - clickable to expand/collapse */}
        <div className="cursor-pointer" onClick={() => setExpanded(!expanded)}>
          <h4 className="font-medium text-gray-800 mb-1 hover:text-blue-600 transition-colors">{task.taskname}</h4>

          {/* Task description preview - only show if there is a description */}
          {task.taskdescription && <p className="text-sm text-gray-500 mb-2 line-clamp-2">{task.taskdescription}</p>}

          {/* Milestone and status */}
          <div className="flex items-center justify-between mb-2">
            {milestoneName && (
              <div className="text-xs text-gray-500 flex items-center">
                <span className="truncate max-w-[150px]">{milestoneName}</span>
              </div>
            )}
            <div
              className={`text-xs px-2 py-0.5 rounded-full flex items-center ml-auto ${statusStyles.bg} ${statusStyles.text}`}
            >
              {statusStyles.icon}
              {task.status}
            </div>
          </div>

          {/* Deadline */}
          {deadlineDate && (
            <div
              className={`text-xs flex items-center mb-2 ${
                deadlineOverdue ? "text-red-600" : deadlineApproaching ? "text-amber-600" : "text-gray-500"
              }`}
            >
              <Calendar className="w-3 h-3 mr-1" />
              Due {deadlineDate}
              {deadlineOverdue && <span className="ml-1 text-red-600 font-medium">(Overdue)</span>}
              {deadlineApproaching && !deadlineOverdue && (
                <span className="ml-1 text-amber-600 font-medium">(Soon)</span>
              )}
            </div>
          )}

          {/* Subtasks summary */}
          {task.subtasks && task.subtasks.length > 0 && (
            <div className="mb-2">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>
                  Subtasks ({task.subtasks.filter((s) => s.status === "Done").length}/{task.subtasks.length})
                </span>
                <span>{progress}% complete</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-1.5">
                <div
                  className={`h-1.5 rounded-full ${
                    progress === 100 ? "bg-green-500" : progress > 50 ? "bg-blue-500" : "bg-amber-500"
                  }`}
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
          )}

          {/* Expand/collapse indicator */}
          <div className="flex justify-center mt-1">
            {expanded ? (
              <ChevronUp className="w-4 h-4 text-gray-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-gray-400" />
            )}
          </div>
        </div>

        {/* Expanded content */}
        {expanded && (
          <div className="mt-3 pt-3 border-t border-gray-100">
            {/* Subtasks detail */}
            {task.subtasks && task.subtasks.length > 0 && (
              <div className="mb-3">
                <h5 className="text-xs font-medium text-gray-700 mb-2">Subtasks</h5>
                <div className="space-y-1.5">
                  {task.subtasks.map((subtask) => (
                    <div
                      key={subtask.sub_task_id}
                      className="flex items-center justify-between bg-gray-50 p-2 rounded-md"
                    >
                      <div className="flex items-center">
                        <div
                          className={`w-2 h-2 rounded-full mr-2 ${
                            subtask.status === "Done"
                              ? "bg-green-500"
                              : subtask.status === "On Progress"
                                ? "bg-amber-500"
                                : "bg-gray-400"
                          }`}
                        ></div>
                        <span className="text-xs text-gray-700">{subtask.subTaskName}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {subtask.priority && (
                          <span
                            className={`text-xs px-1.5 py-0.5 rounded-full ${
                              subtask.priority?.toLowerCase() === "high"
                                ? "bg-red-50 text-red-700"
                                : subtask.priority?.toLowerCase() === "medium"
                                  ? "bg-amber-50 text-amber-700"
                                  : "bg-blue-50 text-blue-700"
                            }`}
                          >
                            {subtask.priority}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Assigned to */}
            {task.student_id && (
              <div className="mb-2 text-xs text-gray-600">
                <span className="font-medium">Assigned to:</span> {task.student_id.substring(0, 8)}
              </div>
            )}

            {/* Files section */}
            {task.files && task.files.length > 0 && (
              <div className="mb-2">
                <h5 className="text-xs font-medium text-gray-700 mb-1">Files</h5>
                <div className="flex items-center text-xs text-gray-600">
                  <div className="mr-1">
                    <FileIcon
                      hasNewFiles={task.files.some(
                        (file) =>
                          file.isNewVersion ||
                          file.uploadedAfterRejection ||
                          (file.uploadedAt &&
                            new Date().getTime() - new Date(file.uploadedAt).getTime() < 24 * 60 * 60 * 1000),
                      )}
                    />
                  </div>
                  <span>
                    {task.files.length} file{task.files.length !== 1 ? "s" : ""} attached
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// Simple FileIcon component
const FileIcon = ({ hasNewFiles }) => {
  return (
    <div className="relative inline-flex">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-gray-500"
      >
        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
        <polyline points="14 2 14 8 20 8" />
      </svg>
      {hasNewFiles && (
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></div>
      )}
    </div>
  )
}

export default TaskCard
