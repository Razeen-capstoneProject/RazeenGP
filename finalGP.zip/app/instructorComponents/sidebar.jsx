"use client"
import Link from "next/link"
import { usePathname, useParams, useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { Home, Users, Calendar, LogOut, Bell } from "lucide-react"
import AnnouncementBadge from "./announcement-badge"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { signOut } from "@/utils/supabase/auth"

export default function Sidebar() {
  const pathname = usePathname()
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(false)
  const [signOutLoading, setSignOutLoading] = useState(false)

  // Check if we're on a group page
  const isGroupPage = pathname.startsWith("/groups/") && params?.id
  const entranceId = isGroupPage ? params.id : null

  // Fetch group members if we're on a group page
  useEffect(() => {
    if (entranceId) {
      fetchGroupMembers(entranceId)
    }
  }, [entranceId])

  // Function to fetch group members using entrance_id
  const fetchGroupMembers = async (entranceId) => {
    try {
      setLoading(true)

      // First, get the actual group ID from the entrance_id
      const { data: groupData, error: groupError } = await supabase
        .from("projectgroup")
        .select("groupid, leader_id")
        .eq("enterance_id", entranceId)
        .single()

      if (groupError) {
        console.error("Error fetching group:", groupError)
        setLoading(false)
        return
      }

      // Now fetch students using the actual group ID
      const { data: students, error } = await supabase
        .from("student")
        .select("*, users!inner(*)")
        .eq("groupid", groupData.groupid)

      if (!error && students) {
        const formattedMembers = students.map((student) => ({
          id: student.student_id,
          name: student.users.userName || `Student ${student.student_id.substring(0, 8)}`,
          isLeader: student.student_id === groupData.leader_id,
        }))

        setMembers(formattedMembers)
      }
    } catch (error) {
      console.error("Error fetching group members:", error)
    } finally {
      setLoading(false)
    }
  }

  // Sign out function that redirects to signup page
  const handleSignOut = async () => {
    try {
      setSignOutLoading(true)
      console.log("Signing out...")

      // Use the imported signOut function
      const { success, error } = await signOut()

      if (success) {
        console.log("Signed out successfully")
        // Redirect to auth page
        router.push("/auth")
      } else {
        console.error("Error signing out:", error)
        alert("Failed to sign out. Please try again.")
      }
    } catch (error) {
      console.error("Error signing out:", error)
      alert("Failed to sign out. Please try again.")
    } finally {
      setSignOutLoading(false)
    }
  }

  // Check if the current path matches the link
  const isActive = (path) => {
    return pathname === path
  }

  return (
    <div className="w-64 bg-white border-r border-gray-200 shadow-sm h-screen">
      <div className="p-4 border-b border-gray-200 flex justify-center">
        <div className="flex items-center">
          <span className="text-xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
            Razeen
          </span>
        </div>
      </div>

      <nav className="p-4">
        <ul className="space-y-2">
          <li>
            <Link
              href="/home"
              className={`flex items-center p-2 rounded-md transition-all ${
                isActive("/home") ? "bg-gray-100 text-gray-700" : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Home className="w-5 h-5 mr-3" />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <Link
              href="/meetings"
              className={`flex items-center p-2 rounded-md transition-all ${
                isActive("/meetings") ? "bg-gray-100 text-gray-700" : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Users className="w-5 h-5 mr-3" />
              <span>Meeting</span>
            </Link>
          </li>
          <li>
            <Link
              href="/scoring"
              className={`flex items-center p-2 rounded-md transition-all ${
                isActive("/scoring") ? "bg-gray-100 text-gray-700" : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Calendar className="w-5 h-5 mr-3" />
              <span>Scoring</span>
            </Link>
          </li>
          <li>
            <Link
              href="/announcements"
              className={`flex items-center p-2 rounded-md transition-all ${
                isActive("/announcements") ? "bg-gray-100 text-gray-700" : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <Bell className="w-5 h-5 mr-3" />
              <span>Announcements</span>
              <AnnouncementBadge userRole="instructor" />
            </Link>
          </li>
        </ul>
      </nav>

      {/* Group Members List - Only show when on a group page */}
      {isGroupPage && (
        <div className="p-4 mt-4">
          <h3 className="text-sm font-medium text-gray-500 mb-3">GROUP MEMBERS</h3>
          {loading ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin h-5 w-5 border-2 border-blue-500 rounded-full border-t-transparent"></div>
            </div>
          ) : members.length > 0 ? (
            <ul className="space-y-1">
              {members.map((member) => (
                <li key={member.id}>
                  <a href="#" className="flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100">
                    <span>{member.name}</span>
                    {member.isLeader && (
                      <span className="ml-auto text-xs bg-gray-100 px-2 py-0.5 rounded-full">Leader</span>
                    )}
                  </a>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500 p-2">No members found</p>
          )}
        </div>
      )}

      <div className="absolute bottom-0 w-64 border-t border-gray-200 bg-white">
        <ul>
          <li>
            <button
              onClick={handleSignOut}
              disabled={signOutLoading}
              className="w-full flex items-center p-4 text-gray-600 transition-all hover:bg-gray-100 disabled:opacity-50"
            >
              {signOutLoading ? (
                <>
                  <div className="w-5 h-5 mr-3 border-2 border-t-transparent border-gray-600 rounded-full animate-spin"></div>
                  <span>Signing out...</span>
                </>
              ) : (
                <>
                  <LogOut className="w-5 h-5 mr-3" />
                  <span>Sign out</span>
                </>
              )}
            </button>
          </li>
        </ul>
      </div>
    </div>
  )
}
