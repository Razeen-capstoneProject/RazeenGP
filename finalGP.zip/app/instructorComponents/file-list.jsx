"use client"

import { useState } from "react"
import FileViewer from "./file-viewer"
import { isFileNewAndUnviewed } from "@/lib/file-utils"
import FeedbackFileIcon from "./feedback-file-icon"

export default function FileList({ files = [], subtaskId, onFileViewed }) {
  const [selectedFile, setSelectedFile] = useState(null)
  const [viewedFileIds, setViewedFileIds] = useState(new Set())

  // Handle file viewed
  const handleFileViewed = (fileId) => {
    setViewedFileIds((prev) => {
      const newSet = new Set(prev)
      newSet.add(fileId)
      return newSet
    })

    if (onFileViewed) {
      onFileViewed(fileId)
    }
  }

  // Count new files
  const newFilesCount = files.filter((file) => isFileNewAndUnviewed(file) && !viewedFileIds.has(file.id)).length

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-700">Files</h3>
        {newFilesCount > 0 && (
          <span className="bg-red-100 text-red-800 text-xs px-2 py-0.5 rounded-full">{newFilesCount} new</span>
        )}
      </div>

      <div className="space-y-2">
        {files.map((file) => (
          <div
            key={file.id || file.name}
            className="flex items-center justify-between p-2 bg-gray-50 rounded border border-gray-200 hover:bg-gray-100 cursor-pointer"
            onClick={() => setSelectedFile(file)}
          >
            <div className="flex items-center">
              <div className="mr-2">
                <FeedbackFileIcon file={file} subtaskId={subtaskId} onFileViewed={handleFileViewed} />
              </div>
              <span className="text-sm truncate max-w-[200px]">{file.name || "Unnamed file"}</span>
            </div>

            <div className="text-xs text-gray-500">
              {file.uploadedAt && new Date(file.uploadedAt).toLocaleDateString()}
            </div>
          </div>
        ))}

        {files.length === 0 && (
          <div className="text-center p-3 bg-gray-50 rounded border border-gray-200 text-gray-500 text-sm">
            No files attached
          </div>
        )}
      </div>

      {selectedFile && (
        <FileViewer
          file={selectedFile}
          subtaskId={subtaskId}
          onClose={() => setSelectedFile(null)}
          onFileViewed={handleFileViewed}
        />
      )}
    </div>
  )
}
