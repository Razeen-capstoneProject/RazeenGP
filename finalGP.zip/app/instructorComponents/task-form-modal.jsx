"use client"

import { useState, useEffect } from "react"
import { X, Calendar, Check, ArrowDown } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function TaskFormModal({
  isOpen,
  onClose,
  groupId,
  onTaskCreated,
  onTaskUpdated,
  editTask,
  isLeader,
  userRole,
}) {
  const [formData, setFormData] = useState({
    taskname: "",
    taskdescription: "",
    priority: "Low",
    status: "To Do", // Default status is always "To Do"
    deadline: "",
    milestone_id: "",
    start_date: "", // Add the start_date field
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [milestones, setMilestones] = useState([]) // Store available milestones
  const isEditMode = !!editTask
  const [subtasks, setSubtasks] = useState([])
  const [newSubtask, setNewSubtask] = useState({
    subTaskName: "",
    priority: "Low",
    status: "To Do",
  })
  const [userNames, setUserNames] = useState({}) // Store user names mapped to IDs
  // Add a new state for delete confirmation dialog
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  // Add the following state for dependencies after the other state declarations
  const [availableTasks, setAvailableTasks] = useState([])
  const [selectedDependencies, setSelectedDependencies] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [showDependencyDropdown, setShowDependencyDropdown] = useState(false)

  // Check if user is a supervisor
  const isSupervisor = userRole === "Supervisor"

  useEffect(() => {
    if (isOpen) {
      // Fetch milestones when modal opens
      fetchMilestones()

      // Fetch available tasks for dependencies
      fetchAvailableTasks()

      if (editTask) {
        // Pre-fill form with task data if in edit mode
        setFormData({
          taskname: editTask.taskname || "",
          taskdescription: editTask.taskdescription || "",
          priority: editTask.priority || "Low",
          status: editTask.status || "To Do",
          deadline: editTask.deadline ? new Date(editTask.deadline).toISOString().split("T")[0] : "",
          milestone_id: editTask.milestone_id || "",
          start_date: editTask.start_date
            ? new Date(editTask.start_date).toISOString().split("T")[0]
            : new Date().toISOString().split("T")[0], // Set to today if not available
        })

        // If editing a task, fetch its subtasks and dependencies
        fetchSubtasks(editTask.taskid)
        fetchExistingDependencies(editTask.taskid)
      } else {
        // Reset form for new task - always set status to "To Do" for new tasks
        // Set start_date to today's date by default for new tasks
        const today = new Date().toISOString().split("T")[0]
        setFormData({
          taskname: "",
          taskdescription: "",
          priority: "Low",
          status: "To Do", // Always "To Do" for new tasks
          deadline: "",
          milestone_id: "",
          start_date: today, // Default to today's date
        })
        setSelectedDependencies([])
      }
      setError(null)
    }
  }, [isOpen, editTask])

  const fetchMilestones = async () => {
    try {
      const { data, error } = await supabase
        .from("milestone")
        .select("milestone_id, name")
        .eq("group_id", groupId)
        .order("name")

      if (error) throw error

      setMilestones(data || [])
    } catch (err) {
      console.error("Error fetching milestones:", err)
      setError("Failed to load milestones. Please try again.")
    }
  }

  // Add this function to fetch available tasks for dependencies after the fetchMilestones function
  const fetchAvailableTasks = async () => {
    try {
      // Only fetch tasks from the same group
      const { data, error } = await supabase
        .from("task")
        .select("taskid, taskname, status, priority")
        .eq("groupid", groupId)
        .order("taskname")

      if (error) throw error

      // If editing a task, filter out the current task (can't depend on itself)
      const filteredTasks = editTask ? data.filter((task) => task.taskid !== editTask.taskid) : data

      setAvailableTasks(filteredTasks || [])
    } catch (err) {
      console.error("Error fetching available tasks:", err)
      setError("Failed to load available tasks. Please try again.")
    }
  }

  const fetchSubtasks = async (taskId) => {
    try {
      const { data, error } = await supabase.from("sub_task").select("*").eq("main_task", taskId).order("subTaskName")

      if (error) throw error

      setSubtasks(data || [])

      // Fetch user names for all student IDs in subtasks
      const studentIds = data.filter((subtask) => subtask.student_id).map((subtask) => subtask.student_id)

      if (studentIds.length > 0) {
        await fetchUserNames(studentIds)
      }
    } catch (err) {
      console.error("Error fetching subtasks:", err)
      setError("Failed to load subtasks. Please try again.")
    }
  }

  // Add this function to fetch existing dependencies after the fetchSubtasks function
  const fetchExistingDependencies = async (taskId) => {
    try {
      const { data, error } = await supabase.from("dependency").select("depend_on").eq("task", taskId)

      if (error) throw error

      // Extract the depend_on IDs
      const dependencyIds = data.map((dep) => dep.depend_on)
      setSelectedDependencies(dependencyIds)
    } catch (err) {
      console.error("Error fetching dependencies:", err)
    }
  }

  const fetchUserNames = async (studentIds) => {
    try {
      // Directly fetch user information using student_id which references user_id
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("user_id, userName, email")
        .in("user_id", studentIds)

      if (userError) throw userError

      console.log("Fetched user data:", userData)

      // Create a mapping of student_id (user_id) to user name
      const nameMap = {}
      userData.forEach((user) => {
        // Use userName if available, otherwise use email username
        nameMap[user.user_id] = user.userName || (user.email ? user.email.split("@")[0] : "Unknown User")
      })

      console.log("User name mapping:", nameMap)
      setUserNames(nameMap)
    } catch (err) {
      console.error("Error fetching user names:", err)
      // Don't set an error, just log it - we'll fall back to showing IDs
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleAddSubtask = () => {
    if (!newSubtask.subTaskName.trim()) return

    setSubtasks([
      ...subtasks,
      {
        ...newSubtask,
        sub_task_id: `temp-${Date.now()}`, // Temporary ID for new subtasks
        isNew: true,
      },
    ])

    // Reset the new subtask form
    setNewSubtask({
      subTaskName: "",
      priority: "Low",
      status: "To Do",
    })
  }

  const handleSubtaskChange = (index, field, value) => {
    const updatedSubtasks = [...subtasks]
    updatedSubtasks[index][field] = value
    setSubtasks(updatedSubtasks)
  }

  const handleRemoveSubtask = (index) => {
    const updatedSubtasks = [...subtasks]
    updatedSubtasks.splice(index, 1)
    setSubtasks(updatedSubtasks)
  }

  // Helper function to check if dates are valid
  const areDatesValid = () => {
    if (!formData.start_date || !formData.deadline) return true // If either date is missing, no validation needed

    const startDate = new Date(formData.start_date)
    const deadlineDate = new Date(formData.deadline)

    return startDate <= deadlineDate
  }

  // Add a new function to handle task deletion
  const handleDeleteTask = async () => {
    setLoading(true)
    setError(null)

    try {
      // First delete any subtasks associated with this task
      const { error: subtaskDeleteError } = await supabase.from("sub_task").delete().eq("main_task", editTask.taskid)

      if (subtaskDeleteError) {
        console.error("Error deleting subtasks:", subtaskDeleteError)
        throw new Error(`Failed to delete subtasks: ${subtaskDeleteError.message}`)
      }

      // Then delete the task itself
      const { error: taskDeleteError } = await supabase.from("task").delete().eq("taskid", editTask.taskid)

      if (taskDeleteError) {
        console.error("Error deleting task:", taskDeleteError)
        throw new Error(`Failed to delete task: ${taskDeleteError.message}`)
      }

      // Close the modal and notify parent component
      onClose()
      // If onTaskUpdated exists, call it to refresh the task list
      if (onTaskUpdated) {
        onTaskUpdated()
      }
    } catch (error) {
      console.error("Error deleting task:", error)
      setError(error.message || "Failed to delete task. Please try again.")
    } finally {
      setLoading(false)
      setShowDeleteConfirm(false)
    }
  }

  // Function to toggle a dependency selection
  const toggleDependency = (taskId) => {
    setSelectedDependencies((prev) => {
      if (prev.includes(taskId)) {
        return prev.filter((id) => id !== taskId)
      } else {
        return [...prev, taskId]
      }
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Validate form
      if (!formData.taskname.trim()) {
        throw new Error("Task name is required")
      }

      if (!formData.milestone_id) {
        throw new Error("Please select a milestone for this task")
      }

      // Ensure start_date is set
      if (!formData.start_date) {
        // If start_date is not set, use today's date
        formData.start_date = new Date().toISOString().split("T")[0]
      }

      // Validate date logic - ensure start date is before deadline
      if (formData.start_date && formData.deadline) {
        const startDate = new Date(formData.start_date)
        const deadlineDate = new Date(formData.deadline)

        if (startDate > deadlineDate) {
          throw new Error("Start date cannot be after the deadline. Please correct the dates.")
        }
      }

      if (isEditMode) {
        // Update existing task
        const taskData = {
          taskname: formData.taskname,
          taskdescription: formData.taskdescription,
          priority: formData.priority,
          deadline: formData.deadline ? new Date(formData.deadline).toISOString() : null,
          milestone_id: formData.milestone_id,
          start_date: formData.start_date ? new Date(formData.start_date).toISOString() : new Date().toISOString(), // Ensure start_date is set
        }

        // CRITICAL: For supervisors, we NEVER update the status field
        // Only allow non-supervisor leaders to update status
        if (isLeader && !isSupervisor) {
          taskData.status = formData.status
        }

        console.log("Updating task data:", taskData)

        const { data, error } = await supabase.from("task").update(taskData).eq("taskid", editTask.taskid).select()

        if (error) {
          console.error("Supabase error updating task:", error)
          throw new Error(`Failed to update task: ${error.message}`)
        }

        console.log("Task updated:", data)

        // Handle subtasks for existing task - skip for supervisors
        if (isEditMode) {
          // For supervisors, we don't modify subtasks at all
          console.log("Supervisor is viewing subtasks but not modifying them")

          // We're skipping these operations:
          // 1. Create new subtasks
          // 2. Update existing subtasks
          // 3. Delete removed subtasks
        }

        // First delete existing dependencies
        const { error: deleteError } = await supabase.from("dependency").delete().eq("task", editTask.taskid)

        if (deleteError) {
          console.error("Error deleting existing dependencies:", deleteError)
        }

        // Then add new dependencies if any are selected
        if (selectedDependencies.length > 0) {
          const dependenciesToInsert = selectedDependencies.map((dependOnId) => ({
            task: editTask.taskid,
            depend_on: dependOnId,
          }))

          const { error: insertError } = await supabase.from("dependency").insert(dependenciesToInsert)

          if (insertError) {
            console.error("Error inserting dependencies:", insertError)
          }
        }
        onTaskUpdated()
      } else {
        // Create new task
        // Get the next task ID
        const { data: maxTaskId, error: maxTaskIdError } = await supabase
          .from("task")
          .select("taskid")
          .order("taskid", { ascending: false })
          .limit(1)

        if (maxTaskIdError) {
          console.error("Error getting max task ID:", maxTaskIdError)
          throw new Error("Failed to generate task ID")
        }

        const nextTaskId = maxTaskId && maxTaskId.length > 0 ? maxTaskId[0].taskid + 1 : 1

        // Prepare task data - always set status to "To Do" for new tasks
        const taskData = {
          taskid: nextTaskId,
          taskname: formData.taskname,
          taskdescription: formData.taskdescription,
          priority: formData.priority,
          status: "To Do", // Force "To Do" status for new tasks regardless of what's in the form
          deadline: formData.deadline ? new Date(formData.deadline).toISOString() : null,
          groupid: Number.parseInt(groupId, 10),
          milestone_id: Number.parseInt(formData.milestone_id, 10),
          start_date: formData.start_date ? new Date(formData.start_date).toISOString() : new Date().toISOString(), // Ensure start_date is set
        }

        console.log("Saving new task data:", taskData)

        // Create the task
        const { data, error } = await supabase.from("task").insert([taskData])

        if (error) {
          console.error("Supabase error saving task:", error)
          throw new Error(`Failed to save task: ${error.message}`)
        }

        // Verify the task was saved
        const { data: verifyData, error: verifyError } = await supabase
          .from("task")
          .select("*")
          .eq("taskid", nextTaskId)
          .single()

        if (verifyError || !verifyData) {
          console.error("Error verifying task was saved:", verifyError)
          throw new Error("Task may not have been saved properly. Please check and try again.")
        }

        console.log("Task saved and verified:", verifyData)

        // Create subtasks for the new task - skip this for new tasks
        if (isEditMode && subtasks.length > 0) {
          const subtasksToCreate = subtasks.map((subtask) => ({
            main_task: nextTaskId,
            subTaskName: subtask.subTaskName,
            priority: subtask.priority,
            status: subtask.status,
            student_id: subtask.student_id || null,
          }))

          const { error: subtasksError } = await supabase.from("sub_task").insert(subtasksToCreate)
          if (subtasksError) {
            console.error("Error creating subtasks:", subtasksError)
          }
        }

        // Add dependencies for the new task if any are selected
        if (selectedDependencies.length > 0) {
          const dependenciesToInsert = selectedDependencies.map((dependOnId) => ({
            task: nextTaskId,
            depend_on: dependOnId,
          }))

          const { error: insertError } = await supabase.from("dependency").insert(dependenciesToInsert)

          if (insertError) {
            console.error("Error inserting dependencies:", insertError)
          }
        }
        onTaskCreated()
      }

      // Close the modal
      onClose()
    } catch (error) {
      console.error("Error handling task:", error)
      setError(error.message || "Failed to process task. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  // Helper function to get user name from ID
  const getUserName = (studentId) => {
    if (!studentId) return "Unassigned"
    return userNames[studentId] || `Student ${studentId.substring(0, 8)}...` // Fall back to shortened ID if name not found
  }

  // Filter tasks based on search term
  const filteredTasks = availableTasks.filter((task) => task.taskname.toLowerCase().includes(searchTerm.toLowerCase()))

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">{isEditMode ? "Edit Task" : "Add New Task"}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 overflow-y-auto flex-1">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}

          <div className="mb-4">
            <label htmlFor="taskname" className="block text-sm font-medium text-gray-700 mb-1">
              Task Name*
            </label>
            <input
              type="text"
              id="taskname"
              name="taskname"
              value={formData.taskname}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="milestone_id" className="block text-sm font-medium text-gray-700 mb-1">
              Milestone*
            </label>
            <select
              id="milestone_id"
              name="milestone_id"
              value={formData.milestone_id}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Select a milestone</option>
              {milestones.map((milestone) => (
                <option key={milestone.milestone_id} value={milestone.milestone_id}>
                  {milestone.name}
                </option>
              ))}
            </select>
            {milestones.length === 0 && (
              <p className="text-xs text-amber-600 mt-1">No milestones available. Please create a milestone first.</p>
            )}
          </div>

          <div className="mb-4">
            <label htmlFor="taskdescription" className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              id="taskdescription"
              name="taskdescription"
              value={formData.taskdescription}
              onChange={handleChange}
              rows={3}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                Priority
              </label>
              <select
                id="priority"
                name="priority"
                value={formData.priority}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>

            <div>
              <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              {/* CRITICAL: For supervisors, ALWAYS show read-only status */}
              {isSupervisor ? (
                <div className="w-full p-2 border border-gray-200 bg-gray-100 rounded-md text-gray-700">
                  {isEditMode ? editTask.status : "To Do"}{" "}
                  <span className="text-xs text-gray-500">(Supervisors cannot change status)</span>
                </div>
              ) : isLeader && isEditMode ? (
                <select
                  id="status"
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="To Do">To Do</option>
                  <option value="On Progress">On Progress</option>
                  <option value="Done">Done</option>
                </select>
              ) : (
                <div className="w-full p-2 border border-gray-200 bg-gray-100 rounded-md text-gray-700">
                  {isEditMode ? formData.status : "To Do"}{" "}
                  <span className="text-xs text-gray-500">
                    {isEditMode ? "(Only leaders can change status)" : "(New tasks always start as To Do)"}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Start Date Field */}
          <div className="mb-4">
            <label htmlFor="start_date" className="block text-sm font-medium text-gray-700 mb-1">
              Start Date*
            </label>
            <div className="relative">
              <input
                type="date"
                id="start_date"
                name="start_date"
                value={formData.start_date}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                required
              />
              <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="deadline" className="block text-sm font-medium text-gray-700 mb-1">
              Deadline
            </label>
            <div className="relative">
              <input
                type="date"
                id="deadline"
                name="deadline"
                value={formData.deadline}
                onChange={handleChange}
                className={`w-full p-2 border ${
                  formData.start_date &&
                  formData.deadline &&
                  new Date(formData.start_date) > new Date(formData.deadline)
                    ? "border-red-300 focus:ring-red-500"
                    : "border-gray-300 focus:ring-blue-500"
                } rounded-md focus:outline-none focus:ring-2 focus:border-transparent transition-all pr-10`}
              />
              <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
            {formData.start_date &&
              formData.deadline &&
              new Date(formData.start_date) > new Date(formData.deadline) && (
                <p className="mt-1 text-sm text-red-600">Deadline cannot be earlier than the start date</p>
              )}
          </div>

          {/* Subtasks section - only show when editing */}
          {isEditMode && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Subtasks</label>

              {/* List of existing subtasks - read-only */}
              {subtasks.length > 0 ? (
                <div className="mb-3 space-y-2">
                  {subtasks.map((subtask, index) => (
                    <div
                      key={subtask.sub_task_id || index}
                      className="p-3 bg-gray-50 rounded-md border border-gray-200"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-sm font-medium text-gray-800">{subtask.subTaskName}</span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${
                            subtask.priority === "High"
                              ? "bg-red-100 text-red-800"
                              : subtask.priority === "Medium"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {subtask.priority}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${
                            subtask.status === "Done"
                              ? "bg-green-100 text-green-800"
                              : subtask.status === "On Progress"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {subtask.status}
                        </span>
                        {subtask.student_id && (
                          <span className="text-xs text-gray-500">Assigned to: {getUserName(subtask.student_id)}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500 p-3 bg-gray-50 rounded-md border border-gray-200">
                  No subtasks have been added to this task.
                </p>
              )}

              <p className="text-xs text-gray-500 mt-2 italic">
                Note: Subtasks can only be added or modified by students or group leaders.
              </p>
            </div>
          )}

          {/* Improved Dependencies Section */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-1">
              <label className="block text-sm font-medium text-gray-700">
                Dependencies <span className="text-gray-500 text-xs">(Tasks this task depends on)</span>
              </label>
              <span className="text-xs text-blue-600">{selectedDependencies.length} selected</span>
            </div>

            <div className="relative">
              <button
                type="button"
                onClick={() => setShowDependencyDropdown(!showDependencyDropdown)}
                className="w-full p-2 border border-gray-300 rounded-md bg-white flex justify-between items-center focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <span className="text-gray-700">
                  {selectedDependencies.length === 0
                    ? "Select dependencies..."
                    : `${selectedDependencies.length} task${selectedDependencies.length === 1 ? "" : "s"} selected`}
                </span>
                <ArrowDown className="w-4 h-4 text-gray-500" />
              </button>

              {showDependencyDropdown && (
                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg">
                  <div className="p-2 border-b">
                    <input
                      type="text"
                      placeholder="Search tasks..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    {filteredTasks.length > 0 ? (
                      filteredTasks.map((task) => (
                        <div
                          key={task.taskid}
                          onClick={() => toggleDependency(task.taskid)}
                          className="flex items-center p-2 hover:bg-gray-100 cursor-pointer"
                        >
                          <div
                            className={`w-5 h-5 mr-2 flex items-center justify-center border rounded ${
                              selectedDependencies.includes(task.taskid)
                                ? "bg-blue-500 border-blue-500"
                                : "border-gray-300"
                            }`}
                          >
                            {selectedDependencies.includes(task.taskid) && <Check className="w-3 h-3 text-white" />}
                          </div>
                          <div className="flex-1">
                            <div className="text-sm font-medium">{task.taskname}</div>
                            <div className="flex items-center mt-1">
                              <span
                                className={`text-xs px-2 py-0.5 rounded-full mr-2 ${
                                  task.status === "Done"
                                    ? "bg-green-100 text-green-800"
                                    : task.status === "On Progress"
                                      ? "bg-amber-100 text-amber-800"
                                      : "bg-blue-100 text-blue-800"
                                }`}
                              >
                                {task.status}
                              </span>
                              <span
                                className={`text-xs px-2 py-0.5 rounded-full ${
                                  task.priority === "High"
                                    ? "bg-red-100 text-red-800"
                                    : task.priority === "Medium"
                                      ? "bg-amber-100 text-amber-800"
                                      : "bg-blue-100 text-blue-800"
                                }`}
                              >
                                {task.priority}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 text-center text-gray-500">No tasks found</div>
                    )}
                  </div>
                  <div className="p-2 border-t bg-gray-50 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setSelectedDependencies([])}
                      className="text-xs text-gray-600 hover:text-gray-800"
                    >
                      Clear all
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowDependencyDropdown(false)}
                      className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                    >
                      Done
                    </button>
                  </div>
                </div>
              )}
            </div>

            {selectedDependencies.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {selectedDependencies.map((depId) => {
                  const task = availableTasks.find((t) => t.taskid === depId)
                  return task ? (
                    <div
                      key={depId}
                      className="bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full flex items-center"
                    >
                      <span className="mr-1">{task.taskname}</span>
                      <button
                        type="button"
                        onClick={() => toggleDependency(depId)}
                        className="text-blue-500 hover:text-blue-700"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : null
                })}
              </div>
            )}

            <p className="text-xs text-gray-500 mt-2">
              Dependencies are used to create relationships between tasks for the Gantt chart visualization.
            </p>
          </div>

          <div className="flex justify-between space-x-3">
            {/* Add Delete button for supervisors in edit mode */}
            {isSupervisor && isEditMode && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                disabled={loading}
              >
                Delete Task
              </button>
            )}

            <div className="flex space-x-3 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                disabled={loading || milestones.length === 0}
              >
                {loading ? (isEditMode ? "Updating..." : "Creating...") : isEditMode ? "Update Task" : "Create Task"}
              </button>
            </div>
          </div>
        </form>
      </div>
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-sm mx-4">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Confirm Deletion</h3>
            <p className="text-sm text-gray-500 mb-6">
              Are you sure you want to delete this task? This action cannot be undone and will also remove all subtasks.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteTask}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                disabled={loading}
              >
                {loading ? "Deleting..." : "Delete Task"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
