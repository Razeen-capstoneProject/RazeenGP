"use client"

import { File } from "lucide-react"

export default function FileIcon({ hasNewFiles = false }) {
  return (
    <div className="relative inline-flex">
      <File className="w-4 h-4 text-gray-500" />
      {hasNewFiles && (
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full border border-white"></div>
      )}
    </div>
  )
}
