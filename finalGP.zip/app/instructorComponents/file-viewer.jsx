"use client"

import { useState, useEffect } from "react"
import { X, Download, ExternalLink } from "lucide-react"
import { markFileAsViewed } from "@/lib/file-utils"

export default function FileViewer({ file, subtaskId, onClose, onFileViewed }) {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Mark file as viewed when opened
    if (file && subtaskId) {
      markFileAsViewed(subtaskId, file.id || file.name).then((success) => {
        if (success && onFileViewed) {
          onFileViewed(file.id || file.name)
        }
      })
    }

    // Set loading to false after a short delay
    const timer = setTimeout(() => setLoading(false), 500)
    return () => clearTimeout(timer)
  }, [file, subtaskId, onFileViewed])

  // Get file URL
  const fileUrl = file.url || file.file_url || ""

  // Determine file type
  const getFileType = () => {
    const fileName = file.name || file.filename || ""
    const extension = fileName.split(".").pop()?.toLowerCase()

    if (["jpg", "jpeg", "png", "gif", "webp"].includes(extension)) {
      return "image"
    } else if (["pdf"].includes(extension)) {
      return "pdf"
    } else if (["mp4", "webm", "ogg"].includes(extension)) {
      return "video"
    } else {
      return "other"
    }
  }

  const fileType = getFileType()

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-lg font-medium">{file.name || file.filename || "File Preview"}</h3>
          <div className="flex space-x-2">
            {fileUrl && (
              <>
                <a
                  href={fileUrl}
                  download
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
                  title="Download"
                >
                  <Download className="w-5 h-5" />
                </a>
                <a
                  href={fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
                  title="Open in new tab"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
              </>
            )}
            <button
              onClick={onClose}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-4 flex items-center justify-center">
          {loading ? (
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          ) : fileUrl ? (
            fileType === "image" ? (
              <img
                src={fileUrl || "/placeholder.svg"}
                alt={file.name || "File preview"}
                className="max-w-full max-h-[70vh] object-contain"
              />
            ) : fileType === "pdf" ? (
              <iframe src={`${fileUrl}#view=FitH`} className="w-full h-[70vh]" title={file.name || "PDF preview"} />
            ) : fileType === "video" ? (
              <video src={fileUrl} controls className="max-w-full max-h-[70vh]" />
            ) : (
              <div className="text-center">
                <p className="mb-4">Preview not available for this file type</p>
                <a
                  href={fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Open File
                </a>
              </div>
            )
          ) : (
            <div className="text-center text-gray-500">No file URL available</div>
          )}
        </div>

        {/* Footer with file info */}
        {file.description && (
          <div className="p-4 border-t">
            <p className="text-sm text-gray-600">{file.description}</p>
          </div>
        )}
      </div>
    </div>
  )
}
