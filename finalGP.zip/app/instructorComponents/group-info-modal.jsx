"use client"

import { useState, useEffect } from "react"
import { X, Save, Trash2, AlertTriangle, Copy, Check, Info } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function GroupInfoModal({ isOpen, onClose, group, onGroupUpdated, onGroupDeleted }) {
  const [formData, setFormData] = useState({
    groupname: "",
    group_progress: 0,
    group_status: "late",
    leader_id: null,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [groupMembers, setGroupMembers] = useState([])
  const [deletingMember, setDeletingMember] = useState(null)
  const [memberActionLoading, setMemberActionLoading] = useState(false)

  // States for copying IDs
  const [copiedEntranceId, setCopiedEntranceId] = useState(false)
  const [copiedGroupId, setCopiedGroupId] = useState(false)

  // State for showing/hiding the ID info section
  const [showIdInfo, setShowIdInfo] = useState(false)

  useEffect(() => {
    if (isOpen && group) {
      setFormData({
        groupname: group.title || "",
        group_progress: group.progress || 0,
        group_status: group.status || "late",
        leader_id: group.leader_id || null,
      })
      setError(null)
      setSuccess(null)
      setShowDeleteConfirm(false)
      setGroupMembers(group.members || [])
      setShowIdInfo(false) // Reset ID info visibility
    }
  }, [isOpen, group])

  const handleChange = (e) => {
    const { name, value } = e.target

    if (name === "group_progress") {
      const progress = Math.min(100, Math.max(0, Number.parseInt(value) || 0))
      setFormData((prev) => ({ ...prev, [name]: progress }))
    } else if (name === "leader_id") {
      setFormData((prev) => ({ ...prev, [name]: value === "" ? null : value }))
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const updateData = {
        groupname: formData.groupname,
        group_status: formData.group_status,
        leader_id: formData.leader_id,
      }

      const { error } = await supabase.from("projectgroup").update(updateData).eq("groupid", group.id)

      if (error) throw error

      setSuccess("Group updated successfully!")

      if (onGroupUpdated) {
        onGroupUpdated({
          ...group,
          title: formData.groupname,
          progress: group.progress,
          status: formData.group_status,
          leader_id: formData.leader_id,
          members: groupMembers.map((m) => ({
            ...m,
            isLeader: m.id === formData.leader_id,
          })),
        })
      }

      setTimeout(() => {
        setSuccess(null)
        onClose()
      }, 2000)
    } catch (error) {
      console.error("Error updating group:", error)
      setError(`Failed to update group: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteMember = async (memberId) => {
    setMemberActionLoading(true)
    setError(null)

    try {
      const memberToDelete = groupMembers.find((member) => member.id === memberId)
      const memberName = memberToDelete ? memberToDelete.name : "Member"

      const { error } = await supabase.from("student").update({ groupid: null }).eq("student_id", memberId)

      if (error) throw error

      const updatedMembers = groupMembers.filter((member) => member.id !== memberId)
      setGroupMembers(updatedMembers)

      if (memberId === formData.leader_id) {
        setFormData((prev) => ({ ...prev, leader_id: null }))
      }

      setSuccess(`${memberName} has been removed from the group`)

      if (onGroupUpdated) {
        const updatedGroup = {
          ...group,
          members: updatedMembers,
          leader_id: memberId === formData.leader_id ? null : formData.leader_id,
        }
        onGroupUpdated(updatedGroup)
      }

      setDeletingMember(null)

      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (error) {
      console.error("Error removing member:", error)
      setError(`Failed to remove member: ${error.message}`)
    } finally {
      setMemberActionLoading(false)
    }
  }

  const handleDeleteGroup = async () => {
    setDeleting(true)
    setError(null)

    try {
      const { error } = await supabase.from("projectgroup").delete().eq("groupid", group.id)

      if (error) throw error

      if (onGroupDeleted) {
        onGroupDeleted(group.id)
      }

      onClose()
    } catch (error) {
      console.error("Error deleting group:", error)
      setError(`Failed to delete group: ${error.message}`)
      setShowDeleteConfirm(false)
    } finally {
      setDeleting(false)
    }
  }

  const handleCopyEntranceId = () => {
    if (group.entranceId) {
      navigator.clipboard.writeText(group.entranceId)
      setCopiedEntranceId(true)
      setTimeout(() => setCopiedEntranceId(false), 2000)
    }
  }

  const handleCopyGroupId = () => {
    if (group.id) {
      navigator.clipboard.writeText(group.id.toString())
      setCopiedGroupId(true)
      setTimeout(() => setCopiedGroupId(false), 2000)
    }
  }

  if (!isOpen || !group) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b sticky top-0 bg-white z-10 rounded-t-lg">
          <h2 className="text-xl font-semibold text-gray-800">Group Details</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-4 flex-1">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}

          {success && (
            <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md text-sm flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              {success}
            </div>
          )}

          {showDeleteConfirm ? (
            <div className="mb-6">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                <div className="flex items-center mb-2">
                  <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
                  <h3 className="text-lg font-medium text-red-700">Confirm Deletion</h3>
                </div>
                <p className="text-red-600 mb-4">
                  Are you sure you want to delete this group? This action cannot be undone and will remove all
                  associated data.
                </p>
                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowDeleteConfirm(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                    disabled={deleting}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleDeleteGroup}
                    className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                    disabled={deleting}
                  >
                    {deleting ? "Deleting..." : "Yes, Delete Group"}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              {/* Group ID Information Card */}
              <div className="mb-6 bg-blue-50 rounded-lg border border-blue-100 overflow-hidden">
                <div
                  className="flex items-center justify-between p-3 bg-blue-100 cursor-pointer"
                  onClick={() => setShowIdInfo(!showIdInfo)}
                >
                  <div className="flex items-center">
                    <Info className="w-4 h-4 text-blue-600 mr-2" />
                    <h3 className="font-medium text-blue-700">Group Identifiers</h3>
                  </div>
                  <div className="text-blue-600">
                    {showIdInfo ? (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polyline points="18 15 12 9 6 15"></polyline>
                      </svg>
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polyline points="6 9 12 15 18 9"></polyline>
                      </svg>
                    )}
                  </div>
                </div>

                {showIdInfo && (
                  <div className="p-4 space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Group ID</label>
                      <div className="flex items-center">
                        <div className="flex-1 p-2 border border-gray-300 rounded-l-md bg-white text-gray-700 text-sm truncate">
                          {group.id}
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyGroupId}
                          className="p-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-100 hover:bg-gray-200 text-gray-700"
                        >
                          {copiedGroupId ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Entrance ID</label>
                      <div className="flex items-center">
                        <div className="flex-1 p-2 border border-gray-300 rounded-l-md bg-white text-gray-700 text-sm truncate">
                          {group.entranceId}
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyEntranceId}
                          className="p-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-100 hover:bg-gray-200 text-gray-700"
                        >
                          {copiedEntranceId ? (
                            <Check className="w-4 h-4 text-green-600" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">Share this ID to give access to this group</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="mb-4">
                <label htmlFor="groupname" className="block text-sm font-medium text-gray-700 mb-1">
                  Group Name
                </label>
                <input
                  type="text"
                  id="groupname"
                  name="groupname"
                  value={formData.groupname}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Task Completion Progress ({formData.group_progress}%)
                </label>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                  <div
                    className={`${formData.group_status === "late" ? "bg-red-500" : "bg-blue-600"} h-2.5 rounded-full`}
                    style={{ width: `${formData.group_progress}%` }}
                  ></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Progress is automatically calculated based on completed tasks.
                </p>
              </div>

              <div className="mb-6">
                <label htmlFor="group_status" className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  id="group_status"
                  name="group_status"
                  value={formData.group_status}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="late">Late</option>
                  <option value="on track">On Track</option>
                </select>
                <p className="text-xs text-gray-500 mt-1">Note: Group status is independent of progress percentage.</p>
              </div>

              <div className="mb-6">
                <label htmlFor="leader" className="block text-sm font-medium text-gray-700 mb-1">
                  Group Leader
                </label>
                <select
                  id="leader"
                  name="leader_id"
                  value={formData.leader_id || ""}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">No leader</option>
                  {group?.members?.map((member) => (
                    <option key={member.id} value={member.id}>
                      {member.name}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  Select a student to be the group leader, or choose "No leader".
                </p>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Group Members</label>
                {groupMembers.length === 0 ? (
                  <p className="text-sm text-gray-500">No members in this group</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto border border-gray-200 rounded-md p-2">
                    {groupMembers.map((member) => (
                      <div key={member.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                        <div className="flex items-center">
                          <div className="w-7 h-7 bg-gray-200 rounded-full flex items-center justify-center mr-2">
                            <span className="text-xs font-medium">{member.name.charAt(0)}</span>
                          </div>
                          <div>
                            <p className="text-sm font-medium">{member.name}</p>
                            <p className="text-xs text-gray-500">{member.role || "Student"}</p>
                          </div>
                          {member.isLeader && (
                            <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">
                              Leader
                            </span>
                          )}
                        </div>
                        {deletingMember === member.id ? (
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-red-600">Remove?</span>
                            <button
                              type="button"
                              onClick={() => setDeletingMember(null)}
                              className="text-xs px-2 py-1 border border-gray-300 rounded text-gray-700"
                              disabled={memberActionLoading}
                            >
                              No
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteMember(member.id)}
                              className="text-xs px-2 py-1 bg-red-600 text-white rounded"
                              disabled={memberActionLoading}
                            >
                              {memberActionLoading ? "..." : "Yes"}
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setDeletingMember(member.id)}
                            className="text-xs px-2 py-1 text-red-600 hover:bg-red-50 rounded"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">Removing a member will unassign them from this group.</p>
              </div>

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  className="flex items-center px-4 py-2 border border-red-300 text-red-600 rounded-md hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Group
                </button>

                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                    disabled={loading}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="animate-spin mr-2">⏳</span>
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Save Changes
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
