"use client"

import { useState, useEffect, useMemo } from "react"
import { Calendar, momentLocalizer } from "react-big-calendar"
import moment from "moment"
import { supabase } from "@/lib/supabase"
import { Clock, CheckCircle, AlertCircle, CalendarIcon, Plus, XCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useMediaQuery } from "@/hooks/use-media-query"
import { useAuth } from "@/context/auth-context"

// Import the CSS directly - this is important
import "react-big-calendar/lib/css/react-big-calendar.css"

// Setup the localizer for the calendar
const localizer = momentLocalizer(moment)

// Define a color palette for different groups with better contrast
const groupColors = [
  { bg: "#4F46E5", hover: "#4338CA", text: "white" }, // Indigo
  { bg: "#10B981", hover: "#059669", text: "white" }, // Emerald
  { bg: "#F59E0B", hover: "#D97706", text: "white" }, // Amber
  { bg: "#EF4444", hover: "#DC2626", text: "white" }, // Red
  { bg: "#8B5CF6", hover: "#7C3AED", text: "white" }, // Purple
  { bg: "#EC4899", hover: "#DB2777", text: "white" }, // Pink
  { bg: "#06B6D4", hover: "#0891B2", text: "white" }, // Cyan
  { bg: "#F97316", hover: "#EA580C", text: "white" }, // Orange
]

// Meeting status definitions with visual properties - using high contrast colors
// These colors have been selected for high contrast and accessibility
// Each has a WCAG 2.1 AA compliant contrast ratio against both white and black text
const statusConfig = {
  upcoming: {
    label: "Upcoming",
    icon: Clock,
    badgeClass: "bg-blue-100 text-blue-800 border-blue-200",
    color: "#1D4ED8", // blue-700 - darker blue for better contrast
    lightColor: "#DBEAFE", // blue-100
    borderColor: "#1D4ED8", // blue-700
    pattern: "none",
  },
  inProgress: {
    label: "In Progress",
    icon: AlertCircle,
    badgeClass: "bg-amber-100 text-amber-800 border-amber-200",
    color: "#B45309", // amber-700 - darker amber for better contrast
    lightColor: "#FEF3C7", // amber-100
    borderColor: "#B45309", // amber-700
    pattern: "none",
  },
  completed: {
    label: "Completed",
    icon: CheckCircle,
    badgeClass: "bg-green-100 text-green-800 border-green-200",
    color: "#047857", // emerald-700 - darker green for better contrast
    lightColor: "#D1FAE5", // emerald-100
    borderColor: "#047857", // emerald-700
    pattern: "none",
  },
  cancelled: {
    label: "Cancelled",
    icon: XCircle,
    badgeClass: "bg-red-100 text-red-800 border-red-200",
    color: "#B91C1C", // red-700 - darker red for better contrast
    lightColor: "#FEE2E2", // red-100
    borderColor: "#B91C1C", // red-700
    pattern: "striped",
  },
}

// Helper functions for date checking
const isToday = (date) => {
  const today = new Date()
  return (
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
  )
}

const isWeekend = (date) => {
  const day = date.getDay()
  return day === 0 || day === 6 // Sunday (0) or Saturday (6)
}

export default function SupervisorCalendar({
  onSelectMeeting,
  onCreateMeeting,
  instructorId = null, // Add instructorId prop with default value
}) {
  const { user, isLoading: authLoading } = useAuth() // Get authenticated user from context
  const [meetings, setMeetings] = useState([])
  const [loading, setLoading] = useState(true)
  const [groups, setGroups] = useState({})
  const [error, setError] = useState(null)
  const [view, setView] = useState("month")
  const [date, setDate] = useState(new Date())
  const isMobile = useMediaQuery("(max-width: 640px)")

  // Use the instructorId from props or fall back to the authenticated user's ID
  const effectiveInstructorId = useMemo(() => {
    return instructorId || user?.user_id
  }, [instructorId, user])

  // Determine if we're authenticated
  const isAuthenticated = useMemo(() => {
    return !authLoading && !!user
  }, [authLoading, user])

  // Fetch all meetings for all groups supervised by the instructor
  useEffect(() => {
    // Don't fetch if auth is still loading
    if (authLoading) return

    // Don't fetch if not authenticated
    if (!isAuthenticated) {
      setError("Authentication required")
      setLoading(false)
      return
    }

    // Don't fetch if no instructor ID
    if (!effectiveInstructorId) {
      setError("Missing instructor information")
      setLoading(false)
      return
    }

    const fetchSupervisedGroups = async () => {
      try {
        console.log("Fetching supervised groups for instructor:", effectiveInstructorId)

        // Query projectgroup table to get groups where the instructor is the supervisor
        const { data: groupsData, error: groupsError } = await supabase
          .from("projectgroup")
          .select("groupid, groupname")
          .eq("instructor_supervisor_id", effectiveInstructorId) // Use the correct column name

        if (groupsError) {
          console.error("Error fetching supervised groups:", groupsError)
          setError("Failed to load supervised groups")
          return {}
        }

        console.log(`Found ${groupsData?.length || 0} supervised groups for instructor ${effectiveInstructorId}`)

        // Create a map of group IDs to group names and assign colors
        const groupsMap = {}
        const projectIds = []

        groupsData.forEach((group, index) => {
          groupsMap[group.groupid] = {
            name: group.groupname || `Group ${group.groupid.substring(0, 8)}`,
            color: groupColors[index % groupColors.length],
            groupid: group.groupid,
          }

          // Collect project IDs for meeting query
          if (group.groupid) {
            projectIds.push(group.groupid)
          }
        })

        setGroups(groupsMap)
        return { groupsMap, projectIds }
      } catch (error) {
        console.error("Error in fetchSupervisedGroups:", error)
        setError("Failed to load supervised groups")
        return { groupsMap: {}, projectIds: [] }
      }
    }

    const fetchAllMeetings = async () => {
      try {
        setLoading(true)

        // Check if we have a valid instructor ID
        if (!effectiveInstructorId) {
          console.error("No instructor ID provided for fetching meetings")
          setError("Missing instructor information")
          setMeetings([])
          setLoading(false)
          return
        }

        // First get all supervised groups and their project IDs
        const { groupsMap, projectIds } = await fetchSupervisedGroups()

        if (projectIds.length === 0) {
          console.log("No supervised projects found for instructor")
          setMeetings([])
          setLoading(false)
          return
        }

        // Then fetch all meetings for the projects supervised by this instructor
        const { data: meetingsData, error: meetingsError } = await supabase
          .from("meeting")
          .select("*")
          .in("groupid", projectIds) // Filter by project IDs
          .order("scheduletime", { ascending: true })

        if (meetingsError) {
          console.error("Error fetching meetings:", meetingsError)
          setError("Failed to load meetings")
          setMeetings([])
          setLoading(false)
          return
        }

        console.log(`Found ${meetingsData?.length || 0} meetings for supervised projects`)

        // Process meetings with group information and determine status
        const now = new Date()
        const processedMeetings = meetingsData.map((meeting) => {
          // Find the group for this meeting based on project_id
          const groupEntry = Object.entries(groupsMap).find(([_, groupInfo]) => groupInfo.groupid === meeting.groupid)

          const groupInfo = groupEntry
            ? groupEntry[1]
            : { name: `Unknown Group`, color: groupColors[groupColors.length - 1] }

          // Determine meeting status
          const meetingTime = new Date(meeting.scheduletime)
          const endTime = new Date(meetingTime.getTime() + 60 * 60 * 1000) // Assuming 1 hour meetings

          // Default status is upcoming
          let status = "upcoming"

          // Check if meeting is in progress
          if (meetingTime <= now && endTime >= now) {
            status = "inProgress"
          }
          // Check if meeting is completed
          else if (endTime < now) {
            status = "completed"
          }

          // Check if meeting is cancelled (if there's a cancelled field in the data)
          if (meeting.cancelled) {
            status = "cancelled"
          }

          return {
            ...meeting,
            groupName: groupInfo.name,
            groupColor: groupInfo.color,
            status: status,
            formattedTime: formatTime(meetingTime),
          }
        })

        setMeetings(processedMeetings || [])
        setError(null)
      } catch (error) {
        console.error("Error processing meetings:", error)
        setError("Failed to process meetings")
        setMeetings([])
      } finally {
        setLoading(false)
      }
    }

    fetchAllMeetings()

    // Set up real-time subscription for meeting updates
    const meetingsSubscription = supabase
      .channel("meetings-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "meeting" }, () => {
        fetchAllMeetings()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(meetingsSubscription)
    }
  }, [effectiveInstructorId, isAuthenticated, authLoading])

  // Helper function to format time
  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Format meetings for the calendar
  const calendarEvents = useMemo(() => {
    return meetings.map((meeting) => {
      // Ensure title is a string and not empty
      const title = String(meeting.meeting_title || "Untitled Meeting").trim()

      // Create proper start and end dates
      const start = new Date(meeting.scheduletime)
      const end = new Date(new Date(meeting.scheduletime).getTime() + 60 * 60 * 1000) // Default 1 hour duration

      return {
        id: meeting.meetingid,
        title: title,
        start: start,
        end: end,
        resource: meeting,
        groupName: meeting.groupName || "Unknown Group",
        groupColor: meeting.groupColor || { bg: "#4F46E5", text: "white" },
        status: meeting.status || "upcoming",
        formattedTime: meeting.formattedTime || formatTime(start),
        allDay: false,
      }
    })
  }, [meetings])

  // Custom event styling based on status
  const eventStyleGetter = (event) => {
    const status = event.status || "upcoming"
    const statusInfo = statusConfig[status]

    // Base styles
    const style = {
      backgroundColor: statusInfo.color,
      color: "white", // White text for all status colors for better contrast
      borderRadius: "4px",
      padding: "1px 4px",
      fontSize: "12px",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      display: "flex",
      alignItems: "center",
      minHeight: "18px",
      maxHeight: "24px",
      fontWeight: "500",
    }

    // Add special styling for cancelled meetings
    if (status === "cancelled") {
      style.textDecoration = "line-through"
      style.opacity = "0.85"
    }

    return { style }
  }

  // Handle event selection
  const handleSelectEvent = (event) => {
    if (onSelectMeeting && event.resource) {
      onSelectMeeting(event.resource)
    }
  }

  // Simple event component
  const EventComponent = ({ event }) => {
    const status = event.status || "upcoming"
    const StatusIcon = statusConfig[status]?.icon || Clock

    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="rbc-event-content p-1 flex items-center overflow-hidden">
              <div className="flex items-center gap-1 flex-1 overflow-hidden">
                {/* Status indicator */}
                <StatusIcon className="w-3 h-3 flex-shrink-0" />
                <div className="font-medium text-xs truncate">{event.title}</div>
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent side="top" className="bg-white p-3 shadow-lg rounded-lg border z-50 max-w-xs">
            <div className="space-y-2">
              <div className="font-semibold text-lg">{event.title}</div>
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="w-4 h-4 text-gray-500" />
                <span>{event.formattedTime}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: event.groupColor?.bg || "#4F46E5" }}
                ></div>
                <span>{event.groupName}</span>
              </div>
              <Badge
                className="flex items-center gap-1 px-2 py-1 rounded-md"
                style={{
                  backgroundColor: statusConfig[status]?.lightColor,
                  color: statusConfig[status]?.color,
                  border: `1px solid ${statusConfig[status]?.borderColor}`,
                }}
              >
                <StatusIcon className="w-3 h-3 mr-1" />
                {statusConfig[status]?.label || "Upcoming"}
              </Badge>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  // Custom agenda event component to show status
  const AgendaEventComponent = ({ event }) => {
    const status = event.status || "upcoming"
    const StatusIcon = statusConfig[status]?.icon || Clock

    return (
      <div className="flex items-center gap-2">
        <div className="w-3 h-full rounded-l-sm" style={{ backgroundColor: statusConfig[status]?.color }}></div>
        <StatusIcon className="w-4 h-4 flex-shrink-0" style={{ color: statusConfig[status]?.color }} />
        <span className={`font-medium ${status === "cancelled" ? "line-through opacity-75" : ""}`}>{event.title}</span>
        <Badge
          className="ml-auto text-xs px-2"
          style={{
            backgroundColor: statusConfig[status]?.lightColor,
            color: statusConfig[status]?.color,
            border: `1px solid ${statusConfig[status]?.borderColor}`,
          }}
        >
          {statusConfig[status]?.label}
        </Badge>
      </div>
    )
  }

  // Custom toolbar component
  const CustomToolbar = (toolbar) => {
    return (
      <div className="rbc-toolbar flex flex-wrap justify-between items-center p-4 border-b">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => toolbar.onNavigate("TODAY")}
            className="px-3 py-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-md text-sm font-medium"
          >
            Today
          </button>
          <div className="flex rounded-md overflow-hidden border border-gray-300">
            <button
              type="button"
              onClick={() => toolbar.onNavigate("PREV")}
              className="px-2 py-1.5 bg-white hover:bg-gray-50 text-gray-700 text-sm border-r border-gray-300"
            >
              Back
            </button>
            <button
              type="button"
              onClick={() => toolbar.onNavigate("NEXT")}
              className="px-2 py-1.5 bg-white hover:bg-gray-50 text-gray-700 text-sm"
            >
              Next
            </button>
          </div>
        </div>

        <span className="rbc-toolbar-label text-lg font-semibold text-gray-800 my-2 md:my-0">{toolbar.label}</span>

        <div className="flex items-center">
          <div className="flex rounded-md overflow-hidden border border-gray-300">
            {toolbar.views.map((viewOption) => (
              <button
                key={viewOption}
                type="button"
                onClick={() => toolbar.onView(viewOption)}
                className={`px-3 py-1.5 text-sm ${
                  viewOption === toolbar.view
                    ? "bg-blue-50 text-blue-600 font-medium"
                    : "bg-white text-gray-700 hover:bg-gray-50"
                } ${viewOption !== toolbar.views[toolbar.views.length - 1] ? "border-r border-gray-300" : ""}`}
              >
                {viewOption.charAt(0).toUpperCase() + viewOption.slice(1)}
              </button>
            ))}

            {/* Schedule Meeting button */}
            {onCreateMeeting && (
              <button
                type="button"
                onClick={onCreateMeeting}
                className="inline-flex items-center px-4 py-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-600 shadow-sm transition-colors duration-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Schedule</span>
              </button>
            )}
          </div>
        </div>
      </div>
    )
  }

  // Status legend component with high contrast colors
  const StatusLegend = () => {
    return (
      <div className="flex flex-wrap items-center justify-end gap-4 px-4 py-2 bg-white border-t border-gray-200 text-xs">
        {Object.entries(statusConfig).map(([key, config]) => (
          <div key={key} className="flex items-center gap-1">
            <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: config.color }} aria-hidden="true"></div>
            <config.icon className="w-3 h-3" style={{ color: config.color }} aria-hidden="true" />
            <span>{config.label}</span>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="h-full bg-white flex flex-col">
      {loading ? (
        <div className="flex justify-center items-center h-full">
          <div className="flex flex-col items-center gap-2">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            <p className="text-sm text-gray-500">Loading calendar...</p>
          </div>
        </div>
      ) : error ? (
        <div className="flex justify-center items-center h-full">
          <div className="text-red-500 text-center p-4">
            <p className="font-medium">Error loading calendar</p>
            <p className="text-sm">{error}</p>
            {!effectiveInstructorId && (
              <p className="mt-2 text-sm">Please ensure you are logged in as an instructor.</p>
            )}
          </div>
        </div>
      ) : (
        <>
          <div className="flex-1">
            {/* Add a small amount of custom CSS to fix any remaining issues */}
            <style jsx global>{`
  /* Ensure the calendar takes full height */
  .rbc-calendar {
    height: 100%;
    font-family: ui-sans-serif, system-ui, sans-serif;
  }
  
  /* Fix month view layout */
  .rbc-month-view {
    flex: 1;
    border: 1px solid #ddd;
    height: 100%;
    overflow: hidden;
  }
  
  /* Ensure month rows display correctly */
  .rbc-month-row {
    display: flex;
    flex-direction: row;
    overflow: hidden;
  }
  
  /* Fix day cells */
  .rbc-day-bg {
    flex: 1;
  }
  
  /* Fix date cells */
  .rbc-date-cell {
    text-align: right;
    padding-right: 5px;
    font-size: 0.85rem;
  }
  
  /* Fix row content */
  .rbc-row-content {
    z-index: 1;
  }
  
  /* Fix row content rows */
  .rbc-row {
    display: flex;
    flex-direction: row;
  }
  
  /* Fix event positioning */
  .rbc-event {
    z-index: 2;
    margin: 1px 0;
    padding: 0;
  }
  
  /* Fix event content */
  .rbc-event-content {
    width: 100%;
    height: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  /* Fix event label */
  .rbc-event-label {
    display: none;
  }
  
  /* Fix toolbar on mobile */
  @media (max-width: 640px) {
    .rbc-toolbar {
      flex-direction: column;
      align-items: stretch;
    }
    
    .rbc-toolbar-label {
      margin: 10px 0;
    }
  }
  
  /* Fix overlapping events */
  .rbc-events-container {
    margin-right: 0 !important;
  }
  
  /* Fix today highlight */
  .rbc-today {
    background-color: rgba(239, 246, 255, 0.6);
  }

  /* Style agenda view */
  .rbc-agenda-view table.rbc-agenda-table {
    border: 1px solid #ddd;
  }

  .rbc-agenda-view table.rbc-agenda-table thead > tr > th {
    padding: 8px;
    background-color: #f9fafb;
  }

  .rbc-agenda-view table.rbc-agenda-table tbody > tr > td {
    padding: 8px;
  }
`}</style>

            <Calendar
              localizer={localizer}
              events={calendarEvents}
              startAccessor="start"
              endAccessor="end"
              style={{ height: "100%" }}
              eventPropGetter={eventStyleGetter}
              onSelectEvent={handleSelectEvent}
              views={["month", "week", "day", "agenda"]}
              view={view}
              onView={setView}
              date={date}
              onNavigate={setDate}
              defaultView="month"
              popup
              components={{
                toolbar: CustomToolbar,
                event: EventComponent,
                agenda: {
                  event: AgendaEventComponent,
                },
              }}
              formats={{
                eventTimeRangeFormat: () => "", // Hide the time range in month view
              }}
              dayPropGetter={(date) => ({
                className: isToday(date) ? "rbc-today" : "",
              })}
              slotPropGetter={(date) => ({
                className: isWeekend(date) ? "rbc-weekend" : "",
              })}
              min={new Date(0, 0, 0, 7, 0, 0)} // Start day at 7 AM
              max={new Date(0, 0, 0, 19, 0, 0)} // End day at 7 PM
            />
          </div>
          <StatusLegend />
        </>
      )}
    </div>
  )
}
