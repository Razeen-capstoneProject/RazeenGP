"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import { X, Send, Paperclip, File, AlertTriangle, Trash, Plus, Search } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { markAllMessagesAsRead } from "@/lib/chat-notification-utils"

export default function ChatModal({ isOpen, onClose, groupId, currentUser }) {
  // Existing state variables...
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [chatId, setChatId] = useState(null)
  const messagesEndRef = useRef(null)
  const chatContainerRef = useRef(null)
  const fileInputRef = useRef(null)
  const [attachedFiles, setAttachedFiles] = useState([])
  const [uploadError, setUploadError] = useState(null)
  const [supabaseError, setSupabaseError] = useState(null)
  const [bucketStatus, setBucketStatus] = useState({ exists: false, canUpload: false })
  const [testUploadResult, setTestUploadResult] = useState(null)
  const [groupInfo, setGroupInfo] = useState(null)
  const [creatingChat, setCreatingChat] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState([])
  const [currentResultIndex, setCurrentResultIndex] = useState(0)
  const [uploadProgress, setUploadProgress] = useState(0)

  // Determine if the current user is a supervisor
  const isSupervisor = currentUser?.role === "Supervisor" || currentUser?.role === "supervisor"

  // Helper function to get current user's display name
  const getCurrentUserName = () => {
    return currentUser?.userName || "Me"
  }

  useEffect(() => {
    if (isOpen) {
      checkBucketStatus()
      fetchChatAndMessages()

      // Mark all messages as read when the chat is opened
      if (chatId && currentUser?.user_id && messages.length > 0) {
        markAllMessagesAsRead(chatId, currentUser.user_id, messages)
      }
    }
  }, [isOpen, groupId, chatId])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // This will filter messages based on the search query
  const filteredMessages = useMemo(() => {
    if (!searchQuery.trim()) {
      return messages
    }

    const query = searchQuery.toLowerCase()
    return messages.filter((message) => {
      const messageText = message.content?.content || message.content?.text || ""
      return messageText.toLowerCase().includes(query)
    })
  }, [messages, searchQuery])

  // Add this function to handle search
  const handleSearch = (e) => {
    setSearchQuery(e.target.value)
    if (e.target.value.trim()) {
      setIsSearching(true)

      // Find all messages that match the search query
      const query = e.target.value.toLowerCase()
      const results = messages.filter((message) => {
        const messageText = message.content?.content || message.content?.text || ""
        return messageText.toLowerCase().includes(query)
      })

      setSearchResults(results)
      setCurrentResultIndex(0)

      // Scroll to the first result if there are any
      if (results.length > 0) {
        const firstResultId = results[0].messageid
        const element = document.getElementById(`message-${firstResultId}`)
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" })
        }
      }
    } else {
      setIsSearching(false)
      setSearchResults([])
    }
  }

  // Add this function to navigate between search results
  const navigateSearchResults = (direction) => {
    if (searchResults.length === 0) return

    let newIndex
    if (direction === "next") {
      newIndex = (currentResultIndex + 1) % searchResults.length
    } else {
      newIndex = (currentResultIndex - 1 + searchResults.length) % searchResults.length
    }

    setCurrentResultIndex(newIndex)

    // Scroll to the selected result
    const resultId = searchResults[newIndex].messageid
    const element = document.getElementById(`message-${resultId}`)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "center" })
    }
  }

  // Add this function to clear the search
  const clearSearch = () => {
    setSearchQuery("")
    setIsSearching(false)
    setSearchResults([])
    setCurrentResultIndex(0)
  }

  const checkBucketStatus = async () => {
    try {
      // Simple test to see if we can list files in the bucket
      const { data, error } = await supabase.storage.from("chat-attachments").list()

      if (error) {
        console.error("Cannot access chat-attachments bucket:", error)
        setBucketStatus({
          exists: false,
          canUpload: false,
          message: "Cannot access the file storage bucket. You can still send text messages.",
        })
      } else {
        console.log("Successfully accessed chat-attachments bucket")
        setBucketStatus({ exists: true, canUpload: true })
      }
    } catch (error) {
      console.error("Error checking bucket:", error)
      setBucketStatus({
        exists: false,
        canUpload: false,
        message: "Error checking file storage: " + error.message,
      })
    }
  }

  // Updated function to fetch supervisor-student chat
  const fetchChatAndMessages = async () => {
    setLoading(true)
    try {
      console.log(`Fetching chat for group_id: ${groupId}`)

      // Find the supervisor chat for this group
      const { data: chatData, error: chatError } = await supabase
        .from("chat")
        .select("*")
        .eq("group_id", groupId)
        .ilike("chatname", "supervisor_students_chats_%")
        .single()

      if (chatError) {
        if (chatError.code === "PGRST116") {
          // Chat not found - handle gracefully
          console.log(`Supervisor chat for group ${groupId} not found`)

          // Set chat ID to null initially
          setChatId(null)

          // For supervisors, we can create the chat if it doesn't exist
          if (isSupervisor) {
            await createSupervisorChat(groupId)
          } else {
            // For students, just show a message that no chat exists
            setMessages([])
            setLoading(false)
          }
        } else {
          // Other error
          console.error("Error fetching chat:", chatError)
          throw chatError
        }
      } else {
        // Chat found
        console.log("Found supervisor chat data:", chatData)
        setChatId(chatData.chatid)

        // Fetch messages for this chat
        await fetchMessages(chatData.chatid)
      }

      // Fetch group info
      await fetchGroupInfo()
    } catch (error) {
      console.error("Error in fetchChatAndMessages:", error)
      setMessages([])
      setLoading(false)
    }
  }

  // Function to create a supervisor chat if it doesn't exist
  const createSupervisorChat = async (groupId) => {
    try {
      setCreatingChat(true)

      console.log(`Creating supervisor chat for group ${groupId}`)

      // Get group name to create a proper chat name
      const { data: groupData, error: groupError } = await supabase
        .from("projectgroup")
        .select("groupname")
        .eq("groupid", groupId)
        .single()

      if (groupError) {
        console.error("Error fetching group data:", groupError)
        throw groupError
      }

      // Generate a chat name based on group name
      const groupName = groupData.groupname || `group_${groupId}`
      const chatName = `supervisor_students_chats_${groupName.toLowerCase().replace(/\s+/g, "_")}`

      // Get the next available chat ID
      const { data: maxChatId, error: maxChatIdError } = await supabase
        .from("chat")
        .select("chatid")
        .order("chatid", { ascending: false })
        .limit(1)
        .single()

      if (maxChatIdError && maxChatIdError.code !== "PGRST116") {
        console.error("Error getting max chat ID:", maxChatIdError)
        throw maxChatIdError
      }

      const nextChatId = maxChatId ? maxChatId.chatid + 1 : 1

      // Insert the new chat
      const { data, error } = await supabase
        .from("chat")
        .insert([
          {
            chatid: nextChatId,
            chatname: chatName,
            group_id: groupId,
          },
        ])
        .select()

      if (error) {
        console.error("Error creating supervisor chat:", error)
        throw error
      }

      console.log("Created supervisor chat:", data)

      // Set the chat ID and fetch messages (which will be empty for a new chat)
      setChatId(nextChatId)

      // Add a system message to indicate this is a new chat
      const systemMessage = {
        messageid: "system-welcome",
        content: {
          content: "This is a new supervisor chat. Start the conversation by sending a message.",
        },
        messagetime: new Date().toISOString(),
        user_id: "system",
        users: { userName: "System" },
      }

      setMessages([systemMessage])
    } catch (error) {
      console.error("Error in createSupervisorChat:", error)
      setUploadError("Failed to create supervisor chat. Please try again.")
    } finally {
      setCreatingChat(false)
      setLoading(false)
    }
  }

  const fetchGroupInfo = async () => {
    try {
      const { data, error } = await supabase.from("projectgroup").select("groupname").eq("groupid", groupId).single()

      if (error) {
        console.error("Error fetching group info:", error)
        setGroupInfo(null)
      } else {
        setGroupInfo(data)
      }
    } catch (error) {
      console.error("Error fetching group info:", error)
      setGroupInfo(null)
    }
  }

  const fetchMessages = async (activeChatId) => {
    try {
      console.log("Fetching messages for chatid:", activeChatId)

      // Now fetch messages
      const { data: messagesData, error: messagesError } = await supabase
        .from("message")
        .select(`
        messageid,
        content,
        messagetime,
        chatid,
        user_id,
        users:user_id (
          userName,
          user_id,
          role
        )
      `)
        .eq("chatid", activeChatId)
        .order("messagetime", { ascending: true })

      if (messagesError) {
        console.error("Error fetching messages:", messagesError)
        throw messagesError
      }

      console.log("Raw messages data:", messagesData)

      const formattedMessages =
        messagesData?.map((message) => {
          let messageContent

          try {
            if (typeof message.content === "string") {
              try {
                const parsed = JSON.parse(message.content)
                messageContent = parsed
              } catch {
                messageContent = { content: message.content }
              }
            } else if (typeof message.content === "object") {
              messageContent = message.content
            } else {
              messageContent = { content: "Unknown content format" }
            }

            // Process "see attachment" messages
            if (messageContent.content === "see" || messageContent.content === "see attachment") {
              messageContent.content = ""
            }
            if (messageContent.text === "see" || messageContent.text === "see attachment") {
              messageContent.text = ""
            }
          } catch (e) {
            console.error("Error parsing message content:", e)
            messageContent = { content: "Error displaying message" }
          }

          return {
            ...message,
            content: messageContent,
          }
        }) || []

      console.log("Formatted messages:", formattedMessages)
      setMessages(formattedMessages)

      // Mark all messages as read when they're fetched
      if (activeChatId && currentUser?.user_id && formattedMessages.length > 0) {
        markAllMessagesAsRead(activeChatId, currentUser.user_id, formattedMessages)
      }
    } catch (error) {
      console.error("Error in fetchMessages:", error)
      setMessages([])
    } finally {
      setLoading(false)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files)
    if (files.length === 0) return

    // Check file size for each file (max 10MB)
    const validFiles = files.filter((file) => {
      if (file.size > 10 * 1024 * 1024) {
        setUploadError(`File ${file.name} is too large. Maximum size is 10MB.`)
        return false
      }
      return true
    })

    setAttachedFiles((prev) => [...prev, ...validFiles])
    // Clear any previous upload errors
    setUploadError(null)
    setTestUploadResult(null)

    // Reset the file input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const testSimpleUpload = async (file) => {
    try {
      setTestUploadResult({ status: "testing", message: "Testing upload..." })

      // Create a simple file path
      const fileName = `test-${Date.now()}-${file.name}`

      // Direct upload
      const { data, error } = await supabase.storage.from("chat-attachments").upload(fileName, file, {
        cacheControl: "3600",
        contentType: file.type,
      })

      if (error) {
        setTestUploadResult({
          status: "error",
          message: `Upload failed: ${error.message}`,
        })
        return false
      }

      // Get URL
      const { data: urlData } = supabase.storage.from("chat-attachments").getPublicUrl(fileName)

      setTestUploadResult({
        status: "success",
        message: "Test upload successful!",
        url: urlData?.publicUrl,
      })

      // Force refresh bucket status
      await checkBucketStatus()

      return true
    } catch (error) {
      setTestUploadResult({
        status: "error",
        message: `Test error: ${error.message}`,
      })
      return false
    }
  }

  const uploadFile = async (file) => {
    try {
      // Create a unique file name to prevent collisions
      const fileExtension = file.name.split(".").pop()
      const uniqueId = `${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
      const fileName = `${uniqueId}.${fileExtension}`
      const filePath = `${groupId}/${fileName}`

      console.log(`Uploading file: ${file.name} to path: ${filePath}`)

      // Direct upload to the bucket
      const { data, error } = await supabase.storage.from("chat-attachments").upload(filePath, file, {
        cacheControl: "3600",
        contentType: file.type,
        onUploadProgress: (progress) => {
          const percent = Math.round((progress.loaded / progress.total) * 100)
          setUploadProgress(percent)
        },
      })

      if (error) {
        console.error("Upload error:", error)
        throw new Error(error.message)
      }

      // Get the public URL
      const { data: urlData } = supabase.storage.from("chat-attachments").getPublicUrl(filePath)

      // Return file metadata
      return {
        name: file.name,
        path: filePath,
        url: urlData.publicUrl,
        type: file.type,
        size: file.size,
        bucket: "chat-attachments",
      }
    } catch (error) {
      console.error("Error uploading file:", error)
      setUploadError(`Failed to upload file: ${error.message}`)
      return null
    }
  }

  const handleSendMessage = async (e) => {
    e.preventDefault()
    if ((!newMessage.trim() && attachedFiles.length === 0) || !chatId) return

    setSending(true)
    setUploadError(null)
    setUploadProgress(0)

    try {
      const userId = currentUser?.user_id 
      const userName = getCurrentUserName()

      // Prepare message content
      const messageContent = {
        text: newMessage.trim(),
        files: [],
      }

      // Upload files if attached
      if (attachedFiles.length > 0) {
        const uploadedFiles = []

        for (let i = 0; i < attachedFiles.length; i++) {
          const file = attachedFiles[i]
          const fileMetadata = await uploadFile(file)

          if (!fileMetadata) {
            setSending(false)
            return // Stop if file upload failed
          }

          uploadedFiles.push(fileMetadata)
        }

        messageContent.files = uploadedFiles

        // For backward compatibility
        if (uploadedFiles.length > 0) {
          messageContent.file = uploadedFiles[0]
        }
      }

      // Insert message with JSON content
      const { error } = await supabase.from("message").insert([
        {
          chatid: chatId,
          user_id: userId,
          content: messageContent,
          messagetime: new Date().toISOString(),
        },
      ])

      if (error) throw error

      // Refresh messages
      await fetchMessages(chatId)
      setNewMessage("")
      setAttachedFiles([])
      setUploadError(null)
      setUploadProgress(0)
    } catch (error) {
      console.error("Error sending message:", error)
      setUploadError("Failed to send message: " + error.message)
    } finally {
      setSending(false)
    }
  }

  const formatTime = (timestamp) => {
    try {
      const date = new Date(timestamp)
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } catch (error) {
      return ""
    }
  }

  const formatMessageDate = (timestamp) => {
    try {
      const date = new Date(timestamp)
      const today = new Date()
      const yesterday = new Date(today)
      yesterday.setDate(yesterday.getDate() - 1)

      if (date.toDateString() === today.toDateString()) {
        return "Today"
      } else if (date.toDateString() === yesterday.toDateString()) {
        return "Yesterday"
      } else {
        return date.toLocaleDateString(undefined, {
          weekday: "long",
          month: "short",
          day: "numeric",
        })
      }
    } catch (error) {
      return ""
    }
  }

  const groupMessagesByDate = (messageList = messages) => {
    const groups = {}

    messageList.forEach((message) => {
      const date = formatMessageDate(message.messagetime)
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(message)
    })

    return groups
  }

  const messageGroups = groupMessagesByDate()

  const handleDeleteMessage = async (messageId) => {
    try {
      // Delete the message from the database
      const { error } = await supabase.from("message").delete().eq("messageid", messageId)

      if (error) {
        console.error("Error deleting message:", error)
        setUploadError(`Failed to delete message: ${error.message}`)
        return
      }

      // If message had files, delete them from storage
      const messageToDelete = messages.find((msg) => msg.messageid === messageId)

      // Handle single file (old format)
      if (messageToDelete?.content?.file?.path) {
        const { error: storageError } = await supabase.storage
          .from("chat-attachments")
          .remove([messageToDelete.content.file.path])

        if (storageError) {
          console.error("Error deleting file:", storageError)
          // Continue even if file deletion fails
        }
      }

      // Handle multiple files (new format)
      if (messageToDelete?.content?.files && Array.isArray(messageToDelete.content.files)) {
        const filePaths = messageToDelete.content.files.filter((file) => file && file.path).map((file) => file.path)

        if (filePaths.length > 0) {
          const { error: storageError } = await supabase.storage.from("chat-attachments").remove(filePaths)

          if (storageError) {
            console.error("Error deleting files:", storageError)
            // Continue even if file deletion fails
          }
        }
      }

      // Update the messages list
      setMessages(messages.filter((msg) => msg.messageid !== messageId))
      setUploadError(null)
    } catch (error) {
      console.error("Error in handleDeleteMessage:", error)
      setUploadError(`Failed to delete message: ${error.message}`)
    }
  }

  const removeAttachedFile = (index) => {
    setAttachedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  // Add this function to highlight search text
  const highlightSearchText = (text, query) => {
    if (!query.trim()) return text

    const parts = text.split(new RegExp(`(${query})`, "gi"))
    return parts.map((part, index) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <span key={index} className="bg-yellow-200 text-gray-900">
          {part}
        </span>
      ) : (
        part
      ),
    )
  }

  if (supabaseError) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full">
          <h2 className="text-xl font-semibold text-red-600 mb-4">Error</h2>
          <p className="text-gray-700">{supabaseError}</p>
          <button onClick={onClose} className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
            Close
          </button>
        </div>
      </div>
    )
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <style jsx global>{`
        @keyframes pulseOnce {
          0% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.5); }
          70% { box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); }
          100% { box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); }
        }
        .animate-pulse-once {
          animation: pulseOnce 1s 1;
        }
      `}</style>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl h-[80vh] flex flex-col">
        {/* Chat Header */}
        <div className="flex flex-col border-b">
          <div className="flex justify-between items-center p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-indigo-600 font-medium">G</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-800">
                  {groupInfo?.groupname ? `${groupInfo.groupname} Chat` : "Group Chat"}
                  <span className="ml-2 text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
                    Supervisor Chat
                  </span>
                </h2>
                <p className="text-sm text-gray-500">{loading ? "Loading..." : `${messages.length} messages`}</p>
              </div>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => setIsSearching(!isSearching)}
                className={`mr-2 p-2 rounded-full hover:bg-gray-100 ${isSearching ? "bg-blue-100 text-blue-600" : "text-gray-500"}`}
                title="Search messages"
              >
                <Search className="w-5 h-5" />
              </button>
              <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search Bar */}
          {isSearching && (
            <div className="px-4 pb-3 flex items-center">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <Search className="w-4 h-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={handleSearch}
                  placeholder="Search in conversation..."
                  className="w-full pl-10 pr-16 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                />
                {searchQuery && (
                  <div className="absolute inset-y-0 right-0 flex items-center pr-2">
                    <button onClick={clearSearch} className="p-1 rounded-full hover:bg-gray-100" title="Clear search">
                      <X className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                )}
              </div>
              {searchResults.length > 0 && (
                <div className="ml-2 flex items-center text-sm">
                  <span className="text-gray-600 mr-2">
                    {currentResultIndex + 1}/{searchResults.length}
                  </span>
                  <div className="flex">
                    <button
                      onClick={() => navigateSearchResults("prev")}
                      className="p-1 rounded-l border border-gray-300 hover:bg-gray-100"
                      title="Previous result"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-gray-600"
                      >
                        <polyline points="15 18 9 12 15 6"></polyline>
                      </svg>
                    </button>
                    <button
                      onClick={() => navigateSearchResults("next")}
                      className="p-1 rounded-r border-t border-r border-b border-gray-300 hover:bg-gray-100"
                      title="Next result"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-gray-600"
                      >
                        <polyline points="9 18 15 12 9 6"></polyline>
                      </svg>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* No chat found message */}
        {!loading && !chatId && !creatingChat && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 flex items-start">
            <AlertTriangle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">No supervisor chat found for this group</p>
              {isSupervisor ? (
                <div>
                  <p className="text-sm mb-2">Would you like to create a supervisor chat for this group?</p>
                  <button
                    onClick={() => createSupervisorChat(groupId)}
                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 flex items-center"
                  >
                    <Plus className="w-3 h-3 mr-1" /> Create Supervisor Chat
                  </button>
                </div>
              ) : (
                <p className="text-sm">Please contact your supervisor to start a chat.</p>
              )}
            </div>
          </div>
        )}

        {/* Creating chat message */}
        {creatingChat && (
          <div className="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 flex items-center">
            <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-blue-700 mr-2"></div>
            <p>Creating supervisor chat...</p>
          </div>
        )}

        {/* Display bucket status warning if needed */}
        {!bucketStatus.canUpload && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 flex items-start">
            <AlertTriangle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">File uploads unavailable</p>
              <p className="text-sm">{bucketStatus.message}</p>
              <p className="text-sm mt-1">You can still send text messages.</p>
            </div>
          </div>
        )}

        {/* Display test upload result if available */}
        {testUploadResult && (
          <div
            className={`p-4 border-b ${
              testUploadResult.status === "success"
                ? "bg-green-50 border-green-200 text-green-700"
                : testUploadResult.status === "error"
                  ? "bg-red-50 border-red-200 text-red-700"
                  : "bg-blue-50 border-blue-200 text-blue-700"
            }`}
          >
            <p className="font-medium">{testUploadResult.message}</p>
            {testUploadResult.url && (
              <div className="mt-2 text-sm">
                <a href={testUploadResult.url} target="_blank" rel="noopener noreferrer" className="underline">
                  View uploaded file
                </a>
              </div>
            )}
            {testUploadResult.details && (
              <pre className="mt-2 text-xs overflow-auto max-h-20 p-2 bg-gray-100 rounded">
                {JSON.stringify(testUploadResult.details, null, 2)}
              </pre>
            )}
          </div>
        )}

        {/* Chat Messages */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 bg-gray-50">
          {loading ? (
            <div className="flex justify-center items-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <p className="text-center">No messages found in the database</p>
              <p className="text-center text-sm mt-2">Start the conversation by sending a message</p>
            </div>
          ) : isSearching && searchQuery && filteredMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <p className="text-center">No messages match your search</p>
              <p className="text-center text-sm mt-2">Try a different search term</p>
            </div>
          ) : (
            Object.entries(isSearching && searchQuery ? groupMessagesByDate(filteredMessages) : messageGroups).map(
              ([date, dateMessages]) => (
                <div key={date} className="mb-6">
                  <div className="flex justify-center mb-4">
                    <span className="text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-full">{date}</span>
                  </div>

                  {dateMessages.map((message, index) => {
                    // Update the isCurrentUser check in the message rendering
                    const isCurrentUser =
                      message.user_id === (currentUser?.user_id)
                    const showSender = index === 0 || dateMessages[index - 1].user_id !== message.user_id
                    const isSystemMessage = message.user_id === "system"

                    // Get sender name - "Me" for current user, or the user's name
                    const senderName = isSystemMessage
                      ? "System"
                      : isCurrentUser
                        ? "Me"
                        : message.users?.userName || "Unknown User"

                    // Extract message content safely
                    const messageText = message.content?.content || message.content?.text || ""

                    // Handle both single file and multiple files formats
                    const fileData = message.content?.file || {
                      url: message.content?.fileUrl,
                      name: message.content?.fileName,
                      type: message.content?.fileType,
                    }

                    const filesArray = message.content?.files || []
                    // If there's a single file but no files array, add it to the array
                    const allFiles = filesArray.length > 0 ? filesArray : fileData?.url ? [fileData] : []

                    return (
                      <div
                        id={`message-${message.messageid}`}
                        key={message.messageid}
                        className={`mb-4 flex ${isSystemMessage ? "justify-center" : isCurrentUser ? "justify-end" : "justify-start"} ${
                          searchResults.some((result) => result.messageid === message.messageid)
                            ? "animate-pulse-once"
                            : ""
                        }`}
                      >
                        {isSystemMessage ? (
                          <div className="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg text-sm max-w-[80%] text-center">
                            {messageText}
                          </div>
                        ) : (
                          <div className={`max-w-[75%] relative group`}>
                            {/* Always show sender name with improved styling */}
                            <div className={`text-sm mb-1 ${isCurrentUser ? "text-right mr-2" : "ml-2"}`}>
                              <span className={`font-medium ${isCurrentUser ? "text-blue-600" : "text-gray-700"}`}>
                                {senderName}
                              </span>
                            </div>

                            <div className="flex items-end">
                              {!isCurrentUser && (
                                <div className="w-8 h-8 rounded-full bg-gray-300 flex-shrink-0 mr-2 flex items-center justify-center">
                                  <span className="text-xs font-medium">
                                    {(message.users?.userName || "U").charAt(0)}
                                  </span>
                                </div>
                              )}

                              <div
                                className={`rounded-lg px-4 py-2 ${
                                  isCurrentUser
                                    ? "bg-blue-500 text-white rounded-br-none shadow-sm"
                                    : "bg-white border border-gray-200 rounded-bl-none shadow-sm"
                                }`}
                              >
                                {messageText && (
                                  <div className="whitespace-pre-wrap break-words">
                                    {searchQuery && isSearching
                                      ? highlightSearchText(messageText, searchQuery)
                                      : messageText}
                                  </div>
                                )}

                                {/* Display all files */}
                                {allFiles.length > 0 && (
                                  <div className="mt-2 space-y-2">
                                    {allFiles.map((file, fileIndex) => {
                                      if (!file || !file.url) return null

                                      if (
                                        file.type?.startsWith("image/") ||
                                        file.url.toLowerCase().match(/\.(jpeg|jpg|gif|png|webp)$/)
                                      ) {
                                        return (
                                          <a
                                            key={fileIndex}
                                            href={file.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="block"
                                          >
                                            <img
                                              src={file.url || "/placeholder.svg"}
                                              alt={file.name || "Attached image"}
                                              className="max-w-full max-h-48 rounded border border-gray-200"
                                            />
                                          </a>
                                        )
                                      } else if (
                                        file.type === "application/pdf" ||
                                        file.url.toLowerCase().endsWith(".pdf")
                                      ) {
                                        return (
                                          <a
                                            key={fileIndex}
                                            href={file.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center text-sm bg-red-50 text-red-700 p-2 rounded border border-red-200"
                                          >
                                            <File className="w-4 h-4 mr-1" />
                                            {file.name || "PDF Document"}
                                            {file.size && (
                                              <span className="ml-1 text-xs text-gray-500">
                                                ({(file.size / 1024).toFixed(1)} KB)
                                              </span>
                                            )}
                                          </a>
                                        )
                                      } else {
                                        return (
                                          <a
                                            key={fileIndex}
                                            href={file.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="flex items-center text-sm bg-gray-50 text-gray-700 p-2 rounded border border-gray-200"
                                          >
                                            <File className="w-4 h-4 mr-1" />
                                            {file.name || "Attached file"}
                                            {file.size && (
                                              <span className="ml-1 text-xs text-gray-500">
                                                ({(file.size / 1024).toFixed(1)} KB)
                                              </span>
                                            )}
                                          </a>
                                        )
                                      }
                                    })}
                                  </div>
                                )}

                                <div
                                  className={`text-xs mt-1 text-right ${isCurrentUser ? "text-blue-100" : "text-gray-500"}`}
                                >
                                  {formatTime(message.messagetime)}
                                </div>
                              </div>
                            </div>

                            {/* Message actions dropdown - only visible on hover and for current user's messages */}
                            {isCurrentUser && (
                              <div className="absolute top-0 right-0 -mt-1 -mr-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="relative">
                                  <button
                                    className="p-1 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600"
                                    onClick={() => handleDeleteMessage(message.messageid)}
                                    title="Delete message"
                                  >
                                    <Trash className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              ),
            )
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Typing indicator (placeholder for future functionality) */}
        <div className="px-3 py-1 text-xs text-gray-500 border-t">
          <span className="italic">Messages will appear with sender identification</span>
        </div>

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="border-t border-gray-200 p-4 bg-white">
          {uploadError && <div className="mb-2 px-3 py-2 bg-red-50 text-red-600 text-sm rounded">{uploadError}</div>}

          {/* Display attached files */}
          {attachedFiles.length > 0 && (
            <div className="mb-3">
              <div className="text-xs text-gray-500 mb-1">Attached files:</div>
              <div className="flex flex-wrap gap-2">
                {attachedFiles.map((file, index) => (
                  <div key={index} className="flex items-center bg-gray-100 rounded px-2 py-1 text-sm">
                    <File className="w-3 h-3 mr-1 text-gray-500" />
                    <span className="truncate max-w-[150px]">{file.name}</span>
                    <button
                      type="button"
                      onClick={() => removeAttachedFile(index)}
                      className="ml-1 text-gray-500 hover:text-red-500"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload progress bar */}
          {sending && uploadProgress > 0 && uploadProgress < 100 && (
            <div className="mb-2">
              <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
              <div className="text-xs text-gray-500 mt-1 text-right">{uploadProgress}% uploading...</div>
            </div>
          )}

          <div className="flex items-center w-full">
            <div className="flex space-x-2 mr-2 flex-shrink-0">
              <button
                type="button"
                className={`text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 ${!bucketStatus.canUpload ? "opacity-50 cursor-not-allowed" : ""}`}
                onClick={() => bucketStatus.canUpload && fileInputRef.current.click()}
                disabled={!bucketStatus.canUpload}
                title={bucketStatus.canUpload ? "Attach files" : "File uploads unavailable"}
              >
                <Paperclip className="w-5 h-5" />
              </button>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                disabled={!bucketStatus.canUpload}
                multiple
              />

              {attachedFiles.length > 0 && (
                <button
                  type="button"
                  onClick={() => testSimpleUpload(attachedFiles[0])}
                  className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded"
                  title="Test upload directly"
                >
                  Test Upload
                </button>
              )}
            </div>

            <div className="flex-1 flex items-center">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type a message..."
                className="w-full border border-gray-300 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={sending || !chatId}
              />
            </div>

            <button
              type="submit"
              disabled={(!newMessage.trim() && attachedFiles.length === 0) || sending || !chatId}
              className={`ml-2 p-2 rounded-full flex-shrink-0 ${
                (!newMessage.trim() && attachedFiles.length === 0) || sending || !chatId
                  ? "bg-gray-200 text-gray-500"
                  : "bg-blue-500 text-white hover:bg-blue-600"
              }`}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
