"use client"

import { useState, useEffect } from "react"
import { countUnreadMessages } from "@/lib/chat-notification-utils"

export default function ChatNotificationBadge({ chatId, userId }) {
  const [unreadCount, setUnreadCount] = useState(0)
  const [loading, setLoading] = useState(true)

  const fetchUnreadCount = async () => {
    try {
      if (!chatId || !userId) return

      const count = await countUnreadMessages(chatId, userId)
      setUnreadCount(count)
    } catch (error) {
      console.error("Error fetching unread count:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUnreadCount()

    // Set up event listeners for real-time updates
    const handleMessageRead = (event) => {
      if (event.detail.chatId === chatId && event.detail.userId === userId) {
        fetchUnreadCount()
      }
    }

    const handleAllMessagesRead = (event) => {
      if (event.detail.chatId === chatId && event.detail.userId === userId) {
        setUnreadCount(0)
      }
    }

    window.addEventListener("chatMessageRead", handleMessageRead)
    window.addEventListener("chatMessagesAllRead", handleAllMessagesRead)

    // Poll for new messages every 30 seconds
    const interval = setInterval(fetchUnreadCount, 30000)

    return () => {
      window.removeEventListener("chatMessageRead", handleMessageRead)
      window.removeEventListener("chatMessagesAllRead", handleAllMessagesRead)
      clearInterval(interval)
    }
  }, [chatId, userId])

  if (loading || unreadCount === 0) return null

  return (
    <span className="absolute top-0 right-0 flex h-5 w-5 items-center justify-center">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
      <span className="relative inline-flex rounded-full h-5 w-5 bg-red-500 text-white text-xs font-bold items-center justify-center">
        {unreadCount > 9 ? "9+" : unreadCount}
      </span>
    </span>
  )
}
