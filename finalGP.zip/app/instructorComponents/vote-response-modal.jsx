"use client"

import { useState, useEffect } from "react"
import { X, Clock, CheckCircle } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function VoteResponseModal({ isOpen, onClose, vote, currentUser, onVoteSubmitted }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  const [suggestions, setSuggestions] = useState([])
  const [selectedOptions, setSelectedOptions] = useState([])
  const [existingVotes, setExistingVotes] = useState([])

  useEffect(() => {
    if (isOpen && vote) {
      fetchVoteSuggestions()
      if (currentUser?.user_id) {
        fetchExistingVotes()
      }
      setError(null)
      setSuccess(false)
    }
  }, [isOpen, vote, currentUser])

  const fetchVoteSuggestions = async () => {
    if (!vote || !vote.vote_id) return

    try {
      setLoading(true)

      // Fetch all suggestions for this vote
      const { data, error } = await supabase
        .from("voting")
        .select("*")
        .eq("vote_id", vote.vote_id)
        .order("suggestion_time", { ascending: true })

      if (error) {
        console.error("Error fetching vote suggestions:", error)
        setSuggestions([])
        return
      }

      // Filter out duplicates by suggestion_id
      const uniqueSuggestions = Array.from(new Map(data.map((item) => [item.id, item])).values())

      console.log("Unique vote suggestions:", uniqueSuggestions)
      setSuggestions(uniqueSuggestions || [])
    } catch (error) {
      console.error("Error in fetchVoteSuggestions:", error)
      setSuggestions([])
    } finally {
      setLoading(false)
    }
  }

  const fetchExistingVotes = async () => {
    if (!vote || !vote.vote_id || !currentUser) return

    try {
      // Fetch existing votes by this user for this vote
      const { data, error } = await supabase
        .from("student_voting")
        .select("*")
        .eq("vote_id", vote.vote_id)
        .eq("student_id", currentUser.user_id)

      if (error) {
        console.error("Error fetching existing votes:", error)
        return
      }

      setExistingVotes(data || [])

      // Pre-select options that the user has already voted for
      // Ensure we only select each suggestion once
      if (data && data.length > 0) {
        const uniqueSuggestionIds = [...new Set(data.map((vote) => vote.suggestion_id))]
        setSelectedOptions(uniqueSuggestionIds)
      }
    } catch (error) {
      console.error("Error fetching existing votes:", error)
    }
  }

  const handleOptionToggle = (suggestionId) => {
    setSelectedOptions((prev) => {
      if (prev.includes(suggestionId)) {
        return prev.filter((id) => id !== suggestionId)
      } else {
        return [...prev, suggestionId]
      }
    })
  }

  const handleSubmitVote = async () => {
    if (selectedOptions.length === 0) {
      setError("Please select at least one option")
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Get the student ID (current user ID)
      const studentId = currentUser?.user_id || "test-student-id"

      // First, delete any existing votes by this user for this vote
      const { error: deleteError } = await supabase
        .from("student_voting")
        .delete()
        .eq("vote_id", vote.vote_id)
        .eq("student_id", studentId)

      if (deleteError) throw deleteError

      // Insert new votes into student_voting table - one per selected suggestion
      const votesToInsert = selectedOptions.map((suggestionId) => ({
        vote_id: vote.vote_id,
        suggestion_id: suggestionId,
        student_id: studentId,
        created_at: new Date().toISOString(),
      }))

      const { error: insertError } = await supabase.from("student_voting").insert(votesToInsert)

      if (insertError) throw insertError

      setSuccess(true)
      setTimeout(() => {
        if (onVoteSubmitted) {
          onVoteSubmitted()
        }
        onClose()
      }, 1500)
    } catch (err) {
      console.error("Error submitting vote:", err)
      setError(err.message || "Failed to submit vote. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen || !vote) return null

  // Check if voting is still open
  const isVotingOpen = new Date(vote.deadline) > new Date()

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Vote for Meeting Time</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 max-h-[calc(90vh-120px)]">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}

          {success && (
            <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md text-sm flex items-center">
              <CheckCircle className="w-5 h-5 mr-2" />
              Your vote has been submitted successfully!
            </div>
          )}

          <div className="mb-6">
            <h3 className="text-xl font-bold text-gray-800 mb-2">{vote.vote_title || `Vote #${vote.vote_id || ""}`}</h3>

            <div className="flex items-center mt-4 text-sm text-gray-500">
              <Clock className="w-4 h-4 mr-1" />
              <span>
                Voting deadline: {new Date(vote.deadline).toLocaleDateString()} at{" "}
                {new Date(vote.deadline).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          </div>

          {!isVotingOpen ? (
            <div className="bg-amber-50 border-l-4 border-amber-500 p-4 text-amber-700">
              <p className="font-medium">Voting is closed</p>
              <p className="text-sm">The deadline for voting has passed. You can no longer submit your vote.</p>
            </div>
          ) : loading && suggestions.length === 0 ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : suggestions.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No meeting options available</div>
          ) : (
            <>
              <div className="mb-6">
                <h4 className="text-lg font-medium text-gray-800 mb-3">Select your preferred meeting times</h4>
                <p className="text-sm text-gray-500 mb-4">
                  You can select multiple options if you're available at different times.
                </p>

                <div className="space-y-3">
                  {suggestions.map((suggestion) => {
                    const startDate = new Date(suggestion.suggestion_time)
                    const endDate = suggestion.end_time
                      ? new Date(suggestion.end_time)
                      : new Date(startDate.getTime() + 60 * 60 * 1000)

                    const formattedDate = startDate.toLocaleDateString("en-US", {
                      weekday: "long",
                      month: "long",
                      day: "numeric",
                    })

                    const formattedStartTime = startDate.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })

                    const formattedEndTime = endDate.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })

                    const isSelected = selectedOptions.includes(suggestion.id)

                    return (
                      <div
                        key={suggestion.id}
                        className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                          isSelected ? "border-blue-500 bg-blue-50" : "border-gray-200 bg-white hover:bg-gray-50"
                        }`}
                        onClick={() => handleOptionToggle(suggestion.id)}
                      >
                        <div className="flex items-center">
                          <div
                            className={`w-5 h-5 rounded-full border mr-3 flex items-center justify-center ${
                              isSelected ? "border-blue-500 bg-blue-500" : "border-gray-300"
                            }`}
                          >
                            {isSelected && <CheckCircle className="w-3 h-3 text-white" />}
                          </div>
                          <div>
                            <div className="font-medium text-gray-800">{formattedDate}</div>
                            <div className="text-sm text-gray-600">
                              {formattedStartTime} - {formattedEndTime}
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={loading}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSubmitVote}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  disabled={loading || selectedOptions.length === 0}
                >
                  {loading ? "Submitting..." : "Submit Vote"}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
