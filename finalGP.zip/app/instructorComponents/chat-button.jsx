"use client"

import { useState, useEffect } from "react"
import { MessageSquare } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { hasUnreadMessages } from "@/lib/chat-notification-utils"
import ChatModal from "./chat-modal"
import { useAuth } from "@/context/auth-context"

export default function ChatButton({ groupId, entranceId }) {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const { user } = useAuth() // Add useAuth hook
  const [hasUnread, setHasUnread] = useState(false)
  const [actualGroupId, setActualGroupId] = useState(null)

  useEffect(() => {
    // Get actual group ID from entrance ID
    const fetchActualGroupId = async () => {
      if (!entranceId) return

      const { data, error } = await supabase
        .from("projectgroup")
        .select("groupid")
        .eq("enterance_id", entranceId)
        .single()

      if (!error && data) {
        setActualGroupId(data.groupid)

        // Check for unread messages if we have a user
        if (user?.user_id) {
          const unread = await hasUnreadMessages(data.groupid, user.user_id)
          setHasUnread(unread)
        }
      }
    }

    fetchActualGroupId()

    // Poll for new messages every 30 seconds if we have a user
    const interval = setInterval(() => {
      if (actualGroupId && user?.user_id) {
        hasUnreadMessages(actualGroupId, user.user_id).then((unread) => setHasUnread(unread))
      }
    }, 30000)

    return () => clearInterval(interval)
  }, [entranceId, actualGroupId, user])

  const openModal = () => {
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)

    // Refresh unread status after closing
    if (actualGroupId && user?.user_id) {
      hasUnreadMessages(actualGroupId, user.user_id).then((unread) => setHasUnread(unread))
    }
  }

  return (
    <>
      <button
        onClick={openModal}
        className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md shadow-sm text-sm font-medium  hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        style={{ minWidth: "90px", height: "38px" }}
        aria-label={hasUnread ? "Chat with unread messages" : "Chat"}
      >
        {hasUnread ? (
          <div className="mr-2 relative">
            <div className="absolute -left-1 -top-1">
              <span className="flex h-3 w-3">
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
              </span>
            </div>
            <MessageSquare className="w-5 h-5" />
          </div>
        ) : (
          <MessageSquare className="w-5 h-5 mr-2" />
        )}
        <span>Chat</span>
      </button>

      {isModalOpen && (
        <ChatModal isOpen={isModalOpen} onClose={closeModal} groupId={actualGroupId || groupId} currentUser={user} />
      )}
    </>
  )
}
