"use client"

import { useState, useEffect } from "react"
import { Clock, Check } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function VoteDetailsView({ groupId, currentUser }) {
  const [votes, setVotes] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selectedOptions, setSelectedOptions] = useState({})
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (groupId) {
      fetchVotes()
    }
  }, [groupId])

  const fetchVotes = async () => {
    try {
      setLoading(true)

      // Fetch all votes for this group
      const { data: allVotes, error: votesError } = await supabase
        .from("voting")
        .select("*")
        .eq("group_id", groupId)
        .order("created_at", { ascending: false })

      if (votesError) {
        throw votesError
      }

      // Group votes by vote_id to separate main votes from suggestions
      const voteMap = new Map()
      const mainVotes = []

      // First, identify main votes (those with vote_title)
      allVotes.forEach((vote) => {
        if (vote.vote_title) {
          const mainVote = {
            ...vote,
            title: vote.vote_title,
            suggestions: [],
            studentVotes: {},
          }
          voteMap.set(vote.vote_id, mainVote)
          mainVotes.push(mainVote)
        }
      })

      // If we couldn't identify main votes by vote_title, try another approach
      if (voteMap.size === 0) {
        // Group by vote_id and take the first one as the main vote
        const voteGroups = {}
        allVotes.forEach((vote) => {
          if (!voteGroups[vote.vote_id]) {
            voteGroups[vote.vote_id] = []
          }
          voteGroups[vote.vote_id].push(vote)
        })

        // For each group, take the first vote as the main one
        Object.entries(voteGroups).forEach(([voteId, votes]) => {
          if (votes.length > 0) {
            const mainVote = {
              ...votes[0],
              title: votes[0].vote_title || votes[0].meeting_title || "Untitled Meeting",
              suggestions: [],
              studentVotes: {},
            }
            voteMap.set(Number.parseInt(voteId), mainVote)
            mainVotes.push(mainVote)
          }
        })
      }

      // Now add suggestions to their respective main votes
      allVotes.forEach((vote) => {
        // If this vote has a vote_id and it's not the main vote for this vote_id
        if (vote.vote_id && voteMap.has(vote.vote_id) && vote.id !== voteMap.get(vote.vote_id).id) {
          const mainVote = voteMap.get(vote.vote_id)
          mainVote.suggestions.push(vote)
        }
      })

      // Fetch student_voting data for each vote
      for (const mainVote of mainVotes) {
        const { data: studentVotes, error: studentVotesError } = await supabase
          .from("student_voting")
          .select("*")
          .eq("vote_id", mainVote.vote_id)

        if (!studentVotesError && studentVotes) {
          // Process student votes
          studentVotes.forEach((vote) => {
            if (!mainVote.studentVotes[vote.suggestion_id]) {
              mainVote.studentVotes[vote.suggestion_id] = []
            }
            mainVote.studentVotes[vote.suggestion_id].push(vote)
          })
        }

        // Initialize selected options for current user
        if (currentUser) {
          const userVotes = studentVotes?.filter((vote) => vote.student_id === currentUser.user_id) || []
          if (userVotes.length > 0) {
            setSelectedOptions((prev) => ({
              ...prev,
              [mainVote.vote_id]: userVotes.map((vote) => vote.suggestion_id),
            }))
          }
        }
      }

      setVotes(mainVotes)
    } catch (err) {
      console.error("Error fetching votes:", err)
      setError("Failed to load votes. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleOptionSelect = (voteId, suggestionId) => {
    setSelectedOptions((prev) => {
      const currentSelections = prev[voteId] || []

      // If already selected, remove it
      if (currentSelections.includes(suggestionId)) {
        return {
          ...prev,
          [voteId]: currentSelections.filter((id) => id !== suggestionId),
        }
      }

      // Otherwise add it
      return {
        ...prev,
        [voteId]: [...currentSelections, suggestionId],
      }
    })
  }

  const updateVotes = async (voteId) => {
    if (!currentUser) {
      setError("You must be logged in to vote")
      return
    }

    const selectedForVote = selectedOptions[voteId] || []
    if (selectedForVote.length === 0) {
      setError("Please select at least one option")
      return
    }

    try {
      setSubmitting(true)

      // First, delete any existing votes by this user for this vote
      const { error: deleteError } = await supabase
        .from("student_voting")
        .delete()
        .eq("vote_id", voteId)
        .eq("student_id", currentUser.user_id)

      if (deleteError) throw deleteError

      // Then insert new votes
      const votesToInsert = selectedForVote.map((suggestionId) => ({
        vote_id: voteId,
        suggestion_id: suggestionId,
        student_id: currentUser.user_id,
        created_at: new Date().toISOString(),
      }))

      const { error: insertError } = await supabase.from("student_voting").insert(votesToInsert)

      if (insertError) throw insertError

      // Refresh votes
      await fetchVotes()
    } catch (err) {
      console.error("Error updating votes:", err)
      setError("Failed to update votes. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  const getTimeRemaining = (deadline) => {
    const now = new Date()
    const deadlineDate = new Date(deadline)
    const diffMs = deadlineDate - now

    if (diffMs <= 0) return "Voting closed"

    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

    return `${diffHrs}h ${diffMins}m remaining`
  }

  const getVoteCount = (voteId, suggestionId) => {
    const vote = votes.find((v) => v.vote_id === voteId)
    if (!vote || !vote.studentVotes[suggestionId]) return 0
    return vote.studentVotes[suggestionId].length
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
        <div className="flex">
          <div className="ml-3">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        </div>
      </div>
    )
  }

  if (votes.length === 0) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-sm text-center">
        <p className="text-gray-500">No votes found for this group.</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {votes.map((vote) => {
        const isVotingOpen = new Date(vote.deadline) > new Date()
        const timeRemaining = getTimeRemaining(vote.deadline)

        return (
          <div key={vote.vote_id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-800">Vote #{vote.vote_id}</h3>
                <button className="text-sm text-gray-500 hover:text-gray-700">Hide Options</button>
              </div>
              <div className="flex items-center text-sm text-gray-500 mt-1">
                <Clock className="w-4 h-4 mr-1" />
                <span>{timeRemaining}</span>
              </div>
            </div>

            <div className="divide-y divide-gray-100">
              {vote.suggestions.map((suggestion) => {
                const startDate = new Date(suggestion.suggestion_time)
                const voteCount = getVoteCount(vote.vote_id, suggestion.id)
                const isSelected = (selectedOptions[vote.vote_id] || []).includes(suggestion.id)

                return (
                  <div
                    key={suggestion.id}
                    className={`p-4 flex justify-between items-center hover:bg-gray-50 ${isSelected ? "bg-blue-50" : ""}`}
                    onClick={() => isVotingOpen && handleOptionSelect(vote.vote_id, suggestion.id)}
                  >
                    <div className="flex items-center">
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                          isSelected ? "border-blue-500 bg-blue-500" : "border-gray-300"
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span>
                        {startDate.toLocaleDateString("en-US", {
                          weekday: "short",
                          month: "short",
                          day: "numeric",
                        })}
                        ,{" "}
                        {startDate.toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                    <div className="text-sm text-gray-500">
                      {voteCount} {voteCount === 1 ? "vote" : "votes"}
                    </div>
                  </div>
                )
              })}
            </div>

            {isVotingOpen && (
              <div className="p-4 border-t border-gray-200 flex justify-end">
                <button
                  onClick={() => updateVotes(vote.vote_id)}
                  disabled={submitting}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                >
                  {submitting ? "Updating..." : "Update Votes"}
                </button>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
