"use client"

import { useState, useEffect } from "react"
import { X, Calendar, Clock, Video, Trash, Save, AlertTriangle } from "lucide-react"
import { supabase } from "@/lib/supabase"

export default function MeetingDetailsModal({ isOpen, onClose, meeting, group, onMeetingUpdated, onMeetingDeleted }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    meeting_title: "",
    description: "",
    scheduletime: "",
    time: "",
    meeting_link: "",
  })

  // Initialize form data when meeting changes
  useEffect(() => {
    if (meeting) {
      const meetingDate = meeting.scheduletime ? new Date(meeting.scheduletime) : new Date()

      setFormData({
        meeting_title: meeting.meeting_title || "",
        description: meeting.meeting_description || "",
        scheduletime: meetingDate.toISOString().split("T")[0],
        time: meetingDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false }),
        meeting_link: meeting.meeting_link || "",
      })
    }
  }, [meeting])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // Validate form
      if (!formData.meeting_title.trim()) {
        throw new Error("Meeting title is required")
      }

      if (!formData.scheduletime) {
        throw new Error("Meeting date is required")
      }

      if (!formData.time) {
        throw new Error("Meeting time is required")
      }

      // Combine date and time
      const scheduletime = new Date(`${formData.scheduletime}T${formData.time}:00`)

      // Update the meeting
      const { data, error } = await supabase
        .from("meeting")
        .update({
          meeting_title: formData.meeting_title,
          meeting_description: formData.description,
          scheduletime: scheduletime.toISOString(),
          meeting_link: formData.meeting_link,
          // Don't change instructor_id
        })
        .eq("meetingid", meeting.meetingid)
        .select()

      if (error) throw error

      setSuccess("Meeting updated successfully")
      setIsEditing(false)

      // Call the onMeetingUpdated callback
      if (onMeetingUpdated) {
        onMeetingUpdated(data[0])
      }

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (err) {
      console.error("Error updating meeting:", err)
      setError(err.message || "Failed to update meeting. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteMeeting = async () => {
    if (!meeting) return

    try {
      setDeleting(true)

      // Delete the meeting
      const { error } = await supabase.from("meeting").delete().eq("meetingid", meeting.meetingid)

      if (error) throw error

      // Call the onMeetingDeleted callback
      if (onMeetingDeleted) {
        onMeetingDeleted(meeting.meetingid)
      }

      onClose()
    } catch (err) {
      console.error("Error deleting meeting:", err)
      setError("Failed to delete meeting. Please try again.")
    } finally {
      setDeleting(false)
      setConfirmDelete(false)
    }
  }

  // Format date for display
  const formatDateTime = (dateTimeString) => {
    if (!dateTimeString) return "N/A"

    const date = new Date(dateTimeString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  // Check if meeting is in the past
  const isPastMeeting = meeting ? new Date(meeting.scheduletime) < new Date() : false

  if (!isOpen || !meeting) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Meeting Details</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto p-6 max-h-[calc(90vh-120px)]">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}
          {success && <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md text-sm">{success}</div>}

          {isEditing ? (
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="meeting_title" className="block text-sm font-medium text-gray-700 mb-1">
                  Meeting Title*
                </label>
                <input
                  type="text"
                  id="meeting_title"
                  name="meeting_title"
                  value={formData.meeting_title}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>

              <div className="mb-4">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={3}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label htmlFor="scheduletime" className="block text-sm font-medium text-gray-700 mb-1">
                    Date*
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      id="scheduletime"
                      name="scheduletime"
                      value={formData.scheduletime}
                      onChange={handleChange}
                      min={new Date().toISOString().split("T")[0]}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 pr-10"
                      required
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>
                <div>
                  <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">
                    Time*
                  </label>
                  <div className="relative">
                    <input
                      type="time"
                      id="time"
                      name="time"
                      value={formData.time}
                      onChange={handleChange}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 pr-10"
                      required
                    />
                    <Clock className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <label htmlFor="meeting_link" className="block text-sm font-medium text-gray-700 mb-1">
                  Meeting Link (optional)
                </label>
                <div className="relative">
                  <input
                    type="url"
                    id="meeting_link"
                    name="meeting_link"
                    value={formData.meeting_link}
                    onChange={handleChange}
                    placeholder="https://meet.google.com/..."
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 pr-10"
                  />
                  <Video className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={loading}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            <>
              {/* View mode */}
              <div className="mb-6">
                <div className="flex justify-between items-start">
                  <h3 className="text-2xl font-bold text-gray-800">{meeting.meeting_title}</h3>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${isPastMeeting ? "bg-gray-100 text-gray-800" : "bg-green-100 text-green-800"}`}
                  >
                    {isPastMeeting ? "Completed" : "Upcoming"}
                  </span>
                </div>

                {meeting.meeting_description && (
                  <p className="text-gray-600 mt-2 mb-4">{meeting.meeting_description}</p>
                )}

                <div className="flex items-center text-sm text-gray-600 mb-3">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>{formatDateTime(meeting.scheduletime)}</span>
                </div>

                {meeting.meeting_link && (
                  <div className="flex items-center text-sm text-blue-600 hover:text-blue-800 mb-3">
                    <Video className="w-4 h-4 mr-2" />
                    <a href={meeting.meeting_link} target="_blank" rel="noopener noreferrer">
                      Join Meeting
                    </a>
                  </div>
                )}

                {/* Attendees section could be added here if we have that data */}
              </div>

              {/* Related votes section - if we want to show related votes */}
              {/* This would require fetching votes related to this meeting */}
            </>
          )}

          {/* Actions */}
          <div className="flex justify-between items-center mt-8">
            {confirmDelete ? (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 w-full">
                <div className="flex items-center mb-2">
                  <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
                  <h3 className="text-lg font-medium text-red-700">Confirm Deletion</h3>
                </div>
                <p className="text-red-600 mb-4">
                  Are you sure you want to delete this meeting? This action cannot be undone.
                </p>
                <div className="flex justify-end space-x-3">
                  <button
                    onClick={() => setConfirmDelete(false)}
                    className="px-3 py-1 border border-gray-300 rounded text-gray-700 text-sm"
                    disabled={deleting}
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteMeeting}
                    className="px-3 py-1 bg-red-600 text-white rounded text-sm"
                    disabled={deleting}
                  >
                    {deleting ? "Deleting..." : "Confirm Delete"}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <button
                  onClick={() => setConfirmDelete(true)}
                  className="flex items-center text-red-600 hover:text-red-800"
                >
                  <Trash className="w-4 h-4 mr-1" />
                  Delete Meeting
                </button>

                <div className="flex space-x-3">
                  {!isEditing && (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="px-4 py-2 border border-gray-300 bg-white text-gray-700 rounded-md hover:bg-gray-50"
                    >
                      Edit Meeting
                    </button>
                  )}
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700" onClick={onClose}>
                    Close
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
