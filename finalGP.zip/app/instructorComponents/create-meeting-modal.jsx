"use client"

import { useState } from "react"
import { X, Calendar, Video } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context" // Import the auth context

export default function CreateMeetingModal({ isOpen, onClose, group, onMeetingCreated }) {
  const { user: authUser } = useAuth() // Get user from auth context
  const [formData, setFormData] = useState({
    meeting_title: "",
    meeting_description: "",
    scheduletime: "",
    meeting_link: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Validate meeting title
      if (!formData.meeting_title.trim()) {
        throw new Error("Meeting title is required")
      }

      // Validate group data
      if (!group) {
        throw new Error("No group selected. Please select a group before creating a meeting.")
      }

      // Check which property contains the group ID (could be groupid or id)
      const groupId = group.groupid || group.id

      if (!groupId) {
        console.error("Group object is missing ID:", group)
        throw new Error("Invalid group data. The group ID is missing.")
      }

      // Check if user is authenticated using the auth context
      if (!authUser || !authUser.user_id) {
        console.error("Authentication error: No user found in auth context")
        throw new Error("You must be logged in to create a meeting")
      }

      // Use the instructor ID from the auth context
      const instructorId = authUser.user_id

      console.log("Creating meeting with instructor ID:", instructorId)
      console.log("Group ID:", groupId)

      const { data, error: supabaseError } = await supabase
        .from("meeting")
        .insert([
          {
            groupid: groupId,
            meeting_title: formData.meeting_title,
            meeting_description: formData.meeting_description,
            scheduletime: formData.scheduletime,
            meeting_link: formData.meeting_link,
          },
        ])
        .select()

      if (supabaseError) {
        console.error("Supabase error:", supabaseError)
        throw new Error(supabaseError.message || "Failed to create meeting")
      }

      if (onMeetingCreated) {
        onMeetingCreated(data[0])
      }

      onClose()
    } catch (err) {
      console.error("Error creating meeting:", err)
      setError(err.message || "Failed to create meeting. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  // Show a message if not authenticated
  if (!authUser) {
    return (
      isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h2 className="text-xl font-semibold text-red-600 mb-4">Authentication Error</h2>
            <p className="mb-4">You must be logged in to create a meeting. Please log in and try again.</p>
            <div className="flex justify-end">
              <button onClick={onClose} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                Close
              </button>
            </div>
          </div>
        </div>
      )
    )
  }

  if (!isOpen || !group) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Schedule Meeting</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4">
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
              {error}
              {!authUser && (
                <div className="mt-2 font-medium">
                  Authentication issue detected. Please try refreshing the page or logging in again.
                </div>
              )}
            </div>
          )}

          <div className="mb-4">
            <label htmlFor="meeting_title" className="block text-sm font-medium text-gray-700 mb-1">
              Meeting Title*
            </label>
            <input
              type="text"
              id="meeting_title"
              name="meeting_title"
              value={formData.meeting_title}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div className="mb-4">
            <label htmlFor="meeting_description" className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              id="meeting_description"
              name="meeting_description"
              value={formData.meeting_description}
              onChange={handleChange}
              rows={3}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="mb-4">
            <label htmlFor="scheduletime" className="block text-sm font-medium text-gray-700 mb-1">
              Schedule Time*
            </label>
            <div className="relative">
              <input
                type="datetime-local"
                id="scheduletime"
                name="scheduletime"
                value={formData.scheduletime}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                required
              />
              <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="meeting_link" className="block text-sm font-medium text-gray-700 mb-1">
              Meeting Link (optional)
            </label>
            <div className="relative">
              <input
                type="url"
                id="meeting_link"
                name="meeting_link"
                value={formData.meeting_link}
                onChange={handleChange}
                placeholder="https://meet.google.com/..."
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
              />
              <Video className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              disabled={loading}
            >
              {loading ? "Creating..." : "Create Meeting"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
