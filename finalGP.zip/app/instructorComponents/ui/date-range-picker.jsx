"use client"

import React, { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { CalendarIcon, X } from "lucide-react"

export function DateRangePicker({ value, onChange }) {
  const [date, setDate] = useState(value?.start)
  const [dateRange, setDateRange] = useState([
    value?.start,
    value?.end,
  ])

  const handleSelect = (selectedDate) => {
    setDate(selectedDate)
    const [start, end] = dateRange

    if (!start) {
      // If no start date is selected, set it
      setDateRange([selectedDate, undefined])
    } else if (!end && selectedDate && selectedDate > start) {
      // If we have a start date but no end date, and the selected date is after the start date
      setDateRange([start, selectedDate])
      // Commit the date range
      onChange({ start, end: selectedDate })
    } else {
      // If both dates are selected or selected date is before start date, reset and set as new start
      setDateRange([selectedDate, undefined])
    }
  }

  const handleClear = () => {
    setDateRange([undefined, undefined])
    setDate(undefined)
    onChange(null)
  }

  const formatDateRange = () => {
    if (dateRange[0] && dateRange[1]) {
      return `${dateRange[0].toLocaleDateString()} - ${dateRange[1].toLocaleDateString()}`
    }
    if (dateRange[0]) {
      return `From ${dateRange[0].toLocaleDateString()}`
    }
    return "Select date range"
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-full justify-start text-left font-normal">
          <CalendarIcon className="mr-2 h-4 w-4" />
          {value ? <span className="flex-1 truncate">{formatDateRange()}</span> : <span>Select date range</span>}
          {value && (
            <X
              className="h-4 w-4 opacity-50 hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation()
                handleClear()
              }}
            />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode="range"
          selected={{ from: dateRange[0], to: dateRange[1] }}
          onSelect={(range) => {
            if (range?.from) setDateRange([range.from, range.to])
            if (range?.from && range.to) onChange({ start: range.from, end: range.to })
          }}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  )
}
