"use client"

import { useState, useEffect } from "react"
import { countUnreadAnnouncements, markAnnouncementsAsViewedInSession } from "@/lib/announcement-utils"

export default function AnnouncementBadge({ userRole = "instructor" }) {
  const [unreadCount, setUnreadCount] = useState(0)
  const [loading, setLoading] = useState(true)

  const fetchUnreadCount = async () => {
    try {
      const count = await countUnreadAnnouncements(userRole)
      setUnreadCount(count)
    } catch (error) {
      console.error("Error fetching unread announcements count:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUnreadCount()

    // Set up interval to periodically check for new announcements
    const intervalId = setInterval(fetchUnreadCount, 60000) // Check every minute

    // Listen for announcement read events to update the badge immediately
    const handleAnnouncementRead = (event) => {
      if (event.detail.userRole === userRole) {
        fetchUnreadCount()
      }
    }

    // Listen for all announcements read event
    const handleAllAnnouncementsRead = (event) => {
      if (event.detail.userRole === userRole) {
        setUnreadCount(0)
      }
    }

    // Mark announcements as viewed in the current session
    // This prevents notifications from reappearing after minor changes
    markAnnouncementsAsViewedInSession(userRole)

    window.addEventListener("announcementRead", handleAnnouncementRead)
    window.addEventListener("allAnnouncementsRead", handleAllAnnouncementsRead)

    return () => {
      clearInterval(intervalId)
      window.removeEventListener("announcementRead", handleAnnouncementRead)
      window.removeEventListener("allAnnouncementsRead", handleAllAnnouncementsRead)
    }
  }, [userRole])

  if (loading || unreadCount === 0) {
    return null
  }

  return (
    <span className="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
      {unreadCount > 99 ? "99+" : unreadCount}
    </span>
  )
}
