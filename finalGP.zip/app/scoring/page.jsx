"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Calendar, ChevronDown, Search, FileCheck, Clipboard } from "lucide-react"
import { fetchProjects, fetchSupervisor, fetchExaminatorProjects } from "@/lib/data"
import { testConnection } from "@/lib/supabase"
import Sidebar from "../instructorComponents/sidebar"
import { useAuth } from "@/context/auth-context"

export default function ScoringPage() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth() // Add useAuth hook
  const [supervisorProjects, setSupervisorProjects] = useState([])
  const [examinatorProjects, setExaminatorProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [connectionStatus, setConnectionStatus] = useState(null)
  const [supervisor, setSupervisor] = useState(null)

  useEffect(() => {
    const checkConnection = async () => {
      const result = await testConnection()
      setConnectionStatus(result)

      if (result.success) {
        // Even if tables don't exist, we're still connected to Supabase
        if (user) {
          loadSupervisor(user.user_id)
        } else if (!authLoading) {
          setError("User not authenticated. Please log in.")
          setLoading(false)
        }
      } else {
        setError("Failed to connect to Supabase. Please check your credentials.")
        setLoading(false)
      }
    }

    const loadSupervisor = async (userId) => {
      try {
        const supervisorData = await fetchSupervisor(userId)
        setSupervisor({
          ...supervisorData,
          // Fallback to auth context user data if supervisor data is incomplete
          username: supervisorData.userName || user.userName || "Instructor",
          role: supervisorData.role || user.role || "Supervisor",
          user_id: supervisorData.user_id || user.user_id,
        })

        // Now load both types of projects for this supervisor
        loadProjects(userId)
      } catch (error) {
        console.error("Failed to fetch supervisor:", error)
        setError("Failed to load supervisor information.")
        setLoading(false)
      }
    }

    const loadProjects = async (supervisorId) => {
      try {
        setLoading(true)

        // Load supervisor projects
        const supervisorData = await fetchProjects(supervisorId)
        setSupervisorProjects(supervisorData)

        // Load examinator projects
        const examinatorData = await fetchExaminatorProjects(supervisorId)
        setExaminatorProjects(examinatorData)

        setError(null)
      } catch (error) {
        console.error("Failed to fetch projects:", error)
        setError("Failed to load projects. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    // Only run the effect if we have a user or if we know loading is complete
    if (!authLoading) {
      checkConnection()
    }
  }, [user, authLoading]) // Add authLoading as a dependency

  // Helper function to get initials safely
  const getInitials = (name) => {
    if (!name) return "I" // Default fallback
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
  }

  // Handle click on a project card
  const handleProjectClick = (projectId, isExaminator) => {
    if (isExaminator) {
      router.push(`/scoring/${projectId}?role=examinator`)
    } else {
      router.push(`/scoring/${projectId}?role=supervisor`)
    }
  }

  // Then modify the return statement to include the Sidebar component
  // Change this:
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex-1 overflow-auto bg-gray-50">
        {/* Header */}
        <header className="bg-white p-4 border-b border-gray-200 flex justify-between items-center shadow-sm">
          <div className="relative w-80">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="w-5 h-5 text-gray-500" />
            </div>
            <input
              type="text"
              className="bg-gray-100 border border-gray-200 text-gray-700 text-sm rounded-lg block w-full pl-10 p-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              placeholder="Search for anything..."
            />
          </div>

          <div className="flex items-center space-x-4">
            <button className="text-gray-600 hover:bg-gray-100 p-2 rounded-full transition-all">
              <Calendar className="w-5 h-5" />
            </button>

            {supervisor && (
              <div className="flex items-center ml-4">
                <div className="mr-3 text-right">
                  <div className="font-medium">{supervisor.userName}</div>
                  <div className="text-sm text-gray-500">{supervisor.role}</div>
                </div>
                <div className="relative">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                    <span>{getInitials(supervisor.userName) || "U"}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 absolute -right-4 top-3 text-gray-600" />
                </div>
              </div>
            )}
          </div>
        </header>

        {/* Main Content */}
        <main className="p-6">
          {connectionStatus && !connectionStatus.success && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              <p className="font-bold">Connection Error</p>
              <p>Failed to connect to Supabase. Please check your credentials.</p>
              <p className="text-sm mt-2">Error details: {connectionStatus.error?.message || "Unknown error"}</p>
            </div>
          )}

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              <p>{error}</p>
            </div>
          )}

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <>
              {/* Supervisor Section */}
              <div className="mb-10">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <Clipboard className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-semibold text-gray-800">AS SUPERVISOR:</h2>
                    <p className="text-sm text-gray-500">Groups you supervise and can grade (out of 60)</p>
                  </div>
                </div>

                {supervisorProjects.length === 0 ? (
                  <div className="bg-blue-50 text-blue-700 p-4 rounded-lg text-center">
                    No supervisor projects found. You may need to create the database schema.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {supervisorProjects.map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onClick={() => handleProjectClick(project.id, false)}
                        role="supervisor"
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Examinator Section */}
              <div>
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                    <FileCheck className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-semibold text-gray-800">AS EXAMINATOR:</h2>
                    <p className="text-sm text-gray-500">Groups you examine and can grade (out of 20)</p>
                  </div>
                </div>

                {examinatorProjects.length === 0 ? (
                  <div className="bg-purple-50 text-purple-700 p-4 rounded-lg text-center">
                    No examinator projects found. You may need to create the database schema.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {examinatorProjects.map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onClick={() => handleProjectClick(project.id, true)}
                        role="examinator"
                      />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  )
}

function ProjectCard({ project, onClick, role }) {
  const { id, title, progress, members } = project

  // Get status directly from the project data
  const getProgressStatus = (project) => {
    return project.status || "late"
  }

  // Get color based on progress status
  const getProgressStatusColor = (status) => {
    switch (status) {
      case "late":
        return "bg-red-500"
      case "on progress":
        return "bg-amber-400"
      case "on track":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  // Get text color based on progress status
  const getProgressTextColor = (status) => {
    switch (status) {
      case "on progress":
        return "text-gray-700"
      default:
        return "text-white"
    }
  }

  // Get border color based on role
  const getBorderColor = (role) => {
    return role === "supervisor" ? "border-blue-200" : "border-purple-200"
  }

  const progressStatus = getProgressStatus(project)
  const progressStatusColor = getProgressStatusColor(progressStatus)
  const progressTextColor = getProgressTextColor(progressStatus)
  const borderColor = getBorderColor(role)

  return (
    <div
      className={`bg-white rounded-xl p-5 shadow-md hover:shadow-lg transition-all border-2 ${borderColor} cursor-pointer`}
      onClick={onClick}
    >
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <div className="w-5 h-5 border border-gray-300 rounded mr-2 flex-shrink-0"></div>
          <h3 className="font-medium text-gray-800">{title}</h3>
        </div>
        <div className="flex items-center">
          <span
            className={`text-xs px-2 py-1 rounded-full ${progressStatusColor} ${progressTextColor} mr-2 font-medium`}
          >
            {progressStatus}
          </span>
          <button
            className="hover:bg-gray-100 p-1 rounded-full transition-all"
            onClick={(e) => {
              e.stopPropagation() // Prevent card click when clicking the menu
            }}
          >
            <div className="w-5 h-5 text-gray-500">⋮</div>
          </button>
        </div>
      </div>

      {/* Role badge */}
      <div className="mb-3">
        <span
          className={`text-xs px-2 py-1 rounded-full ${
            role === "supervisor" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
          }`}
        >
          {role === "supervisor" ? "Supervisor (out of 60)" : "Examinator (out of 20)"}
        </span>
      </div>

      <div className="space-y-3 mb-5">
        {members &&
          members.map((member) => (
            <div key={member.id} className="flex items-center">
              <div className="w-7 h-7 bg-gradient-to-br from-gray-100 to-gray-50 rounded-full flex items-center justify-center mr-2 border border-gray-200">
                <div className="w-3 h-3 text-gray-600">👤</div>
              </div>
              <div className="flex-1">
                <span className="text-sm mr-2 text-gray-700">{member.name}</span>
                <span className="text-xs text-gray-500">{member.role || "Student"}</span>
              </div>
              {member.isLeader && (
                <span className="text-sm text-gray-500 ml-auto mr-2 bg-gray-100 px-2 py-0.5 rounded-full">Leader</span>
              )}
            </div>
          ))}
      </div>
    </div>
  )
}
