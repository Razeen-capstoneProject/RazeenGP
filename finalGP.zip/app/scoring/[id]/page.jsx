"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter, useSearchParams } from "next/navigation"
import { ArrowLeft, Save, User } from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context" // Import the auth context

export default function GroupScoringPage() {
  const router = useRouter()
  const params = useParams()
  const searchParams = useSearchParams()
  const { user, isLoading: authLoading } = useAuth() // Get current user from auth context
  const groupId = params.id
  const role = searchParams.get("role") || "examinator" // Default to examinator if not specified

  // Set max grade based on role
  const maxGrade = role === "supervisor" ? 60 : 20

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [groupDetails, setGroupDetails] = useState(null)
  const [grades, setGrades] = useState({})
  const [instructorId, setInstructorId] = useState(null) // State to store the instructor ID

  useEffect(() => {
    // Only proceed when auth state is resolved
    if (!authLoading) {
      if (user) {
        setInstructorId(user.user_id)
        fetchGroupDetails(user.user_id)
      } else {
        setError("User not authenticated. Please log in.")
        setLoading(false)
      }
    }
  }, [groupId, role, user, authLoading])

  // Helper function to get status from the group data
  const getGroupStatus = (group) => {
    return group?.group_status || "late"
  }

  const fetchGroupDetails = async (currentInstructorId) => {
    if (!currentInstructorId) {
      setError("No instructor ID available")
      setLoading(false)
      return
    }

    try {
      setLoading(true)

      // Step 1: Fetch group details
      const { data: groupData, error: groupError } = await supabase
        .from("projectgroup")
        .select("groupid, groupname, group_status")
        .eq("groupid", groupId)
        .single()

      if (groupError) {
        console.error("Error fetching group:", groupError)
        throw groupError
      }

      console.log("Group data:", groupData)

      // Step 2: Fetch students that belong to this group from the student table
      const { data: studentsData, error: studentsError } = await supabase
        .from("student")
        .select("student_id")
        .eq("groupid", groupId)

      if (studentsError) {
        console.error("Error fetching students:", studentsError)
        throw studentsError
      }

      console.log("Students data:", studentsData)

      if (!studentsData || studentsData.length === 0) {
        setGroupDetails({
          ...groupData,
          students: [],
        })
        setLoading(false)
        return
      }

      // Extract student IDs
      const studentIds = studentsData.map((student) => student.student_id)

      // Step 3: Fetch user information for these students from the users table
      const { data: usersData, error: usersError } = await supabase
        .from("users")
        .select("user_id, userName, email")
        .in("user_id", studentIds)

      if (usersError) {
        console.error("Error fetching users:", usersError)
        throw usersError
      }

      console.log("Users data:", usersData)

      // Step 4: Fetch existing grades for these students from student_masked table
      // Use different table based on role
      const tableName = "evaluate_student"

      const { data: existingGrades, error: gradesError } = await supabase
        .from("evaluate_student")
        .select("student_id, score") // Use score instead of grade
        .eq("instructor_id", currentInstructorId) // Use the dynamic instructor ID
        .in("student_id", studentIds)

      if (gradesError) {
        console.warn(`Error fetching grades from ${tableName}:`, gradesError)
        // Continue even if there's an error - might be that the table doesn't exist yet
      } else {
        console.log(`Existing grades from ${tableName}:`, existingGrades)
      }

      // Create a map of existing grades
      const gradeMap = {}
      if (existingGrades) {
        existingGrades.forEach((item) => {
          gradeMap[item.student_id] = item.score // Use score instead of grade
        })
      }

      // Create a map of user data by user_id
      const userMap = {}
      if (usersData) {
        usersData.forEach((user) => {
          userMap[user.user_id] = user
        })
      }

      // Combine student and user data
      const studentsWithUserInfo = studentsData.map((student) => {
        const userData = userMap[student.student_id] || {}
        return {
          student_id: student.student_id,
          userName: userData.userName || `Student ${student.student_id.substring(0, 8)}`,
          email: userData.email || "No email available",
        }
      })

      setGrades(gradeMap)
      setGroupDetails({
        ...groupData,
        students: studentsWithUserInfo || [],
      })
    } catch (error) {
      console.error("Error in fetchGroupDetails:", error)
      setError("Failed to load group details")
    } finally {
      setLoading(false)
    }
  }

  const handleGradeChange = (studentId, value) => {
    // Use the role-specific maximum grade
    const grade = Math.min(maxGrade, Math.max(0, Number(value) || 0))
    setGrades((prev) => ({
      ...prev,
      [studentId]: grade,
    }))
  }

  const handleSubmit = async () => {
    if (!instructorId) {
      setError("No instructor ID available. Please log in again.")
      return
    }

    try {
      setSaving(true)
      setError(null)
      setSuccess(null)

      // Use different table based on role
      const tableName = "evaluate_student"

      // Prepare the data for upsert
      const gradesToSubmit = Object.entries(grades).map(([student_id, grade]) => ({
        student_id,
        instructor_id: instructorId, // Use the dynamic instructor ID
        score: grade, // Always use 'score' field for both roles
      }))

      console.log(`Submitting grades to ${tableName} table:`, gradesToSubmit)

      // Use upsert to handle both insert and update cases
      const { error } = await supabase.from("evaluate_student").upsert(gradesToSubmit, {
        onConflict: "student_id,instructor_id",
      })

      if (error) throw error

      setSuccess(`Grades saved successfully as ${role}!`)
      setTimeout(() => setSuccess(null), 3000)
    } catch (error) {
      console.error("Error saving grades:", error)
      setError("Failed to save grades. Please try again.")
    } finally {
      setSaving(false)
    }
  }

  if (authLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        <p className="ml-3 text-blue-500">Loading authentication...</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  // Get role-specific styling
  const getRoleStyles = () => {
    if (role === "supervisor") {
      return {
        headerBg: "bg-blue-50",
        headerBorder: "border-blue-200",
        headerText: "text-blue-700",
        buttonBg: "bg-blue-600",
        buttonHover: "hover:bg-blue-700",
        buttonRing: "focus:ring-blue-500",
      }
    } else {
      return {
        headerBg: "bg-purple-50",
        headerBorder: "border-purple-200",
        headerText: "text-purple-700",
        buttonBg: "bg-purple-600",
        buttonHover: "hover:bg-purple-700",
        buttonRing: "focus:ring-purple-500",
      }
    }
  }

  const styles = getRoleStyles()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className={`bg-white border-b border-gray-200 sticky top-0 z-10`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <button
                onClick={() => router.push("/scoring")}
                className="text-gray-600 hover:text-gray-900 p-2 rounded-full hover:bg-gray-100"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h1 className="ml-4 text-2xl font-semibold text-gray-900">
                {groupDetails?.groupname || `Group ${groupId}`}
              </h1>
              <span className={`ml-4 px-3 py-1 rounded-full text-sm ${styles.headerBg} ${styles.headerText}`}>
                {role === "supervisor" ? "As Supervisor (out of 60)" : "As Examinator (out of 20)"}
              </span>
              <div className="text-amber-500 text-sm font-medium mt-1">{getGroupStatus(groupDetails)}</div>
            </div>
            <button
              onClick={handleSubmit}
              disabled={saving}
              className={`flex items-center px-4 py-2 ${styles.buttonBg} text-white rounded-lg ${styles.buttonHover} focus:outline-none focus:ring-2 ${styles.buttonRing} focus:ring-offset-2 disabled:opacity-50`}
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? "Saving..." : "Save Grades"}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">{error}</div>}

        {success && (
          <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">{success}</div>
        )}

        <div className={`bg-white rounded-lg shadow border ${styles.headerBorder}`}>
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">Student Grades (out of {maxGrade})</h3>

            {groupDetails?.students.length === 0 ? (
              <div className="text-center py-8 text-gray-500">No students found in this group</div>
            ) : (
              <div className="space-y-4">
                {groupDetails?.students.map((student) => (
                  <div
                    key={student.student_id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div className="ml-4">
                        <div className="font-medium text-gray-900">{student.userName}</div>
                        <div className="text-sm text-gray-500">{student.email}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input
                        type="number"
                        value={grades[student.student_id] || ""}
                        onChange={(e) => handleGradeChange(student.student_id, e.target.value)}
                        min="0"
                        max={maxGrade}
                        className="w-20 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder={`0-${maxGrade}`}
                      />
                      <span className="text-sm text-gray-500">/{maxGrade}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
