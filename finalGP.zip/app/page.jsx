"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import Link from "next/link"
import Image from "next/image"

export default function HomePage() {
  const { user, isLoading, redirectToUserDashboard } = useAuth()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)
  const [userData, setUserData] = useState(null)

  useEffect(() => {
    // Only handle redirection if we have finished loading and have a user
    if (!isLoading) {
      if (user) {
        // Store user data in state for use in the component
        setUserData(user)

        if (user.role !== "student") {
          // If not a student, redirect to appropriate dashboard
          console.log("User is not a student, redirecting to appropriate dashboard")
          setRedirecting(true)
          redirectToUserDashboard()
        } else {
          // For students, redirect to dashboard
          router.push("/dashboard")
        }
      }
    }
  }, [user, isLoading, router, redirectToUserDashboard])

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-gray-900"></div>
      </div>
    )
  }

  // Show loading state while redirecting
  if (redirecting) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p>Redirecting to your dashboard, {userData?.userName || ""}...</p>
        </div>
      </div>
    )
  }

  // Landing page for unauthenticated users
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 text-center">
        <div>
          <Image src="/images/razeen-logo.png" alt="Razeen Logo" width={200} height={200} className="mx-auto" />
        </div>

        <h1 className="mt-6 text-5xl font-bold text-gray-900">Graduate with us</h1>

        <p className="mt-2 text-center text-lg text-gray-600">
          Make your senior year easier with Razeen.
          <br />
          sign up now to simplify your capstone project!
        </p>

        <div className="mt-8 space-y-3">
          <div>
            <Link
              href="/signup"
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-sm text-lg font-medium text-white bg-black hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            >
              Signup
            </Link>
          </div>
          <div>
            <Link
              href="/auth"
              className="w-full flex justify-center py-3 px-4 border border-gray-300 rounded-full shadow-sm text-lg font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            >
              Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
