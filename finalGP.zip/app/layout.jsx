import { AuthProvider } from "@/context/auth-context"
import "./globals.css"
import ClientLayout from "./ClientLayout"

export const metadata = {
  title: "Project Management Dashboard",
  description: "A dashboard for managing projects and tasks",
    generator: 'v0.dev'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
      </head>
      <body className="font-sans">
        <AuthProvider>
          <ClientLayout>{children}</ClientLayout>
        </AuthProvider>
      </body>
    </html>
  )
}
