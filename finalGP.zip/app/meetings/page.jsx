"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { fetchProjects } from "@/lib/data"
import { supabase } from "@/lib/supabase"
import { Calendar, Users, Clock, Plus, ChevronRight, Search, Video, Filter, List } from "lucide-react"
import Sidebar from "@/app/instructorComponents/sidebar"
import CreateVoteModal from "@/app/instructorComponents/create-vote-modal"
import VoteDetailsModal from "@/app/instructorComponents/vote-details-modal"
import CreateMeetingModal from "@/app/instructorComponents/create-meeting-modal"
import MeetingDetailsModal from "@/app/instructorComponents/meeting-details-modal"
import SupervisorCalendar from "@/app/instructorComponents/supervisor-calendar"
import { useAuth } from "@/context/auth-context"
import "react-big-calendar/lib/css/react-big-calendar.css"

export default function MeetingsPage() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()
  const [groups, setGroups] = useState([])
  const [selectedGroup, setSelectedGroup] = useState(null)
  const [loading, setLoading] = useState(true)
  const [meetings, setMeetings] = useState([])
  const [votes, setVotes] = useState([])
  const [isCreateVoteModalOpen, setIsCreateVoteModalOpen] = useState(false)
  const [isCreateMeetingModalOpen, setIsCreateMeetingModalOpen] = useState(false)
  const [selectedVote, setSelectedVote] = useState(null)
  const [isVoteDetailsModalOpen, setIsVoteDetailsModalOpen] = useState(false)
  const [selectedMeeting, setSelectedMeeting] = useState(null)
  const [isMeetingDetailsModalOpen, setIsMeetingDetailsModalOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState("all") // all, active, completed
  const [meetingFilterStatus, setMeetingFilterStatus] = useState("all") // all, upcoming, past
  const [viewMode, setViewMode] = useState("calendar") // "list" or "calendar"
  const [showSidebar, setShowSidebar] = useState(false)
  const [error, setError] = useState(null)

  // Debug authentication state
  useEffect(() => {
    if (user) {
      console.log("Authentication state:", {
        userId: user.user_id,
        role: user.role,
        authenticated: !!user,
      })
    } else if (!authLoading) {
      console.log("No authenticated user found")
    }
  }, [user, authLoading])

  useEffect(() => {
    const loadData = async () => {
      try {
        // Wait for auth to load before fetching data
        if (authLoading) return

        if (!user) {
          console.error("No authenticated user found")
          setError("Please log in to view meetings")
          setLoading(false)
          return
        }

        setLoading(true)
        setError(null)

        // Check URL for view parameter
        const params = new URLSearchParams(window.location.search)
        const viewParam = params.get("view")
        if (viewParam === "list") {
          setViewMode("list")
        } else {
          setViewMode("calendar") // Default to calendar view
        }

        // Use the authenticated user's ID to fetch groups
        console.log(`Fetching groups for instructor ID: ${user.user_id}`)
        const groupsData = await fetchProjects(user.user_id)
        console.log(`Found ${groupsData?.length || 0} groups for instructor`)
        setGroups(groupsData || [])

        // If there are groups and we're in list view, select the first one by default
        if (groupsData && groupsData.length > 0 && viewMode === "list") {
          setSelectedGroup(groupsData[0])
          // Fetch data for the first group
          await fetchDataForGroup(groupsData[0].id)
        }
      } catch (error) {
        console.error("Error loading data:", error)
        setError("Failed to load meetings data. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [user, authLoading, viewMode])

  // Verify authentication before opening modals
  const verifyAuthAndProceed = (action) => {
    if (!user) {
      console.error("Authentication required")
      setError("You must be logged in to perform this action")
      return false
    }
    action()
    return true
  }

  const fetchDataForGroup = async (groupId) => {
    if (!groupId) {
      console.error("No group ID provided for fetching data")
      return
    }

    try {
      setError(null)
      await Promise.all([fetchMeetingsForGroup(groupId), fetchVotesForGroup(groupId)])
    } catch (error) {
      console.error("Error fetching data for group:", error)
      setError("Failed to load group data. Please try again later.")
    }
  }

  const fetchMeetingsForGroup = async (groupId) => {
    try {
      console.log(`Fetching meetings for group ${groupId}`)

      if (!user?.user_id) {
        console.error("No authenticated user ID available")
        setMeetings([])
        return
      }

      // Fetch all meetings for this group - using "groupid" instead of "group_id"
      const { data, error } = await supabase
        .from("meeting")
        .select("*")
        .eq("groupid", groupId)
        .order("scheduletime", { ascending: true })

      if (error) {
        console.error("Error fetching meetings:", error)
        setMeetings([])
        return
      }

      // Ensure all meeting data is properly formatted
      const formattedMeetings = (data || []).map((meeting) => ({
        ...meeting,
        meeting_title: meeting.meeting_title || "Untitled Meeting",
        scheduletime: meeting.scheduletime || new Date().toISOString(),
        meeting_description: meeting.meeting_description || "",
      }))

      console.log(`Found ${formattedMeetings.length} meetings for group ${groupId}`)
      setMeetings(formattedMeetings)
    } catch (error) {
      console.error("Error processing meetings:", error)
      setMeetings([])
    }
  }

  const fetchVotesForGroup = async (groupId) => {
    try {
      console.log(`Fetching votes for group ${groupId}`)

      // Fetch all votes for this group
      const { data: allVotes, error: votesError } = await supabase.from("voting").select("*").eq("group_id", groupId)

      if (votesError) {
        console.error("Error fetching votes:", votesError)
        setVotes([])
        return
      }

      // Group votes by vote_id
      const voteMap = new Map()

      allVotes.forEach((vote) => {
        if (!voteMap.has(vote.vote_id)) {
          // Create a new entry for this vote_id
          voteMap.set(vote.vote_id, {
            vote_id: vote.vote_id,
            title: vote.vote_title,
            deadline: vote.deadline,
            description: vote.description,
            num_voters: 0, // Will be updated after fetching student_voting data
            suggestions: [],
          })
        }

        // Add this as a suggestion
        voteMap.get(vote.vote_id).suggestions.push({
          id: vote.id,
          suggestion_time: vote.suggestion_time,
          end_time: vote.end_time,
        })
      })

      // Fetch student voting data to count distinct voters for each vote
      for (const [voteId, voteData] of voteMap.entries()) {
        const { data: studentVotes, error: studentVotesError } = await supabase
          .from("student_voting")
          .select("student_id")
          .eq("vote_id", voteId)

        if (!studentVotesError && studentVotes) {
          // Count distinct student IDs
          const distinctStudentIds = new Set(studentVotes.map((vote) => vote.student_id))
          voteData.num_voters = distinctStudentIds.size
        }
      }

      // Convert the map to an array
      const processedVotes = Array.from(voteMap.values())
      console.log(`Found ${processedVotes.length} votes for group ${groupId}`)
      setVotes(processedVotes || [])
    } catch (error) {
      console.error("Error processing votes:", error)
      setVotes([])
    }
  }

  const handleGroupSelect = async (group) => {
    setSelectedGroup(group)
    await fetchDataForGroup(group.id)
    setShowSidebar(false) // Close sidebar on mobile after selection
  }

  const handleCreateVote = () => {
    verifyAuthAndProceed(() => {
      if (!selectedGroup && groups.length > 0) {
        setSelectedGroup(groups[0])
      }
      setIsCreateVoteModalOpen(true)
    })
  }

  const handleCreateMeeting = () => {
    verifyAuthAndProceed(() => {
      // Make sure we have a valid selected group before opening the modal
      if (!selectedGroup && groups.length > 0) {
        // If no group is selected but groups exist, select the first one
        const firstGroup = groups[0]
        console.log("Auto-selecting first group:", firstGroup)
        setSelectedGroup(firstGroup)

        // Ensure the group has the expected ID property
        if (!firstGroup.groupid && firstGroup.id) {
          // If the group has id but not groupid, create a copy with groupid
          const groupWithCorrectId = {
            ...firstGroup,
            groupid: firstGroup.id,
          }
          setSelectedGroup(groupWithCorrectId)
        }
      } else if (selectedGroup && !selectedGroup.groupid && selectedGroup.id) {
        // If selected group has id but not groupid, create a copy with groupid
        const groupWithCorrectId = {
          ...selectedGroup,
          groupid: selectedGroup.id,
        }
        setSelectedGroup(groupWithCorrectId)
      }

      // Now open the modal
      setIsCreateMeetingModalOpen(true)
    })
  }

  const handleVoteCreated = async (newVote) => {
    // Refresh votes after creation
    if (selectedGroup) {
      await fetchVotesForGroup(selectedGroup.id)
    }
    setIsCreateVoteModalOpen(false)
  }

  const handleMeetingCreated = async (newMeeting) => {
    // Refresh meetings after creation
    if (selectedGroup) {
      await fetchMeetingsForGroup(selectedGroup.id)
    }
    setIsCreateMeetingModalOpen(false)
  }

  const handleViewVoteDetails = (vote) => {
    setSelectedVote(vote)
    setIsVoteDetailsModalOpen(true)
  }

  const handleViewMeetingDetails = (meeting) => {
    // Find the group this meeting belongs to
    const meetingGroup = groups.find((group) => group.id === meeting.groupid)
    if (meetingGroup) {
      setSelectedGroup(meetingGroup)
    }

    setSelectedMeeting(meeting)
    setIsMeetingDetailsModalOpen(true)
  }

  const handleMeetingUpdated = async () => {
    // Refresh meetings after update
    if (selectedGroup) {
      await fetchMeetingsForGroup(selectedGroup.id)
    }
  }

  const handleMeetingDeleted = async () => {
    // Refresh meetings after deletion
    if (selectedGroup) {
      await fetchMeetingsForGroup(selectedGroup.id)
    }
    setIsMeetingDetailsModalOpen(false)
  }

  // Filter groups based on search query
  const filteredGroups = groups.filter((group) => group.title.toLowerCase().includes(searchQuery.toLowerCase()))

  // Filter votes based on status
  const filteredVotes = votes.filter((vote) => {
    if (filterStatus === "all") return true
    if (filterStatus === "active") return new Date(vote.deadline) > new Date()
    if (filterStatus === "completed") return new Date(vote.deadline) <= new Date()
    return true
  })

  // Filter meetings based on status
  const filteredMeetings = meetings.filter((meeting) => {
    if (meetingFilterStatus === "all") return true
    if (meetingFilterStatus === "upcoming") return new Date(meeting.scheduletime) > new Date()
    if (meetingFilterStatus === "past") return new Date(meeting.scheduletime) <= new Date()
    return true
  })

  // Get upcoming meetings (future meetings)
  const upcomingMeetings =
    meetingFilterStatus === "past"
      ? []
      : filteredMeetings.filter((meeting) => new Date(meeting.scheduletime) > new Date())

  // Get past meetings
  const pastMeetings =
    meetingFilterStatus === "upcoming"
      ? []
      : filteredMeetings.filter((meeting) => new Date(meeting.scheduletime) <= new Date())

  // Format date for display
  const formatDateTime = (dateTimeString) => {
    if (!dateTimeString) return "N/A"

    const date = new Date(dateTimeString)
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  // If still loading auth, show loading indicator
  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  // If no authenticated user, show login prompt
  if (!user) {
    return (
      <div className="flex h-screen items-center justify-center flex-col">
        <div className="text-2xl font-bold text-red-500 mb-4">Authentication Required</div>
        <p className="text-gray-600 mb-6">Please log in to view your meetings.</p>
        <button
          onClick={() => router.push("/auth")}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Go to Login
        </button>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white p-4 border-b border-gray-200 flex justify-between items-center shadow-sm">
          <h1 className="text-2xl font-bold text-gray-800">Meeting Scheduler</h1>

          <div className="flex items-center space-x-2 ml-4">
            <button
              onClick={() => {
                setViewMode("list")
                router.push("/meetings?view=list")
              }}
              className={`px-3 py-1.5 text-sm rounded-md ${
                viewMode === "list" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-700"
              }`}
            >
              <List className="w-4 h-4 md:mr-1 inline-block" />
              <span className="hidden md:inline">List</span>
            </button>
            <button
              onClick={() => {
                setViewMode("calendar")
                router.push("/meetings?view=calendar")
              }}
              className={`px-3 py-1.5 text-sm rounded-md ${
                viewMode === "calendar" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-700"
              }`}
            >
              <Calendar className="w-4 h-4 md:mr-1 inline-block" />
              <span className="hidden md:inline">Calendar</span>
            </button>
          </div>

          <div className="flex items-center space-x-4">
            {user && (
              <div className="flex items-center">
                <div className="mr-3 text-right hidden md:block">
                  <div className="font-medium">{user.userName || "Instructor"}</div>
                  <div className="text-sm text-gray-500">{user.role || "Instructor"}</div>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                  <span>{user.userName?.charAt(0) || "I"}</span>
                </div>
              </div>
            )}
          </div>
        </header>

        {/* Error message if any */}
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 m-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex-1 flex overflow-hidden">
          {/* Left sidebar - Groups list (only shown in list view or when toggled) */}
          {(viewMode === "list" || showSidebar) && (
            <div
              className={`${showSidebar ? "absolute z-10 h-full" : ""} w-80 border-r border-gray-200 bg-white overflow-y-auto`}
            >
              <div className="p-4 border-b border-gray-200">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Search groups..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              <div className="p-2">
                <h2 className="px-3 py-2 text-sm font-medium text-gray-500 uppercase tracking-wider">Your Groups</h2>

                {loading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                  </div>
                ) : filteredGroups.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No groups found</div>
                ) : (
                  <ul className="space-y-1">
                    {filteredGroups.map((group) => (
                      <li key={group.id}>
                        <button
                          onClick={() => handleGroupSelect(group)}
                          className={`w-full flex items-center justify-between px-3 py-3 rounded-md text-left ${
                            selectedGroup?.id === group.id
                              ? "bg-blue-50 text-blue-700"
                              : "text-gray-700 hover:bg-gray-100"
                          }`}
                        >
                          <div className="flex items-center">
                            <Users className="w-5 h-5 mr-3 text-gray-400" />
                            <span className="font-medium">{group.title}</span>
                          </div>
                          
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}

          {/* Main content */}
          <div className="flex-1 overflow-y-auto">
            {viewMode === "calendar" ? (
              <div className="p-6 h-full flex flex-col">
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center">
                    <button
                      onClick={() => setShowSidebar(!showSidebar)}
                      className="ml-2 md:hidden p-2 rounded-md hover:bg-gray-100"
                    >
                      <Filter className="w-5 h-5 text-gray-500" />
                    </button>
                  </div>
                </div>
                <div className="flex-1">
                  <SupervisorCalendar
                    onSelectMeeting={handleViewMeetingDetails}
                    onCreateMeeting={handleCreateMeeting}
                    instructorId={user?.user_id}
                    isAuthenticated={!!user}
                    key={`calendar-${meetings.length}-${user?.user_id}`} // Force re-render when meetings or user changes
                  />
                </div>
              </div>
            ) : selectedGroup ? (
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800">{selectedGroup.title}</h2>
                    <p className="text-gray-500">
                      {selectedGroup.members?.length || 0} members • {meetings.length} meetings • {votes.length} votes
                    </p>
                  </div>
                  <button
                    onClick={() => setShowSidebar(!showSidebar)}
                    className="md:hidden p-2 rounded-md hover:bg-gray-100"
                  >
                    <Filter className="w-5 h-5 text-gray-500" />
                  </button>
                </div>

                {/* Meetings Section */}
                <div className="mb-10">
                  <div className="flex items-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-800">Scheduled Meetings</h3>
                    <div className="ml-auto">
                      <button
                        onClick={handleCreateMeeting}
                        className="flex items-center px-4 py-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 shadow-sm transition-colors duration-200"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Schedule Meeting
                      </button>
                    </div>
                  </div>

                  {/* Meeting filter controls */}
                  <div className="flex items-center mb-6 space-x-2">
                    <div className="bg-white rounded-md border border-gray-200 p-1 flex">
                      <button
                        onClick={() => setMeetingFilterStatus("all")}
                        className={`px-3 py-1.5 text-sm rounded-md ${
                          meetingFilterStatus === "all" ? "bg-gray-100 text-gray-800" : "text-gray-600"
                        }`}
                      >
                        All Meetings
                      </button>
                      <button
                        onClick={() => setMeetingFilterStatus("upcoming")}
                        className={`px-3 py-1.5 text-sm rounded-md ${
                          meetingFilterStatus === "upcoming" ? "bg-green-50 text-green-700" : "text-gray-600"
                        }`}
                      >
                        Upcoming
                      </button>
                      <button
                        onClick={() => setMeetingFilterStatus("past")}
                        className={`px-3 py-1.5 text-sm rounded-md ${
                          meetingFilterStatus === "past" ? "bg-gray-50 text-gray-700" : "text-gray-600"
                        }`}
                      >
                        Past
                      </button>
                    </div>
                  </div>

                  {/* Upcoming Meetings */}
                  {upcomingMeetings.length === 0 && meetingFilterStatus !== "past" ? (
                    <div className="bg-white rounded-lg border border-gray-200 p-8 text-center mb-6">
                      <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium text-gray-800 mb-2">
                        {meetingFilterStatus === "all" ? "No meetings found" : "No upcoming meetings"}
                      </h3>
                      <p className="text-gray-500 mb-4">
                        {meetingFilterStatus !== "all"
                          ? `No ${meetingFilterStatus} meetings found. Try changing your filter.`
                          : "Schedule a meeting with this group to get started."}
                      </p>
                      <button
                        onClick={handleCreateMeeting}
                        className="inline-flex items-center px-4 py-2 bg-emerald-500 text-white rounded-md hover:bg-emerald-600 shadow-sm transition-colors duration-200"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Schedule Meeting
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      {upcomingMeetings.map((meeting) => (
                        <div
                          key={meeting.meetingid}
                          className="bg-white rounded-lg border border-green-200 hover:shadow-md transition-shadow cursor-pointer"
                          onClick={() => handleViewMeetingDetails(meeting)}
                        >
                          <div className="p-4">
                            <div className="flex justify-between items-start mb-2">
                              <h3 className="font-medium text-lg text-gray-800">{meeting.meeting_title}</h3>
                              <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800">
                                Upcoming
                              </span>
                            </div>

                            <p className="text-gray-500 text-sm mb-4 line-clamp-2">{meeting.meeting_description}</p>

                            <div className="flex items-center text-sm text-gray-500 mb-2">
                              <Clock className="w-4 h-4 mr-1" />
                              <span>{formatDateTime(meeting.scheduletime)}</span>
                            </div>

                            {meeting.meeting_link && (
                              <div className="mt-3 pt-3 border-t border-gray-100">
                                <a
                                  href={meeting.meeting_link}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                                >
                                  <Video className="w-4 h-4 mr-1" />
                                  Join Meeting
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Past Meetings */}
                  {pastMeetings.length > 0 ? (
                    <div>
                      <h4 className="text-md font-medium text-gray-700 mb-3">Past Meetings</h4>
                      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                        <div className="divide-y divide-gray-100">
                          {pastMeetings.map((meeting) => (
                            <div
                              key={meeting.meetingid}
                              className="p-4 hover:bg-gray-50 cursor-pointer"
                              onClick={() => handleViewMeetingDetails(meeting)}
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-medium text-gray-800">{meeting.meeting_title}</h3>
                                  <div className="flex items-center text-sm text-gray-500 mt-1">
                                    <Clock className="w-4 h-4 mr-1" />
                                    <span>{formatDateTime(meeting.scheduletime)}</span>
                                  </div>
                                </div>
                                <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-800">
                                  Completed
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    meetingFilterStatus === "past" && (
                      <div className="bg-white rounded-lg border border-gray-200 p-8 text-center mb-6">
                        <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-800 mb-2">No past meetings</h3>
                        <p className="text-gray-500">No completed meetings found for this group.</p>
                      </div>
                    )
                  )}
                </div>

                {/* Voting Section */}
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-800">Meeting Votes</h3>
                    <button
                      onClick={handleCreateVote}
                      className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Vote
                    </button>
                  </div>

                  {/* Filter controls */}
                  <div className="flex items-center mb-6 space-x-2">
                    <div className="bg-white rounded-md border border-gray-200 p-1 flex">
                      <button
                        onClick={() => setFilterStatus("all")}
                        className={`px-3 py-1.5 text-sm rounded-md ${
                          filterStatus === "all" ? "bg-gray-100 text-gray-800" : "text-gray-600"
                        }`}
                      >
                        All Votes
                      </button>
                      <button
                        onClick={() => setFilterStatus("active")}
                        className={`px-3 py-1.5 text-sm rounded-md ${
                          filterStatus === "active" ? "bg-blue-50 text-blue-700" : "text-gray-600"
                        }`}
                      >
                        Active
                      </button>
                      <button
                        onClick={() => setFilterStatus("completed")}
                        className={`px-3 py-1.5 text-sm rounded-md ${
                          filterStatus === "completed" ? "bg-green-50 text-green-700" : "text-gray-600"
                        }`}
                      >
                        Completed
                      </button>
                    </div>
                  </div>

                  {/* Votes list */}
                  {filteredVotes.length === 0 ? (
                    <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
                      <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium text-gray-800 mb-2">No meeting votes found</h3>
                      <p className="text-gray-500 mb-4">
                        {filterStatus !== "all"
                          ? `No ${filterStatus} votes found. Try changing your filter.`
                          : "Create your first meeting vote to schedule a meeting with this group."}
                      </p>
                      <button
                        onClick={handleCreateVote}
                        className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Create Vote
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filteredVotes.map((vote) => {
                        const isActive = new Date(vote.deadline) > new Date()
                        const totalVotes = vote.num_voters || 0
                        const totalMembers = selectedGroup.members?.length || 0
                        const responseRate = totalMembers > 0 ? Math.round((totalVotes / totalMembers) * 100) : 0
                        const suggestionCount = vote.suggestions?.length || 0

                        return (
                          <div
                            key={vote.vote_id}
                            className="bg-white rounded-lg border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
                            onClick={() => handleViewVoteDetails(vote)}
                          >
                            <div className="p-4">
                              <div className="flex justify-between items-start mb-2">
                                <h3 className="font-medium text-lg text-gray-800">{vote.title}</h3>
                                <span
                                  className={`text-xs px-2 py-1 rounded-full ${
                                    isActive ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"
                                  }`}
                                >
                                  {isActive ? "Active" : "Completed"}
                                </span>
                              </div>

                              <p className="text-gray-500 text-sm mb-4 line-clamp-2">{vote.description}</p>

                              <div className="flex items-center text-sm text-gray-500 mb-3">
                                <Clock className="w-4 h-4 mr-1" />
                                <span>
                                  Deadline: {new Date(vote.deadline).toLocaleDateString()} at{" "}
                                  {new Date(vote.deadline).toLocaleTimeString([], {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })}
                                </span>
                              </div>

                              <div className="flex justify-between items-center">
                                <div className="flex items-center">
                                  <Users className="w-4 h-4 mr-1 text-gray-400" />
                                  <span className="text-sm text-gray-500">
                                    {totalVotes} of {totalMembers} voted
                                  </span>
                                </div>

                                <div className="flex items-center">
                                  <div className="w-20 bg-gray-200 rounded-full h-2 mr-2">
                                    <div
                                      className="bg-blue-600 h-2 rounded-full"
                                      style={{ width: `${responseRate}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-xs text-gray-500">{responseRate}%</span>
                                </div>
                              </div>

                              {suggestionCount > 0 && (
                                <div className="mt-3 pt-3 border-t border-gray-100">
                                  <span className="text-xs text-blue-600">
                                    {suggestionCount} meeting time suggestion{suggestionCount !== 1 ? "s" : ""}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center p-8">
                  <Calendar className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium text-gray-700 mb-2">Calendar View</h3>
                  <p className="text-gray-500 max-w-md mb-6">
                    View all your meetings across all groups in one unified calendar.
                  </p>
                  <button
                    onClick={() => setViewMode("calendar")}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Switch to Calendar View
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create Vote Modal */}
      <CreateVoteModal
        isOpen={isCreateVoteModalOpen}
        onClose={() => setIsCreateVoteModalOpen(false)}
        group={selectedGroup}
        onVoteCreated={handleVoteCreated}
      />

      {/* Create Meeting Modal */}
      <CreateMeetingModal
        isOpen={isCreateMeetingModalOpen}
        onClose={() => setIsCreateMeetingModalOpen(false)}
        group={selectedGroup}
        onMeetingCreated={handleMeetingCreated}
      />

      {/* Vote Details Modal */}
      <VoteDetailsModal
        isOpen={isVoteDetailsModalOpen}
        onClose={() => setIsVoteDetailsModalOpen(false)}
        vote={selectedVote}
        group={selectedGroup}
        onVoteUpdated={() => fetchVotesForGroup(selectedGroup?.id)}
      />

      {/* Meeting Details Modal */}
      <MeetingDetailsModal
        isOpen={isMeetingDetailsModalOpen}
        onClose={() => setIsMeetingDetailsModalOpen(false)}
        meeting={selectedMeeting}
        group={selectedGroup}
        onMeetingUpdated={handleMeetingUpdated}
        onMeetingDeleted={handleMeetingDeleted}
      />
    </div>
  )
}
