"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { supabase } from "@/lib/supabase"
import Sidebar from "@/app/instructorComponents/sidebar"
import VoteDetailsView from "@/app/instructorComponents/vote-details-view"

export default function VotesPage() {
  const searchParams = useSearchParams()
  const groupId = searchParams.get("groupId")
  const [currentUser, setCurrentUser] = useState(null)
  const [group, setGroup] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)

        // Fetch current user (for demo, we'll use the supervisor)
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("*")
          .eq("user_id", "863f0f67-0a17-4ede-96d8-6fe15d746c64")
          .single()

        if (!userError) {
          setCurrentUser({
            ...userData,
            userName: userData.userName || "Supervisor",
          })
        } else {
          // Mock user for demo
          setCurrentUser({
            user_id: "863f0f67-0a17-4ede-96d8-6fe15d746c64",
            userName: "Supervisor",
            role: "Supervisor",
          })
        }

        // Fetch group details if groupId is provided
        if (groupId) {
          const { data: groupData, error: groupError } = await supabase
            .from("projectgroup")
            .select("*")
            .eq("groupid", groupId)
            .single()

          if (!groupError) {
            setGroup(groupData)
          }
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [groupId])

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />

      <div className="flex-1 overflow-auto">
        <header className="bg-white p-4 border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-2xl font-bold text-gray-800">Meeting Votes</h1>
            {group && <p className="text-gray-500">Group: {group.groupname}</p>}
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : groupId ? (
            <VoteDetailsView groupId={groupId} currentUser={currentUser} />
          ) : (
            <div className="bg-white rounded-lg p-6 shadow-sm text-center">
              <p className="text-gray-500">Please select a group to view votes.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
