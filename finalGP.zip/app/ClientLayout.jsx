"use client"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/context/auth-context"

export default function ClientLayout({ children }) {
  const router = useRouter()
  const path = usePathname()
  const { user } = useAuth()

  useEffect(() => {
    // skip the public auth pages
    if (["/auth", "/signup", "/forgot-password", "/reset-password", "/auth-redirect"].includes(path)) {
      return
    }

    // if logged out, send to login and stop
    if (!user) {
      router.replace("/auth")
      return
    }

    // if at root, redirect by role
    if (path === "/") {
      const role = (user.role || "").toLowerCase()
      if (role === "instructor") {
        console.log("CLIENT LAYOUT: ✓ Redirecting INSTRUCTOR to /home")
        router.replace("/home")
      } else if (role === "projectcommittee") {
        console.log("CLIENT LAYOUT: ✓ Redirecting COMMITTEE to /committee")
        router.replace("/committee")
      } else {
        console.log("CLIENT LAYOUT: ✓ Redirecting STUDENT to /dashboard")
        router.replace("/dashboard")
      }
    }
  }, [path, user, router])

  return <>{children}</>
}
