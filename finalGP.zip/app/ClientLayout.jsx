"use client"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { getCurrentUser } from "@/utils/supabase/auth"

export default function ClientLayout({ children }) {
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Check authentication status
    const user = getCurrentUser()

    // Skip redirection for auth-related pages
    if (pathname === "/auth" || pathname === "/signup" || pathname === "/forgot-password") {
      return
    }

    // If no user is logged in, redirect to auth page
    if (!user) {
      router.push("/auth")
      return
    }

    // Handle role-based redirection for root path
    if (pathname === "/") {
      const userRole = (user.role || "").toLowerCase().trim()
      console.log(`CLIENT LAYOUT: User at root path with role "${userRole}"`)

      // Very explicit role checking
      if (userRole === "instructor") {
        console.log("CLIENT LAYOUT: ✓ Redirecting INSTRUCTOR to /home")
        router.push("/home")
      } else if (userRole === "projectcommittee") {
        console.log("CLIENT LAYOUT: ✓ Redirecting COMMITTEE to /committee")
        router.push("/committee")
      } else {
        console.log("CLIENT LAYOUT: ✓ Redirecting STUDENT to /dashboard")
        router.push("/dashboard")
      }
    }
  }, [pathname])

  return <>{children}</>
}
