export default function Loading() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div className="bg-blue-600 p-4">
          <div className="h-8 w-3/4 bg-blue-400/30 rounded animate-pulse"></div>
          <div className="h-4 w-1/2 bg-blue-400/30 rounded animate-pulse mt-2"></div>
        </div>

        <div className="p-6 space-y-4">
          <div className="h-5 w-1/4 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-10 w-full bg-gray-200 rounded animate-pulse"></div>

          <div className="h-5 w-1/4 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-10 w-full bg-gray-200 rounded animate-pulse"></div>

          <div className="h-5 w-1/4 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-10 w-full bg-gray-200 rounded animate-pulse"></div>

          <div className="h-5 w-1/4 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-10 w-full bg-gray-200 rounded animate-pulse"></div>

          <div className="h-5 w-1/4 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-10 w-full bg-gray-200 rounded animate-pulse"></div>

          <div className="h-10 w-full bg-gray-300 rounded animate-pulse mt-4"></div>
        </div>
      </div>
    </div>
  )
}
