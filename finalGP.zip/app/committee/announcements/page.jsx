"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { getAnnouncements } from "@/utils/supabase/announcement-service"
import { AnnouncementsTable } from "@/components/committee/announcements-table"
import { AlertCircle, ArrowLeft, Megaphone } from "lucide-react"
import Link from "next/link"

export default function ViewAnnouncementsPage() {
  const { user } = useAuth()
  const [announcements, setAnnouncements] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Function to fetch announcements
  useEffect(() => {
    async function fetchAnnouncements() {
      if (!user?.user_id) return

      setLoading(true)
      setError(null)

      try {
        const { announcements: fetchedAnnouncements, error: fetchError } = await getAnnouncements()

        if (fetchError) {
          throw new Error(fetchError)
        }

        setAnnouncements(fetchedAnnouncements)
      } catch (err) {
        console.error("Error fetching announcements:", err)
        setError("Failed to load announcements: " + err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchAnnouncements()
  }, [user])

  const handleAnnouncementDeleted = (deletedId) => {
    // If the deletedId is "refresh", fetch all announcements again
    if (deletedId === "refresh") {
      setLoading(true)
      getAnnouncements()
        .then(({ announcements: refreshedAnnouncements }) => {
          setAnnouncements(refreshedAnnouncements)
          setLoading(false)
        })
        .catch((err) => {
          console.error("Error refreshing announcements:", err)
          setLoading(false)
        })
      return
    }

    // Otherwise, remove the deleted announcement from the state
    setAnnouncements((prevAnnouncements) =>
      prevAnnouncements.filter((announcement) => announcement.announcement_id !== deletedId),
    )
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Megaphone className="text-blue-600" />
          Previous Announcements
        </h1>
        <Link
          href="/committee"
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
        >
          <ArrowLeft size={16} />
          <span>Back to Create Announcement</span>
        </Link>
      </div>

      {/* Error message */}
      {error && (
        <div className="p-4 bg-red-50 text-red-800 rounded-lg flex items-start gap-3 mb-6">
          <AlertCircle className="mt-0.5" />
          <div>
            <p className="font-medium">Error Loading Announcements</p>
            <p>{error}</p>
          </div>
        </div>
      )}

      {/* Announcements table */}
      {loading ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 flex justify-center items-center h-64">
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-gray-500">Loading announcements...</p>
          </div>
        </div>
      ) : (
        <AnnouncementsTable announcements={announcements} onAnnouncementDeleted={handleAnnouncementDeleted} />
      )}
    </div>
  )
}
