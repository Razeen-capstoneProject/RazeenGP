"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import { AssignExaminerComponent } from "@/components/committee/assign-examiner"
import { Users } from "lucide-react"

export default function AssignExaminerPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const [redirecting, setRedirecting] = useState(false)

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        // Redirect to auth if not logged in
        console.log("No user found, redirecting to auth")
        setRedirecting(true)
        router.push("/auth")
      } else if (user.role !== "projectcommittee") {
        // If not a project committee member, redirect to appropriate dashboard
        console.log("User is not a project committee member, redirecting")
        setRedirecting(true)
        router.push("/dashboard")
      }
    }
  }, [user, isLoading, router])

  // Show loading state while checking authentication
  if (isLoading || redirecting) {
    return (
      <div className="p-8">
        <div className="flex justify-center items-center h-64">
          <div className="w-10 h-10 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      </div>
    )
  }

  // Don't render anything if not authenticated as project committee
  if (!user || user.role !== "projectcommittee") {
    return null
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Users className="text-blue-600" />
          Assign Examiners
        </h1>
      </div>

      <AssignExaminerComponent />
    </div>
  )
}
