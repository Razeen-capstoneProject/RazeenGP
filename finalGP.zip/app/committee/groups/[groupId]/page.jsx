"use client"

import { GroupDetails } from "@/components/committee/group-details"

export default function CommitteeGroupDetailsPage({ params }) {
  const { groupId } = params

  return (
    <div className="p-8">
      <GroupDetails groupId={groupId} />
    </div>
  )
}
