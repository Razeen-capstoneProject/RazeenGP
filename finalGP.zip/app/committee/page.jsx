"use client"

import { useState } from "react"
import { useAuth } from "@/context/auth-context"
import { AnnouncementForm } from "@/components/committee/announcement-form"
import { Megaphone, ListFilter } from "lucide-react"
import Link from "next/link"

export default function CommitteeAnnouncementsPage() {
  const { user } = useAuth()
  const [success, setSuccess] = useState(null)

  const handleAnnouncementCreated = (newAnnouncement) => {
    // Set success message
    setSuccess("Announcement created successfully!")

    // Clear success message after 5 seconds
    setTimeout(() => {
      setSuccess(null)
    }, 5000)
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <Megaphone className="text-blue-600" />
          Create Announcement
        </h1>
        <Link
          href="/committee/announcements"
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <ListFilter size={18} />
          <span>View Previous Announcements</span>
        </Link>
      </div>

      {/* Success message */}
      {success && <div className="p-4 bg-green-50 text-green-800 rounded-lg mb-6">{success}</div>}

      <div className="space-y-8">
        {/* Create announcement form */}
        <AnnouncementForm onAnnouncementCreated={handleAnnouncementCreated} />
      </div>
    </div>
  )
}
