"use client"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import Link from "next/link"
// Add the import for the UserPlus icon
import { Megaphone, ListFilter, Users, Layers, UserPlus } from "lucide-react"
import { signOut } from "@/utils/supabase/auth"

export default function CommitteeLayout({ children }) {
  const { user, isLoading, redirectToUserDashboard } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [redirecting, setRedirecting] = useState(false)
  const [activeRoute, setActiveRoute] = useState("")

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        // Redirect to auth if not logged in
        console.log("No user found, redirecting to auth")
        setRedirecting(true)
        router.push("/auth")
      } else if (user.role !== "projectcommittee") {
        // If not a project committee member, redirect to appropriate dashboard
        console.log("User is not a project committee member, redirecting")
        setRedirecting(true)
        redirectToUserDashboard()
      }
    }

    // Set active route based on pathname
    setActiveRoute(pathname)
  }, [user, isLoading, router, redirectToUserDashboard, pathname])

  // Show loading state while checking authentication
  if (isLoading || redirecting) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-2 border-gray-900 mx-auto mb-4"></div>
          <p>{redirecting ? "Redirecting..." : "Loading..."}</p>
        </div>
      </div>
    )
  }

  // Don't render anything if not authenticated as project committee
  if (!user || user.role !== "projectcommittee") {
    return null
  }

  const handleSignOut = async () => {
    try {
      const { success, error } = await signOut()
      if (success) {
        router.push("/auth")
      } else {
        console.error("Error signing out:", error)
        alert("Failed to sign out. Please try again.")
      }
    } catch (error) {
      console.error("Unexpected error during sign out:", error)
      alert("An unexpected error occurred. Please try again.")
    }
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-[#111827] text-white flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold">Project Committee</h1>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-4 space-y-2">
          <Link
            href="/committee"
            className={`flex items-center gap-3 px-4 py-3 rounded-md ${
              activeRoute === "/committee" ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            <Megaphone className="h-5 w-5" />
            <span>Create Announcement</span>
          </Link>
          <Link
            href="/committee/announcements"
            className={`flex items-center gap-3 px-4 py-3 rounded-md ${
              activeRoute === "/committee/announcements" ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            <ListFilter className="h-5 w-5" />
            <span>View Announcements</span>
          </Link>
          <Link
            href="/committee/assign-examiner"
            className={`flex items-center gap-3 px-4 py-3 rounded-md ${
              activeRoute === "/committee/assign-examiner"
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            <Users className="h-5 w-5" />
            <span>Assign Examiner</span>
          </Link>
          <Link
            href="/committee/groups"
            className={`flex items-center gap-3 px-4 py-3 rounded-md ${
              activeRoute === "/committee/groups" || activeRoute?.startsWith("/committee/groups/")
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            <Layers className="h-5 w-5" />
            <span>Groups</span>
          </Link>
          {/* Add the Create Account link in the navigation section, after the Groups link */}
          <Link
            href="/committee/create-account"
            className={`flex items-center gap-3 px-4 py-3 rounded-md ${
              activeRoute === "/committee/create-account" ? "bg-blue-600 text-white" : "text-gray-300 hover:bg-gray-700"
            }`}
          >
            <UserPlus className="h-5 w-5" />
            <span>Create Account</span>
          </Link>
        </nav>

        {/* Sign Out Button */}
        <div className="p-4 mt-auto">
          <button
            onClick={handleSignOut}
            className="w-full py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-gray-50">{children}</div>
    </div>
  )
}
