"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function AuthRedirectPage() {
  const router = useRouter()

  useEffect(() => {
    const hash = window.location.hash
    const params = new URLSearchParams(hash.substring(1))
    const accessToken = params.get("access_token")

    if (accessToken) {
      router.replace(`/reset-password?access_token=${accessToken}`)
    } else {
      router.replace("/") // رجع المستخدم للصفحة الرئيسية لو ما فيه توكن
    }
  }, [router])

  return <p>Redirecting...</p>
}
