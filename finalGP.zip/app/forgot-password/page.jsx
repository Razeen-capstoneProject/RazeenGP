"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"
import { supabase } from "@/utils/supabase/client"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")

  const handleResetPassword = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")
    setMessage("")

    try {
      // Check if the email exists in the database first
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("user_id, email")
        .eq("email", email.trim())
        .single()

      if (userError || !userData) {
        setError("No account found with this email address.")
        setIsSubmitting(false)
        return
      }

      // Use Supabase's built-in password reset functionality
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
  redirectTo: 'https://razeen1.vercel.app/auth-redirect'
});



      if (resetError) {
        console.error("Password reset error:", resetError)
        setError("Failed to send password reset email. Please try again.")
        setIsSubmitting(false)
        return
      }

      setMessage("Password reset instructions have been sent to your email address.")
    } catch (err) {
      console.error("Password reset request error:", err)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white">
      <div className="w-full max-w-md p-6">
        <div className="flex justify-center mb-8">
          <Image src="/images/razeen-logo.png" alt="Razeen Logo" width={180} height={120} />
        </div>

        <h2 className="text-3xl font-bold text-center mb-8">Reset Password</h2>

        <form onSubmit={handleResetPassword}>
          <div className="mb-6">
            <label htmlFor="email" className="block mb-2 text-base font-medium text-gray-700">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              disabled={isSubmitting}
              className="w-full px-3 py-3 border border-gray-300 rounded-md shadow-sm text-base focus:outline-none focus:ring-black focus:border-black disabled:bg-gray-100 disabled:text-gray-500"
              placeholder="Enter your email address"
            />
          </div>

          {error && <div className="p-3 mb-6 bg-red-100 text-red-800 rounded-md">{error}</div>}
          {message && <div className="p-3 mb-6 bg-green-100 text-green-800 rounded-md">{message}</div>}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 px-4 bg-black text-white border-none rounded-md text-base mb-6 transition-opacity disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                <span>Processing...</span>
              </div>
            ) : (
              "Send Reset Instructions"
            )}
          </button>
        </form>

        <div className="mt-4">
          <Link href="/auth" className="text-sm text-gray-600 hover:underline flex items-center justify-center">
            <ArrowLeft size={16} className="mr-1" />
            Back to Login
          </Link>
        </div>
      </div>
    </div>
  )
}
