"use client"

import { createContext, useContext, useState, useEffect } from "react"
import { getCurrentUser } from "@/utils/supabase/auth"
import { useRouter } from "next/navigation"

// Create the auth context
const AuthContext = createContext()

// Custom hook to use the auth context
export function useAuth() {
  return useContext(AuthContext)
}

// Auth provider component
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Function to redirect user based on role - simplified and more direct
  const redirectToUserDashboard = (user) => {
    if (!user) return false

    try {
      // Force lowercase for consistent comparison
      const role = (user.role || "").toLowerCase().trim()

      console.log(`AUTH CONTEXT: Redirecting user with role "${role}"`)

      // Very explicit role checking for instructors
      if (role === "instructor") {
        console.log("AUTH CONTEXT: ✓ Redirecting INSTRUCTOR to /home")
        router.push("/home")
        return true
      }
      // Project Committee check
      else if (role === "projectcommittee") {
        console.log("AUTH CONTEXT: ✓ Redirecting COMMITTEE to /committee")
        router.push("/committee")
        return true
      }
      // Default to student dashboard
      else {
        console.log("AUTH CONTEXT: ✓ Redirecting STUDENT to /dashboard")
        router.push("/dashboard")
        return true
      }
    } catch (error) {
      console.error("Error redirecting user:", error)
      return false
    }
  }

  // Load user on initial render
  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = getCurrentUser()
        console.log("AUTH CONTEXT: Current user loaded:", currentUser?.role || "no user")
        setUser(currentUser)
      } catch (error) {
        console.error("Error loading user:", error)
        setUser(null)
      } finally {
        setIsLoading(false)
      }
    }

    loadUser()

    // Listen for auth state changes
    const handleAuthChange = () => {
      const currentUser = getCurrentUser()
      console.log("AUTH CONTEXT: Auth state changed, user role:", currentUser?.role || "no user")
      setUser(currentUser)
    }

    window.addEventListener("auth-state-changed", handleAuthChange)

    return () => {
      window.removeEventListener("auth-state-changed", handleAuthChange)
    }
  }, [])

  // Context value
  const value = {
    user,
    isLoading,
    redirectToUserDashboard,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
