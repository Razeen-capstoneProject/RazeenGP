"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"

export function useGanttData(groupId) {
  const [tasks, setTasks] = useState([])
  const [dependencies, setDependencies] = useState([])
  const [milestones, setMilestones] = useState([])
  const [assignees, setAssignees] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchData = async () => {
      if (!groupId) return

      try {
        setIsLoading(true)
        setError(null)

        // Fetch tasks for this group
        const { data: tasksData, error: tasksError } = await supabase.from("task").select("*").eq("groupid", groupId)

        if (tasksError) {
          throw new Error(`Error fetching tasks: ${tasksError.message}`)
        }

        // Process tasks to ensure they have start dates and end dates
        const processedTasks = tasksData.map((task) => {
          // If task has no start_date, use created_at or current date
          const startDate = task.start_date
            ? new Date(task.start_date)
            : task.created_at
              ? new Date(task.created_at)
              : new Date()

          // Ensure deadline exists, default to start date + 7 days if not
          const endDate = task.deadline
            ? new Date(task.deadline)
            : new Date(startDate.getTime() + 7 * 24 * 60 * 60 * 1000)

          return {
            ...task,
            start_date: startDate.toISOString(),
            end_date: endDate.toISOString(),
          }
        })

        setTasks(processedTasks || [])

        // Fetch dependencies
        const { data: dependenciesData, error: dependenciesError } = await supabase
          .from("task_dependency")
          .select("*")
          .or(
            `source_task.in.(${tasksData.map((t) => t.id).join(",")}),target_task.in.(${tasksData.map((t) => t.id).join(",")})`,
          )

        if (dependenciesError && dependenciesError.code !== "PGRST116") {
          console.error("Error fetching dependencies:", dependenciesError)
        } else {
          setDependencies(dependenciesData || [])
        }

        // Fetch milestones for this group
        const { data: milestonesData, error: milestonesError } = await supabase
          .from("milestone")
          .select("*")
          .eq("group_id", groupId)

        if (milestonesError) {
          console.error("Error fetching milestones:", milestonesError)
        } else {
          setMilestones(milestonesData || [])
        }

        // Fetch assignees (students) for this group
        const { data: studentsData, error: studentsError } = await supabase
          .from("student")
          .select("student_id, users!inner(*)")
          .eq("groupid", groupId)

        if (studentsError) {
          console.error("Error fetching students:", studentsError)
        } else {
          const formattedAssignees = (studentsData || []).map((student) => ({
            id: student.student_id,
            name: student.users?.userName || `Student ${student.student_id.substring(0, 8)}`,
          }))
          setAssignees(formattedAssignees)
        }
      } catch (err) {
        console.error("Error fetching Gantt data:", err)
        setError(err instanceof Error ? err.message : "An unknown error occurred")
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()

    // Set up real-time subscription
    const taskSubscription = supabase
      .channel("task-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "task" }, (payload) => {
        // Handle real-time updates - this is simplified, in a real app you would need to
        // determine if the change affects tasks in the current group
        fetchData()
      })
      .subscribe()

    return () => {
      // Clean up subscription
      supabase.removeChannel(taskSubscription)
    }
  }, [groupId])

  // Function to update task dates
  const updateTaskDates = async (taskId, startDate, endDate) => {
    try {
      const { error } = await supabase
        .from("task")
        .update({
          start_date: startDate.toISOString(),
          deadline: endDate.toISOString(),
        })
        .eq("taskid", taskId)

      if (error) {
        throw error
      }

      // Update local state
      setTasks(
        tasks.map((task) =>
          task.taskid === taskId
            ? { ...task, start_date: startDate.toISOString(), end_date: endDate.toISOString() }
            : task,
        ),
      )

      return true
    } catch (error) {
      console.error("Error updating task dates:", error)
      throw error
    }
  }

  return {
    tasks,
    dependencies,
    milestones,
    assignees,
    isLoading,
    error,
    updateTaskDates,
  }
}
