import { supabase } from "./client"

/**
 * Get all project groups with their details including supervisor and current examiners
 * @returns {Promise<Object>} - The groups and any error
 */
export async function getAllGroupsWithDetails() {
  try {
    console.log("Fetching all groups with details")

    // First, get all project groups with their basic info
    const { data: groups, error: groupsError } = await supabase
      .from("projectgroup")
      .select(`
        groupid,
        groupname,
        group_status,
        group_progress,
        instructor_supervisor_id
      `)
      .order("groupname", { ascending: true })

    if (groupsError) {
      console.error("Error fetching groups:", groupsError)
      return { groups: [], error: groupsError.message }
    }

    // Now get all examiner assignments
    const { data: assignments, error: assignmentsError } = await supabase
      .from("assign_examiner_to_group")
      .select("groupid, instructor_id, pcmid")

    if (assignmentsError) {
      console.error("Error fetching examiner assignments:", assignmentsError)
      return { groups: [], error: assignmentsError.message }
    }

    // Create a map of assignments by group ID (supporting multiple examiners)
    const assignmentsByGroup = {}
    assignments?.forEach((assignment) => {
      if (!assignmentsByGroup[assignment.groupid]) {
        assignmentsByGroup[assignment.groupid] = []
      }
      assignmentsByGroup[assignment.groupid].push(assignment.instructor_id)
    })

    // Get all users who are instructors
    const { data: instructors, error: instructorsError } = await supabase
      .from("users")
      .select("user_id, userName, email, role")
      .eq("role", "instructor")

    if (instructorsError) {
      console.error("Error fetching instructors:", instructorsError)
      return { groups: [], error: instructorsError.message }
    }

    // Create a map of instructors by ID
    const instructorsById = {}
    instructors?.forEach((instructor) => {
      instructorsById[instructor.user_id] = instructor
    })

    // Process the data to make it easier to work with
    const processedGroups = groups.map((group) => {
      // Get supervisor info
      const supervisorId = group.instructor_supervisor_id
      const supervisor = supervisorId ? instructorsById[supervisorId] : null

      // Get examiner info - now supporting multiple examiners
      const examinerIds = assignmentsByGroup[group.groupid] || []
      const examiners = examinerIds.map((id) => instructorsById[id]).filter(Boolean)

      return {
        id: group.groupid,
        name: group.groupname,
        status: group.group_status,
        progress: group.group_progress,
        supervisor: supervisor,
        examiners: examiners,
        hasExaminers: examiners.length > 0,
      }
    })

    return { groups: processedGroups, error: null }
  } catch (error) {
    console.error("Unexpected error in getAllGroupsWithDetails:", error)
    return { groups: [], error: "An unexpected error occurred" }
  }
}

/**
 * Get all instructors who can be assigned as examiners
 * @returns {Promise<Object>} - The instructors and any error
 */
export async function getAllInstructors() {
  try {
    console.log("Fetching all instructors")

    const { data, error } = await supabase
      .from("users")
      .select("user_id, userName, email")
      .eq("role", "instructor")
      .order("userName", { ascending: true })

    if (error) {
      console.error("Error fetching instructors:", error)
      return { instructors: [], error: error.message }
    }

    return { instructors: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getAllInstructors:", error)
    return { instructors: [], error: "An unexpected error occurred" }
  }
}

/**
 * Check if an instructor is already assigned as an examiner to a group
 * @param {number} groupId - The ID of the group
 * @param {string} instructorId - The ID of the instructor
 * @returns {Promise<Object>} - Whether the instructor is assigned and any error
 */
export async function isExaminerAssignedToGroup(groupId, instructorId) {
  try {
    if (!groupId || !instructorId) {
      return { isAssigned: false, error: "Group ID and instructor ID are required" }
    }

    const { data, error } = await supabase
      .from("assign_examiner_to_group")
      .select("*")
      .eq("groupid", groupId)
      .eq("instructor_id", instructorId)
      .single()

    if (error) {
      // If the error is "No rows found", it means the instructor is not assigned
      if (error.code === "PGRST116") {
        return { isAssigned: false, error: null }
      }
      console.error("Error checking examiner assignment:", error)
      return { isAssigned: false, error: error.message }
    }

    return { isAssigned: !!data, error: null }
  } catch (error) {
    console.error("Unexpected error in isExaminerAssignedToGroup:", error)
    return { isAssigned: false, error: "An unexpected error occurred" }
  }
}

/**
 * Get all examiners assigned to a group
 * @param {number} groupId - The ID of the group
 * @returns {Promise<Object>} - The examiners and any error
 */
export async function getGroupExaminers(groupId) {
  try {
    if (!groupId) {
      return { examiners: [], error: "Group ID is required" }
    }

    const { data: assignments, error: assignmentsError } = await supabase
      .from("assign_examiner_to_group")
      .select(`
        instructor_id,
        users:instructor_id(user_id, userName, email)
      `)
      .eq("groupid", groupId)

    if (assignmentsError) {
      console.error("Error fetching group examiners:", assignmentsError)
      return { examiners: [], error: assignmentsError.message }
    }

    // Extract the user data from the result
    const examiners = assignments.map((assignment) => assignment.users).filter(Boolean)

    return { examiners, error: null }
  } catch (error) {
    console.error("Unexpected error in getGroupExaminers:", error)
    return { examiners: [], error: "An unexpected error occurred" }
  }
}

/**
 * Assign an examiner to a group
 * @param {number} groupId - The ID of the group
 * @param {string} instructorId - The ID of the instructor to assign as examiner
 * @param {string} pcmId - The ID of the project committee member making the assignment
 * @returns {Promise<Object>} - Success status and any error
 */
export async function assignExaminerToGroup(groupId, instructorId, pcmId) {
  try {
    if (!groupId || !instructorId) {
      return { success: false, error: "Group ID and instructor ID are required" }
    }

    console.log(`Assigning examiner ${instructorId} to group ${groupId}`)

    // Check if this instructor is already assigned as an examiner to this group
    const { isAssigned, error: checkError } = await isExaminerAssignedToGroup(groupId, instructorId)

    if (checkError) {
      console.error("Error checking existing assignment:", checkError)
      return { success: false, error: checkError }
    }

    if (isAssigned) {
      // Instructor is already assigned, no need to do anything
      return { success: true, updated: false, error: null, alreadyAssigned: true }
    }

    // Create new assignment
    const { error: insertError } = await supabase.from("assign_examiner_to_group").insert({
      groupid: groupId,
      instructor_id: instructorId,
      pcmid: pcmId,
    })

    if (insertError) {
      console.error("Error creating examiner assignment:", insertError)
      return { success: false, error: insertError.message }
    }

    return { success: true, updated: false, error: null }
  } catch (error) {
    console.error("Unexpected error in assignExaminerToGroup:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

/**
 * Remove an examiner assignment from a group
 * @param {number} groupId - The ID of the group
 * @param {string} instructorId - The ID of the instructor to remove
 * @returns {Promise<Object>} - Success status and any error
 */
export async function removeExaminerFromGroup(groupId, instructorId) {
  try {
    if (!groupId || !instructorId) {
      return { success: false, error: "Group ID and instructor ID are required" }
    }

    console.log(`Removing examiner ${instructorId} from group ${groupId}`)

    const { error } = await supabase
      .from("assign_examiner_to_group")
      .delete()
      .eq("groupid", groupId)
      .eq("instructor_id", instructorId)

    if (error) {
      console.error("Error removing examiner assignment:", error)
      return { success: false, error: error.message }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Unexpected error in removeExaminerFromGroup:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
