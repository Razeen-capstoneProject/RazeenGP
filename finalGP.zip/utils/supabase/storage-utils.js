import { supabase } from "./client"

/**
 * Lists all files in a specific path within a bucket
 * @param {string} bucket - The storage bucket name
 * @param {string} path - The path within the bucket
 * @returns {Promise<Object>} - The list of files and any error
 */
export async function listFiles(bucket, path = "") {
  try {
    console.log(`Listing files in bucket: ${bucket}, path: ${path}`)

    const { data, error } = await supabase.storage.from(bucket).list(path, {
      limit: 100,
      offset: 0,
      sortBy: { column: "name", order: "asc" },
    })

    if (error) {
      console.error("Error listing files:", error)
      return { files: [], error: error.message }
    }

    return { files: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in listFiles:", error)
    return { files: [], error: "An unexpected error occurred" }
  }
}

/**
 * Deletes a file from storage
 * @param {string} bucket - The storage bucket name
 * @param {string} path - The file path to delete
 * @returns {Promise<Object>} - Success status and any error
 */
export async function deleteFile(bucket, path) {
  try {
    if (!bucket || !path) {
      return { success: false, error: "Bucket and path are required" }
    }

    console.log(`Attempting to delete file: ${path} from bucket: ${bucket}`)

    const { data, error } = await supabase.storage.from(bucket).remove([path])

    if (error) {
      console.error("Error deleting file:", error)
      return { success: false, error: error.message }
    }

    console.log("File deletion result:", data)
    return { success: true, data, error: null }
  } catch (error) {
    console.error("Unexpected error in deleteFile:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

/**
 * Checks if a file exists in storage
 * @param {string} bucket - The storage bucket name
 * @param {string} path - The file path to check
 * @returns {Promise<Object>} - Whether the file exists and any error
 */
export async function fileExists(bucket, path) {
  try {
    if (!bucket || !path) {
      return { exists: false, error: "Bucket and path are required" }
    }

    // Extract the directory path and filename
    const pathParts = path.split("/")
    const filename = pathParts.pop()
    const directory = pathParts.join("/")

    console.log(`Checking if file exists: ${filename} in directory: ${directory}`)

    // List files in the directory
    const { data, error } = await supabase.storage.from(bucket).list(directory)

    if (error) {
      console.error("Error checking if file exists:", error)
      return { exists: false, error: error.message }
    }

    // Check if the file is in the list
    const exists = data.some((item) => item.name === filename)

    return { exists, error: null }
  } catch (error) {
    console.error("Unexpected error in fileExists:", error)
    return { exists: false, error: "An unexpected error occurred" }
  }
}
