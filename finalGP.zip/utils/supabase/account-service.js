import { supabase } from "./client"
import { hashPassword } from "./password-utils"

export async function createUserAccount(email, username, password, role) {
  try {
    // Validate role - only allow student or instructor
    if (role !== "student" && role !== "instructor") {
      return { success: false, error: "Invalid role. Only student or instructor roles are allowed." }
    }

    // Check if email or username already exists
    const { data: existingUser, error: checkError } = await supabase
      .from("users")
      .select("email, userName")
      .or(`email.eq.${email},userName.eq.${username}`)
      .limit(1)

    if (checkError) {
      console.error("Error checking existing user:", checkError)
      return { success: false, error: "Error checking user availability" }
    }

    if (existingUser && existingUser.length > 0) {
      if (existingUser[0].email === email) {
        return { success: false, error: "Email already exists" }
      }
      if (existingUser[0].userName === username) {
        return { success: false, error: "Username already exists" }
      }
    }

    // First, create the auth user with Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email.trim(),
      password: password,
      options: {
        data: {
          userName: username.trim(),
          role: role,
        },
      },
    })

    if (authError) {
      console.error("Error creating auth user:", authError)
      return { success: false, error: authError.message }
    }

    // Get the user ID from the auth response
    const userId = authData.user.id

    // Hash the password for the users table
    const hashedPassword = hashPassword(password)

    // Insert into users table
    const { data, error } = await supabase
      .from("users")
      .insert([
        {
          user_id: userId,
          email: email.trim(),
          userName: username.trim(),
          password: hashedPassword,
          role: role,
        },
      ])
      .select()

    if (error) {
      console.error("Error creating user record:", error)
      return { success: false, error: error.message }
    }

    // If role is student, create student record
    if (role === "student") {
      const { error: studentError } = await supabase.from("student").insert([
        {
          student_id: userId,
          groupid: null,
          grade: null,
        },
      ])

      if (studentError && studentError.code !== "23505") {
        console.error("Error creating student record:", studentError)
        return {
          success: true,
          user: data[0],
          warning: "User account created but student profile setup failed. Please contact support.",
        }
      }
    }

    // If role is instructor, create instructor record if needed
    // Note: This depends on your database schema. If you have an instructor table, add similar code as for student

    return {
      success: true,
      user: data[0],
      message: `${role.charAt(0).toUpperCase() + role.slice(1)} account created successfully.`,
    }
  } catch (error) {
    console.error("Unexpected error during user creation:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function createInstructorAccount(email, username, password) {
  try {
    // Check if email already exists
    const { data: existingEmail } = await supabase.from("users").select("email").eq("email", email).single()

    if (existingEmail) {
      return { success: false, error: "Email already exists" }
    }

    // Check if username already exists
    const { data: existingUsername } = await supabase.from("users").select("userName").eq("userName", username).single()

    if (existingUsername) {
      return { success: false, error: "Username already exists" }
    }

    // Generate a UUID for the user_id
    const userId = crypto.randomUUID()

    // Hash the password
    const hashedPassword = hashPassword(password)

    // Insert the user directly into the users table
    const { error: insertError } = await supabase.from("users").insert([
      {
        user_id: userId,
        email,
        userName: username,
        password: hashedPassword,
        role: "instructor",
      },
    ])

    if (insertError) {
      console.error("Error inserting user:", insertError)
      return { success: false, error: insertError.message }
    }

    return {
      success: true,
      message: `Instructor account for ${username} created successfully`,
    }
  } catch (error) {
    console.error("Error creating instructor account:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}
