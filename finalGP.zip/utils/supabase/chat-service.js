import { supabase } from "./client"

// Get all chats for a specific group
export async function getGroupChats(groupId) {
  try {
    const { data, error } = await supabase.from("chat").select("*").eq("group_id", groupId)

    if (error) {
      console.error("Error fetching chats:", error)
      return { chats: [], error: error.message }
    }

    return { chats: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error:", error)
    return { chats: [], error: "An unexpected error occurred" }
  }
}

// Get all messages for a specific chat
export async function getChatMessages(chatId) {
  try {
    console.log("Fetching messages for chat:", chatId)

    const { data, error } = await supabase
      .from("message")
      .select(`
        messageid,
        content,
        messagetime,
        chatid,
        user_id,
        users:user_id (user_id, userName, email, role)
      `)
      .eq("chatid", chatId)
      .order("messagetime", { ascending: true })

    if (error) {
      console.error("Error fetching messages:", error)
      return { messages: [], error: error.message }
    }

    console.log(`Retrieved ${data?.length || 0} messages`)

    // Process messages to ensure they have the correct format
    const processedMessages = (data || []).map((message) => {
      console.log("Processing message:", message.messageid)

      // Ensure content is properly formatted
      let processedContent = message.content

      console.log("Original content type:", typeof processedContent)
      if (processedContent !== null) {
        console.log(
          "Original content:",
          typeof processedContent === "object" ? JSON.stringify(processedContent) : processedContent,
        )
      }

      // If content is a string, try to parse it as JSON
      if (typeof processedContent === "string") {
        try {
          processedContent = JSON.parse(processedContent)
          console.log("Successfully parsed string content to JSON")
        } catch (e) {
          console.warn("Failed to parse content as JSON:", e.message)
          // If parsing fails, create a properly formatted object
          processedContent = {
            text: processedContent,
            file: null,
            files: null,
            senderName: message.users?.userName || "",
          }
          console.log("Created fallback content object")
        }
      }
      // If content is already an object but doesn't match our format
      else if (processedContent && typeof processedContent === "object") {
        // If it has the old format with 'content' field
        if (processedContent.content && !processedContent.text) {
          console.log("Converting old format content to new format")
          processedContent = {
            text: processedContent.content,
            file: null,
            files: null,
            senderName: message.users?.userName || "",
          }
        }

        // Ensure senderName exists
        if (!processedContent.senderName) {
          console.log("Adding missing senderName")
          processedContent.senderName = message.users?.userName || ""
        }

        // Ensure file field exists
        if (!("file" in processedContent)) {
          console.log("Adding missing file field")
          processedContent.file = null
        }

        // Ensure files field exists
        if (!("files" in processedContent)) {
          console.log("Adding missing files field")
          processedContent.files = null
        }

        // Convert legacy single file to files array for consistency
        if (processedContent.file && !processedContent.files) {
          console.log("Converting single file to files array")
          processedContent.files = [processedContent.file]
        }

        // Fix for file URLs in instructor-student chats
        if (
          processedContent.file &&
          typeof processedContent.file === "string" &&
          processedContent.file.startsWith('{"url":')
        ) {
          try {
            const fileObj = JSON.parse(processedContent.file)
            processedContent.file = {
              url: fileObj.url,
              name: fileObj.name || "Attachment",
              type: fileObj.type || "application/octet-stream",
              size: fileObj.size || 0,
              path: fileObj.path || "",
            }
            console.log("Fixed file object from string:", processedContent.file)
          } catch (e) {
            console.error("Error parsing file string:", e)
          }
        }
      }
      // If content is null or undefined
      else {
        console.warn("Content is null or undefined, creating default content")
        processedContent = {
          text: "No content",
          file: null,
          files: null,
          senderName: message.users?.userName || "",
        }
      }

      console.log("Final processed content:", JSON.stringify(processedContent))

      return {
        ...message,
        content: processedContent,
      }
    })

    return { messages: processedMessages || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getChatMessages:", error)
    return { messages: [], error: "An unexpected error occurred" }
  }
}

// Send a new message to a chat
export async function sendMessage(chatId, userId, messageContent) {
  try {
    console.log("sendMessage called with:", {
      chatId,
      userId,
      messageContent: JSON.stringify(messageContent),
    })

    // Get user info to add senderName
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("userName, role")
      .eq("user_id", userId)
      .single()

    if (userError) {
      console.error("Error fetching user data:", userError)
    }

    console.log("User data retrieved:", userData)

    // Add senderName to the message content
    const content = {
      ...messageContent,
      senderName: userData?.userName || "",
    }

    // Ensure file object is properly formatted for storage
    if (content.file && typeof content.file === "object") {
      // Make sure the file object has all required properties
      content.file = {
        ...content.file,
        name: content.file.name || "Attachment",
        type: content.file.type || "application/octet-stream",
        size: content.file.size || 0,
        path: content.file.path || "",
        url: content.file.url || "",
      }
    }

    console.log("Final message content:", JSON.stringify(content))

    const messageData = {
      chatid: chatId,
      user_id: userId,
      content: content,
      messagetime: new Date().toISOString(),
    }

    console.log("Inserting message into database:", JSON.stringify(messageData))

    const { data, error } = await supabase.from("message").insert(messageData).select()

    if (error) {
      console.error("Error sending message:", error)
      return { message: null, error: error.message }
    }

    console.log("Message inserted successfully:", data?.[0])
    return { message: data?.[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in sendMessage:", error)
    return { message: null, error: "An unexpected error occurred" }
  }
}

// Get file URL from storage
export async function getFileUrl(bucket, path) {
  try {
    console.log("Getting file URL for:", { bucket, path })

    if (!bucket || !path) {
      console.error("Missing bucket or path:", { bucket, path })
      return null
    }

    // Sanitize the path to ensure it's valid
    const sanitizedPath = path.trim()
    if (!sanitizedPath) {
      console.error("Empty path after sanitization")
      return null
    }

    // Get the public URL
    const { data, error } = await supabase.storage.from(bucket).getPublicUrl(sanitizedPath)

    if (error) {
      console.error("Error getting file URL:", error)
      return null
    }

    if (!data || !data.publicUrl) {
      console.error("No public URL returned from Supabase")
      return null
    }

    console.log("Retrieved public URL:", data.publicUrl)
    return data.publicUrl
  } catch (error) {
    console.error("Unexpected error getting file URL:", error)
    return null
  }
}

// Get all users in a specific chat
export async function getChatUsers(chatId) {
  try {
    console.log("Fetching users for chat ID:", chatId)

    // First get the group ID and chat type for this chat
    const { data: chatData, error: chatError } = await supabase
      .from("chat")
      .select("group_id, chatname")
      .eq("chatid", chatId)
      .single()

    if (chatError) {
      console.error("Error fetching chat:", chatError)
      return { users: [], error: chatError.message }
    }

    const groupId = chatData.group_id
    const isSupervisorChat = chatData.chatname.includes("supervisor")
    console.log(`Found group ID: ${groupId}, Chat type: ${isSupervisorChat ? "Supervisor" : "Student"} chat`)

    // Get all students in this group with their user information
    const { data: groupStudents, error: studentsError } = await supabase
      .from("student_masked")
      .select(`
        student_id,
        users!student_id(user_id, userName, email, role)
      `)
      .eq("groupid", groupId)

    if (studentsError) {
      console.error("Error fetching group students:", studentsError)
      return { users: [], error: studentsError.message }
    }

    console.log(`Found ${groupStudents.length} students in group`)

    // Extract student users
    const studentUsers = groupStudents.map((item) => item.users).filter((user) => user !== null)

    const allUsers = [...studentUsers]

    // For supervisor chat, also include the instructor
    if (isSupervisorChat) {
      console.log("Fetching instructor data for group:", groupId)

      // Get the instructor_supervisor_id from projectgroup
      const { data: groupData, error: groupError } = await supabase
        .from("projectgroup")
        .select("instructor_supervisor_id")
        .eq("groupid", groupId)
        .single()

      if (groupError) {
        console.error("Error fetching group data:", groupError)
      } else if (groupData?.instructor_supervisor_id) {
        console.log("Found instructor_supervisor_id:", groupData.instructor_supervisor_id)

        // Get instructor details directly from users table
        const { data: instructorData, error: instructorError } = await supabase
          .from("users")
          .select("user_id, userName, email, role")
          .eq("user_id", groupData.instructor_supervisor_id)
          .single()

        if (instructorError) {
          console.error("Error fetching instructor data:", instructorError)
        } else if (instructorData) {
          console.log("Found instructor data:", instructorData)

          // Ensure instructor has the correct role
          const instructor = {
            ...instructorData,
            role: instructorData.role || "instructor",
          }

          // Add instructor to the users list for supervisor chats
          allUsers.push(instructor)
        }
      }
    }

    console.log(`Final users list: ${allUsers.length} users`)
    return { users: allUsers, error: null }
  } catch (error) {
    console.error("Unexpected error in getChatUsers:", error)
    return { users: [], error: "An unexpected error occurred" }
  }
}

// Get instructor information for a group
export async function getGroupInstructor(groupId) {
  try {
    console.log("Fetching instructor for group ID:", groupId)

    // Get the instructor_supervisor_id from projectgroup
    const { data: groupData, error: groupError } = await supabase
      .from("projectgroup")
      .select("instructor_supervisor_id")
      .eq("groupid", groupId)
      .single()

    if (groupError) {
      console.error("Error fetching group data:", groupError)
      return { instructor: null, error: groupError.message }
    }

    if (!groupData?.instructor_supervisor_id) {
      console.log("No instructor found for this group")
      return { instructor: null, error: null }
    }

    console.log("Found instructor_supervisor_id:", groupData.instructor_supervisor_id)

    // Get instructor details directly from users table
    const { data: instructorData, error: instructorError } = await supabase
      .from("users")
      .select("user_id, userName, email, role")
      .eq("user_id", groupData.instructor_supervisor_id)
      .single()

    if (instructorError) {
      console.error("Error fetching instructor data:", instructorError)
      return { instructor: null, error: instructorError.message }
    }

    // Ensure instructor has the correct role
    const instructor = {
      ...instructorData,
      role: instructorData.role || "instructor",
    }

    console.log("Found instructor:", instructor)
    return { instructor, error: null }
  } catch (error) {
    console.error("Unexpected error:", error)
    return { instructor: null, error: "An unexpected error occurred" }
  }
}

// Find and return the student and supervisor chats for a group
export async function getGroupChatChannels(groupId) {
  try {
    console.log("Finding chat channels for group:", groupId)

    // Get all chats for this group
    const { data: groupChats, error: chatsError } = await supabase.from("chat").select("*").eq("group_id", groupId)

    if (chatsError) {
      console.error("Error fetching group chats:", chatsError)
      return { studentChatId: null, supervisorChatId: null, error: chatsError.message }
    }

    console.log("Found chats for group:", groupChats)

    // Find student chat and supervisor chat
    let studentChatId = null
    let supervisorChatId = null

    for (const chat of groupChats || []) {
      if (chat.chatname.startsWith("students_chats_")) {
        studentChatId = chat.chatid
      } else if (chat.chatname.startsWith("supervisor_students_chats_")) {
        supervisorChatId = chat.chatid
      }
    }

    return {
      studentChatId,
      supervisorChatId,
      error: null,
    }
  } catch (error) {
    console.error("Unexpected error in getGroupChatChannels:", error)
    return {
      studentChatId: null,
      supervisorChatId: null,
      error: "An unexpected error occurred",
    }
  }
}

// Subscribe to new messages in a chat
export function subscribeToChat(chatId, callback) {
  return supabase
    .channel(`chat:${chatId}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "message",
        filter: `chatid=eq.${chatId}`,
      },
      (payload) => {
        callback(payload.new)
      },
    )
    .subscribe()
}
