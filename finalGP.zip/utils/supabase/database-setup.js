import { supabase } from "./client"

/**
 * Initialize the database schema for the student portal
 * This function creates all necessary tables if they don't exist
 */
export async function initializeDatabase() {
  console.log("Initializing database schema...")

  try {
    // Check if database is accessible
    const { data, error } = await supabase.from("users").select("count").limit(1)

    if (error) {
      console.error("Database connection error:", error.message)
      return { success: false, error: error.message }
    }

    console.log("Database connection successful")
    return { success: true }
  } catch (error) {
    console.error("Unexpected error initializing database:", error)
    return { success: false, error: error.message }
  }
}

/**
 * Seed the database with initial data for testing
 * Only use this in development environments
 */
export async function seedDatabase() {
  if (process.env.NODE_ENV === "production") {
    console.warn("Seeding should not be run in production")
    return { success: false, error: "Seeding is disabled in production" }
  }

  console.log("Seeding database with initial data...")

  try {
    // Example: Seed users table with test data
    const { error: usersError } = await supabase.from("users").upsert(
      [
        {
          user_id: "test-instructor-1",
          userName: "Test Instructor",
          email: "instructor@example.com",
          role: "instructor",
        },
        {
          user_id: "test-student-1",
          userName: "Test Student 1",
          email: "student1@example.com",
          role: "student",
        },
        {
          user_id: "test-student-2",
          userName: "Test Student 2",
          email: "student2@example.com",
          role: "student",
        },
        {
          user_id: "test-committee-1",
          userName: "Test Committee Member",
          email: "committee@example.com",
          role: "projectcommittee",
        },
      ],
      { onConflict: "user_id" },
    )

    if (usersError) {
      console.error("Error seeding users:", usersError)
      return { success: false, error: usersError.message }
    }

    // Seed project groups
    const { error: groupsError } = await supabase.from("projectgroup").upsert(
      [
        {
          groupid: 1,
          groupname: "Test Project Group",
          instructor_supervisor_id: "test-instructor-1",
          group_status: "active",
          group_progress: 30,
        },
      ],
      { onConflict: "groupid" },
    )

    if (groupsError) {
      console.error("Error seeding groups:", groupsError)
      return { success: false, error: groupsError.message }
    }

    // Seed student_masked table (student-group relationships)
    const { error: studentMaskedError } = await supabase.from("student_masked").upsert(
      [
        {
          student_id: "test-student-1",
          groupid: 1,
        },
        {
          student_id: "test-student-2",
          groupid: 1,
        },
      ],
      { onConflict: ["student_id", "groupid"] },
    )

    if (studentMaskedError) {
      console.error("Error seeding student_masked:", studentMaskedError)
      return { success: false, error: studentMaskedError.message }
    }

    console.log("Database seeded successfully")
    return { success: true }
  } catch (error) {
    console.error("Unexpected error seeding database:", error)
    return { success: false, error: error.message }
  }
}

/**
 * Validate the database schema to ensure all required tables exist
 */
export async function validateDatabaseSchema() {
  console.log("Validating database schema...")

  const requiredTables = [
    "users",
    "projectgroup",
    "student_masked",
    "student",
    "task",
    "sub_task",
    "chat",
    "message",
    "announcement",
    "milestone",
    "voting",
  ]

  const missingTables = []

  try {
    for (const table of requiredTables) {
      const { count, error } = await supabase.from(table).select("*", { count: "exact", head: true })

      if (error) {
        console.error(`Error checking table ${table}:`, error)
        missingTables.push(table)
      }
    }

    if (missingTables.length > 0) {
      console.error("Missing tables:", missingTables)
      return {
        success: false,
        missingTables,
        error: `Missing required tables: ${missingTables.join(", ")}`,
      }
    }

    console.log("Database schema validation successful")
    return { success: true }
  } catch (error) {
    console.error("Unexpected error validating schema:", error)
    return { success: false, error: error.message }
  }
}
