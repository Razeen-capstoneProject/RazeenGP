/**
 * This file documents the database schema for the student portal application.
 * It serves as a reference for developers working with the database.
 *
 * Note: This is not used to create the schema - it's just documentation.
 * The actual schema should be created in the Supabase dashboard or using migrations.
 */

export const DATABASE_SCHEMA = {
  // Users table - stores all user information
  users: {
    user_id: "uuid primary key",
    userName: "text",
    email: "text unique not null",
    role: "text not null", // 'student', 'instructor', 'projectcommittee'
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Project groups
  projectgroup: {
    groupid: "serial primary key",
    groupname: "text not null",
    instructor_supervisor_id: "uuid references users(user_id)",
    leader_id: "uuid references users(user_id)",
    group_status: "text default 'active'", // 'active', 'completed', 'archived'
    group_progress: "integer default 0",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Student-group relationship
  student_masked: {
    student_id: "uuid references users(user_id)",
    groupid: "integer references projectgroup(groupid)",
    created_at: "timestamp with time zone default now()",
    primary_key: "(student_id, groupid)",
  },

  // Student table (additional student info)
  student: {
    student_id: "uuid references users(user_id) primary key",
    groupid: "integer references projectgroup(groupid)",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Project committee members
  projectcommitteemember: {
    pcm_id: "uuid primary key",
    user_id: "uuid references users(user_id)",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Milestones
  milestone: {
    milestone_id: "serial primary key",
    name: "text not null",
    description: "text",
    deadline: "timestamp with time zone",
    status: "text default 'pending'", // 'pending', 'in_progress', 'completed'
    group_id: "integer references projectgroup(groupid)",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Tasks
  task: {
    taskid: "serial primary key",
    taskname: "text not null",
    taskdescription: "text",
    priority: "text default 'Medium'", // 'Low', 'Medium', 'High'
    status: "text default 'To Do'", // 'To Do', 'On Progress', 'Done'
    deadline: "timestamp with time zone",
    start_date: "timestamp with time zone default now()",
    groupid: "integer references projectgroup(groupid)",
    milestone_id: "integer references milestone(milestone_id)",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Sub-tasks
  sub_task: {
    sub_task_id: "serial primary key",
    main_task: "integer references task(taskid)",
    subTaskName: "text not null",
    description: "text",
    priority: "text default 'Medium'", // 'Low', 'Medium', 'High'
    status: "text default 'To Do'", // 'To Do', 'On Progress', 'Done'
    deadline: "timestamp with time zone",
    student_id: "uuid references users(user_id)",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Chat channels
  chat: {
    chatid: "serial primary key",
    chatname: "text not null",
    group_id: "integer references projectgroup(groupid)",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Chat messages
  message: {
    message_id: "serial primary key",
    chat_id: "integer references chat(chatid)",
    sender_id: "uuid references users(user_id)",
    content: "text not null",
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Announcements
  announcement: {
    announcement_id: "serial primary key",
    pcm_id: "uuid references projectcommitteemember(pcm_id)",
    announ_content: "jsonb not null", // Contains text and attachments
    user_role: "text not null", // Target role: 'student', 'instructor', 'all'
    created_at: "timestamp with time zone default now()",
    updated_at: "timestamp with time zone default now()",
  },

  // Meeting voting
  voting: {
    vote_id: "integer not null",
    group_id: "integer references projectgroup(groupid)",
    suggestion_time: "timestamp with time zone not null",
    end_time: "timestamp with time zone",
    deadline: "timestamp with time zone not null",
    vote_title: "text not null",
    created_by: "uuid references users(user_id)",
    num_voters: "integer default 0",
    created_at: "timestamp with time zone default now()",
    primary_key: "(vote_id, suggestion_time)",
  },

  // Student votes
  student_voting: {
    student_id: "uuid references users(user_id)",
    vote_id: "integer not null",
    suggestion_time: "timestamp with time zone not null",
    created_at: "timestamp with time zone default now()",
    primary_key: "(student_id, vote_id, suggestion_time)",
    foreign_key: "(vote_id, suggestion_time) references voting(vote_id, suggestion_time)",
  },
}
