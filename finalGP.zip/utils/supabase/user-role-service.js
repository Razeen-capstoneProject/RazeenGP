import { supabase } from "./client"

/**
 * Get detailed information about a user's role
 * @param {string} userId - The user's ID
 * @returns {Promise<Object>} - The user's role information and any error
 */
export async function getUserRoleInfo(userId) {
  try {
    if (!userId) {
      return { roleInfo: null, error: "User ID is required" }
    }

    console.log("Getting role info for user:", userId)

    // Get user's basic info including role
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("user_id, userName, email, role")
      .eq("user_id", userId)
      .single()

    if (userError) {
      console.error("Error fetching user data:", userError)
      return { roleInfo: null, error: userError.message }
    }

    if (!userData) {
      return { roleInfo: null, error: "User not found" }
    }

    // Build role info object
    const roleInfo = {
      userId: userData.user_id,
      userName: userData.userName,
      email: userData.email,
      role: userData.role,
      isStudent: userData.role === "student",
      isInstructor: userData.role === "instructor",
      isCommitteeMember: userData.role === "projectcommittee",
    }

    return { roleInfo, error: null }
  } catch (error) {
    console.error("Unexpected error in getUserRoleInfo:", error)
    return { roleInfo: null, error: "An unexpected error occurred" }
  }
}

/**
 * Get all groups a user belongs to
 * @param {string} userId - The user's ID
 * @returns {Promise<Object>} - The user's groups and any error
 */
export async function getUserGroups(userId) {
  try {
    if (!userId) {
      return { groups: [], error: "User ID is required" }
    }

    console.log("Getting groups for user:", userId)

    // Get user's groups from student_masked table
    const { data: studentData, error: studentError } = await supabase
      .from("student_masked")
      .select("groupid")
      .eq("student_id", userId)

    if (studentError) {
      console.error("Error fetching student data:", studentError)
      return { groups: [], error: studentError.message }
    }

    if (!studentData || studentData.length === 0) {
      return { groups: [], error: null }
    }

    // Get group details for each group ID
    const groupIds = studentData.map((item) => item.groupid).filter(Boolean)

    if (groupIds.length === 0) {
      return { groups: [], error: null }
    }

    const { data: groupsData, error: groupsError } = await supabase
      .from("projectgroup")
      .select("groupid, groupname, group_status")
      .in("groupid", groupIds)

    if (groupsError) {
      console.error("Error fetching group data:", groupsError)
      return { groups: [], error: groupsError.message }
    }

    return { groups: groupsData || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getUserGroups:", error)
    return { groups: [], error: "An unexpected error occurred" }
  }
}
