import { supabase } from "./client"

// Get all tasks assigned by supervisors for a specific group
export async function getSupervisorTasks(groupId) {
  try {
    if (!groupId) return { tasks: [], error: "No group ID provided" }

    console.log("Getting supervisor tasks for group:", groupId)

    // Get all tasks for this group with milestone information
    const { data, error } = await supabase
      .from("task")
      .select(`
        *,
        milestone:milestone_id (
          milestone_id,
          name,
          deadline,
          status
        )
      `)
      .eq("groupid", groupId)
      .order("deadline", { ascending: true })

    if (error) {
      console.error("Error fetching supervisor tasks:", error)
      return { tasks: [], error: error.message }
    }

    return { tasks: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getSupervisorTasks:", error)
    return { tasks: [], error: "An unexpected error occurred" }
  }
}

// Update task status
export async function updateTaskStatus(taskId, status) {
  try {
    if (!taskId) return { success: false, error: "No task ID provided" }

    // Validate status
    const validStatuses = ["To Do", "On Progress", "Done"]
    if (!validStatuses.includes(status)) {
      return {
        success: false,
        error: `Invalid status. Status must be one of: ${validStatuses.join(", ")}`,
      }
    }

    console.log(`Updating task ${taskId} status to ${status}`)

    const { data, error } = await supabase.from("task").update({ status }).eq("taskid", taskId).select()

    if (error) {
      console.error("Error updating task status:", error)
      return { success: false, error: error.message }
    }

    return { success: true, task: data[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in updateTaskStatus:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Get sub-tasks by main task ID
export async function getSubTasksByMainTask(taskId) {
  try {
    if (!taskId) return { subTasks: [], error: "No task ID provided" }

    console.log("Getting sub-tasks for main task:", taskId)

    const { data, error } = await supabase
      .from("sub_task")
      .select("sub_task_id, subTaskName, status")
      .eq("main_task", taskId)
      .order("subTaskName", { ascending: true })

    if (error) {
      console.error("Error fetching sub-tasks:", error)
      return { subTasks: [], error: error.message }
    }

    return { subTasks: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getSubTasksByMainTask:", error)
    return { subTasks: [], error: "An unexpected error occurred" }
  }
}
