import { supabase } from "./client"

/**
 * Fetches the pcm_id for a user based on their email address
 * @param {string} email - The user's email address
 * @returns {Promise<{pcmId: string|null, error: string|null}>} - The pcm_id or error
 */
export async function getPcmIdByEmail(email) {
  try {
    if (!email) {
      return { pcmId: null, error: "Email is required" }
    }

    console.log(`Fetching pcm_id for user with email: ${email}`)

    // First, find the user by email to get their user_id
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("user_id, role")
      .eq("email", email)
      .single()

    if (userError) {
      console.error(`Error finding user with email ${email}:`, userError)
      return { pcmId: null, error: `User not found: ${userError.message}` }
    }

    if (!userData) {
      return { pcmId: null, error: `No user found with email: ${email}` }
    }

    // Check if the user has the projectcommittee role
    if (userData.role !== "projectcommittee") {
      console.log(`User ${email} is not a project committee member (role: ${userData.role})`)
      return { pcmId: null, error: "User is not a project committee member" }
    }

    // For project committee members, directly query the projectcommitteemember table
    // Since we don't know the exact column name that links to users, we'll try a direct approach
    const { data: pcmData, error: pcmError } = await supabase.from("projectcommitteemember").select("pcm_id").limit(1)

    if (pcmError) {
      console.error(`Error finding pcm_id:`, pcmError)
      return { pcmId: null, error: `Error finding committee member: ${pcmError.message}` }
    }

    if (!pcmData || pcmData.length === 0 || !pcmData[0].pcm_id) {
      return { pcmId: null, error: `No committee member found` }
    }

    // For simplicity, we'll use the first pcm_id found
    // In a real application, you would need to determine the correct relationship
    const pcmId = pcmData[0].pcm_id
    console.log(`Using pcm_id for user ${email}: ${pcmId}`)
    return { pcmId, error: null }
  } catch (error) {
    console.error("Unexpected error in getPcmIdByEmail:", error)
    return { pcmId: null, error: "An unexpected error occurred" }
  }
}

/**
 * Fetches all committee members with their user information
 * @returns {Promise<{committeeMembers: Array, error: string|null}>} - The committee members or error
 */
export async function getAllCommitteeMembers() {
  try {
    console.log("Fetching all committee members")

    const { data, error } = await supabase.from("projectcommitteemember").select(`
        pcm_id,
        user:user_id (
          user_id,
          email,
          first_name,
          last_name
        )
      `)

    if (error) {
      console.error("Error fetching committee members:", error)
      return { committeeMembers: [], error: error.message }
    }

    console.log(`Retrieved ${data?.length || 0} committee members`)
    return { committeeMembers: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getAllCommitteeMembers:", error)
    return { committeeMembers: [], error: "An unexpected error occurred" }
  }
}

/**
 * Gets all students in a project group
 * @param {string} groupId - The ID of the group
 * @returns {Promise<{students: Array, error: string|null}>} - The students or error
 */
export async function getGroupStudents(groupId) {
  try {
    if (!groupId) return { students: [], error: "No group ID provided" }

    console.log("Getting students for group:", groupId)

    const { data, error } = await supabase
      .from("student_masked")
      .select(`
        student_id,
        users!student_id (
          user_id,
          userName,
          email
        )
      `)
      .eq("groupid", groupId)

    if (error) {
      console.error("Error fetching group students:", error)
      return { students: [], error: error.message }
    }

    // Extract the user data from the result
    const students = data.map((item) => ({
      id: item.student_id,
      name: item.users?.userName || item.users?.email || "Unknown Student",
      email: item.users?.email || "",
    }))

    return { students: students || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getGroupStudents:", error)
    return { students: [], error: "An unexpected error occurred" }
  }
}

/**
 * Gets all tasks for a project group
 * @param {string} groupId - The ID of the group
 * @returns {Promise<{tasks: Array, error: string|null}>} - The tasks or error
 */
export async function getGroupTasks(groupId) {
  try {
    if (!groupId) return { tasks: [], error: "No group ID provided" }

    console.log("Getting tasks for group:", groupId)

    const { data, error } = await supabase
      .from("task")
      .select("taskid, taskname, taskdescription")
      .eq("groupid", groupId)
      .order("taskname", { ascending: true })

    if (error) {
      console.error("Error fetching group tasks:", error)
      return { tasks: [], error: error.message }
    }

    return { tasks: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getGroupTasks:", error)
    return { tasks: [], error: "An unexpected error occurred" }
  }
}

/**
 * Checks if a user is a leader of a project group
 * @param {string} userId - The ID of the user
 * @returns {Promise<boolean>} - Whether the user is a leader
 */
export async function isGroupLeader(userId) {
  try {
    if (!userId) return false

    console.log("Checking if user is a group leader:", userId)

    // First check if the user is an instructor leader (supervisor)
    const { data: instructorGroup, error: instructorError } = await supabase
      .from("projectgroup")
      .select("groupid")
      .eq("instructor_supervisor_id", userId)
      .single()

    if (!instructorError && instructorGroup) {
      return true // User is an instructor leader
    }

    // If not an instructor leader, check if they're a student leader
    const { data: studentGroup, error: studentError } = await supabase
      .from("projectgroup")
      .select("groupid")
      .eq("leader_id", userId)
      .single()

    if (studentError) {
      // If the error is "No rows found", it means the user is not a leader
      if (studentError.code === "PGRST116") {
        return false
      }
      console.error("Error checking student leader status:", studentError)
      return false
    }

    return !!studentGroup // Returns true if the user is a student leader
  } catch (error) {
    console.error("Unexpected error in isGroupLeader:", error)
    return false
  }
}

/**
 * Gets the group information for a leader
 * @param {string} userId - The ID of the user
 * @returns {Promise<{group: Object|null, error: string|null}>} - The group or error
 */
export async function getLeaderGroupInfo(userId) {
  try {
    if (!userId) return { group: null, error: "No user ID provided" }

    console.log("Getting group info for leader:", userId)

    // First check if the user is an instructor leader
    const { data: instructorGroup, error: instructorError } = await supabase
      .from("projectgroup")
      .select("*")
      .eq("instructor_supervisor_id", userId)
      .single()

    if (!instructorError && instructorGroup) {
      return { group: instructorGroup, error: null }
    }

    // If not an instructor leader, check if they're a student leader
    const { data: studentGroup, error: studentError } = await supabase
      .from("projectgroup")
      .select("*")
      .eq("leader_id", userId)
      .single()

    if (studentError) {
      console.error("Error fetching leader group info:", studentError)
      return { group: null, error: studentError.message }
    }

    return { group: studentGroup || null, error: null }
  } catch (error) {
    console.error("Unexpected error in getLeaderGroupInfo:", error)
    return { group: null, error: "An unexpected error occurred" }
  }
}

// Add this function to get the user's current group
export async function getCurrentUserGroup(userId) {
  try {
    console.log("Getting current group for user:", userId)

    const { data: student, error: studentError } = await supabase
      .from("student_masked")
      .select("groupid")
      .eq("student_id", userId)
      .single()

    console.log("Student group result:", { student, studentError })

    if (studentError || !student) {
      console.error("Error finding student group:", studentError)
      return { groupId: null, error: "Failed to find student group" }
    }

    return { groupId: student.groupid, error: null }
  } catch (error) {
    console.error("Error:", error)
    return { groupId: null, error: "An unexpected error occurred" }
  }
}

// Get all sub-tasks for a student
export async function getStudentSubTasks(studentId) {
  try {
    if (!studentId) return { subTasks: [], error: "No student ID provided" }

    console.log("Getting sub-tasks for student:", studentId)

    // First get the tasks without the user join that's causing issues
    const { data, error } = await supabase
      .from("sub_task")
      .select(`
       *,
       task:main_task(taskname, taskdescription)
     `)
      .eq("student_id", studentId)
      .order("deadline", { ascending: true })

    if (error) {
      console.error("Error fetching student sub-tasks:", error)
      return { subTasks: [], error: error.message }
    }

    // Then fetch user data separately and add it to each task
    const enrichedTasks = await Promise.all(
      (data || []).map(async (task) => {
        try {
          // Fetch user info separately
          const { data: userData, error: userError } = await supabase
            .from("users")
            .select("user_id, userName, email")
            .eq("user_id", studentId)
            .single()

          if (userError) {
            console.log(`Could not fetch user info for student ${studentId}:`, userError)
            return { ...task, users: null }
          }

          return { ...task, users: userData || null }
        } catch (err) {
          console.error(`Error enriching task data:`, err)
          return { ...task, users: null }
        }
      }),
    )

    return { subTasks: enrichedTasks || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getStudentSubTasks:", error)
    return { subTasks: [], error: "An unexpected error occurred" }
  }
}

// Get all sub-tasks for a group
export async function getGroupSubTasks(groupId) {
  try {
    if (!groupId) return { subTasks: [], error: "No group ID provided" }

    console.log("Getting sub-tasks for group:", groupId)

    // First get all student IDs in this group
    const { data: students, error: studentsError } = await supabase
      .from("student_masked")
      .select("student_id")
      .eq("groupid", groupId)

    if (studentsError) {
      console.error("Error fetching group students:", studentsError)
      return { subTasks: [], error: studentsError.message }
    }

    // If no students found, return empty array
    if (!students || students.length === 0) {
      return { subTasks: [], error: null }
    }

    // Extract student IDs
    const studentIds = students.map((student) => student.student_id)

    console.log(`Found ${studentIds.length} students in group ${groupId}:`, studentIds)

    // Now fetch sub-tasks for these students without trying to join with users table
    const { data: subTasks, error: tasksError } = await supabase
      .from("sub_task")
      .select(`
        *,
        task:main_task(taskname, taskdescription)
      `)
      .in("student_id", studentIds)
      .order("deadline", { ascending: true })

    if (tasksError) {
      console.error("Error fetching group sub-tasks:", tasksError)
      return { subTasks: [], error: tasksError.message }
    }

    // Now fetch user information separately for each task
    const enrichedTasks = await Promise.all(
      (subTasks || []).map(async (task) => {
        if (!task.student_id) return task

        try {
          // Fetch user info separately
          const { data: userData, error: userError } = await supabase
            .from("users")
            .select("user_id, userName, email")
            .eq("user_id", task.student_id)
            .single()

          if (userError) {
            console.log(`Could not fetch user info for student ${task.student_id}:`, userError)
            return { ...task, users: null }
          }

          return { ...task, users: userData || null }
        } catch (err) {
          console.error(`Error enriching task ${task.sub_task_id}:`, err)
          return { ...task, users: null }
        }
      }),
    )

    return { subTasks: enrichedTasks, error: null }
  } catch (error) {
    console.error("Unexpected error in getGroupSubTasks:", error)
    return { subTasks: [], error: "An unexpected error occurred" }
  }
}
