import { supabase } from "./client"

// Define valid status options - ensure all three are included
export const VALID_STATUSES = ["To Do", "On Progress", "Done"]

// Define valid priority options based on database constraint
export const VALID_PRIORITIES = ["Low", "Medium", "High"]

// Create a new sub-task
export async function createSubTask(subTaskData) {
  try {
    console.log("Creating new sub-task:", subTaskData)

    if (!subTaskData.student_id || !subTaskData.main_task || !subTaskData.subTaskName) {
      return {
        subTask: null,
        error: "Missing required fields: student_id, main_task, or subTaskName",
      }
    }

    // Validate status if provided
    if (subTaskData.status && !VALID_STATUSES.includes(subTaskData.status)) {
      return {
        subTask: null,
        error: `Invalid status. Status must be one of: ${VALID_STATUSES.join(", ")}`,
      }
    }

    // Validate priority if provided
    if (subTaskData.priority && !VALID_PRIORITIES.includes(subTaskData.priority)) {
      return {
        subTask: null,
        error: `Invalid priority. Priority must be one of: ${VALID_PRIORITIES.join(", ")}`,
      }
    }

    // Insert the new sub-task
    const { data, error } = await supabase
      .from("sub_task")
      .insert({
        student_id: subTaskData.student_id,
        main_task: subTaskData.main_task,
        subTaskName: subTaskData.subTaskName,
        priority: subTaskData.priority || "Medium", // Default to "Medium"
        status: subTaskData.status || "To Do", // Default to "To Do"
        deadline: subTaskData.deadline || null,
        description: subTaskData.description || "",
      })
      .select()

    if (error) {
      console.error("Error creating sub-task:", error)
      return { subTask: null, error: error.message }
    }

    console.log("Sub-task created successfully:", data)
    return { subTask: data[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in createSubTask:", error)
    return { subTask: null, error: "An unexpected error occurred" }
  }
}

// Get all sub-tasks for a student
export async function getStudentSubTasks(studentId) {
  try {
    if (!studentId) return { subTasks: [], error: "No student ID provided" }

    console.log("Getting sub-tasks for student:", studentId)

    const { data, error } = await supabase
      .from("sub_task")
      .select(`
        *,
        task:main_task(taskname, taskdescription)
      `)
      .eq("student_id", studentId)
      .order("deadline", { ascending: true })

    if (error) {
      console.error("Error fetching student sub-tasks:", error)
      return { subTasks: [], error: error.message }
    }

    return { subTasks: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getStudentSubTasks:", error)
    return { subTasks: [], error: "An unexpected error occurred" }
  }
}

// Update a sub-task status
export async function updateSubTaskStatus(subTaskId, status) {
  try {
    if (!subTaskId) return { success: false, error: "No sub-task ID provided" }

    // Validate the status against allowed options
    if (!VALID_STATUSES.includes(status)) {
      return {
        success: false,
        error: `Invalid status. Status must be one of: ${VALID_STATUSES.join(", ")}`,
      }
    }

    console.log(`Updating sub-task ${subTaskId} status to ${status}`)

    const { data, error } = await supabase.from("sub_task").update({ status }).eq("sub_task_id", subTaskId).select()

    if (error) {
      console.error("Error updating sub-task status:", error)
      return { success: false, error: error.message }
    }

    return { success: true, subTask: data[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in updateSubTaskStatus:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Update a sub-task description
export async function updateSubTaskDescription(subTaskId, description) {
  try {
    if (!subTaskId) return { success: false, error: "No sub-task ID provided" }

    console.log(`Updating sub-task ${subTaskId} description`)

    const { data, error } = await supabase
      .from("sub_task")
      .update({ description })
      .eq("sub_task_id", subTaskId)
      .select()

    if (error) {
      console.error("Error updating sub-task description:", error)
      return { success: false, error: error.message }
    }

    return { success: true, subTask: data[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in updateSubTaskDescription:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Update a sub-task (multiple fields)
export async function updateSubTask(subTaskData) {
  try {
    if (!subTaskData.sub_task_id) return { success: false, error: "No sub-task ID provided" }

    console.log(`Updating sub-task ${subTaskData.sub_task_id}:`, subTaskData)

    // Validate priority if provided
    if (subTaskData.priority && !VALID_PRIORITIES.includes(subTaskData.priority)) {
      return {
        success: false,
        error: `Invalid priority. Priority must be one of: ${VALID_PRIORITIES.join(", ")}`,
      }
    }

    // Prepare update data (remove sub_task_id from the update payload)
    const { sub_task_id, ...updateData } = subTaskData

    // Log the main_task value for debugging
    if (updateData.main_task) {
      console.log(`Updating main_task to: ${updateData.main_task}`)
    }

    const { data, error } = await supabase.from("sub_task").update(updateData).eq("sub_task_id", sub_task_id).select()

    if (error) {
      console.error("Error updating sub-task:", error)
      return { success: false, error: error.message }
    }

    // After successful update, fetch the updated task with its related task info
    if (data && data.length > 0) {
      const updatedTask = data[0]

      // If main_task was updated, fetch the related task info
      if (updateData.main_task) {
        const { data: taskData, error: taskError } = await supabase
          .from("task")
          .select("taskid, taskname, taskdescription")
          .eq("taskid", updateData.main_task)
          .single()

        if (!taskError && taskData) {
          // Add the task info to the response
          updatedTask.task = {
            taskname: taskData.taskname,
            taskdescription: taskData.taskdescription,
          }
        }
      }

      return { success: true, subTask: updatedTask, error: null }
    }

    return { success: true, subTask: data?.[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in updateSubTask:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Delete a sub-task
export async function deleteSubTask(subTaskId) {
  try {
    if (!subTaskId) return { success: false, error: "No sub-task ID provided" }

    console.log(`Deleting sub-task ${subTaskId}`)

    const { error } = await supabase.from("sub_task").delete().eq("sub_task_id", subTaskId)

    if (error) {
      console.error("Error deleting sub-task:", error)
      return { success: false, error: error.message }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Unexpected error in deleteSubTask:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Check if a user is a leader for a specific sub-task's group
export async function isLeaderForSubTask(userId, subTaskId) {
  try {
    if (!userId || !subTaskId) return false

    console.log(`Checking if user ${userId} is leader for sub-task ${subTaskId}`)

    // First get the sub-task to find its associated group
    const { data: subTask, error: subTaskError } = await supabase
      .from("sub_task")
      .select(`
        main_task(groupid)
      `)
      .eq("sub_task_id", subTaskId)
      .single()

    if (subTaskError || !subTask || !subTask.main_task) {
      console.error("Error fetching sub-task:", subTaskError)
      return false
    }

    const groupId = subTask.main_task.groupid

    if (!groupId) {
      console.error("No group ID found for sub-task")
      return false
    }

    // Check if the user is a leader of this group (either as instructor or student)
    const { data: instructorGroup, error: instructorError } = await supabase
      .from("projectgroup")
      .select("leader_id, instructor_supervisor_id")
      .eq("groupid", groupId)
      .single()

    if (instructorError) {
      console.error("Error checking leader status:", instructorError)
      return false
    }

    // Check if user is either the instructor supervisor or the student leader
    return instructorGroup.instructor_supervisor_id === userId || instructorGroup.leader_id === userId
  } catch (error) {
    console.error("Unexpected error in isLeaderForSubTask:", error)
    return false
  }
}
