import { createHash } from "crypto"

// Function to hash passwords using SHA-256
export function hashPassword(password) {
  return createHash("sha256").update(password).digest("hex")
}

// Function to validate password requirements
export function validatePassword(password) {
  const requirements = {
    uppercase: /[A-Z]/.test(password),
    lowercase: /[a-z]/.test(password),
    number: /[0-9]/.test(password),
    special: /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password),
    length: password.length >= 6,
  }

  const isValid = Object.values(requirements).every(Boolean)

  return {
    isValid,
    requirements,
  }
}
