import { supabase } from "./client"
import crypto from "crypto"

// Function to hash password using SHA-256
function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex")
}

export async function signIn(email, password, selectedRole) {
  try {
    if (!email || !password) {
      return { user: null, error: "Email and password are required" }
    }

    console.log(`AUTH SERVICE: Login attempt as ${selectedRole} with email ${email}`)

    // Hash the password before comparing with database
    const hashedPassword = hashPassword(password)

    // Query the users table with hashed password
    const { data: users, error } = await supabase
      .from("users")
      .select("user_id, email, role, userName")
      .eq("email", email.trim())
      .eq("password", hashedPassword)

    if (error) {
      console.error("Sign in error:", error)
      return { user: null, error: "Invalid login credentials" }
    }

    // Check if any users were found
    if (!users || users.length === 0) {
      return { user: null, error: "Invalid email or password" }
    }

    // Use the first matching user
    const user = users[0]

    // IMPORTANT: Ensure role is exactly as expected for instructors
    if (selectedRole === "instructor" && user.role.toLowerCase() === "instructor") {
      // Force the role to be exactly "instructor" to avoid any case issues
      user.role = "instructor"
      console.log("AUTH SERVICE: ✓ Confirmed instructor role")
    }

    console.log(`AUTH SERVICE: User authenticated with role "${user.role}"`)

    // Check if the role matches what was selected
    if (selectedRole && user.role.toLowerCase() !== selectedRole.toLowerCase()) {
      console.log(`AUTH SERVICE: Role mismatch - user: ${user.role}, selected: ${selectedRole}`)
      return {
        user: null,
        error: `You don't have access as a ${selectedRole}. Your role is ${user.role}.`,
      }
    }

    // Store user data without the password
    try {
      console.log(`AUTH SERVICE: Storing user in localStorage with role "${user.role}"`)
      localStorage.setItem("user", JSON.stringify(user))

      // Also set up Supabase session for API calls
      await supabase.auth.signInWithPassword({
        email: email,
        password: password,
      })

      // Dispatch a custom event to notify other components about the login
      window.dispatchEvent(new Event("auth-state-changed"))
    } catch (storageError) {
      console.error("Error storing user data:", storageError)
    }

    return { user, error: null }
  } catch (error) {
    console.error("Unexpected error during sign in:", error)
    return { user: null, error: "An unexpected error occurred" }
  }
}

export async function signOut() {
  try {
    // 1) clear the client session
    const { error } = await supabase.auth.signOut()
    if (error) {
      console.error("Sign-out failed:", error)
      return { success: false, error: error.message }
    }

    // 2) Clear any user data from localStorage
    if (typeof window !== "undefined") {
      localStorage.removeItem("user")
    }

    return { success: true }
  } catch (error) {
    console.error("Error during sign out:", error)
    return { success: false, error: error.message }
  }
}

export function getCurrentUser() {
  if (typeof window === "undefined") return null

  const userStr = localStorage.getItem("user")
  if (!userStr) return null

  try {
    return JSON.parse(userStr)
  } catch (error) {
    console.error("Error parsing user data:", error)
    return null
  }
}
