import { supabase } from "./client"

// Update the joinGroup function to verify both groupId and entranceId
export async function joinGroup(groupId, entranceId, userId) {
  try {
    console.log("Joining group with:", { groupId, entranceId, userId })

    // First check if the group exists and the entrance ID matches
    const { data: group, error: groupError } = await supabase
      .from("projectgroup")
      .select("*")
      .eq("groupid", groupId)
      .eq("enterance_id", entranceId)
      .single()

    console.log("Group check result:", { group, groupError })

    if (groupError || !group) {
      return {
        success: false,
        message: groupError ? "Invalid group ID or entrance ID" : "Group ID and entrance ID do not match",
      }
    }

    // Add/Update the user's active group in the student table
    // This will create a new record if it doesn't exist or update if it does
    const { error: joinError } = await supabase.from("student").upsert({
      student_id: userId,
      groupid: groupId,
    })

    console.log("Join result:", { joinError })

    if (joinError) {
      console.error("Error joining group:", joinError)
      return { success: false, message: "Failed to join group: " + joinError.message }
    }

    // Also update the student_masked table if needed
    const { data: existingMasked, error: maskedCheckError } = await supabase
      .from("student_masked")
      .select("*")
      .eq("student_id", userId)
      .single()

    if (!existingMasked && !maskedCheckError) {
      // If no record exists in student_masked, create one
      await supabase.from("student_masked").insert({
        student_id: userId,
        groupid: groupId,
      })
    } else if (existingMasked) {
      // If record exists, update it
      await supabase.from("student_masked").update({ groupid: groupId }).eq("student_id", userId)
    }

    return { success: true, message: "Successfully joined group" }
  } catch (error) {
    console.error("Error:", error)
    return { success: false, message: "An unexpected error occurred: " + error.message }
  }
}

export async function getUserGroups(userId) {
  try {
    // Use student_masked table to get user's groups
    const { data: groups, error } = await supabase
      .from("projectgroup")
      .select(`
        groupid,
        groupname,
        group_status,
        group_progress
      `)
      .in("groupid", supabase.from("student_masked").select("groupid").eq("student_id", userId))

    if (error) {
      console.error("Error fetching user groups:", error)
      return { groups: [], error: "Failed to fetch user groups" }
    }

    return { groups: groups || [], error: null }
  } catch (error) {
    console.error("Error:", error)
    return { groups: [], error: "An unexpected error occurred: " + error.message }
  }
}

export async function getGroupMilestones(groupId) {
  try {
    console.log("Fetching milestones for group:", groupId)

    // First check if the group exists
    const { data: group, error: groupError } = await supabase
      .from("projectgroup")
      .select("*")
      .eq("groupid", groupId)
      .single()

    console.log("Group check result:", { group, groupError })

    if (groupError) {
      console.error("Error finding group:", groupError)
      return { milestones: [], error: "Failed to find group" }
    }

    // Get milestones for this group - using group_id instead of groupid
    const { data: milestones, error: milestonesError } = await supabase
      .from("milestone")
      .select("*")
      .eq("group_id", groupId) // Changed from groupid to group_id
      .order("deadline", { ascending: true })

    console.log("Milestones result:", { milestones, milestonesError })

    if (milestonesError) {
      console.error("Error fetching milestones:", milestonesError)
      return { milestones: [], error: "Failed to fetch milestones" }
    }

    return { milestones: milestones || [], error: null }
  } catch (error) {
    console.error("Error:", error)
    return { milestones: [], error: "An unexpected error occurred" }
  }
}

// Add this function to get the user's current group
export async function getCurrentUserGroup(userId) {
  try {
    console.log("Getting current group for user:", userId)

    const { data: student, error: studentError } = await supabase
      .from("student_masked")
      .select("groupid")
      .eq("student_id", userId)
      .single()

    console.log("Student group result:", { student, studentError })

    if (studentError || !student) {
      console.error("Error finding student group:", studentError)
      return { groupId: null, error: "Failed to find student group" }
    }

    return { groupId: student.groupid, error: null }
  } catch (error) {
    console.error("Error:", error)
    return { groupId: null, error: "An unexpected error occurred" }
  }
}

// Get all project groups
export async function getAllGroups() {
  try {
    console.log("Fetching all project groups")

    const { data, error } = await supabase
      .from("projectgroup")
      .select("groupid, groupname, group_status")
      .order("groupname", { ascending: true })

    if (error) {
      console.error("Error fetching groups:", error)
      return { groups: [], error: error.message }
    }

    return { groups: data || [], error: null }
  } catch (error) {
    console.error("Error:", error)
    return { groups: [], error: "An unexpected error occurred" }
  }
}
