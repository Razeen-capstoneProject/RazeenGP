import { supabase } from "./client"

/**
 * Creates a new announcement
 * @param {Object} announcementData - The announcement data to create
 * @param {string} announcementData.content - The content of the announcement
 * @param {Array<string>} announcementData.targetRoles - The roles to target with the announcement
 * @param {Array<File>} files - Array of files to attach to the announcement
 * @returns {Promise<Object>} - The created announcements and any error
 */
export async function createAnnouncement(announcementData, files = []) {
  try {
    console.log("Creating new announcement:", announcementData)

    if (!announcementData.content) {
      return { announcements: null, error: "Announcement content is required" }
    }

    // Get user info from local storage
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      return { announcements: null, error: "User not authenticated" }
    }

    const user = JSON.parse(userStr)

    // Prepare attachments array
    const attachments = []

    // Upload files to storage - only need to do this once
    for (const file of files) {
      const timestamp = Date.now()
      const sanitizedFileName = file.name.replace(/\.[^/.]+$/, "").replace(/[^a-z0-9]/gi, "_")
      const filePath = `uploads/${user.user_id}/${timestamp}_${sanitizedFileName}.${file.name.split(".").pop()}`

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("announcement.backet")
        .upload(filePath, file, {
          cacheControl: "3600",
          upsert: false,
        })

      if (uploadError) {
        console.error(`Error uploading file ${file.name}:`, uploadError)
        return { announcements: null, error: `Upload failed for ${file.name}: ${uploadError.message}` }
      }

      // Get the public URL for the uploaded file
      const { data: urlData } = await supabase.storage.from("announcement.backet").getPublicUrl(uploadData.path)
      const publicUrl = urlData?.publicUrl

      attachments.push({
        path: uploadData.path,
        bucket: "announcement.backet",
        filename: file.name,
        size: file.size,
        type: file.type,
        url: publicUrl,
      })
    }

    // Prepare announcement content - same for all announcements
    const announ_content = {
      text: announcementData.content,
      attachments: attachments,
    }

    // Handle role targeting
    let targetRoles = announcementData.targetRoles || []

    // If no roles are selected or "all" is included, create a single announcement for all roles
    if (targetRoles.length === 0 || targetRoles.includes("all")) {
      targetRoles = ["all"]
    }

    // Create an array to hold all created announcements
    const createdAnnouncements = []

    // Create a separate announcement for each target role
    for (const role of targetRoles) {
      const { data, error } = await supabase
        .from("announcement")
        .insert({
          pcm_id: user.user_id,
          announ_content: announ_content,
          user_role: role,
          created_at: new Date().toISOString(),
        })
        .select()

      if (error) {
        console.error(`Error creating announcement for role ${role}:`, error)
        // Continue with other roles even if one fails
        continue
      }

      if (data && data.length > 0) {
        createdAnnouncements.push(...data)
      }
    }

    if (createdAnnouncements.length === 0) {
      return { announcements: null, error: "Failed to create any announcements" }
    }

    console.log(
      `Successfully created ${createdAnnouncements.length} announcements for roles: ${targetRoles.join(", ")}`,
    )
    return { announcements: createdAnnouncements, error: null }
  } catch (error) {
    console.error("Unexpected error in createAnnouncement:", error)
    return { announcements: null, error: "An unexpected error occurred" }
  }
}

/**
 * Deletes an announcement
 * @param {string} announcementId - The ID of the announcement to delete
 * @returns {Promise<Object>} - Success status and any error
 */
export async function deleteAnnouncement(announcementId) {
  try {
    if (!announcementId) return { success: false, error: "No announcement ID provided" }

    console.log("Deleting announcement:", announcementId)

    const { error } = await supabase.from("announcement").delete().eq("announcement_id", announcementId)

    if (error) {
      console.error("Error deleting announcement:", error)
      return { success: false, error: error.message }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Unexpected error in deleteAnnouncement:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Only updating the getAnnouncements function to ensure proper deduplication
export async function getAnnouncements(userRole = null) {
  try {
    console.log("Getting announcements", userRole ? `with role: ${userRole}` : "with any role")

    // Build the query
    let query = supabase
      .from("announcement")
      .select(`
       *,
       committee_member:pcm_id(*)
     `)
      .order("created_at", { ascending: false })

    // Filter by role if provided
    if (userRole) {
      // Include announcements for this role or for 'all' users
      query = query.or(`user_role.eq.${userRole},user_role.eq.all`)
    }

    const { data, error } = await query

    if (error) {
      console.error("Error fetching announcements:", error)
      return { announcements: [], error: error.message }
    }

    console.log(`Retrieved ${data?.length || 0} announcements`)
    if (data && data.length > 0) {
      console.log("Sample announcement:", data[0])
    }

    // Process announcements to extract file attachments from announ_content if present
    const processedAnnouncements =
      data?.map((announcement) => {
        let content = announcement.announ_content
        let fileAttachments = []

        // Check if announ_content contains attachment info
        if (typeof content === "object" && content !== null) {
          // Handle both single attachment and multiple attachments
          if (content.attachments && Array.isArray(content.attachments)) {
            fileAttachments = content.attachments
          } else if (content.attachment) {
            // Legacy format with single attachment
            fileAttachments = [content.attachment]
          }

          // Extract the text content
          content = content.text || ""
        }

        return {
          ...announcement,
          announ_content: content,
          file_attachments: fileAttachments,
        }
      }) || []

    // Deduplicate announcements by announcement_id
    const uniqueMap = new Map()
    processedAnnouncements.forEach((announcement) => {
      uniqueMap.set(announcement.announcement_id, announcement)
    })

    // Convert Map values back to array and sort by created_at (newest first)
    const uniqueAnnouncements = Array.from(uniqueMap.values()).sort(
      (a, b) => new Date(b.created_at) - new Date(a.created_at),
    )

    return { announcements: uniqueAnnouncements, error: null }
  } catch (error) {
    console.error("Unexpected error in getAnnouncements:", error)
    return { announcements: [], error: "An unexpected error occurred" }
  }
}

// Similarly update getAnnouncementsForUser function
export async function getAnnouncementsForUser(options) {
  try {
    const { userRole, userId, searchQuery = "", includeAllAnnouncements = false } = options

    console.log("Getting announcements for user:", {
      userRole,
      userId,
      searchQuery: searchQuery ? "Yes" : "No",
      includeAllAnnouncements,
    })

    if (!userRole) {
      return { announcements: [], error: "User role is required" }
    }

    // Build the query
    let query = supabase.from("announcement").select(`
     *,
     committee_member:pcm_id(*)
   `)

    // Apply role-based filtering if not including all announcements
    if (!includeAllAnnouncements) {
      if (options.selectedRoles && options.selectedRoles.length > 0) {
        // Handle multiple selected roles
        const roleFilters = options.selectedRoles.map((role) => `user_role.eq.${role}`)
        // Also include announcements for 'all' users
        roleFilters.push("user_role.eq.all")
        query = query.or(roleFilters.join(","))
      } else {
        // Default to user's role if no specific roles selected
        query = query.or(`user_role.eq.${userRole},user_role.eq.all`)
      }
    }

    // Order by creation date, newest first
    query = query.order("created_at", { ascending: false })

    // Execute the query
    const { data, error } = await query

    if (error) {
      console.error("Error fetching announcements:", error)
      return { announcements: [], error: error.message }
    }

    console.log(`Retrieved ${data?.length || 0} announcements`)

    // Process announcements to extract file attachments from announ_content if present
    const processedAnnouncements =
      data?.map((announcement) => {
        let content = announcement.announ_content
        let fileAttachments = []

        // Check if announ_content contains attachment info
        if (typeof content === "object" && content !== null) {
          // Handle both single attachment and multiple attachments
          if (content.attachments && Array.isArray(content.attachments)) {
            fileAttachments = content.attachments
          } else if (content.attachment) {
            // Legacy format with single attachment
            fileAttachments = [content.attachment]
          }

          // Extract the text content
          content = content.text || ""
        }

        return {
          ...announcement,
          announ_content: content,
          file_attachments: fileAttachments,
        }
      }) || []

    // Deduplicate announcements by announcement_id
    const uniqueMap = new Map()
    processedAnnouncements.forEach((announcement) => {
      uniqueMap.set(announcement.announcement_id, announcement)
    })

    // Convert Map values back to array and sort by created_at (newest first)
    const uniqueAnnouncements = Array.from(uniqueMap.values()).sort(
      (a, b) => new Date(b.created_at) - new Date(a.created_at),
    )

    // Filter announcements based on search query
    const filteredAnnouncements = uniqueAnnouncements.filter((announcement) => {
      // Apply search filter if provided
      if (searchQuery) {
        const searchLower = searchQuery.toLowerCase()
        const contentMatches =
          typeof announcement.announ_content === "string" &&
          announcement.announ_content.toLowerCase().includes(searchLower)
        const committeeNameMatches = announcement.committee_member?.userName?.toLowerCase().includes(searchLower)

        return contentMatches || committeeNameMatches
      }

      return true
    })

    return { announcements: filteredAnnouncements, error: null }
  } catch (error) {
    console.error("Unexpected error in getAnnouncementsForUser:", error)
    return { announcements: [], error: "An unexpected error occurred" }
  }
}
