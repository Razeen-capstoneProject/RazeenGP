import { supabase } from "./client"

// Get all in-progress sub-tasks for a student
export async function getInProgressSubTasks(studentId) {
  try {
    if (!studentId) return { tasks: [], error: "No student ID provided" }

    console.log("Getting in-progress sub-tasks for student:", studentId)

    // Get all in-progress tasks for this student
    const { data, error } = await supabase
      .from("sub_task")
      .select(`
        *,
        task:main_task(taskname, taskdescription)
      `)
      .eq("student_id", studentId)
      .eq("status", "On Progress")
      .order("deadline", { ascending: true })

    if (error) {
      console.error("Error fetching in-progress sub-tasks:", error)
      return { tasks: [], error: error.message }
    }

    // Now let's fetch feedback separately for each task
    const tasksWithFeedback = await Promise.all(
      data.map(async (task) => {
        try {
          const { data: feedbackData } = await supabase
            .from("feedback")
            .select("*")
            .eq("sub_task_id", task.sub_task_id)
            .order("feedbackid", { ascending: false })
            .limit(1)

          // Process attachment data if it exists
          const processedTask = { ...task }

          if (task.attachment) {
            // Ensure the attachment has a URL
            if (!task.attachment.url) {
              processedTask.attachment = {
                ...task.attachment,
                url: getAttachmentPublicUrl(task.attachment),
              }
            }
          }

          return {
            ...processedTask,
            feedback: feedbackData || [],
          }
        } catch (err) {
          console.error(`Error fetching feedback for task ${task.sub_task_id}:`, err)
          return {
            ...task,
            feedback: [],
          }
        }
      }),
    )

    return { tasks: tasksWithFeedback || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getInProgressSubTasks:", error)
    return { tasks: [], error: "An unexpected error occurred" }
  }
}

// Enhanced uploadAttachment function with improved file deletion logic
export async function uploadAttachment(subTaskId, file) {
  try {
    if (!subTaskId) return { success: false, error: "No sub-task ID provided" }
    if (!file) return { success: false, error: "No file provided" }

    console.log(`Uploading attachment for sub-task ${subTaskId}`)

    // First, get the current task to check if it has an existing attachment
    const { data: taskData, error: taskError } = await supabase
      .from("sub_task")
      .select("attachment")
      .eq("sub_task_id", subTaskId)
      .single()

    if (taskError && taskError.code !== "PGRST116") {
      // PGRST116 is "no rows returned" which is fine if the task doesn't exist yet
      console.error(`Error fetching task ${subTaskId}:`, taskError)
      return { success: false, error: taskError.message || "Failed to fetch task" }
    }

    // If there's an existing attachment, delete the file from storage
    let oldFilePath = null
    let oldFileBucket = null
    let deletionResult = null

    if (taskData?.attachment?.path) {
      oldFilePath = taskData.attachment.path
      oldFileBucket = taskData.attachment.bucket || "sub.task.attachment"

      console.log(`Found existing attachment to delete:`, {
        bucket: oldFileBucket,
        path: oldFilePath,
        filename: taskData.attachment.filename,
      })

      try {
        // Attempt to delete the file
        const { data, error: deleteError } = await supabase.storage.from(oldFileBucket).remove([oldFilePath])

        if (deleteError) {
          console.error(`Error deleting previous attachment:`, deleteError)
          deletionResult = { success: false, error: deleteError.message }
        } else {
          console.log(`Successfully deleted previous attachment:`, data)
          deletionResult = { success: true, data }
        }
      } catch (deleteErr) {
        console.error(`Exception during file deletion:`, deleteErr)
        deletionResult = { success: false, error: deleteErr.message }
      }
    }

    // Create a unique file path with the correct structure:
    // sub.task.attachment/uploads/{sub_task_id}/{filename}
    const timestamp = Date.now()
    const fileExt = file.name.split(".").pop()
    const sanitizedFileName = file.name.replace(/\.[^/.]+$/, "").replace(/[^a-z0-9]/gi, "_")
    const fileName = `${timestamp}_${sanitizedFileName}.${fileExt}`
    const filePath = `uploads/${subTaskId}/${fileName}`

    console.log(`Uploading new file to path: ${filePath} in bucket: sub.task.attachment`)

    // Upload the file to the sub.task.attachment bucket
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("sub.task.attachment")
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: false, // Changed to false to avoid silent overwrites
      })

    if (uploadError) {
      console.error(`Error uploading file for sub-task ${subTaskId}:`, uploadError)
      return {
        success: false,
        error: uploadError.message || "Upload failed",
        deletionResult,
      }
    }

    // Get the public URL for the uploaded file
    const { data: urlData } = await supabase.storage.from("sub.task.attachment").getPublicUrl(uploadData.path)
    const publicUrl = urlData?.publicUrl

    // Prepare attachment metadata
    const attachmentData = {
      path: uploadData.path,
      bucket: "sub.task.attachment",
      filename: file.name,
      size: file.size,
      type: file.type,
      url: publicUrl, // Store the URL directly
      uploaded_at: new Date().toISOString(),
      previous_path: oldFilePath, // Store the previous path for reference
    }

    console.log("New attachment data to be stored:", attachmentData)

    // Update the sub-task with attachment info - only update the attachment column
    const { error: updateError } = await supabase
      .from("sub_task")
      .update({
        attachment: attachmentData,
      })
      .eq("sub_task_id", subTaskId)

    if (updateError) {
      console.error(`Error updating sub-task ${subTaskId} with attachment:`, updateError)
      return { success: false, error: updateError.message, deletionResult }
    }

    return {
      success: true,
      attachment: attachmentData,
      deletionResult,
      error: null,
    }
  } catch (error) {
    console.error("Unexpected error in uploadAttachment:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Get feedback for a specific sub-task
export async function getSubTaskFeedback(subTaskId) {
  try {
    if (!subTaskId) return { feedback: null, error: "No sub-task ID provided" }

    console.log(`Getting feedback for sub-task ${subTaskId}`)

    // First, let's check the structure of the feedback table
    const { data: feedbackColumns, error: columnsError } = await supabase.from("feedback").select("*").limit(1)

    console.log("Feedback table structure:", feedbackColumns)

    // Modify the query based on the actual structure
    const { data, error } = await supabase
      .from("feedback")
      .select("*")
      .eq("sub_task_id", subTaskId)
      .order("feedbackid", { ascending: false })
      .limit(1)
      .single()

    if (error && error.code !== "PGRST116") {
      // PGRST116 is the error code for "no rows returned"
      console.error(`Error fetching feedback for sub-task ${subTaskId}:`, error)
      return { feedback: null, error: error.message }
    }

    // If we have feedback, try to get instructor info
    let instructorInfo = null
    if (data && data.supervisor_id) {
      const { data: instructor } = await supabase
        .from("users")
        .select("user_id, userName, email, role")
        .eq("user_id", data.supervisor_id)
        .single()

      instructorInfo = instructor
    }

    // Return feedback with instructor info
    return {
      feedback: data
        ? {
            ...data,
            instructor: instructorInfo,
          }
        : null,
      error: null,
    }
  } catch (error) {
    console.error("Unexpected error in getSubTaskFeedback:", error)
    return { feedback: null, error: "An unexpected error occurred" }
  }
}

// Helper function to get the public URL for an attachment
export function getAttachmentPublicUrl(attachment) {
  if (!attachment || !attachment.bucket || !attachment.path) {
    return null
  }

  // If the attachment already has a URL, use it
  if (attachment.url) {
    return attachment.url
  }

  // Otherwise construct the URL directly
  return `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/${attachment.bucket}/${attachment.path}`
}

// Simplified function that returns an empty array since we're not tracking history
export async function getAttachmentHistory(subTaskId) {
  console.log(`Attachment history not being tracked for sub-task ${subTaskId}`)
  return { history: [], error: null }
}

// New function to request additional feedback after status change
// Modified to remove references to non-existent columns
export async function requestAdditionalFeedback(subTaskId, message, hasAttachment) {
  try {
    if (!subTaskId) return { success: false, error: "No sub-task ID provided" }
    if (!message) return { success: false, error: "No message provided" }

    console.log(`Requesting additional feedback for sub-task ${subTaskId}`)

    // Get the current user from localStorage
    const userStr = localStorage.getItem("user")
    if (!userStr) {
      return { success: false, error: "User not authenticated" }
    }

    const user = JSON.parse(userStr)

    // Create a feedback request record
    const feedbackRequestData = {
      sub_task_id: subTaskId,
      student_id: user.user_id,
      message: message,
      status: "pending", // Status of the feedback request
      created_at: new Date().toISOString(),
      needs_attachment: !hasAttachment, // Flag if student needs to upload a new attachment
    }

    // Insert the feedback request
    const { data, error } = await supabase.from("feedback_request").insert(feedbackRequestData).select()

    if (error) {
      console.error(`Error creating feedback request for sub-task ${subTaskId}:`, error)
      return { success: false, error: error.message }
    }

    // Update the sub-task with a flag indicating there's a pending feedback request
    // Only update the feedback_requested field if it exists
    try {
      // First check if the column exists by getting the table info
      const { data: tableInfo } = await supabase.rpc("get_table_info", { table_name: "sub_task" })

      // If we have table info, check for the columns we want to update
      if (tableInfo) {
        const columns = tableInfo.map((col) => col.column_name)
        const updateData = {}

        // Only add fields that exist in the table
        if (columns.includes("feedback_requested")) {
          updateData.feedback_requested = true
        }

        if (columns.includes("feedback_request_date")) {
          updateData.feedback_request_date = new Date().toISOString()
        }

        // Only perform the update if we have fields to update
        if (Object.keys(updateData).length > 0) {
          await supabase.from("sub_task").update(updateData).eq("sub_task_id", subTaskId)
        }
      }
    } catch (updateErr) {
      // Log but don't fail if this update fails
      console.warn(`Warning: Could not update feedback request flags: ${updateErr.message}`)
    }

    return { success: true, feedbackRequest: data?.[0] || null, error: null }
  } catch (error) {
    console.error("Unexpected error in requestAdditionalFeedback:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Get all feedback requests for a sub-task
export async function getFeedbackRequests(subTaskId) {
  try {
    if (!subTaskId) return { requests: [], error: "No sub-task ID provided" }

    console.log(`Getting feedback requests for sub-task ${subTaskId}`)

    const { data, error } = await supabase
      .from("feedback_request")
      .select(`
        *,
        student:student_id(user_id, userName, email)
      `)
      .eq("sub_task_id", subTaskId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error(`Error fetching feedback requests for sub-task ${subTaskId}:`, error)
      return { requests: [], error: error.message }
    }

    return { requests: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getFeedbackRequests:", error)
    return { requests: [], error: "An unexpected error occurred" }
  }
}

// Track status changes for analytics and history
export async function trackStatusChange(subTaskId, previousStatus, newStatus, userId) {
  try {
    if (!subTaskId) return { success: false, error: "No sub-task ID provided" }
    if (!userId) return { success: false, error: "No user ID provided" }

    console.log(`Tracking status change for sub-task ${subTaskId}: ${previousStatus} -> ${newStatus}`)

    // Create a status change record
    const statusChangeData = {
      sub_task_id: subTaskId,
      user_id: userId,
      previous_status: previousStatus,
      new_status: newStatus,
      changed_at: new Date().toISOString(),
    }

    // Insert the status change record
    const { error } = await supabase.from("status_change_history").insert(statusChangeData)

    if (error) {
      console.error(`Error tracking status change for sub-task ${subTaskId}:`, error)
      return { success: false, error: error.message }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Unexpected error in trackStatusChange:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
