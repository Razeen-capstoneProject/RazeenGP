import { supabase } from "./client"

export async function getTaskDependencies(groupId) {
  try {
    // First get all tasks for this group
    const { data: tasks, error: tasksError } = await supabase.from("task").select("taskid").eq("groupid", groupId)

    if (tasksError) {
      console.error("Error fetching tasks for dependencies:", tasksError)
      return { dependencies: [], error: tasksError }
    }

    if (!tasks || tasks.length === 0) {
      return { dependencies: [], error: null }
    }

    // Get task IDs
    const taskIds = tasks.map((task) => task.taskid)

    // Get dependencies where both task and depend_on are in this group's tasks
    const { data, error } = await supabase.from("dependency").select("*").in("task", taskIds).in("depend_on", taskIds)

    if (error) {
      console.error("Error fetching dependencies:", error)
      return { dependencies: [], error }
    }

    return { dependencies: data || [], error: null }
  } catch (err) {
    console.error("Unexpected error in getTaskDependencies:", err)
    return { dependencies: [], error: err }
  }
}

// Add this function to get dependencies for a specific task
export async function getTaskDependenciesForTask(taskId) {
  try {
    if (!taskId) {
      return { dependencies: [], error: "No task ID provided" }
    }

    // Get dependencies where this task depends on other tasks
    const { data, error } = await supabase.from("dependency").select("depend_on").eq("task", taskId)

    if (error) {
      console.error("Error fetching dependencies for task:", error)
      return { dependencies: [], error }
    }

    return { dependencies: data || [], error: null }
  } catch (err) {
    console.error("Unexpected error in getTaskDependenciesForTask:", err)
    return { dependencies: [], error: err }
  }
}
