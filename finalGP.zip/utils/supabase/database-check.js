import { supabase } from "./client"
import { validateDatabaseSchema, initializeDatabase } from "./database-setup"

/**
 * Comprehensive database health check
 * @returns {Promise<Object>} Health check results
 */
export async function checkDatabaseHealth() {
  console.log("Performing database health check...")

  try {
    // Test basic connection
    const { data, error } = await supabase.from("users").select("count").limit(1)

    if (error) {
      console.error("Database connection error:", error.message)
      return {
        status: "error",
        connection: false,
        message: `Connection failed: ${error.message}`,
        details: error,
      }
    }

    // Validate schema
    const schemaValidation = await validateDatabaseSchema()

    if (!schemaValidation.success) {
      return {
        status: "warning",
        connection: true,
        schema: false,
        message: `Schema validation failed: ${schemaValidation.error}`,
        missingTables: schemaValidation.missingTables,
        details: schemaValidation,
      }
    }

    // Check row counts for key tables
    const tableCounts = {}
    const keyTables = ["users", "projectgroup", "task", "chat", "announcement"]

    for (const table of keyTables) {
      const { count, error: countError } = await supabase.from(table).select("*", { count: "exact", head: true })

      if (countError) {
        console.error(`Error counting rows in ${table}:`, countError)
        tableCounts[table] = { error: countError.message }
      } else {
        tableCounts[table] = { count }
      }
    }

    return {
      status: "healthy",
      connection: true,
      schema: true,
      tableCounts,
      message: "Database is healthy and properly configured",
    }
  } catch (error) {
    console.error("Unexpected error in database health check:", error)
    return {
      status: "error",
      connection: false,
      message: `Health check failed: ${error.message}`,
      details: error,
    }
  }
}

/**
 * Initialize the database if needed
 * @returns {Promise<Object>} Initialization results
 */
export async function ensureDatabaseInitialized() {
  try {
    // Check current state
    const healthCheck = await checkDatabaseHealth()

    if (healthCheck.status === "healthy") {
      return {
        success: true,
        message: "Database already properly initialized",
        initialized: false,
      }
    }

    // Initialize if needed
    const initResult = await initializeDatabase()

    if (!initResult.success) {
      return {
        success: false,
        message: `Database initialization failed: ${initResult.error}`,
        details: initResult,
      }
    }

    // Verify initialization
    const verifyHealth = await checkDatabaseHealth()

    return {
      success: verifyHealth.status === "healthy",
      message:
        verifyHealth.status === "healthy"
          ? "Database successfully initialized"
          : "Database initialization completed but health check failed",
      initialized: true,
      healthCheck: verifyHealth,
    }
  } catch (error) {
    console.error("Error ensuring database initialization:", error)
    return {
      success: false,
      message: `Database initialization check failed: ${error.message}`,
      details: error,
    }
  }
}
