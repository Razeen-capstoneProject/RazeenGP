import { supabase } from "./client"

/**
 * Get all project groups with basic information
 * @returns {Promise<Object>} - The groups and any error
 */
export async function getAllGroups() {
  try {
    console.log("Fetching all groups")

    const { data, error } = await supabase
      .from("projectgroup")
      .select(`
        groupid,
        groupname,
        group_status,
        group_progress,
        enterance_id
      `)
      .order("groupname", { ascending: true })

    if (error) {
      console.error("Error fetching groups:", error)
      return { groups: [], error: error.message }
    }

    return { groups: data || [], error: null }
  } catch (error) {
    console.error("Unexpected error in getAllGroups:", error)
    return { groups: [], error: "An unexpected error occurred" }
  }
}

/**
 * Get detailed information about a specific group
 * @param {number} groupId - The ID of the group
 * @returns {Promise<Object>} - The group details and any error
 */
export async function getGroupDetails(groupId) {
  try {
    if (!groupId) {
      return { group: null, error: "Group ID is required" }
    }

    console.log("Fetching details for group:", groupId)

    // Get basic group information
    const { data: groupData, error: groupError } = await supabase
      .from("projectgroup")
      .select(`
        groupid,
        groupname,
        group_status,
        group_progress,
        enterance_id,
        instructor_supervisor_id,
        leader_id
      `)
      .eq("groupid", groupId)
      .single()

    if (groupError) {
      console.error("Error fetching group details:", groupError)
      return { group: null, error: groupError.message }
    }

    // Get supervisor information
    let supervisor = null
    if (groupData.instructor_supervisor_id) {
      const { data: supervisorData, error: supervisorError } = await supabase
        .from("users")
        .select("user_id, userName, email")
        .eq("user_id", groupData.instructor_supervisor_id)
        .single()

      if (!supervisorError && supervisorData) {
        supervisor = supervisorData
      }
    }

    // Get leader information
    let leader = null
    if (groupData.leader_id) {
      const { data: leaderData, error: leaderError } = await supabase
        .from("users")
        .select("user_id, userName, email")
        .eq("user_id", groupData.leader_id)
        .single()

      if (!leaderError && leaderData) {
        leader = leaderData
      }
    }

    // Get all students in the group
    const { data: studentData, error: studentError } = await supabase
      .from("student_masked")
      .select(`
        student_id
      `)
      .eq("groupid", groupId)

    if (studentError) {
      console.error("Error fetching group students:", studentError)
      return { group: null, error: studentError.message }
    }

    // Fetch user details separately to avoid the relationship ambiguity
    const students = []
    if (studentData && studentData.length > 0) {
      const studentIds = studentData.map((s) => s.student_id)

      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("user_id, userName, email")
        .in("user_id", studentIds)

      if (!userError && userData) {
        // Map user data to students array
        students.push(
          ...userData.map((user) => ({
            id: user.user_id,
            name: user.userName || "Unknown Student",
            email: user.email || "",
          })),
        )
      }
    }

    // Combine all data
    const groupDetails = {
      ...groupData,
      supervisor,
      leader,
      students,
    }

    return { group: groupDetails, error: null }
  } catch (error) {
    console.error("Unexpected error in getGroupDetails:", error)
    return { group: null, error: "An unexpected error occurred" }
  }
}
