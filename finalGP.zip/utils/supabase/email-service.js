import { supabase } from "./client"

export async function sendPasswordResetEmail(email, resetCode) {
  try {
    // In a real production app, you would use a proper email service like SendGrid, Mailgun, etc.
    // For this demo, we'll use a simple approach to simulate email sending

    const emailSubject = "Reset Your Password"
    const emailBody = `
      <h2>Reset Password</h2>
      <p>Follow this link to reset the password for your account:</p>
      <p>Your reset code is: <strong>${resetCode}</strong></p>
      <p>Enter this code on the verification page to continue with your password reset.</p>
      <p>If you didn't request this, you can safely ignore this email.</p>
    `

    // Log the email for demo purposes
    console.log(`Email sent to ${email} with subject: ${emailSubject}`)
    console.log(`Email body: ${emailBody}`)

    // Store the email in the database for demo purposes
    // In a real app, you would use an actual email service
    const { error } = await supabase.from("sent_emails").insert([
      {
        recipient: email,
        subject: emailSubject,
        body: emailBody,
        sent_at: new Date().toISOString(),
      },
    ])

    if (error) {
      console.error("Error storing email:", error)
      // Continue even if storing fails - we'll return success anyway
    }

    return { success: true }
  } catch (error) {
    console.error("Error sending email:", error)
    return { success: false, error: "Failed to send email" }
  }
}
