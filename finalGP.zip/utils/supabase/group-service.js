import { supabase } from "./client"

/**
 * Creates a new project group and associates it with existing chat channels
 * @param {Object} groupData - The group data to create
 * @param {string} groupData.groupname - The name of the group
 * @param {string} groupData.instructor_supervisor_id - The ID of the instructor/supervisor
 * @param {string} groupData.project_type - The type of project (e.g., "testTrigger", "tri2", "capstone", etc.)
 * @returns {Promise<Object>} - The created group and any error
 */
export async function createProjectGroup(groupData) {
  try {
    console.log("Creating new project group:", groupData)

    if (!groupData.groupname || !groupData.instructor_supervisor_id || !groupData.project_type) {
      return {
        group: null,
        error: "Missing required fields: groupname, instructor_supervisor_id, or project_type",
      }
    }

    // Insert the new group
    const { data: newGroup, error: groupError } = await supabase
      .from("projectgroup")
      .insert({
        groupname: groupData.groupname,
        instructor_supervisor_id: groupData.instructor_supervisor_id,
        group_status: groupData.group_status || "active",
        group_progress: groupData.group_progress || 0,
      })
      .select()
      .single()

    if (groupError) {
      console.error("Error creating project group:", groupError)
      return { group: null, error: groupError.message }
    }

    console.log("Created new group:", newGroup)

    // Find existing chat channels for the project type
    const projectType = groupData.project_type.toLowerCase()

    // Find the pair of chats for this project type
    const { data: existingChats, error: chatsError } = await supabase
      .from("chat")
      .select("*")
      .or(`chatname.ilike.%${projectType}%`)
      .is("group_id", null)

    if (chatsError) {
      console.error("Error finding existing chats:", chatsError)
      return { group: newGroup, error: "Group created but failed to link chats" }
    }

    console.log("Found existing chats:", existingChats)

    // Filter for student chat and supervisor chat
    const studentChat = existingChats.find(
      (chat) => chat.chatname.startsWith("students_chats_") && chat.chatname.includes(projectType),
    )

    const supervisorChat = existingChats.find(
      (chat) => chat.chatname.startsWith("supervisor_students_chats_") && chat.chatname.includes(projectType),
    )

    // Link student chat to the group
    if (studentChat) {
      console.log("Linking student chat:", studentChat.chatid)
      const { error: updateStudentChatError } = await supabase
        .from("chat")
        .update({ group_id: newGroup.groupid })
        .eq("chatid", studentChat.chatid)

      if (updateStudentChatError) {
        console.error("Error linking student chat:", updateStudentChatError)
      }
    } else {
      console.warn("No matching student chat found for project type:", projectType)
    }

    // Link supervisor chat to the group
    if (supervisorChat) {
      console.log("Linking supervisor chat:", supervisorChat.chatid)
      const { error: updateSupervisorChatError } = await supabase
        .from("chat")
        .update({ group_id: newGroup.groupid })
        .eq("chatid", supervisorChat.chatid)

      if (updateSupervisorChatError) {
        console.error("Error linking supervisor chat:", updateSupervisorChatError)
      }
    } else {
      console.warn("No matching supervisor chat found for project type:", projectType)
    }

    // Return the created group
    return {
      group: newGroup,
      studentChatId: studentChat?.chatid || null,
      supervisorChatId: supervisorChat?.chatid || null,
      error: null,
    }
  } catch (error) {
    console.error("Unexpected error creating project group:", error)
    return { group: null, error: "An unexpected error occurred" }
  }
}

/**
 * Gets all available project types based on existing chat channels
 * @returns {Promise<Object>} - List of project types and any error
 */
export async function getAvailableProjectTypes() {
  try {
    // Get all unique chat names for student chats
    const { data: chats, error: chatError } = await supabase
      .from("chat")
      .select("chatname")
      .ilike("chatname", "students_chats_%")
      .is("group_id", null) // Only get unassigned chats

    if (chatError) {
      console.error("Error fetching chat names:", chatError)
      return { projectTypes: [], error: chatError.message }
    }

    // Extract project types from chat names
    const projectTypes = chats
      .map((chat) => {
        // Extract project type from chat name (e.g., "students_chats_testTrigger" -> "testTrigger")
        const match = chat.chatname.match(/students_chats_(.+)/)
        return match ? match[1] : null
      })
      .filter(Boolean) // Remove nulls
      .filter((value, index, self) => self.indexOf(value) === index) // Remove duplicates
      .map((type) => ({
        id: type,
        name: type.charAt(0).toUpperCase() + type.slice(1).replace(/_/g, " "), // Format for display
      }))

    return { projectTypes, error: null }
  } catch (error) {
    console.error("Unexpected error getting project types:", error)
    return { projectTypes: [], error: "An unexpected error occurred" }
  }
}

/**
 * Adds a student to a project group
 * @param {string} groupId - The ID of the group
 * @param {string} studentId - The ID of the student
 * @returns {Promise<Object>} - Success status and any error
 */
export async function addStudentToGroup(groupId, studentId) {
  try {
    console.log(`Adding student ${studentId} to group ${groupId}`)

    // Add student to the student_masked table
    const { error: addError } = await supabase.from("student_masked").insert({
      student_id: studentId,
      groupid: groupId,
    })

    if (addError) {
      console.error("Error adding student to group:", addError)
      return { success: false, error: addError.message }
    }

    // Also update the student table
    const { error: updateError } = await supabase.from("student").upsert({
      student_id: studentId,
      groupid: groupId,
    })

    if (updateError) {
      console.error("Error updating student record:", updateError)
      return { success: false, error: updateError.message }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Unexpected error adding student to group:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
