import { supabase } from "./client"
import { hashPassword } from "./password-utils"

export async function checkUserExists(email, username) {
  try {
    // Check if email exists
    const { data: emailData, error: emailError } = await supabase
      .from("users")
      .select("email")
      .eq("email", email.trim())
      .single()

    if (emailError && emailError.code !== "PGRST116") {
      console.error("Error checking email:", emailError)
      return { error: "Error checking email availability" }
    }

    // Check if username exists
    const { data: usernameData, error: usernameError } = await supabase
      .from("users")
      .select("userName")
      .eq("userName", username.trim())
      .single()

    if (usernameError && usernameError.code !== "PGRST116") {
      console.error("Error checking username:", usernameError)
      return { error: "Error checking username availability" }
    }

    return {
      emailExists: !!emailData,
      usernameExists: !!usernameData,
    }
  } catch (error) {
    console.error("Unexpected error during existence check:", error)
    return { error: "An unexpected error occurred" }
  }
}

export async function createUser(email, username, password, role = "student") {
  try {
    // First, create the auth user with Supabase Auth
    // This will automatically send a verification email
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email.trim(),
      password: password,
      options: {
        data: {
          userName: username.trim(),
          role: "student",
        },
      },
    })

    if (authError) {
      console.error("Error creating auth user:", authError)
      return { success: false, error: authError.message }
    }

    // Get the user ID from the auth response
    const userId = authData.user.id

    // Hash the password for the users table
    const hashedPassword = hashPassword(password)

    // Insert into users table
    const { data, error } = await supabase
      .from("users")
      .insert([
        {
          user_id: userId, // Use the ID from auth
          email: email.trim(),
          userName: username.trim(),
          password: hashedPassword,
          role: "student",
        },
      ])
      .select()

    if (error) {
      console.error("Error creating user record:", error)
      return { success: false, error: error.message }
    }

    // Insert into student table
    const { error: studentError } = await supabase.from("student").insert([
      {
        student_id: userId,
        groupid: null,
        grade: null,
      },
    ])

    if (studentError) {
      if (studentError.code === "23505") {
        console.log("Student record already exists, continuing...")
      } else {
        console.error("Error creating student record:", studentError)
        return {
          success: true,
          user: data[0],
          warning: "User account created but student profile setup failed. Please contact support.",
        }
      }
    }

    return {
      success: true,
      user: data[0],
      message: "Account created successfully. Please check your email for verification instructions.",
    }
  } catch (error) {
    console.error("Unexpected error during user creation:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

// Using Supabase's built-in functionality for email verification
export async function sendVerificationEmail(email) {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    })

    if (error) {
      console.error("Error sending password reset:", error)
      return { error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Error sending verification email:", error)
    return { error: "Failed to send verification email" }
  }
}
