import { supabase } from "./client"

/**
 * Get all available voting options for a specific group, filtered by deadline
 * @param {string} groupId - The group ID
 * @returns {Promise<{votingGroups: Array, error: string|null}>}
 */
export async function getVotingOptions(groupId) {
  try {
    const { data, error } = await supabase
      .from("voting")
      .select("*")
      .eq("group_id", groupId)
      .order("vote_id")
      .order("suggestion_time", { ascending: true })

    if (error) {
      console.error("Error fetching voting options:", error)
      return { votingGroups: [], error: error.message }
    }

    // Filter out expired options and group by vote_id
    const now = new Date()
    const validOptions =
      data?.filter((option) => {
        const deadline = new Date(option.deadline)
        return deadline > now
      }) || []

    // Group options by vote_id
    const groupedOptions = validOptions.reduce((groups, option) => {
      const existingGroup = groups.find((group) => group.vote_id === option.vote_id)

      if (existingGroup) {
        existingGroup.options.push(option)
      } else {
        groups.push({
          vote_id: option.vote_id,
          deadline: option.deadline,
          vote_title: option.vote_title || `Vote #${option.vote_id}`,
          options: [option],
        })
      }

      return groups
    }, [])

    return { votingGroups: groupedOptions, error: null }
  } catch (error) {
    console.error("Error in getVotingOptions:", error)
    return { votingGroups: [], error: "An unexpected error occurred" }
  }
}

/**
 * Get student's current votes
 * @param {string} studentId - The student ID
 * @returns {Promise<{studentVotes: Array, error: string|null}>}
 */
export async function getStudentVotes(studentId) {
  try {
    const { data, error } = await supabase.from("student_voting").select("*").eq("student_id", studentId)

    if (error) {
      console.error("Error fetching student votes:", error)
      return { studentVotes: [], error: error.message }
    }

    return { studentVotes: data || [], error: null }
  } catch (error) {
    console.error("Error in getStudentVotes:", error)
    return { studentVotes: [], error: "An unexpected error occurred" }
  }
}

/**
 * Update vote count for a specific vote option
 * @param {number} voteId - The vote ID
 * @param {string} suggestionTime - The suggestion time
 * @param {number} increment - Amount to increment (1) or decrement (-1)
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
async function updateVoteCount(voteId, suggestionTime, increment) {
  try {
    // First get the current vote count
    const { data, error: fetchError } = await supabase
      .from("voting")
      .select("num_voters")
      .eq("vote_id", voteId)
      .eq("suggestion_time", suggestionTime)
      .single()

    if (fetchError) {
      console.error("Error fetching vote count:", fetchError)
      return { success: false, error: fetchError.message }
    }

    // Calculate new count (ensure it doesn't go below 0)
    const newCount = Math.max(0, (data.num_voters || 0) + increment)

    // Update the vote count
    const { error: updateError } = await supabase
      .from("voting")
      .update({ num_voters: newCount })
      .eq("vote_id", voteId)
      .eq("suggestion_time", suggestionTime)

    if (updateError) {
      console.error("Error updating vote count:", updateError)
      return { success: false, error: updateError.message }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Error in updateVoteCount:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

/**
 * Cast a vote for a meeting time
 * @param {string} studentId - The student ID
 * @param {number} voteId - The vote ID
 * @param {string} suggestionTime - The suggestion time
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
export async function castVote(studentId, voteId, suggestionTime) {
  try {
    // First check if the student has already voted for this option
    const { data: existingVote, error: checkError } = await supabase
      .from("student_voting")
      .select("*")
      .eq("student_id", studentId)
      .eq("vote_id", voteId)
      .eq("suggestion_time", suggestionTime)
      .single()

    if (checkError && checkError.code !== "PGRST116") {
      // PGRST116 means no rows returned, which is expected if they haven't voted
      console.error("Error checking existing vote:", checkError)
      return { success: false, error: checkError.message }
    }

    // If the student has already voted for this option, return success
    if (existingVote) {
      return { success: true, error: null }
    }

    // Insert the vote record
    const { error: voteError } = await supabase.from("student_voting").insert({
      student_id: studentId,
      vote_id: voteId,
      suggestion_time: suggestionTime,
    })

    if (voteError) {
      console.error("Error casting vote:", voteError)
      return { success: false, error: voteError.message }
    }

    // Update the vote count
    const { success: updateSuccess, error: updateError } = await updateVoteCount(voteId, suggestionTime, 1)

    if (!updateSuccess) {
      console.error("Error updating vote count:", updateError)
      return { success: false, error: updateError }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Error in castVote:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

/**
 * Remove a vote for a meeting time
 * @param {string} studentId - The student ID
 * @param {number} voteId - The vote ID
 * @param {string} suggestionTime - The suggestion time
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
export async function removeVote(studentId, voteId, suggestionTime) {
  try {
    // First check if the student has voted for this option
    const { data: existingVote, error: checkError } = await supabase
      .from("student_voting")
      .select("*")
      .eq("student_id", studentId)
      .eq("vote_id", voteId)
      .eq("suggestion_time", suggestionTime)
      .single()

    if (checkError) {
      // If no vote exists, nothing to remove
      if (checkError.code === "PGRST116") {
        return { success: true, error: null }
      }
      console.error("Error checking existing vote:", checkError)
      return { success: false, error: checkError.message }
    }

    // Delete the vote record
    const { error: voteError } = await supabase
      .from("student_voting")
      .delete()
      .eq("student_id", studentId)
      .eq("vote_id", voteId)
      .eq("suggestion_time", suggestionTime)

    if (voteError) {
      console.error("Error removing vote:", voteError)
      return { success: false, error: voteError.message }
    }

    // Update the vote count
    const { success: updateSuccess, error: updateError } = await updateVoteCount(voteId, suggestionTime, -1)

    if (!updateSuccess) {
      console.error("Error updating vote count:", updateError)
      return { success: false, error: updateError }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Error in removeVote:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

/**
 * Update a student's vote from one option to another
 * @param {string} studentId - The student ID
 * @param {number} voteId - The vote ID
 * @param {string} newSuggestionTime - The new suggestion time to vote for
 * @param {string|null} oldSuggestionTime - The old suggestion time to remove (if any)
 * @returns {Promise<{success: boolean, error: string|null}>}
 */
export async function updateVote(studentId, voteId, newSuggestionTime, oldSuggestionTime = null) {
  try {
    // If there's an old vote to remove
    if (oldSuggestionTime) {
      // Remove the old vote
      const { success: removeSuccess, error: removeError } = await removeVote(studentId, voteId, oldSuggestionTime)

      if (!removeSuccess) {
        console.error("Error removing old vote:", removeError)
        return { success: false, error: removeError }
      }
    }

    // Add the new vote
    const { success: addSuccess, error: addError } = await castVote(studentId, voteId, newSuggestionTime)

    if (!addSuccess) {
      console.error("Error adding new vote:", addError)
      return { success: false, error: addError }
    }

    return { success: true, error: null }
  } catch (error) {
    console.error("Error in updateVote:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

/**
 * Format a date string to a readable format
 * @param {string} dateString - ISO date string
 * @returns {string} - Formatted date string
 */
export function formatMeetingDate(dateString, endTimeString = null) {
  try {
    const date = new Date(dateString)
    const formatter = new Intl.DateTimeFormat("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      hour12: true,
    })

    if (!endTimeString) {
      return formatter.format(date)
    }

    // Format with interval if end_time exists
    const endTime = new Date(endTimeString)
    const startFormatted = formatter.format(date)

    // For the end time, we only need the time portion if it's the same day
    const endFormatter = new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "numeric",
      hour12: true,
    })

    return `${startFormatted} - ${endFormatter.format(endTime)}`
  } catch (error) {
    console.error("Error formatting date:", error)
    return dateString
  }
}

/**
 * Format a deadline date to show remaining time
 * @param {string} deadlineString - ISO date string for deadline
 * @returns {string} - Formatted deadline string
 */
export function formatDeadline(deadlineString) {
  try {
    const deadline = new Date(deadlineString)
    const now = new Date()

    // Calculate difference in milliseconds
    const diffMs = deadline - now

    // If deadline has passed
    if (diffMs <= 0) {
      return "Expired"
    }

    // Convert to days, hours, minutes
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

    if (diffDays > 0) {
      return `${diffDays}d ${diffHours}h remaining`
    } else if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}m remaining`
    } else {
      return `${diffMinutes}m remaining`
    }
  } catch (error) {
    console.error("Error formatting deadline:", error)
    return "Unknown deadline"
  }
}
