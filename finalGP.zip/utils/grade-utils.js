/**
 * Converts a numeric score to a letter grade
 * @param {number} score - The numeric score (0-100)
 * @returns {string} The corresponding letter grade
 */
export function getLetterGrade(score) {
  if (score === null || score === undefined) return "N/A"

  if (score >= 95) return "A+"
  if (score >= 90) return "A"
  if (score >= 85) return "B+"
  if (score >= 80) return "B"
  if (score >= 75) return "C+"
  if (score >= 70) return "C"
  if (score >= 65) return "D+"
  if (score >= 60) return "D"
  return "F"
}

/**
 * Gets the color class for a letter grade
 * @param {string} grade - The letter grade
 * @returns {string} Tailwind color class
 */
export function getGradeColor(grade) {
  switch (grade) {
    case "A+":
    case "A":
      return "text-green-600"
    case "B+":
    case "B":
      return "text-blue-600"
    case "C+":
    case "C":
      return "text-yellow-600"
    case "D+":
    case "D":
      return "text-orange-600"
    case "F":
      return "text-red-600"
    default:
      return "text-gray-600"
  }
}

/**
 * Determines if a grade is passing
 * @param {string} letterGrade - The letter grade
 * @returns {boolean} - Whether the grade is passing
 */
export function isPassingGrade(letterGrade) {
  return !["F", "D", "D+"].includes(letterGrade)
}
