"use client"

import { useState, useEffect } from "react"
import { X, FileText, ArrowUpRight } from "lucide-react"
import { updateSubTaskDescription, isLeaderForSubTask } from "@/utils/supabase/subtask-service"
import { isGroupLeader } from "@/utils/supabase/user-service"

export function TaskDescriptionModal({
  isOpen,
  onClose,
  task,
  students,
  groupId,
  onUpdate,
  currentUser,
  readOnly = false,
}) {
  const [isEditingDescription, setIsEditingDescription] = useState(false)
  const [description, setDescription] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [isLeader, setIsLeader] = useState(false)
  const [checkingRole, setCheckingRole] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)

  // Check if the current user is a leader
  useEffect(() => {
    async function checkLeaderStatus() {
      if (!currentUser?.user_id || readOnly) {
        setIsLeader(false)
        setCheckingRole(false)
        return
      }

      try {
        // First check if the user is a group leader
        const leaderStatus = await isGroupLeader(currentUser.user_id)

        if (leaderStatus) {
          setIsLeader(true)
        } else if (task?.sub_task_id) {
          // If not a general leader, check if they're a leader for this specific sub-task
          const isLeaderForTask = await isLeaderForSubTask(currentUser.user_id, task.sub_task_id)
          setIsLeader(isLeaderForTask)
        } else {
          setIsLeader(false)
        }
      } catch (error) {
        console.error("Error checking leader status:", error)
        setIsLeader(false)
      } finally {
        setCheckingRole(false)
      }
    }

    if (isOpen && task) {
      checkLeaderStatus()
    }
  }, [isOpen, currentUser, task, readOnly])

  const handleSaveDescription = async () => {
    if (!task || !task.sub_task_id || !isLeader) return

    setIsSaving(true)
    setError(null)
    setSuccess(false)

    try {
      const { success, error: updateError } = await updateSubTaskDescription(task.sub_task_id, description)

      if (updateError) {
        throw new Error(updateError)
      }

      if (success) {
        setSuccess(true)
        setIsEditingDescription(false)

        // Notify parent component about the update
        if (onUpdate) {
          const updatedTask = { ...task, description }
          onUpdate(updatedTask)
        }
      }
    } catch (err) {
      console.error("Error updating description:", err)
      setError(err.message || "Failed to update description")
    } finally {
      setIsSaving(false)
    }
  }

  if (!isOpen || !task) return null

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="bg-white rounded-lg shadow-lg w-full max-w-md overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex justify-between items-center border-b border-gray-200 p-4">
          <h3 className="font-semibold text-lg">{isEditingDescription ? "Edit Description" : "Task Description"}</h3>
          <div className="flex items-center gap-2">
            <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100 transition-colors">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          {error && <div className="mb-4 p-3 bg-red-50 text-red-800 rounded-md text-sm">{error}</div>}

          {success && (
            <div className="mb-4 p-3 bg-green-50 text-green-800 rounded-md text-sm">
              Description updated successfully!
            </div>
          )}

          <div className="mb-4">
            <h4 className="font-medium text-gray-900 text-lg mb-2">{task.subTaskName}</h4>

            {task.task?.taskname && (
              <div className="text-sm text-gray-500 mb-4 flex items-center gap-1">
                <ArrowUpRight size={14} className="text-gray-400" />
                Related to: <span className="font-medium">{task.task.taskname}</span>
              </div>
            )}

            <div className="bg-gray-50 rounded-md p-4 mt-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <FileText size={18} className="text-gray-400" />
                  <h5 className="font-medium text-gray-700">Description</h5>
                </div>

                {isLeader && !isEditingDescription && !checkingRole && !readOnly && (
                  <button
                    onClick={() => setIsEditingDescription(true)}
                    className="text-blue-600 hover:text-blue-800 text-sm"
                  >
                    Edit
                  </button>
                )}
              </div>

              <div className="pl-6 mt-3">
                {isEditingDescription ? (
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md min-h-[150px] focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter task description..."
                    disabled={isSaving}
                  />
                ) : (
                  <div className="bg-white border border-gray-100 rounded-md p-3 min-h-[100px] whitespace-pre-wrap">
                    {task.description ? (
                      <p className="text-gray-800">{task.description}</p>
                    ) : (
                      <p className="text-gray-400 italic">No description provided</p>
                    )}
                  </div>
                )}

                {isEditingDescription && (
                  <div className="flex justify-end gap-2 mt-3">
                    <button
                      onClick={() => setIsEditingDescription(false)}
                      className="px-3 py-1.5 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 text-sm"
                      disabled={isSaving}
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveDescription}
                      disabled={isSaving}
                      className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-1.5"
                    >
                      {isSaving ? (
                        <>
                          <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                          <span>Saving...</span>
                        </>
                      ) : (
                        <span>Save</span>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
