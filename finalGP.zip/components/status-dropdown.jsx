"use client"

import { useState, useEffect, useRef } from "react"
import { ChevronDown, Clock, CheckCircle, CircleDot } from "lucide-react"
import { usePathname } from "next/navigation"

export function StatusDropdown({
  taskId,
  currentStatus,
  onStatusChange,
  isUpdating,
  className = "",
  disabled = false,
}) {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef(null)
  const pathname = usePathname()
  const isMyTaskPage = pathname === "/dashboard/my-task"

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Status options data with colors and icons
  const statusOptions = [
    {
      value: "To Do",
      icon: <Clock size={14} />,
      bgColor: "bg-gray-100",
      textColor: "text-gray-800",
      iconColor: "text-gray-500",
      hoverColor: "hover:bg-gray-200",
    },
    {
      value: "On Progress",
      icon: <CircleDot size={14} />,
      bgColor: "bg-blue-100",
      textColor: "text-blue-800",
      iconColor: "text-blue-500",
      hoverColor: "hover:bg-blue-200",
    },
    {
      value: "Done",
      icon: <CheckCircle size={14} />,
      bgColor: "bg-green-100",
      textColor: "text-green-800",
      iconColor: "text-green-500",
      hoverColor: "hover:bg-green-200",
    },
  ]

  // Find current status option
  const currentStatusOption =
    statusOptions.find((option) => option.value.toLowerCase() === (currentStatus || "").toLowerCase()) ||
    statusOptions[0]

  const handleSelect = (status) => {
    if (currentStatus !== status) {
      onStatusChange(taskId, status)
    }
    setIsOpen(false)
  }

  // Only render the dropdown on the my-task page
  if (!isMyTaskPage) {
    return null
  }

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {/* Current status button */}
      <button
        onClick={() => !isUpdating && !disabled && setIsOpen(!isOpen)}
        disabled={isUpdating || disabled}
        className={`px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 
        ${currentStatusOption.bgColor} ${currentStatusOption.textColor} 
        hover:opacity-90 transition-colors ${disabled ? "opacity-70 cursor-default" : ""}`}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-labelledby={`status-label-${taskId}`}
      >
        {isUpdating ? (
          <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin"></span>
        ) : (
          <span className={currentStatusOption.iconColor}>{currentStatusOption.icon}</span>
        )}
        <span id={`status-label-${taskId}`}>{currentStatusOption.value}</span>
        {!disabled && <ChevronDown size={12} className={`transition-transform ${isOpen ? "rotate-180" : ""}`} />}
      </button>

      {/* Dropdown menu */}
      {isOpen && !disabled && (
        <div
          className="absolute right-0 top-full mt-1 bg-white rounded-md shadow-lg border border-gray-200 z-[100] overflow-hidden"
          role="listbox"
          aria-labelledby={`status-label-${taskId}`}
        >
          {/* Horizontal layout for status options */}
          <div className="flex flex-col">
            {statusOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => handleSelect(option.value)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs ${option.textColor} ${option.hoverColor} transition-colors
                  ${currentStatus === option.value ? `${option.bgColor} font-medium` : ""}
                `}
                role="option"
                aria-selected={currentStatus === option.value}
              >
                <span className={option.iconColor}>{option.icon}</span>
                <span>{option.value}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
