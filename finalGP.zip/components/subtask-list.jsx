"use client"

import { useState, useEffect } from "react"
import { getStudentSubTasks, updateSubTaskStatus } from "@/utils/supabase/subtask-service"
import { useAuth } from "@/context/auth-context"
import { motion, AnimatePresence } from "framer-motion"
import { getCurrentUserGroup } from "@/utils/supabase/user-service"
import {
  AlertCircle,
  Calendar,
  ArrowUpRight,
  User,
  ChevronDown,
  ChevronRight,
  Clock,
  CircleDot,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Check,
  FileText,
} from "lucide-react"
// import { formatDistanceToNow } from "date-fns"
import { TaskDescriptionModal } from "@/components/task-description-modal"

export function SubTaskList() {
  const { user } = useAuth()
  const [subTasks, setSubTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [statusUpdating, setStatusUpdating] = useState({})
  const [updateError, setUpdateError] = useState({})
  const [expandedTasks, setExpandedTasks] = useState({})
  const [selectedTask, setSelectedTask] = useState(null)
  const [showDescriptionModal, setShowDescriptionModal] = useState(false)
  const [groupId, setGroupId] = useState(null)

  // Fetch user's group ID
  useEffect(() => {
    async function fetchGroupId() {
      if (!user?.user_id) return

      try {
        const { groupId: userGroupId, error } = await getCurrentUserGroup(user.user_id)

        if (!error && userGroupId) {
          setGroupId(userGroupId)
        }
      } catch (err) {
        console.error("Error fetching user's group:", err)
      }
    }

    fetchGroupId()
  }, [user])

  useEffect(() => {
    async function fetchSubTasks() {
      if (!user?.user_id) return

      setLoading(true)
      setError(null)

      try {
        const { subTasks: tasks, error: fetchError } = await getStudentSubTasks(user.user_id)

        if (fetchError) {
          throw new Error(fetchError)
        }

        setSubTasks(tasks)
      } catch (err) {
        console.error("Error fetching sub-tasks:", err)
        setError("Failed to load your tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchSubTasks()
  }, [user])

  const handleStatusChange = async (subTaskId, newStatus) => {
    console.log(`Attempting to update task ${subTaskId} to status: ${newStatus}`)

    setStatusUpdating((prev) => ({ ...prev, [subTaskId]: true }))
    setUpdateError((prev) => ({ ...prev, [subTaskId]: null }))

    try {
      const { success, subTask, error: updateErr } = await updateSubTaskStatus(subTaskId, newStatus)

      console.log("Status update result:", { success, subTask, error: updateErr })

      if (updateErr) {
        throw new Error(updateErr)
      }

      if (success && subTask) {
        // Update the sub-task in the list immediately
        setSubTasks((prev) =>
          prev.map((task) => (task.sub_task_id === subTaskId ? { ...task, status: newStatus } : task)),
        )
        console.log(`Successfully updated task ${subTaskId} to status: ${newStatus}`)
      }
    } catch (err) {
      console.error(`Error updating sub-task ${subTaskId} status:`, err)
      setUpdateError((prev) => ({ ...prev, [subTaskId]: err.message || "Failed to update status" }))
    } finally {
      setStatusUpdating((prev) => ({ ...prev, [subTaskId]: false }))
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      // Format as "Mar 17, 2025 9:00 PM"
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get display name for the student
  const getStudentDisplayName = (subTask) => {
    // If there's no student assigned, return empty string
    if (!subTask.student_id || !subTask.users) {
      return ""
    }

    // If userName exists, use it
    if (subTask.users.userName) {
      return subTask.users.userName
    }

    // Fallback to truncated email if available
    if (subTask.users.email) {
      const email = subTask.users.email
      // Extract name part from email (before @)
      const namePart = email.split("@")[0]
      // Capitalize first letter and replace dots/underscores with spaces
      return namePart.charAt(0).toUpperCase() + namePart.slice(1).replace(/[._]/g, " ")
    }

    // Last resort fallback
    return "Unnamed Student"
  }

  // Toggle task expansion
  const toggleTaskExpansion = (taskId) => {
    setExpandedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }))
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Group tasks by status
  const todoTasks = subTasks.filter(
    (task) => task.status?.toLowerCase() === "to do" && task.student_id === user?.user_id,
  )

  const inProgressTasks = subTasks.filter(
    (task) => task.status?.toLowerCase() === "on progress" && task.student_id === user?.user_id,
  )

  const completedTasks = subTasks.filter(
    (task) => task.status?.toLowerCase() === "done" && task.student_id === user?.user_id,
  )

  // Render status change buttons based on current status
  const renderStatusButtons = (task) => {
    // Only show buttons if the task is assigned to the current user
    if (task.student_id !== user?.user_id) {
      return null
    }

    const isUpdating = statusUpdating[task.sub_task_id]
    const currentStatus = task.status?.toLowerCase()

    return (
      <div className="flex flex-wrap gap-2 mt-3">
        {/* To Do button - show for In Progress and Completed tasks */}
        {currentStatus !== "to do" && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              handleStatusChange(task.sub_task_id, "To Do")
            }}
            disabled={isUpdating}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
          >
            <ArrowLeft size={12} />
            <span>To Do</span>
          </button>
        )}

        {/* In Progress button - show for To Do and Completed tasks */}
        {currentStatus !== "on progress" && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              handleStatusChange(task.sub_task_id, "On Progress")
            }}
            disabled={isUpdating}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-md bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors"
          >
            {currentStatus === "to do" ? (
              <>
                <ArrowRight size={12} />
                <span>In Progress</span>
              </>
            ) : (
              <>
                <ArrowLeft size={12} />
                <span>In Progress</span>
              </>
            )}
          </button>
        )}

        {/* Completed button - show for To Do and In Progress tasks */}
        {currentStatus !== "done" && (
          <button
            onClick={(e) => {
              e.stopPropagation()
              handleStatusChange(task.sub_task_id, "Done")
            }}
            disabled={isUpdating}
            className="flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-md bg-green-100 text-green-700 hover:bg-green-200 transition-colors"
          >
            <Check size={12} />
            <span>Completed</span>
          </button>
        )}

        {/* Loading indicator */}
        {isUpdating && (
          <span className="flex items-center gap-1 text-xs text-gray-500">
            <div className="w-3 h-3 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
            Updating...
          </span>
        )}
      </div>
    )
  }

  const handleDescriptionUpdate = (subTaskId, newDescription) => {
    // Update the task in the local state
    setSubTasks((prev) =>
      prev.map((task) => (task.sub_task_id === subTaskId ? { ...task, description: newDescription } : task)),
    )
  }

  // Render a single task card
  const renderTaskCard = (task) => {
    const studentName = getStudentDisplayName(task)
    const isExpanded = expandedTasks[task.sub_task_id] || false
    const isAssignedToCurrentUser = task.student_id === user?.user_id

    return (
      <motion.div
        key={task.sub_task_id}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className={`bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow mb-3 ${
          isAssignedToCurrentUser ? "border-l-4 border-l-blue-400" : ""
        }`}
      >
        {/* Collapsed view - task name and status */}
        <div
          className="p-3 cursor-pointer flex justify-between items-center"
          onClick={() => toggleTaskExpansion(task.sub_task_id)}
        >
          <div className="flex items-center gap-2 flex-1 min-w-0">
            {isExpanded ? (
              <ChevronDown size={16} className="text-gray-500 flex-shrink-0" />
            ) : (
              <ChevronRight size={16} className="text-gray-500 flex-shrink-0" />
            )}
            <div className="min-w-0">
              <h4 className="font-medium text-base truncate">{task.subTaskName}</h4>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0 ml-2">
            {studentName && (
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <User size={12} />
                <span>{studentName}</span>
              </div>
            )}
            {/* Status indicator */}
            <div
              className={`px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 
              ${
                task.status?.toLowerCase() === "to do"
                  ? "bg-gray-100 text-gray-800"
                  : task.status?.toLowerCase() === "on progress"
                    ? "bg-blue-100 text-blue-800"
                    : "bg-green-100 text-green-800"
              }`}
            >
              {task.status?.toLowerCase() === "to do" ? (
                <Clock size={12} />
              ) : task.status?.toLowerCase() === "on progress" ? (
                <CircleDot size={12} />
              ) : (
                <CheckCircle size={12} />
              )}
              <span>{task.status}</span>
            </div>
          </div>
        </div>

        {/* Expanded view - all details */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="border-t border-gray-200 p-3 bg-gray-50"
            >
              {updateError[task.sub_task_id] && (
                <div className="mb-3 p-2 bg-red-50 text-red-800 text-xs rounded-md">
                  {updateError[task.sub_task_id]}
                </div>
              )}

              {task.description ? (
                <div className="flex items-center gap-2 mb-3">
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setSelectedTask(task)
                      setShowDescriptionModal(true)
                    }}
                    className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                  >
                    <FileText size={14} />
                    View Description
                  </button>
                </div>
              ) : (
                <div className="text-sm text-gray-400 italic mb-3">No description provided</div>
              )}

              <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-gray-500 mb-3">
                <div className="flex items-center gap-1">
                  <Calendar size={14} />
                  <span>{formatDate(task.deadline)}</span>
                </div>

                {task.task?.taskname && (
                  <div className="flex items-center gap-1">
                    <ArrowUpRight size={14} />
                    <span>From: {task.task.taskname}</span>
                  </div>
                )}

                {task.priority && (
                  <div className={`px-2 py-0.5 rounded-full text-xs ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </div>
                )}
              </div>

              {/* Status change buttons */}
              {renderStatusButtons(task)}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    )
  }

  // Render a status column
  const renderStatusColumn = (title, tasks, icon, color) => {
    // Get the appropriate icon component
    const getIcon = () => {
      switch (icon) {
        case "clock":
          return <Clock size={18} className="text-gray-500" />
        case "circle-dot":
          return <CircleDot size={18} className="text-blue-500" />
        case "check-circle":
          return <CheckCircle size={18} className="text-green-500" />
        default:
          return <Clock size={18} className="text-gray-500" />
      }
    }

    // Get the appropriate color classes
    const getColorClasses = () => {
      switch (color) {
        case "gray":
          return "bg-gray-50 border-gray-200"
        case "blue":
          return "bg-blue-50 border-blue-200"
        case "green":
          return "bg-green-50 border-green-200"
        default:
          return "bg-gray-50 border-gray-200"
      }
    }

    return (
      <div className={`rounded-lg border ${getColorClasses()} p-4 h-full`}>
        <div className="flex items-center gap-2 mb-4">
          {getIcon()}
          <h3 className="font-medium text-lg">{title}</h3>
          <span className="ml-auto bg-white text-xs font-medium px-2 py-0.5 rounded-full">{tasks.length}</span>
        </div>

        <div className="space-y-3 max-h-[calc(100vh-250px)] overflow-y-auto pr-1">
          {tasks.length === 0 ? (
            <div className="text-center py-8 text-sm text-gray-500">No tasks</div>
          ) : (
            <AnimatePresence>{tasks.map((task) => renderTaskCard(task))}</AnimatePresence>
          )}
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="p-6 flex justify-center">
        <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="inline-flex items-center gap-2 text-red-600 mb-2">
          <AlertCircle size={20} />
          <span className="font-medium">Error</span>
        </div>
        <p className="text-gray-600">{error}</p>
      </div>
    )
  }

  if (subTasks.length === 0) {
    return (
      <div className="p-6 text-center">
        <p className="text-gray-500">You don't have any assigned sub-tasks yet.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      {renderStatusColumn("To Do", todoTasks, "clock", "gray")}
      {renderStatusColumn("In Progress", inProgressTasks, "circle-dot", "blue")}
      {renderStatusColumn("Completed", completedTasks, "check-circle", "green")}
      {/* Description Modal */}
      <TaskDescriptionModal
        isOpen={showDescriptionModal}
        onClose={() => setShowDescriptionModal(false)}
        task={selectedTask}
        students={[]} // We'll pass an empty array since we don't have students here
        groupId={groupId}
        onUpdate={(updatedTask) => {
          // Update the task in the local state
          setSubTasks((prev) => prev.map((task) => (task.sub_task_id === updatedTask.sub_task_id ? updatedTask : task)))
        }}
        currentUser={user}
      />
    </div>
  )
}
