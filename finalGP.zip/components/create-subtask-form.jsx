"use client"

import { useState, useEffect } from "react"
import { createSubTask } from "@/utils/supabase/subtask-service"
import { getGroupStudents, getGroupTasks } from "@/utils/supabase/user-service"
import { motion, AnimatePresence } from "framer-motion"
import { X, Calendar, AlertCircle } from "lucide-react"

export function CreateSubTaskForm({ groupId, onClose, onSuccess, preselectedTask = null }) {
  const [students, setStudents] = useState([])
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    student_id: "",
    main_task: "",
    subTaskName: "",
    priority: "Medium",
    deadline: "",
    description: "",
  })

  useEffect(() => {
    async function fetchData() {
      setLoading(true)
      setError(null)

      try {
        // Fetch students in the group
        const { students, error: studentsError } = await getGroupStudents(groupId)
        if (studentsError) {
          throw new Error(`Failed to fetch students: ${studentsError}`)
        }
        setStudents(students)

        // Fetch tasks for the group
        const { tasks, error: tasksError } = await getGroupTasks(groupId)
        if (tasksError) {
          throw new Error(`Failed to fetch tasks: ${tasksError}`)
        }
        setTasks(tasks)

        // If a task is preselected, initialize the form with its data
        if (preselectedTask) {
          // Format the date for the datetime-local input if available
          let formattedDeadline = ""
          if (preselectedTask.deadline) {
            try {
              const date = new Date(preselectedTask.deadline)
              formattedDeadline = date.toISOString().slice(0, 16) // Format as YYYY-MM-DDTHH:MM
            } catch (error) {
              console.error("Error formatting date:", error)
            }
          }

          setFormData({
            student_id: "",
            main_task: preselectedTask.taskid,
            subTaskName: preselectedTask.taskname || "",
            priority: preselectedTask.priority || "Medium",
            deadline: formattedDeadline,
            description: preselectedTask.taskdescription || "",
          })
        }
      } catch (err) {
        console.error("Error fetching form data:", err)
        setError(err.message || "Failed to load form data")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [groupId, preselectedTask])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    setError(null)
    setSuccess(false)

    try {
      // Validate form
      if (!formData.student_id || !formData.main_task || !formData.subTaskName) {
        throw new Error("Please fill in all required fields")
      }

      // Create sub-task
      const { subTask, error: createError } = await createSubTask(formData)

      if (createError) {
        throw new Error(`Failed to create sub-task: ${createError}`)
      }

      setSuccess(true)
      setFormData({
        student_id: "",
        main_task: "",
        subTaskName: "",
        priority: "Medium",
        deadline: "",
        description: "",
      })

      // Notify parent component
      if (onSuccess) {
        onSuccess(subTask)
      }

      // Close form after a delay
      setTimeout(() => {
        if (onClose) onClose()
      }, 2000)
    } catch (err) {
      console.error("Error creating sub-task:", err)
      setError(err.message || "Failed to create sub-task")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.div
        className="bg-white rounded-lg shadow-lg w-full max-w-md overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
      >
        <div className="flex justify-between items-center border-b border-gray-200 p-4">
          <h3 className="font-semibold text-lg">{preselectedTask ? "Assign Task to Member" : "Assign Sub-Task"}</h3>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100 transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-4">
          {loading ? (
            <div className="py-8 text-center">
              <div className="inline-block w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
              <p className="mt-2 text-gray-500">Loading form data...</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <AnimatePresence>
                {error && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-start gap-2"
                  >
                    <AlertCircle size={18} className="mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </motion.div>
                )}

                {success && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-4 p-3 bg-green-50 text-green-800 rounded-md"
                  >
                    Sub-task assigned successfully!
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="mb-4">
                <label htmlFor="student_id" className="block font-medium mb-1 text-gray-700">
                  Assign To <span className="text-red-500">*</span>
                </label>
                <select
                  id="student_id"
                  name="student_id"
                  value={formData.student_id}
                  onChange={handleChange}
                  required
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                >
                  <option value="">Select a student</option>
                  {students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label htmlFor="main_task" className="block font-medium mb-1 text-gray-700">
                  Related To <span className="text-red-500">*</span>
                </label>
                <select
                  id="main_task"
                  name="main_task"
                  value={formData.main_task}
                  onChange={handleChange}
                  required
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting || preselectedTask}
                >
                  <option value="">Select a task</option>
                  {tasks.map((task) => (
                    <option key={task.taskid} value={task.taskid}>
                      {task.taskname}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label htmlFor="subTaskName" className="block font-medium mb-1 text-gray-700">
                  Sub-Task Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="subTaskName"
                  name="subTaskName"
                  value={formData.subTaskName}
                  onChange={handleChange}
                  required
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                  placeholder="Enter sub-task name"
                />
              </div>

              <div className="mb-4">
                <label htmlFor="priority" className="block font-medium mb-1 text-gray-700">
                  Priority
                </label>
                <select
                  id="priority"
                  name="priority"
                  value={formData.priority}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div className="mb-4">
                <label htmlFor="deadline" className="block font-medium mb-1 text-gray-700">
                  Deadline
                </label>
                <div className="relative">
                  <input
                    type="datetime-local"
                    id="deadline"
                    name="deadline"
                    value={formData.deadline}
                    onChange={handleChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 pl-10"
                    disabled={submitting}
                  />
                  <Calendar size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                </div>
              </div>

              <div className="mb-4">
                <label htmlFor="description" className="block font-medium mb-1 text-gray-700">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={3}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                  placeholder="Enter sub-task description"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                  disabled={submitting}
                >
                  {submitting ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Assigning...
                    </span>
                  ) : (
                    "Assign Sub-Task"
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}
