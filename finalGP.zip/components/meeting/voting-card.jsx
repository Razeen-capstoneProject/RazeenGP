"use client"

import { useState, useEffect } from "react"
import { VotingGroup } from "./voting-group"
import { castVote, removeVote } from "@/utils/supabase/voting-service"
import { motion, AnimatePresence } from "framer-motion"
import { AlertCircle, CheckCircle, Info } from "lucide-react"

export function VotingCard({ votingGroups, studentId, studentVotes, onVoteChange }) {
  const [selectedOptions, setSelectedOptions] = useState([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [message, setMessage] = useState({ type: null, text: "" })
  const [pendingChanges, setPendingChanges] = useState({})

  // Initialize selected options based on student's existing votes
  useEffect(() => {
    if (studentVotes && studentVotes.length > 0) {
      const votedOptions = studentVotes.map((vote) => ({
        vote_id: vote.vote_id,
        suggestion_time: vote.suggestion_time,
      }))
      setSelectedOptions(votedOptions)
    } else {
      setSelectedOptions([])
    }
  }, [studentVotes])

  // Set up periodic checking for expired options
  useEffect(() => {
    // Check for expired options every minute
    const checkInterval = setInterval(() => {
      // This will trigger a re-render and the parent component
      // should re-fetch voting options, filtering out expired ones
      if (onVoteChange) {
        onVoteChange()
      }
    }, 60000) // 1 minute

    return () => clearInterval(checkInterval)
  }, [onVoteChange])

  const handleOptionSelect = (option) => {
    setSelectedOptions((prev) => {
      // Check if this option is already selected
      const isSelected = prev.some(
        (selected) => selected.vote_id === option.vote_id && selected.suggestion_time === option.suggestion_time,
      )

      // If already selected, remove it
      if (isSelected) {
        // Track this change
        setPendingChanges((changes) => ({
          ...changes,
          [`${option.vote_id}-${option.suggestion_time}`]: {
            action: "remove",
            option,
          },
        }))

        return prev.filter(
          (selected) => !(selected.vote_id === option.vote_id && selected.suggestion_time === option.suggestion_time),
        )
      }

      // Otherwise add it
      // Track this change
      setPendingChanges((changes) => ({
        ...changes,
        [`${option.vote_id}-${option.suggestion_time}`]: {
          action: "add",
          option,
        },
      }))

      return [
        ...prev,
        {
          vote_id: option.vote_id,
          suggestion_time: option.suggestion_time,
        },
      ]
    })
  }

  const handleSubmitVote = async () => {
    if (!studentId) {
      setMessage({ type: "error", text: "You must be logged in to vote" })
      return
    }

    if (Object.keys(pendingChanges).length === 0) {
      setMessage({ type: "info", text: "No changes to update" })
      return
    }

    setIsSubmitting(true)
    setMessage({ type: null, text: "" })

    try {
      // Process all pending changes
      for (const key in pendingChanges) {
        const change = pendingChanges[key]
        const { option, action } = change

        if (action === "add") {
          const { success, error } = await castVote(studentId, option.vote_id, option.suggestion_time)
          if (!success) {
            throw new Error(error || "Failed to add vote")
          }
        } else if (action === "remove") {
          const { success, error } = await removeVote(studentId, option.vote_id, option.suggestion_time)
          if (!success) {
            throw new Error(error || "Failed to remove vote")
          }
        }
      }

      setMessage({
        type: "success",
        text: "Your votes have been updated successfully",
      })

      // Clear pending changes
      setPendingChanges({})

      // Notify parent component that votes have changed
      if (onVoteChange) {
        onVoteChange()
      }
    } catch (error) {
      console.error("Error submitting votes:", error)
      setMessage({
        type: "error",
        text: error.message || "Failed to update votes. Please try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
      <h3 className="text-xl font-semibold mb-4">Meeting Time Voting</h3>

      <div className="mb-6"></div>

      {votingGroups.length === 0 ? (
        <div className="p-4 bg-gray-50 rounded-lg text-center">
          <p className="text-gray-500">No meeting time options available for voting.</p>
        </div>
      ) : (
        <>
          <div className="mb-4">
            {votingGroups.map((group) => (
              <VotingGroup
                key={`group-${group.vote_id}`}
                group={group}
                selectedOptions={selectedOptions}
                onOptionSelect={handleOptionSelect}
              />
            ))}
          </div>

          {Object.keys(pendingChanges).length > 0 && (
            <div className="flex justify-end mt-4">
              <button
                onClick={handleSubmitVote}
                disabled={isSubmitting}
                className="px-4 py-2 rounded-md text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400"
              >
                {isSubmitting ? "Updating..." : "Update Votes"}
              </button>
            </div>
          )}

          <AnimatePresence>
            {message.type && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`mt-4 p-3 rounded-md flex items-start gap-2 ${
                  message.type === "error"
                    ? "bg-red-50 text-red-700"
                    : message.type === "info"
                      ? "bg-blue-50 text-blue-700"
                      : "bg-green-50 text-green-700"
                }`}
              >
                {message.type === "error" ? (
                  <AlertCircle size={18} className="flex-shrink-0 mt-0.5" />
                ) : message.type === "info" ? (
                  <Info size={18} className="flex-shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle size={18} className="flex-shrink-0 mt-0.5" />
                )}
                <p>{message.text}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </div>
  )
}
