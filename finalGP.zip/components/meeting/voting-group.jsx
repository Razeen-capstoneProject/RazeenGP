"use client"

import { useState } from "react"
import { VotingOption } from "./voting-option"
import { formatDeadline } from "@/utils/supabase/voting-service"
import { Clock } from "lucide-react"

export function VotingGroup({ group, selectedOptions, onOptionSelect }) {
  const [expanded, setExpanded] = useState(true)

  // Get the first option to extract vote_id, deadline, and vote_title
  const firstOption = group.options[0]
  const voteId = firstOption?.vote_id
  const deadline = firstOption?.deadline
  const voteTitle = firstOption?.vote_title || `Vote #${voteId}`

  // Helper function to check if an option is selected
  const isOptionSelected = (option) => {
    return selectedOptions.some(
      (selected) => selected.vote_id === option.vote_id && selected.suggestion_time === option.suggestion_time,
    )
  }

  // Helper function to generate a unique key for each option
  const getOptionKey = (option) => {
    return `vote-${option.vote_id}-${new Date(option.suggestion_time).getTime()}`
  }

  return (
    <div className="mb-6 border border-gray-200 rounded-lg overflow-hidden">
      <div
        className="bg-gray-50 p-4 flex justify-between items-center cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div>
          <h4 className="font-medium text-lg">{voteTitle}</h4>
          <div className="flex items-center text-sm text-gray-500 mt-1">
            <Clock size={14} className="mr-1" />
            <span>{formatDeadline(deadline)}</span>
          </div>
        </div>
        <button className="text-gray-500 hover:text-gray-700">{expanded ? "Hide Options" : "Show Options"}</button>
      </div>

      {expanded && (
        <div className="p-4">
          <p className="text-sm text-gray-500 mb-3"></p>
          {group.options.map((option) => (
            <VotingOption
              key={getOptionKey(option)}
              option={option}
              isSelected={isOptionSelected(option)}
              onSelect={() => onOptionSelect(option)}
              voteCount={option.num_voters || 0}
            />
          ))}
        </div>
      )}
    </div>
  )
}
