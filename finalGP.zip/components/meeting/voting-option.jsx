"use client"

import { useState, useEffect } from "react"
import { formatMeetingDate } from "@/utils/supabase/voting-service"
import { Check, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { supabase } from "@/utils/supabase/client"

// Update the VotingOption component to use end_time
export function VotingOption({ option, isSelected, onSelect, voteCount }) {
  const [open, setOpen] = useState(false)
  const [voters, setVoters] = useState([])
  const [loadingVoters, setLoadingVoters] = useState(false)

  useEffect(() => {
    async function fetchVoters() {
      setLoadingVoters(true)
      try {
        const { data, error } = await supabase
          .from("student_voting")
          .select(
            `
            student_id,
            student_masked (
              users (
                userName
              )
            )
          `,
          )
          .eq("vote_id", option.vote_id)
          .eq("suggestion_time", option.suggestion_time)

        if (error) {
          console.error("Error fetching voters:", error)
          // Handle error appropriately
        } else {
          setVoters(data.map((item) => ({ name: item.student_masked?.users?.userName || "Unknown" })))
        }
      } catch (error) {
        console.error("Error fetching voters:", error)
      } finally {
        setLoadingVoters(false)
      }
    }

    if (open) {
      fetchVoters()
    }
  }, [open, option.vote_id, option.suggestion_time])

  return (
    <>
      <div className="flex items-center justify-between p-3 mb-2 rounded-md border border-gray-200 bg-white hover:bg-gray-50 transition-colors">
        <div className="flex items-center cursor-pointer" onClick={onSelect}>
          <div
            className={`w-5 h-5 rounded flex items-center justify-center mr-3 ${
              isSelected ? "bg-blue-500" : "border border-gray-300"
            }`}
          >
            {isSelected && <Check size={14} className="text-white" />}
          </div>
          <span className="font-medium">{formatMeetingDate(option.suggestion_time, option.end_time)}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">
            <span className="font-medium">{voteCount}</span> {voteCount === 1 ? "vote" : "votes"}
          </span>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm">
                <Users className="h-4 w-4 mr-2" />
                View Participants
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Voters</DialogTitle>
                <DialogDescription>
                  Here are the students who voted for {formatMeetingDate(option.suggestion_time, option.end_time)}.
                </DialogDescription>
              </DialogHeader>
              {loadingVoters ? (
                <p>Loading...</p>
              ) : (
                <div className="grid gap-4 py-4">
                  {voters.length === 0 ? (
                    <p>No voters yet.</p>
                  ) : (
                    voters.map((voter) => (
                      <div key={voter.name} className="border p-4 rounded-md">
                        {voter.name}
                      </div>
                    ))
                  )}
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </>
  )
}
