"use client"

import { useState, useEffect } from "react"
import { CalendarIcon, ExternalLink } from "lucide-react"
import { formatMeetingDate } from "@/utils/supabase/voting-service"
import { supabase } from "@/utils/supabase/client"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"

export function ScheduledMeetings({ groupId }) {
  const [meetings, setMeetings] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [calendarView, setCalendarView] = useState(false)
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [meetingsForSelectedDate, setMeetingsForSelectedDate] = useState([])

  useEffect(() => {
    async function fetchMeetings() {
      if (!groupId) return

      setLoading(true)
      setError(null)

      try {
        const { data, error } = await supabase
          .from("meeting")
          .select("*")
          .eq("groupid", groupId)
          .order("scheduletime", { ascending: true })

        if (error) {
          throw new Error(`Failed to fetch meetings: ${error.message}`)
        }

        setMeetings(data || [])
      } catch (err) {
        console.error("Error fetching meetings:", err)
        setError(err.message || "Failed to load scheduled meetings")
      } finally {
        setLoading(false)
      }
    }

    fetchMeetings()
  }, [groupId])

  const filterMeetingsForDate = (date) => {
    if (!date) return []

    return meetings.filter((meeting) => {
      const meetingDate = new Date(meeting.scheduletime)
      return (
        meetingDate.getDate() === date.getDate() &&
        meetingDate.getMonth() === date.getMonth() &&
        meetingDate.getFullYear() === date.getFullYear()
      )
    })
  }

  useEffect(() => {
    if (selectedDate) {
      setMeetingsForSelectedDate(filterMeetingsForDate(selectedDate))
    }
  }, [selectedDate, meetings])

  const toggleCalendarView = () => {
    setCalendarView(!calendarView)
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold flex items-center gap-2">
          <CalendarIcon className="text-blue-600" />
          <span>Scheduled Meetings</span>
        </h3>
        <Button variant="ghost" size="icon" onClick={toggleCalendarView}>
          <CalendarIcon className="h-4 w-4" />
          <span className="sr-only">Toggle Calendar</span>
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-32">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : error ? (
        <div className="p-4 bg-red-50 text-red-800 rounded-lg">
          <p>Error: {error}</p>
        </div>
      ) : meetings.length === 0 ? (
        <div className="p-4 text-gray-500">No meetings scheduled yet.</div>
      ) : (
        <>
          {calendarView ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border rounded-md p-2">
                <h4 className="text-sm font-medium mb-2 text-gray-700">Select Date</h4>
                <Calendar
                  className="rounded-md"
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                />
              </div>
              <div className="border rounded-md p-2">
                <h4 className="text-sm font-medium mb-2 text-gray-700">Meetings for {selectedDate.toDateString()}</h4>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {meetingsForSelectedDate.length > 0 ? (
                    meetingsForSelectedDate.map((meeting) => (
                      <div key={meeting.meetingid} className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                        <h5 className="font-medium text-gray-800">{meeting.meeting_title}</h5>
                        <div className="text-sm text-gray-600 flex items-center gap-1 mt-1">
                          <CalendarIcon size={14} />
                          <span>
                            {new Date(meeting.scheduletime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        </div>
                        {meeting.meeting_description && (
                          <p className="mt-1 text-xs text-gray-600">{meeting.meeting_description}</p>
                        )}
                        {meeting.meeting_link && meeting.meeting_link !== "EMPTY" && (
                          <div className="mt-1">
                            <a
                              href={meeting.meeting_link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-800 text-xs inline-flex items-center"
                            >
                              <ExternalLink size={12} className="mr-1" />
                              Join
                            </a>
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-4 text-gray-500">No meetings scheduled for this date</div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <ul className="space-y-4">
              {meetings.map((meeting) => (
                <li key={meeting.meetingid} className="p-4 border border-gray-200 rounded-md">
                  <h4 className="font-medium text-gray-800">{meeting.meeting_title}</h4>
                  <div className="text-sm text-gray-600 mt-1">
                    <CalendarIcon size={16} className="inline-block mr-1" />
                    {formatMeetingDate(meeting.scheduletime)}
                  </div>
                  {meeting.meeting_description && (
                    <p className="mt-2 text-sm text-gray-600">{meeting.meeting_description}</p>
                  )}
                  {meeting.meeting_link && meeting.meeting_link !== "EMPTY" && (
                    <div className="mt-2">
                      <a
                        href={meeting.meeting_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 text-sm inline-flex items-center"
                      >
                        <ExternalLink size={14} className="mr-1" />
                        Join Meeting
                      </a>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </div>
  )
}
