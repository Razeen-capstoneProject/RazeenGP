"use client"

import { MessageSquare, Users } from "lucide-react"
import { motion } from "framer-motion"

export function ChatSelector({ onSelectChat, selectedChatType, hasStudentChat, hasInstructorChat }) {
  return (
    <div className="flex border-b border-gray-200 relative">
      <button
        onClick={() => onSelectChat("student")}
        disabled={!hasStudentChat}
        className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 relative transition-all duration-200 ${
          !hasStudentChat
            ? "text-gray-300 cursor-not-allowed"
            : selectedChatType === "student"
              ? "text-blue-600 font-medium"
              : "text-gray-500 hover:text-gray-700 hover:bg-gray-50"
        }`}
      >
        <MessageSquare size={18} className={selectedChatType === "student" ? "text-blue-600" : ""} />
        <span>Student Chat</span>

        {selectedChatType === "student" && hasStudentChat && (
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600"
            layoutId="activeTab"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          />
        )}
      </button>

      <button
        onClick={() => onSelectChat("supervisor")}
        disabled={!hasInstructorChat}
        className={`flex-1 py-3 px-4 flex items-center justify-center gap-2 relative transition-all duration-200 ${
          !hasInstructorChat
            ? "text-gray-300 cursor-not-allowed"
            : selectedChatType === "supervisor"
              ? "text-blue-600 font-medium"
              : "text-gray-500 hover:text-gray-700 hover:bg-gray-50"
        }`}
      >
        <Users size={18} className={selectedChatType === "supervisor" ? "text-blue-600" : ""} />
        <span>Instructor Chat</span>

        {selectedChatType === "supervisor" && hasInstructorChat && (
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600"
            layoutId="activeTab"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          />
        )}
      </button>
    </div>
  )
}
