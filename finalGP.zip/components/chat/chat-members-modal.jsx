"use client"

import { X, GraduationCap, User } from "lucide-react"

export function ChatMembersModal({ isOpen, onClose, members, isLoading }) {
  if (!isOpen) return null

  // Separate instructors and students
  const instructors = members.filter((member) => member.role === "instructor")
  const students = members.filter((member) => member.role !== "instructor")

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center border-b border-gray-200 p-4">
          <h3 className="font-semibold text-lg">Chat Members</h3>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100">
            <X size={20} />
          </button>
        </div>
        <div className="p-4 max-h-96 overflow-y-auto">
          {isLoading ? (
            <p className="text-gray-500 text-center">Loading members...</p>
          ) : members.length === 0 ? (
            <p className="text-gray-500 text-center">No members found</p>
          ) : (
            <div className="space-y-6">
              {/* Instructors Section */}
              {instructors.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-700 mb-3 flex items-center gap-2">
                    <GraduationCap size={18} className="text-purple-600" />
                    Instructors
                  </h4>
                  <ul className="space-y-2">
                    {instructors.map((instructor) => (
                      <li
                        key={instructor.user_id}
                        className="flex items-center p-3 bg-purple-50 rounded-lg border border-purple-100"
                      >
                        <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                          <span className="text-purple-600 font-semibold">
                            {instructor.userName?.[0]?.toUpperCase() || instructor.email?.[0]?.toUpperCase() || "I"}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{instructor.userName || "Instructor"}</p>
                          <p className="text-xs text-gray-500">{instructor.email}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Students Section */}
              <div>
                <h4 className="font-medium text-gray-700 mb-3 flex items-center gap-2">
                  <User size={18} className="text-blue-600" />
                  Students
                </h4>
                <ul className="space-y-2">
                  {students.map((student) => (
                    <li key={student.user_id} className="flex items-center p-3 bg-gray-50 rounded-lg">
                      <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                        <span className="text-gray-600 font-semibold">
                          {student.userName?.[0]?.toUpperCase() || student.email?.[0]?.toUpperCase() || "S"}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium">{student.userName || "Unknown Student"}</p>
                        <p className="text-xs text-gray-500">{student.email}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
