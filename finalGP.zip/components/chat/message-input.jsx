"use client"

import { useState, useRef } from "react"
import { Paperclip, Send, X, File } from "lucide-react"
import { motion } from "framer-motion"
import { supabase } from "@/utils/supabase/client"

export function MessageInput({ onSendMessage, disabled, groupId }) {
  const [message, setMessage] = useState("")
  const [attachedFiles, setAttachedFiles] = useState([])
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadError, setUploadError] = useState(null)
  const fileInputRef = useRef(null)

  const handleSendMessage = async (e) => {
    e.preventDefault()

    if ((!message.trim() && attachedFiles.length === 0) || disabled || isUploading) return

    try {
      setIsUploading(true)
      setUploadProgress(0)
      const uploadedFiles = []

      // If there are files, upload them first
      if (attachedFiles.length > 0) {
        for (let i = 0; i < attachedFiles.length; i++) {
          const file = attachedFiles[i]
          const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 15)}_${file.name}`
          const filePath = `group_${groupId}/${fileName}`

          // Upload the file to Supabase Storage
          const { data, error } = await supabase.storage.from("chat-attachments").upload(filePath, file, {
            cacheControl: "3600",
            upsert: false,
            onUploadProgress: (progress) => {
              const percent = Math.round((progress.loaded / progress.total) * 100)
              setUploadProgress(percent)
            },
          })

          if (error) {
            console.error("Error uploading file:", error)
            setUploadError(`Failed to upload ${file.name}: ${error.message}`)
            throw error
          }

          // Get the public URL
          const { data: urlData } = supabase.storage.from("chat-attachments").getPublicUrl(filePath)

          // Create file metadata object
          const fileData = {
            name: file.name,
            size: file.size,
            type: file.type,
            path: filePath,
            url: urlData.publicUrl,
            bucket: "chat-attachments",
          }

          uploadedFiles.push(fileData)
          console.log("File uploaded successfully:", fileData)
        }
      }

      // Prepare message content
      const messageContent = {
        text: message.trim() || "", // Use empty string if no text
        files: uploadedFiles,
      }

      // For backward compatibility
      if (uploadedFiles.length > 0) {
        messageContent.file = uploadedFiles[0]
      }

      // Send the message
      await onSendMessage(messageContent)

      // Reset form
      setMessage("")
      setAttachedFiles([])
      setUploadProgress(0)
      setUploadError(null)
    } catch (error) {
      console.error("Error sending message:", error)
      if (!uploadError) {
        setUploadError(`Error sending message: ${error.message}`)
      }
    } finally {
      setIsUploading(false)
    }
  }

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files)
    if (files.length === 0) return

    // Check file size for each file (max 10MB)
    const validFiles = files.filter((file) => {
      if (file.size > 10 * 1024 * 1024) {
        setUploadError(`File ${file.name} is too large. Maximum size is 10MB.`)
        return false
      }
      return true
    })

    setAttachedFiles((prev) => [...prev, ...validFiles])
    setUploadError(null)

    // Reset the file input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleRemoveFile = (index) => {
    setAttachedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  return (
    <form onSubmit={handleSendMessage} className="border-t border-gray-200 p-4">
      {uploadError && <div className="mb-2 px-3 py-2 bg-red-50 text-red-600 text-sm rounded">{uploadError}</div>}

      {/* Display attached files */}
      {attachedFiles.length > 0 && (
        <div className="mb-3">
          <div className="text-xs text-gray-500 mb-1">Attached files:</div>
          <div className="flex flex-wrap gap-2">
            {attachedFiles.map((file, index) => (
              <div key={index} className="flex items-center bg-gray-100 rounded px-2 py-1 text-sm">
                <File className="w-3 h-3 mr-1 text-gray-500" />
                <span className="truncate max-w-[150px]">{file.name}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveFile(index)}
                  className="ml-1 text-gray-500 hover:text-red-500"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {isUploading && uploadProgress > 0 && uploadProgress < 100 && (
        <div className="mb-2">
          <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500 transition-all duration-300"
              style={{ width: `${uploadProgress}%` }}
            ></div>
          </div>
          <div className="text-xs text-gray-500 mt-1 text-right">{uploadProgress}% uploading...</div>
        </div>
      )}

      <div className="flex items-center gap-2">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          id="file-upload"
          multiple
          accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
        />
        <label
          htmlFor="file-upload"
          className={`p-2 rounded-full hover:bg-gray-100 cursor-pointer ${
            disabled ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <Paperclip size={20} className="text-gray-500" />
        </label>

        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 py-2 px-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={disabled || isUploading}
        />

        <motion.button
          type="submit"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`p-2 bg-blue-500 text-white rounded-full ${
            (!message.trim() && attachedFiles.length === 0) || disabled || isUploading
              ? "opacity-50 cursor-not-allowed"
              : "hover:bg-blue-600"
          }`}
          disabled={(!message.trim() && attachedFiles.length === 0) || disabled || isUploading}
        >
          <Send size={20} />
        </motion.button>
      </div>
    </form>
  )
}
