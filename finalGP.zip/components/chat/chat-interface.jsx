"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { getCurrentUserGroup } from "@/utils/supabase/queries"
import {
  getChatMessages,
  sendMessage,
  getChatUsers,
  getGroupInstructor,
  getGroupChatChannels,
  subscribeToChat,
} from "@/utils/supabase/chat-service"
import { MessageList } from "./message-list"
import { MessageInput } from "./message-input"
import { ChatHeader } from "./chat-header"
import { ChatSelector } from "./chat-selector"
import { ChatMembersModal } from "./chat-members-modal"
import { ChatSearch } from "./chat-search"

export function ChatInterface() {
  const { user } = useAuth()
  const [groupId, setGroupId] = useState(null)
  const [studentChatId, setStudentChatId] = useState(null)
  const [supervisorChatId, setSupervisorChatId] = useState(null)
  const [selectedChatType, setSelectedChatType] = useState("student")
  const [messages, setMessages] = useState([])
  const [chatMembers, setChatMembers] = useState([])
  const [instructor, setInstructor] = useState(null)
  const [showMembersModal, setShowMembersModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [loadingMembers, setLoadingMembers] = useState(false)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredMessages, setFilteredMessages] = useState([])
  const [isSearchActive, setIsSearchActive] = useState(false)

  const activeChatId = selectedChatType === "student" ? studentChatId : supervisorChatId
  const chatName = selectedChatType === "student" ? "Student Group Chat" : "Instructor & Students Chat"

  // Get user's group and available chats
  useEffect(() => {
    async function fetchGroupAndChats() {
      if (!user?.user_id) return

      try {
        setLoading(true)
        setError(null)

        // Get user's group
        const { groupId: userGroupId, error: groupError } = await getCurrentUserGroup(user.user_id)

        if (groupError || !userGroupId) {
          setError("Failed to get your group information")
          setLoading(false)
          return
        }

        setGroupId(userGroupId)

        // Get instructor information for the group
        const { instructor: groupInstructor } = await getGroupInstructor(userGroupId)
        setInstructor(groupInstructor)

        // Get the chat channels for this group
        const {
          studentChatId: studentChat,
          supervisorChatId: supervisorChat,
          error: chatError,
        } = await getGroupChatChannels(userGroupId)

        if (chatError) {
          setError("Failed to get chat information")
          setLoading(false)
          return
        }

        if (!studentChat && !supervisorChat) {
          setError("No chat channels found for your group")
          setLoading(false)
          return
        }

        setStudentChatId(studentChat)
        setSupervisorChatId(supervisorChat)

        // Default to student chat if available, otherwise use supervisor chat
        if (studentChat) {
          setSelectedChatType("student")
        } else if (supervisorChat) {
          setSelectedChatType("supervisor")
        }
      } catch (err) {
        console.error("Error setting up chats:", err)
        setError("An unexpected error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchGroupAndChats()
  }, [user])

  // Load messages when chat changes
  useEffect(() => {
    async function fetchMessages() {
      if (!activeChatId) return

      try {
        setLoading(true)

        const { messages: chatMessages, error: messagesError } = await getChatMessages(activeChatId)

        if (messagesError) {
          console.error("Error fetching messages:", messagesError)
          return
        }

        // Process messages to handle "see attachment" text
        const processedMessages = chatMessages.map((message) => {
          // If the message text is "see" or "see attachment" and has files, clear the text
          if (
            message.content &&
            (message.content.text === "see" || message.content.text === "see attachment") &&
            ((message.content.file && message.content.file !== null) ||
              (message.content.files && message.content.files.length > 0))
          ) {
            return {
              ...message,
              content: {
                ...message.content,
                text: "", // Clear the "see attachment" text
              },
            }
          }
          return message
        })

        setMessages(processedMessages)
      } catch (err) {
        console.error("Error fetching messages:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchMessages()
  }, [activeChatId])

  // Subscribe to new messages
  useEffect(() => {
    if (!activeChatId) return

    const subscription = subscribeToChat(activeChatId, (newMessage) => {
      // Fetch the complete message with user info
      getChatMessages(activeChatId).then(({ messages: updatedMessages }) => {
        // Process messages to handle "see attachment" text
        const processedMessages = updatedMessages.map((message) => {
          // If the message text is "see" or "see attachment" and has files, clear the text
          if (
            message.content &&
            (message.content.text === "see" || message.content.text === "see attachment") &&
            ((message.content.file && message.content.file !== null) ||
              (message.content.files && message.content.files.length > 0))
          ) {
            return {
              ...message,
              content: {
                ...message.content,
                text: "", // Clear the "see attachment" text
              },
            }
          }
          return message
        })

        setMessages(processedMessages)
      })
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [activeChatId])

  // Update the handleSendMessage function to work with the new message format
  const handleSendMessage = async (messageContent) => {
    if (!user?.user_id || !activeChatId) return

    try {
      // If this is a file-only message, set text to empty instead of "see attachment"
      if (messageContent.file && (!messageContent.text || messageContent.text.trim() === "")) {
        messageContent.text = ""
      }

      const { message: newMessage, error: sendError } = await sendMessage(activeChatId, user.user_id, messageContent)

      if (sendError) {
        console.error("Error sending message:", sendError)
        return
      }

      // The message will be added via the subscription
    } catch (err) {
      console.error("Error sending message:", err)
    }
  }

  const handleSelectChat = (chatType) => {
    // Only allow switching if the chat exists
    if (chatType === "student" && studentChatId) {
      setSelectedChatType("student")
    } else if (chatType === "supervisor" && supervisorChatId) {
      setSelectedChatType("supervisor")
    }
  }

  const handleShowMembers = async () => {
    if (!activeChatId) return

    try {
      setLoadingMembers(true)
      setShowMembersModal(true)

      console.log(`Fetching members for chat: ${activeChatId} (${selectedChatType} chat)`)
      const { users, error } = await getChatUsers(activeChatId)

      if (error) {
        console.error("Error fetching chat members:", error)
        return
      }

      console.log(`Retrieved ${users.length} members:`, users)
      setChatMembers(users)
    } catch (err) {
      console.error("Error fetching chat members:", err)
    } finally {
      setLoadingMembers(false)
    }
  }

  const handleSearch = (query) => {
    setSearchQuery(query)

    if (!query.trim()) {
      setIsSearchActive(false)
      setFilteredMessages([])
      return
    }

    setIsSearchActive(true)

    // Filter messages based on the search query
    const filtered = messages.filter((message) => {
      // Check if the message content exists and has text property
      if (!message.content || typeof message.content !== "object") return false

      const messageText = message.content.text || ""
      const senderName = message.content.senderName || ""

      // Search in message text and sender name
      return (
        messageText.toLowerCase().includes(query.toLowerCase()) ||
        senderName.toLowerCase().includes(query.toLowerCase())
      )
    })

    setFilteredMessages(filtered)
  }

  if (error) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-red-500">{error}</div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col bg-white rounded-lg shadow-sm border border-gray-200">
      <ChatSelector
        onSelectChat={handleSelectChat}
        selectedChatType={selectedChatType}
        hasStudentChat={!!studentChatId}
        hasInstructorChat={!!supervisorChatId}
      />

      <ChatHeader
        chatName={chatName}
        onShowMembers={handleShowMembers}
        hasInstructor={selectedChatType === "supervisor" && instructor !== null}
      />

      <ChatSearch onSearch={handleSearch} />

      <MessageList
        messages={messages}
        currentUser={user}
        loading={loading}
        filteredMessages={filteredMessages}
        isSearchActive={isSearchActive}
      />

      <MessageInput onSendMessage={handleSendMessage} disabled={!activeChatId || loading} groupId={groupId} />

      <ChatMembersModal
        isOpen={showMembersModal}
        onClose={() => setShowMembersModal(false)}
        members={chatMembers}
        isLoading={loadingMembers}
      />
    </div>
  )
}
