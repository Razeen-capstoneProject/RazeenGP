"use client"

import { formatDistanceToNow } from "date-fns"
import { useState, useEffect } from "react"
import { Download, AlertCircle, FileText, File, ImageIcon, Film, Music } from "lucide-react"
import { getFileUrl } from "@/utils/supabase/chat-service"
import { motion } from "framer-motion"

export function MessageItem({ message, currentUser }) {
  const [fileUrls, setFileUrls] = useState({})
  const [fileErrors, setFileErrors] = useState({})
  const [loadingFiles, setLoadingFiles] = useState({})

  const isCurrentUser = message.user_id === currentUser?.user_id
  const isInstructor = message.users?.role === "instructor"
  const userName = message.users?.userName || message.content?.senderName || "Unknown User"
  const formattedTime = message.messagetime
    ? formatDistanceToNow(new Date(message.messagetime), { addSuffix: true })
    : ""

  // Get the message text from the content
  let messageText = message.content?.text || message.content?.content || ""

  // Special handling for "see attachment" messages
  const isSeeAttachmentMessage = messageText === "see" || messageText === "see attachment"
  if (isSeeAttachmentMessage) {
    messageText = "" // Don't display "see attachment" text
  }

  // Check if the message has file attachments (support both single file and multiple files)
  const hasLegacyFile = message.content?.file && message.content.file !== null
  const hasFiles = message.content?.files && Array.isArray(message.content.files) && message.content.files.length > 0

  // Combine legacy file format with new format for backward compatibility
  const files = hasFiles ? message.content.files : hasLegacyFile ? [message.content.file] : []

  useEffect(() => {
    // If message has files, get the public URLs
    if (files.length > 0) {
      files.forEach((file) => {
        const fetchFileUrl = async () => {
          // Skip if file doesn't have necessary properties
          if (!file) {
            console.log("Invalid file object:", file)
            return
          }

          // Handle string file objects (common in instructor-student chats)
          let fileObj = file
          if (typeof file === "string") {
            try {
              fileObj = JSON.parse(file)
              console.log("Parsed file string to object:", fileObj)
            } catch (e) {
              console.error("Error parsing file string:", e)
              // If we can't parse it but it looks like a URL, use it directly
              if (file.startsWith("http")) {
                setFileUrls((prev) => ({ ...prev, [file]: file }))
                return
              }
            }
          }

          // Handle file objects that might be missing properties
          const fileId = fileObj.id || fileObj.path || (typeof fileObj === "string" ? fileObj : JSON.stringify(fileObj))
          const bucket = fileObj.bucket || "chat-attachments" // Default to chat-attachments if not specified
          const filePath = fileObj.path || fileObj.url

          if (!filePath) {
            console.error("No file path or URL found:", fileObj)
            setFileErrors((prev) => ({ ...prev, [fileId]: "Invalid file data" }))
            return
          }

          // If it's already a full URL, use it directly
          if (filePath.startsWith("http")) {
            setFileUrls((prev) => ({ ...prev, [fileId]: filePath }))
            return
          }

          setLoadingFiles((prev) => ({ ...prev, [fileId]: true }))
          setFileErrors((prev) => ({ ...prev, [fileId]: null }))

          try {
            console.log("Fetching file URL for:", {
              bucket,
              path: filePath,
              fileName: fileObj.name,
            })

            // Check if we have all required data
            if (!bucket || !filePath) {
              throw new Error("Missing bucket or file path")
            }

            const url = await getFileUrl(bucket, filePath)

            if (!url) {
              console.error("Failed to get file URL")
              setFileErrors((prev) => ({ ...prev, [fileId]: "Could not retrieve file URL" }))
            } else {
              console.log("File URL retrieved:", url)
              setFileUrls((prev) => ({ ...prev, [fileId]: url }))
            }
          } catch (error) {
            console.error("Error fetching file URL:", error)
            setFileErrors((prev) => ({ ...prev, [fileId]: `Error: ${error.message || "Unknown error"}` }))
          } finally {
            setLoadingFiles((prev) => ({ ...prev, [fileId]: false }))
          }
        }

        fetchFileUrl()
      })
    }
  }, [files])

  // Function to get file size in human-readable format
  const formatFileSize = (bytes) => {
    if (!bytes) return ""
    if (bytes < 1024) return bytes + " B"
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / 1048576).toFixed(1) + " MB"
  }

  // Function to get appropriate icon based on file type
  const getFileIcon = (fileType) => {
    if (!fileType) return <File size={16} />

    if (fileType.startsWith("image/")) return <ImageIcon size={16} />
    if (fileType.startsWith("video/")) return <Film size={16} />
    if (fileType.startsWith("audio/")) return <Music size={16} />
    if (fileType.includes("pdf")) return <FileText size={16} />

    return <File size={16} />
  }

  // Function to get file name from file object or string
  const getFileName = (file) => {
    if (!file) return "Attachment"

    if (typeof file === "string") {
      try {
        const parsed = JSON.parse(file)
        return parsed.name || "Attachment"
      } catch (e) {
        // If it's a URL, extract filename from the end
        if (file.startsWith("http")) {
          const parts = file.split("/")
          return parts[parts.length - 1] || "Attachment"
        }
        return "Attachment"
      }
    }

    return file.name || "Attachment"
  }

  // Function to get file type from file object or string
  const getFileType = (file) => {
    if (!file) return ""

    if (typeof file === "string") {
      try {
        const parsed = JSON.parse(file)
        return parsed.type || ""
      } catch (e) {
        return ""
      }
    }

    return file.type || ""
  }

  // Function to get file size from file object or string
  const getFileSize = (file) => {
    if (!file) return 0

    if (typeof file === "string") {
      try {
        const parsed = JSON.parse(file)
        return parsed.size || 0
      } catch (e) {
        return 0
      }
    }

    return file.size || 0
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex mb-4 ${isCurrentUser ? "justify-end" : "justify-start"}`}
    >
      <motion.div
        whileHover={{ scale: 1.01 }}
        className={`max-w-[75%] rounded-lg px-4 py-2 shadow-sm ${
          isCurrentUser
            ? "bg-blue-500 text-white"
            : isInstructor
              ? "bg-purple-50 border border-purple-100 text-gray-800"
              : "bg-gray-50 border border-gray-100 text-gray-800"
        }`}
      >
        {!isCurrentUser && (
          <div className="font-semibold text-sm mb-1 flex items-center gap-2">
            {userName}
            {isInstructor && (
              <span className="bg-purple-100 text-purple-800 text-xs px-2 py-0.5 rounded-full">Instructor</span>
            )}
          </div>
        )}

        {/* Only show message text if it's not empty and not a "see attachment" message */}
        {messageText && !isSeeAttachmentMessage && <div className="break-words">{messageText}</div>}

        {/* File attachments */}
        {files.length > 0 && (
          <div className="mt-2 space-y-2">
            {files.map((file, index) => {
              // Handle both object and string file formats
              const fileId = typeof file === "object" ? file.id || file.path || index : file
              const isLoading = loadingFiles[fileId]
              const fileError = fileErrors[fileId]
              const fileUrl = fileUrls[fileId]
              const fileName = getFileName(file)
              const fileType = getFileType(file)
              const fileSize = getFileSize(file)

              return (
                <motion.div
                  key={`${fileId}-${index}`}
                  initial={{ opacity: 0.8 }}
                  animate={{ opacity: 1 }}
                  whileHover={{ scale: 1.02 }}
                  className={`p-2 rounded-md flex items-center gap-2 ${
                    isCurrentUser ? "bg-blue-600 bg-opacity-70" : "bg-gray-200 bg-opacity-70"
                  }`}
                >
                  {getFileIcon(fileType)}
                  <span className="text-sm truncate flex-1">
                    {fileName}
                    {fileSize > 0 && <span className="text-xs opacity-70 ml-1">({formatFileSize(fileSize)})</span>}
                  </span>

                  {isLoading && (
                    <motion.div
                      className="w-4 h-4 border-2 border-current border-t-transparent rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                    />
                  )}

                  {fileError && (
                    <div className="flex items-center gap-1 text-xs">
                      <AlertCircle size={14} />
                      <span>{fileError}</span>
                    </div>
                  )}

                  {fileUrl && !isLoading && !fileError && (
                    <motion.a
                      href={fileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      download={fileName}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className={`p-1 rounded-full transition-colors duration-200 ${
                        isCurrentUser ? "hover:bg-blue-700" : "hover:bg-gray-300"
                      }`}
                      onClick={() => console.log("Download clicked for file:", fileName)}
                    >
                      <Download size={16} />
                    </motion.a>
                  )}
                </motion.div>
              )
            })}
          </div>
        )}

        <div className="text-xs mt-1 opacity-70">{formattedTime}</div>
      </motion.div>
    </motion.div>
  )
}
