"use client"

import { Users, GraduationCap } from "lucide-react"
import { motion } from "framer-motion"

export function ChatHeader({ chatName, onShowMembers, hasInstructor }) {
  return (
    <div className="border-b border-gray-200 p-4 flex justify-between items-center bg-white shadow-sm">
      <div className="flex items-center gap-2">
        <h2 className="font-semibold text-lg text-gray-800">{chatName}</h2>
        {hasInstructor && (
          <motion.span
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full flex items-center gap-1"
          >
            <GraduationCap size={14} />
            <span>Instructor Present</span>
          </motion.span>
        )}
      </div>
      <motion.button
        onClick={onShowMembers}
        whileHover={{ scale: 1.1, backgroundColor: "rgba(243, 244, 246, 1)" }}
        whileTap={{ scale: 0.95 }}
        className="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200"
        title="Show chat members"
      >
        <Users size={20} className="text-gray-600" />
      </motion.button>
    </div>
  )
}
