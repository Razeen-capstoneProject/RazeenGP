"use client"

import { useRef, useEffect } from "react"
import { File } from "lucide-react"

export function MessageList({ messages, currentUser, loading, filteredMessages, isSearchActive }) {
  const messagesEndRef = useRef(null)
  const displayMessages = isSearchActive ? filteredMessages : messages

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const formatTime = (timestamp) => {
    try {
      const date = new Date(timestamp)
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } catch (error) {
      return ""
    }
  }

  const formatMessageDate = (timestamp) => {
    try {
      const date = new Date(timestamp)
      const today = new Date()
      const yesterday = new Date(today)
      yesterday.setDate(yesterday.getDate() - 1)

      if (date.toDateString() === today.toDateString()) {
        return "Today"
      } else if (date.toDateString() === yesterday.toDateString()) {
        return "Yesterday"
      } else {
        return date.toLocaleDateString(undefined, {
          weekday: "long",
          month: "short",
          day: "numeric",
        })
      }
    } catch (error) {
      return ""
    }
  }

  const groupMessagesByDate = () => {
    const groups = {}

    displayMessages.forEach((message) => {
      const date = formatMessageDate(message.messagetime)
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(message)
    })

    return groups
  }

  const messageGroups = groupMessagesByDate()

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  if (displayMessages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-4 text-gray-500">
        {isSearchActive ? (
          <p>No messages match your search</p>
        ) : (
          <>
            <p>No messages yet</p>
            <p className="text-sm mt-2">Start the conversation by sending a message</p>
          </>
        )}
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
      {Object.entries(messageGroups).map(([date, dateMessages]) => (
        <div key={date} className="mb-6">
          <div className="flex justify-center mb-4">
            <span className="text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-full">{date}</span>
          </div>

          {dateMessages.map((message) => {
            const isCurrentUser = message.user_id === currentUser?.user_id
            const senderName = message.content?.senderName || message.users?.userName || "Unknown User"
            const messageText = message.content?.text || message.content?.content || ""

            // Handle both single file and multiple files formats
            const fileData = message.content?.file || {
              url: message.content?.fileUrl,
              name: message.content?.fileName,
              type: message.content?.fileType,
            }

            const filesArray = message.content?.files || []
            // If there's a single file but no files array, add it to the array
            const allFiles = filesArray.length > 0 ? filesArray : fileData?.url ? [fileData] : []

            return (
              <div key={message.messageid} className={`mb-4 flex ${isCurrentUser ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[75%]`}>
                  {/* Sender name */}
                  <div className={`text-sm mb-1 ${isCurrentUser ? "text-right mr-2" : "ml-2"}`}>
                    <span className={`font-medium ${isCurrentUser ? "text-blue-600" : "text-gray-700"}`}>
                      {isCurrentUser ? "Me" : senderName}
                    </span>
                  </div>

                  <div className="flex items-end">
                    {!isCurrentUser && (
                      <div className="w-8 h-8 rounded-full bg-gray-300 flex-shrink-0 mr-2 flex items-center justify-center">
                        <span className="text-xs font-medium">{senderName.charAt(0)}</span>
                      </div>
                    )}

                    <div
                      className={`rounded-lg px-4 py-2 ${
                        isCurrentUser
                          ? "bg-blue-500 text-white rounded-br-none shadow-sm"
                          : "bg-white border border-gray-200 rounded-bl-none shadow-sm"
                      }`}
                    >
                      {messageText && <div className="whitespace-pre-wrap break-words">{messageText}</div>}

                      {/* Display all files */}
                      {allFiles.length > 0 && (
                        <div className="mt-2 space-y-2">
                          {allFiles.map((file, fileIndex) => {
                            if (!file || !file.url) return null

                            if (
                              file.type?.startsWith("image/") ||
                              file.url.toLowerCase().match(/\.(jpeg|jpg|gif|png|webp)$/)
                            ) {
                              return (
                                <a
                                  key={fileIndex}
                                  href={file.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="block"
                                >
                                  <img
                                    src={file.url || "/placeholder.svg"}
                                    alt={file.name || "Attached image"}
                                    className="max-w-full max-h-48 rounded border border-gray-200"
                                  />
                                </a>
                              )
                            } else if (file.type === "application/pdf" || file.url.toLowerCase().endsWith(".pdf")) {
                              return (
                                <a
                                  key={fileIndex}
                                  href={file.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center text-sm bg-red-50 text-red-700 p-2 rounded border border-red-200"
                                >
                                  <File className="w-4 h-4 mr-1" />
                                  {file.name || "PDF Document"}
                                  {file.size && (
                                    <span className="ml-1 text-xs text-gray-500">
                                      ({(file.size / 1024).toFixed(1)} KB)
                                    </span>
                                  )}
                                </a>
                              )
                            } else {
                              return (
                                <a
                                  key={fileIndex}
                                  href={file.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center text-sm bg-gray-50 text-gray-700 p-2 rounded border border-gray-200"
                                >
                                  <File className="w-4 h-4 mr-1" />
                                  {file.name || "Unknown File"}
                                  {file.size && (
                                    <span className="ml-1 text-xs text-gray-500">
                                      ({(file.size / 1024).toFixed(1)} KB)
                                    </span>
                                  )}
                                </a>
                              )
                            }
                          })}
                        </div>
                      )}
                    </div>

                    {isCurrentUser && (
                      <div className="w-8 h-8 rounded-full bg-gray-300 flex-shrink-0 ml-2 flex items-center justify-center">
                        <span className="text-xs font-medium">{senderName.charAt(0)}</span>
                      </div>
                    )}
                  </div>
                  <div className={`text-xs mt-1 ${isCurrentUser ? "text-right mr-2" : "ml-2"}`}>
                    {formatTime(message.messagetime)}
                  </div>
                </div>
              </div>
            )
          })}
          <div ref={messagesEndRef} />
        </div>
      ))}
    </div>
  )
}
