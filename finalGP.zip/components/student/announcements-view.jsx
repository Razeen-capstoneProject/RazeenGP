"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { formatDistanceToNow } from "date-fns"
import { getAnnouncementsForUser } from "@/utils/supabase/announcement-service"
import { getUserRoleInfo } from "@/utils/supabase/user-role-service"
import { useAuth } from "@/context/auth-context"
import { motion, AnimatePresence } from "framer-motion"
import {
  AlertCircle,
  Download,
  FileText,
  Users,
  User,
  Megaphone,
  Search,
  Calendar,
  GraduationCap,
  Clock,
  Paperclip,
  Bell,
  ArrowDown,
} from "lucide-react"

export function AnnouncementsView() {
  const { user } = useAuth()
  const [announcements, setAnnouncements] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterMode, setFilterMode] = useState("relevant") // "relevant", "all", "role"
  const [selectedRoles, setSelectedRoles] = useState(["student"]) // Default to student role
  const [userRoleInfo, setUserRoleInfo] = useState(null)
  const [lastRefreshed, setLastRefreshed] = useState(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [showInfoBanner, setShowInfoBanner] = useState(true)
  const [newAnnouncementAlert, setNewAnnouncementAlert] = useState(false)
  const newAnnouncementsRef = useRef([])
  const listRef = useRef(null)

  // Removed real-time subscription

  // Helper function to deduplicate announcements
  const deduplicateAnnouncements = (announcementsList) => {
    const uniqueMap = new Map()

    // Use a Map to keep only the latest version of each announcement by ID
    announcementsList.forEach((announcement) => {
      uniqueMap.set(announcement.announcement_id, announcement)
    })

    // Convert Map values back to array and sort by created_at (newest first)
    return Array.from(uniqueMap.values()).sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
  }

  // Fetch user role info
  useEffect(() => {
    async function fetchUserData() {
      if (!user?.user_id) return

      try {
        // Get detailed role info
        const { roleInfo, error: roleError } = await getUserRoleInfo(user.user_id)
        if (roleError) {
          console.error("Error fetching user role info:", roleError)
        } else {
          setUserRoleInfo(roleInfo)
        }
      } catch (err) {
        console.error("Error fetching user data:", err)
      }
    }

    fetchUserData()
  }, [user])

  // Function to fetch announcements
  const fetchAnnouncements = useCallback(
    async (showLoadingState = true) => {
      if (!user?.user_id || !user?.role) return

      if (showLoadingState) {
        setLoading(true)
      }
      setError(null)

      try {
        // Prepare filter options based on mode
        const filterOptions = {
          userRole: user.role,
          userId: user.user_id,
          searchQuery: searchQuery,
          includeAllAnnouncements: false, // Always filter by role
          filterMode: "relevant", // Always use relevant mode
          selectedRoles: ["student"], // Only show student announcements
        }

        // Fetch announcements with the appropriate filters
        const { announcements: fetchedAnnouncements, error: fetchError } = await getAnnouncementsForUser(filterOptions)

        if (fetchError) {
          throw new Error(fetchError)
        }

        // Deduplicate announcements before setting state
        const uniqueAnnouncements = deduplicateAnnouncements(fetchedAnnouncements)
        setAnnouncements(uniqueAnnouncements)

        // Clear new announcements reference after fetching
        newAnnouncementsRef.current = []
        setNewAnnouncementAlert(false)
      } catch (err) {
        console.error("Error fetching announcements:", err)
        setError("Failed to load announcements")
      } finally {
        setLoading(false)
        setIsRefreshing(false)
      }
    },
    [user, filterMode, searchQuery, selectedRoles],
  )

  // Fetch announcements when dependencies change
  useEffect(() => {
    fetchAnnouncements()
  }, [fetchAnnouncements, lastRefreshed])

  // Helper function to get announcement content text
  const getAnnouncementContent = (announcement) => {
    const content = announcement.announ_content

    // If content is a string, return it directly
    if (typeof content === "string") {
      return content
    }

    // If content is an object with a text property, return that
    if (content && typeof content === "object" && "text" in content) {
      return content.text || ""
    }

    // If we can't determine the content, return an empty string
    return ""
  }

  const handleRefresh = () => {
    if (isRefreshing) return
    setIsRefreshing(true)
    setLastRefreshed(new Date())
  }

  const handleNewAnnouncementsClick = () => {
    fetchAnnouncements(false)
    setNewAnnouncementAlert(false)
  }

  const formatDate = (dateString) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true })
    } catch (error) {
      return dateString
    }
  }

  // Get role badge component
  const getRoleBadge = (role) => {
    switch (role) {
      case "student":
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-blue-100 text-blue-800">
            <User size={12} className="mr-1" />
            Students
          </span>
        )
      case "instructor":
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-purple-100 text-purple-800">
            <GraduationCap size={12} className="mr-1" />
            Instructors
          </span>
        )
      case "all":
      default:
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-800">
            <Users size={12} className="mr-1" />
            All Users
          </span>
        )
    }
  }

  if (loading && announcements.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 flex justify-center items-center h-64">
        <div className="flex flex-col items-center">
          <div className="w-10 h-10 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-500">Loading announcements...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="p-4 bg-red-50 text-red-800 rounded-lg flex items-start gap-3">
          <AlertCircle className="mt-0.5" />
          <div>
            <p className="font-medium">Error Loading Announcements</p>
            <p>{error}</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Megaphone className="text-blue-600" />
        <span>Announcements</span>

        {/* Real-time updates removed */}
      </h2>

      {/* New announcements alert */}
      <AnimatePresence>
        {newAnnouncementAlert && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-4 p-3 bg-blue-600 text-white rounded-lg flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <Bell size={18} className="animate-pulse" />
              <span>New announcements available</span>
            </div>
            <button
              onClick={handleNewAnnouncementsClick}
              className="flex items-center gap-1 px-3 py-1 bg-white text-blue-600 rounded-md hover:bg-blue-50 transition-colors"
            >
              <ArrowDown size={14} />
              <span>View now</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search bar */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search announcements..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Status indicator */}
      <div className="flex justify-between items-center mb-4 text-sm text-gray-500">
        <div>
          {isRefreshing && (
            <span className="flex items-center gap-1">
              <Clock size={14} className="animate-spin" />
              Refreshing...
            </span>
          )}
        </div>
        <div>
          Showing {announcements.length} announcement{announcements.length !== 1 ? "s" : ""}
        </div>
      </div>

      {announcements.length === 0 ? (
        <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border border-gray-200">
          <Megaphone size={36} className="mx-auto text-gray-300 mb-2" />
          <p className="font-medium">No announcements found</p>
          <p className="text-sm mt-1">
            {searchQuery
              ? "Try adjusting your search query"
              : "There are no announcements relevant to you at this time"}
          </p>
          {searchQuery && (
            <button
              onClick={() => {
                setSearchQuery("")
              }}
              className="mt-3 text-blue-600 hover:text-blue-800 text-sm"
            >
              Clear search
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4" ref={listRef}>
          {announcements.map((announcement) => (
            <motion.div
              key={announcement.announcement_id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              layout
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  {getRoleBadge(announcement.user_role)}
                  <span className="text-sm text-gray-500 flex items-center gap-1">
                    <Calendar size={12} />
                    {formatDate(announcement.created_at)}
                  </span>
                </div>
                <span className="text-sm text-gray-500">
                  By: {announcement.committee_member?.userName || "Project Committee"}
                </span>
              </div>

              <div className="text-gray-800 mb-3 whitespace-pre-wrap">{getAnnouncementContent(announcement)}</div>

              {/* Multiple attachments */}
              {announcement.file_attachments && announcement.file_attachments.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-100">
                  <div className="flex items-center gap-1 mb-2 text-sm text-gray-600">
                    <Paperclip size={14} />
                    <span>Attachments ({announcement.file_attachments.length})</span>
                  </div>
                  <div className="space-y-2">
                    {announcement.file_attachments.map((attachment, index) => (
                      <a
                        key={index}
                        href={attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors w-full"
                      >
                        <FileText size={14} className="text-blue-600 flex-shrink-0" />
                        <span className="text-sm truncate flex-1">{attachment.filename}</span>
                        <Download size={14} className="flex-shrink-0" />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
