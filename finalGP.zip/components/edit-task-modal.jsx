"use client"

import { useState, useEffect, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  X,
  Save,
  AlertCircle,
  Calendar,
  User,
  Clock,
  FileText,
  CheckCircle,
  Tag,
  ArrowUpRight,
  Loader2,
} from "lucide-react"
import { updateSubTask } from "@/utils/supabase/subtask-service"
import { getGroupTasks } from "@/utils/supabase/user-service"

export function EditTaskModal({ task, students, groupId, onClose, onUpdate }) {
  const [formData, setFormData] = useState({
    subTaskName: "",
    description: "",
    priority: "",
    deadline: "",
    student_id: "",
    main_task: "", // Add main_task to formData
  })
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  const [availableTasks, setAvailableTasks] = useState([]) // Add state for available tasks
  const [isLoadingTasks, setIsLoadingTasks] = useState(false) // Add loading state for tasks
  const [currentTaskName, setCurrentTaskName] = useState("") // Track current task name for display

  // Fetch available tasks for the group - using useCallback to memoize the function
  const fetchAvailableTasks = useCallback(async () => {
    if (!groupId) return

    setIsLoadingTasks(true)
    try {
      const { tasks, error: tasksError } = await getGroupTasks(groupId)

      if (tasksError) {
        console.error("Error fetching tasks:", tasksError)
        return
      }

      setAvailableTasks(tasks || [])

      // If task has a main_task, find its name
      if (task?.main_task) {
        const currentTask = tasks?.find((t) => t.taskid === task.main_task)
        if (currentTask) {
          setCurrentTaskName(currentTask.taskname)
        }
      }
    } catch (err) {
      console.error("Error fetching available tasks:", err)
    } finally {
      setIsLoadingTasks(false)
    }
  }, [groupId, task?.main_task])

  // Fetch tasks immediately when component mounts
  useEffect(() => {
    fetchAvailableTasks()
  }, [fetchAvailableTasks])

  // Initialize form data when task changes
  useEffect(() => {
    if (task) {
      // Format the date for the datetime-local input
      let formattedDeadline = ""
      if (task.deadline) {
        try {
          const date = new Date(task.deadline)
          formattedDeadline = date.toISOString().slice(0, 16) // Format as YYYY-MM-DDTHH:MM
        } catch (error) {
          console.error("Error formatting date:", error)
        }
      }

      setFormData({
        subTaskName: task.subTaskName || "",
        description: task.description || "",
        priority: task.priority || "Medium",
        deadline: formattedDeadline,
        student_id: task.student_id || "",
        main_task: task.main_task || "", // Initialize main_task
      })
    }
  }, [task])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Update current task name when main_task changes
    if (name === "main_task" && value) {
      const selectedTask = availableTasks.find((t) => t.taskid === value)
      if (selectedTask) {
        setCurrentTaskName(selectedTask.taskname)
      }
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSaving(true)
    setError(null)
    setSuccess(false)

    try {
      // Validate form
      if (!formData.subTaskName) {
        throw new Error("Task name is required")
      }

      // Prepare update data
      const updateData = {
        sub_task_id: task.sub_task_id,
        subTaskName: formData.subTaskName,
        description: formData.description,
        priority: formData.priority,
        deadline: formData.deadline || null,
        student_id: formData.student_id,
        main_task: formData.main_task, // Include main_task in update data
      }

      // Update the task
      const { success, subTask, error: updateError } = await updateSubTask(updateData)

      if (updateError) {
        throw new Error(updateError)
      }

      if (success) {
        setSuccess(true)

        // Find the updated task name
        const updatedTaskName = formData.main_task
          ? availableTasks.find((t) => t.taskid === formData.main_task)?.taskname || ""
          : ""

        // Merge the updated data with the original task to maintain other properties
        const updatedTask = {
          ...task,
          ...subTask,
          task: {
            ...task.task,
            taskname: updatedTaskName,
          },
        }

        // Notify parent component
        setTimeout(() => {
          onUpdate(updatedTask)
        }, 1000)
      }
    } catch (err) {
      console.error("Error updating task:", err)
      setError(err.message || "Failed to update task")
    } finally {
      setIsSaving(false)
    }
  }

  // Handle click outside to close
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      if (isSaving) return
      onClose()
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={handleBackdropClick}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-lg shadow-lg w-full max-w-md overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex justify-between items-center border-b border-gray-200 p-4 bg-gray-50">
            <h3 className="font-semibold text-lg">Edit Task</h3>
            <button
              onClick={onClose}
              className="p-1 rounded-full hover:bg-gray-200 transition-colors"
              disabled={isSaving}
            >
              <X size={20} />
            </button>
          </div>

          {/* Content */}
          <div className="p-4">
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-start gap-2"
                >
                  <AlertCircle size={18} className="mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </motion.div>
              )}

              {success && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-4 p-3 bg-green-50 text-green-800 rounded-md flex items-center gap-2"
                >
                  <CheckCircle size={18} className="flex-shrink-0" />
                  <span>Task updated successfully!</span>
                </motion.div>
              )}
            </AnimatePresence>

            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="subTaskName" className="block font-medium mb-1 text-gray-700 flex items-center gap-1">
                    <FileText size={16} className="text-gray-500" />
                    Task Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    id="subTaskName"
                    name="subTaskName"
                    value={formData.subTaskName}
                    onChange={handleChange}
                    required
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    disabled={isSaving}
                    placeholder="Enter task name"
                  />
                </div>

                {/* Add Related Task dropdown - moved up in the form for better visibility */}
                <div>
                  <label htmlFor="main_task" className="block font-medium mb-1 text-gray-700 flex items-center gap-1">
                    <ArrowUpRight size={16} className="text-gray-500" />
                    Related Task
                  </label>

                  {isLoadingTasks ? (
                    <div className="flex items-center gap-2 text-gray-500 p-2">
                      <Loader2 size={16} className="animate-spin" />
                      <span>Loading tasks...</span>
                    </div>
                  ) : (
                    <>
                      <select
                        id="main_task"
                        name="main_task"
                        value={formData.main_task}
                        onChange={handleChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                        disabled={isSaving || isLoadingTasks}
                      >
                        <option value="">Select a related task</option>
                        {availableTasks.map((availableTask) => (
                          <option key={availableTask.taskid} value={availableTask.taskid}>
                            {availableTask.taskname}
                          </option>
                        ))}
                      </select>

                      {/* Show current task info */}
                      {(task.task?.taskname || currentTaskName) && (
                        <div className="mt-1 text-xs flex items-center gap-1">
                          <span className="text-gray-500">Currently linked to:</span>
                          <span className="font-medium text-blue-600">{task.task?.taskname || currentTaskName}</span>
                        </div>
                      )}

                      {/* Show warning if no tasks available */}
                      {availableTasks.length === 0 && !isLoadingTasks && (
                        <p className="mt-1 text-xs text-amber-600">No tasks available. Please create a task first.</p>
                      )}
                    </>
                  )}
                </div>

                <div>
                  <label htmlFor="description" className="block font-medium mb-1 text-gray-700 flex items-center gap-1">
                    <FileText size={16} className="text-gray-500" />
                    Description
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    rows={4}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    disabled={isSaving}
                    placeholder="Enter task description"
                  />
                </div>

                <div>
                  <label htmlFor="student_id" className="block font-medium mb-1 text-gray-700 flex items-center gap-1">
                    <User size={16} className="text-gray-500" />
                    Assigned To
                  </label>
                  <select
                    id="student_id"
                    name="student_id"
                    value={formData.student_id}
                    onChange={handleChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    disabled={isSaving}
                  >
                    <option value="">Select a student</option>
                    {students.map((student) => (
                      <option key={student.id} value={student.id}>
                        {student.name || student.email}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="priority" className="block font-medium mb-1 text-gray-700 flex items-center gap-1">
                    <Tag size={16} className="text-gray-500" />
                    Priority
                  </label>
                  <select
                    id="priority"
                    name="priority"
                    value={formData.priority}
                    onChange={handleChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    disabled={isSaving}
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="deadline" className="block font-medium mb-1 text-gray-700 flex items-center gap-1">
                    <Calendar size={16} className="text-gray-500" />
                    Deadline
                  </label>
                  <div className="relative">
                    <input
                      type="datetime-local"
                      id="deadline"
                      name="deadline"
                      value={formData.deadline}
                      onChange={handleChange}
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 pl-10"
                      disabled={isSaving}
                    />
                    <Clock size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <motion.button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={isSaving}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Cancel
                </motion.button>
                <motion.button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 flex items-center gap-2"
                  disabled={isSaving}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {isSaving ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save size={16} />
                      Save Changes
                    </>
                  )}
                </motion.button>
              </div>
            </form>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
