"use client"

import Link from "next/link"
import { Home, Video } from "lucide-react"
import { useRouter } from "next/navigation"
import { supabase } from "@/utils/supabase/client"

export function Sidebar() {
  const router = useRouter()
  const navigation = [
    {
      name: "Home",
      href: "/",
      icon: Home,
    },
    {
      name: "Meeting",
      href: "/dashboard/meeting",
      icon: Video,
    },
  ]

  // Update the handleSignOut function to use window.location.href directly
  const handleSignOut = async () => {
    try {
      // 1) clear the client session
      const { error } = await supabase.auth.signOut()
      if (error) {
        console.error("Sign-out failed:", error)
        return // bail out if something went wrong
      }

      // 2) Clear any user data from localStorage
      localStorage.removeItem("user")

      // 3) Force redirect to login page using window.location
      window.location.href = "/auth"
    } catch (error) {
      console.error("Error signing out:", error)
      alert("Failed to sign out. Please try again.")
    }
  }

  return (
    <div className="w-64 border-r border-gray-200 h-full flex flex-col">
      {/* Logo/Brand */}
      <div className="p-6">
        <h1 className="text-xl font-bold">Razeen</h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1">
        {navigation.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="flex items-center gap-3 px-6 py-3 bg-gray-100 text-gray-800 no-underline"
          >
            <item.icon size={20} />
            <span>{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* Add Sign Out Button */}
      <div className="p-6 border-t border-gray-200">
        <button
          onClick={handleSignOut}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-md hover:bg-red-100 transition-colors"
        >
          Sign Out
        </button>
      </div>
    </div>
  )
}
