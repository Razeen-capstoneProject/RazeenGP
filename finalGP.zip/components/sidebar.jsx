"use client"

import Link from "next/link"
import { Home, Video } from "lucide-react"
import { signOut } from "@/utils/supabase/auth"
import { useRouter } from "next/navigation"

export function Sidebar() {
  const router = useRouter()
  const navigation = [
    {
      name: "Home",
      href: "/",
      icon: Home,
    },
    {
      name: "Meeting",
      href: "/dashboard/meeting",
      icon: Video,
    },
  ]

  // Add the handleSignOut function
  const handleSignOut = async () => {
    try {
      const { success, error } = await signOut()
      if (success) {
        // Redirect to login page after successful sign out
        router.push("/auth")
      } else {
        console.error("Error signing out:", error)
        alert("Failed to sign out. Please try again.")
      }
    } catch (error) {
      console.error("Unexpected error during sign out:", error)
      alert("An unexpected error occurred. Please try again.")
    }
  }

  return (
    <div className="w-64 border-r border-gray-200 h-full flex flex-col">
      {/* Logo/Brand */}
      <div className="p-6">
        <h1 className="text-xl font-bold">Razeen</h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1">
        {navigation.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="flex items-center gap-3 px-6 py-3 bg-gray-100 text-gray-800 no-underline"
          >
            <item.icon size={20} />
            <span>{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* Add Sign Out Button */}
      <div className="p-6 border-t border-gray-200">
        <button
          onClick={handleSignOut}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-md hover:bg-red-100 transition-colors"
        >
          Sign Out
        </button>
      </div>
    </div>
  )
}
