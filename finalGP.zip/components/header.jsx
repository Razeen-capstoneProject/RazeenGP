import { MoreVertical } from "lucide-react"

export function Header() {
  return (
    <header className="h-16 border-b border-gray-200 flex items-center justify-end px-6">
      <div className="flex items-center gap-3">
        <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
          <span className="text-sm">S</span>
        </div>
        <span className="text-sm">Name of the student</span>
        <button className="bg-transparent border-none cursor-pointer flex p-1">
          <MoreVertical size={20} />
        </button>
      </div>
    </header>
  )
}
