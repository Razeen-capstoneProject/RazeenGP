"use client"

import { useEffect } from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createProjectGroup, getAvailableProjectTypes } from "@/utils/supabase/group-service"
import { useAuth } from "@/context/auth-context"

export function CreateGroupForm() {
  const { user } = useAuth()
  const router = useRouter()
  const [groupName, setGroupName] = useState("")
  const [projectType, setProjectType] = useState("")
  const [availableProjectTypes, setAvailableProjectTypes] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState({})

  useEffect(() => {
    async function fetchProjectTypes() {
      const { projectTypes, error } = await getAvailableProjectTypes()
      if (error) {
        console.error("Error fetching project types:", error)
        setStatus({ success: false, message: "Failed to load project types" })
      } else {
        setAvailableProjectTypes(projectTypes)
        if (projectTypes.length > 0) {
          setProjectType(projectTypes[0].id) // Select the first one by default
        }
      }
    }

    fetchProjectTypes()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!user?.user_id) {
      setStatus({ success: false, message: "You must be logged in as an instructor to create a group" })
      return
    }

    setIsLoading(true)
    setStatus({})

    const groupData = {
      groupname: groupName,
      instructor_supervisor_id: user.user_id,
      project_type: projectType,
    }

    const result = await createProjectGroup(groupData)

    setStatus({
      success: result.group !== null,
      message: result.error || "Group created successfully!",
    })
    setIsLoading(false)

    if (result.group) {
      setGroupName("")
      setTimeout(() => {
        router.push(`/dashboard/groups/${result.group.groupid}`)
      }, 1500)
    }
  }

  return (
    <div className="w-full max-w-md border border-gray-200 rounded-lg p-6 shadow-sm">
      <div className="text-center mb-4">
        <h2 className="text-2xl font-bold mb-2">Create Group</h2>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="groupName" className="block font-medium mb-2">
            Group Name
          </label>
          <input
            id="groupName"
            placeholder="Enter group name"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            required
            className="w-full p-2.5 border border-gray-300 rounded-md text-base"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="projectType" className="block font-medium mb-2">
            Project Type
          </label>
          <select
            id="projectType"
            value={projectType}
            onChange={(e) => setProjectType(e.target.value)}
            required
            className="w-full p-2.5 border border-gray-300 rounded-md text-base"
          >
            {availableProjectTypes.map((type) => (
              <option key={type.id} value={type.id}>
                {type.name}
              </option>
            ))}
          </select>
        </div>

        {status.message && (
          <div
            className={`p-2.5 mb-4 rounded ${
              status.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            }`}
          >
            {status.message}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading}
          className={`w-full p-3 bg-black text-white border-none rounded-md text-base cursor-pointer ${
            isLoading ? "opacity-70 cursor-not-allowed" : "opacity-100"
          }`}
        >
          {isLoading ? "Creating..." : "Create Group"}
        </button>
      </form>
    </div>
  )
}
