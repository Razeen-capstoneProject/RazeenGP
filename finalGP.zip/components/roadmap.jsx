import { CheckCircle2, Circle, Clock } from "lucide-react"

export function Roadmap({ milestones }) {
  console.log("Rendering roadmap with milestones:", milestones)

  const getStatusIcon = (status) => {
    switch (status.toLowerCase()) {
      case "done":
      case "completed":
        return <CheckCircle2 className="text-green-500" size={20} />
      case "on progress":
        return <Clock className="text-blue-500" size={20} />
      default:
        return <Circle className="text-gray-400" size={20} />
    }
  }

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "done":
      case "completed":
        return "bg-green-100" // Light green background for Done/Completed
      case "on progress":
        return "bg-blue-100" // Light blue background for In Progress
      default:
        return "bg-gray-100" // Light gray background for To Do
    }
  }

  const getStatusTextColor = (status) => {
    switch (status.toLowerCase()) {
      case "done":
      case "completed":
        return "text-green-500" // Green text for Done/Completed
      case "on progress":
        return "text-blue-500" // Blue text for In Progress
      default:
        return "text-gray-500" // Gray text for To Do
    }
  }

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  if (!milestones || milestones.length === 0) {
    return null
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <h2 className="text-xl font-bold mb-6">Project Roadmap</h2>

      <div className="flex flex-col gap-4">
        {milestones.map((milestone, index) => (
          <div
            key={milestone.milestone_id}
            className={`flex gap-4 p-4 rounded-lg ${getStatusColor(milestone.status)} relative`}
          >
            {/* Timeline connector */}
            {index < milestones.length - 1 && (
              <div className="absolute left-7 top-11 bottom-[-16px] w-0.5 bg-gray-200" />
            )}

            {/* Status icon */}
            <div className="flex-shrink-0">{getStatusIcon(milestone.status)}</div>

            {/* Milestone content */}
            <div className="flex-1">
              <h3 className="text-base font-medium mb-1">{milestone.name}</h3>
              <p className="text-sm text-gray-500">Due: {formatDate(milestone.deadline)}</p>
              <div className={`text-sm mt-1 ${getStatusTextColor(milestone.status)}`}>Status: {milestone.status}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
