"use client"

import { Clock, CircleDot, CheckCircle } from "lucide-react"
import { TaskCard } from "./task-card"
import { motion } from "framer-motion"

export function TaskColumn({ title, tasks, icon, color }) {
  // Get the appropriate icon component
  const getIcon = () => {
    switch (icon) {
      case "clock":
        return <Clock size={18} className="text-gray-500" />
      case "circle-dot":
        return <CircleDot size={18} className="text-blue-500" />
      case "check-circle":
        return <CheckCircle size={18} className="text-green-500" />
      default:
        return <Clock size={18} className="text-gray-500" />
    }
  }

  // Get the appropriate color classes
  const getColorClasses = () => {
    switch (color) {
      case "gray":
        return "bg-gray-50 border-gray-200"
      case "blue":
        return "bg-blue-50 border-blue-200"
      case "green":
        return "bg-green-50 border-green-200"
      default:
        return "bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className={`rounded-lg border ${getColorClasses()} p-3`}>
      <div className="flex items-center gap-2 mb-3">
        {getIcon()}
        <h3 className="font-medium">{title}</h3>
        <span className="ml-auto bg-white text-xs font-medium px-2 py-0.5 rounded-full">{tasks.length}</span>
      </div>

      <div className="space-y-2 max-h-[calc(100vh-250px)] overflow-y-auto pr-1">
        {tasks.length === 0 ? (
          <div className="text-center py-8 text-sm text-gray-500">No tasks</div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ staggerChildren: 0.1 }}>
            {tasks.map((task) => (
              <TaskCard key={task.sub_task_id} task={task} />
            ))}
          </motion.div>
        )}
      </div>
    </div>
  )
}
