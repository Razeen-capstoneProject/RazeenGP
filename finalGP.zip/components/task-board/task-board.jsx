"use client"

import { useState, useEffect } from "react"
import { getStudentSubTasks } from "@/utils/supabase/user-service"
import { useAuth } from "@/context/auth-context"
import { TaskColumn } from "./task-column"
import { AlertCircle } from "lucide-react"

export function TaskBoard() {
  const { user } = useAuth()
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function fetchTasks() {
      if (!user?.user_id) return

      setLoading(true)
      setError(null)

      try {
        const { subTasks, error: fetchError } = await getStudentSubTasks(user.user_id)

        if (fetchError) {
          throw new Error(fetchError)
        }

        setTasks(subTasks)
      } catch (err) {
        console.error("Error fetching tasks:", err)
        setError("Failed to load your tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()
  }, [user])

  // Group tasks by status
  const groupedTasks = {
    "To Do": tasks.filter((task) => task.status?.toLowerCase() === "to do"),
    "On Progress": tasks.filter((task) => task.status?.toLowerCase() === "on progress"),
    Done: tasks.filter((task) => task.status?.toLowerCase() === "done"),
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="inline-flex items-center gap-2 text-red-600 mb-2">
          <AlertCircle size={20} />
          <span className="font-medium">Error</span>
        </div>
        <p className="text-gray-600">{error}</p>
      </div>
    )
  }

  if (tasks.length === 0) {
    return (
      <div className="p-6 text-center bg-white rounded-lg shadow-sm border border-gray-200">
        <p className="text-gray-500">You don't have any assigned tasks yet.</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <h2 className="text-lg font-semibold mb-4">Your Tasks</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <TaskColumn title="To Do" tasks={groupedTasks["To Do"]} icon="clock" color="gray" />
        <TaskColumn title="In Progress" tasks={groupedTasks["On Progress"]} icon="circle-dot" color="blue" />
        <TaskColumn title="Completed" tasks={groupedTasks["Done"]} icon="check-circle" color="green" />
      </div>
    </div>
  )
}
