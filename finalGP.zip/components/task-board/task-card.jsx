"use client"

import { Calendar, ArrowUpRight, User } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { motion } from "framer-motion"

export function TaskCard({ task }) {
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      return formatDistanceToNow(date, { addSuffix: true })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Get display name for the student
  const getStudentDisplayName = () => {
    // If there's no student assigned, return empty string
    if (!task.student_id || !task.users) {
      return ""
    }

    // If userName exists and is not empty, use it
    if (task.users.userName && task.users.userName.trim() !== "") {
      return task.users.userName
    }

    // Last resort fallback
    return "Unknown Student"
  }

  const studentName = getStudentDisplayName()

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-md border border-gray-200 shadow-sm p-3 hover:shadow-md transition-shadow"
    >
      <h4 className="font-medium text-sm mb-2 line-clamp-2">{task.subTaskName}</h4>

      {task.description && <p className="text-gray-600 text-xs mb-2 line-clamp-2">{task.description}</p>}

      <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-500">
        <div className="flex items-center gap-1">
          <Calendar size={12} />
          <span>{formatDate(task.deadline)}</span>
        </div>

        {task.task?.taskname && (
          <div className="flex items-center gap-1">
            <ArrowUpRight size={12} />
            <span className="truncate max-w-[100px]">{task.task.taskname}</span>
          </div>
        )}

        {studentName && (
          <div className="flex items-center gap-1">
            <User size={12} />
            <span>{studentName}</span>
          </div>
        )}
      </div>

      {task.priority && (
        <div className="mt-2">
          <span className={`px-2 py-0.5 rounded-full text-xs ${getPriorityColor(task.priority)}`}>{task.priority}</span>
        </div>
      )}
    </motion.div>
  )
}
