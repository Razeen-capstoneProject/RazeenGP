export function GradingScale() {
  return (
    <div className="mt-6 pt-4 border-t border-gray-200">
      <h4 className="text-sm font-medium text-gray-700 mb-2">Grading Scale</h4>
      <div className="grid grid-cols-2 gap-1 text-sm">
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">A+</span>
          <span>95-100</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">A</span>
          <span>90-94</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">B+</span>
          <span>85-89</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">B</span>
          <span>80-84</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">C+</span>
          <span>75-79</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">C</span>
          <span>70-74</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">D+</span>
          <span>65-69</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">D</span>
          <span>60-64</span>
        </div>
        <div className="flex justify-between items-center py-1">
          <span className="font-medium">F</span>
          <span>0-59</span>
        </div>
      </div>
    </div>
  )
}
