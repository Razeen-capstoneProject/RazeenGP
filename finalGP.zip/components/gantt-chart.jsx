"use client"

import { useState, useEffect, useRef } from "react"
import { supabase } from "@/utils/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export function GanttChart({ groupId }) {
  const [tasks, setTasks] = useState([])
  const [dependencies, setDependencies] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [expanded, setExpanded] = useState(true)
  const [dateRange, setDateRange] = useState({ start: null, end: null })
  const [selectedTask, setSelectedTask] = useState(null)
  const [showTaskDetails, setShowTaskDetails] = useState(false)
  const chartRef = useRef(null)
  const svgRef = useRef(null)

  // Fetch tasks for the group
  useEffect(() => {
    async function fetchTasks() {
      if (!groupId) {
        console.log("No groupId provided to GanttChart")
        setLoading(false)
        return
      }

      try {
        console.log("Fetching tasks for group:", groupId)
        const { data, error } = await supabase
          .from("task")
          .select("*")
          .eq("groupid", groupId)
          .order("start_date", { ascending: true })

        if (error) {
          console.error("Error fetching tasks:", error)
          setError("Failed to load tasks")
        } else {
          console.log("Tasks fetched:", data)

          // Fetch dependencies for all tasks
          const { data: dependenciesData, error: dependenciesError } = await supabase
            .from("dependency")
            .select("*")
            .eq("groupid", groupId)

          if (dependenciesError) {
            console.error("Error fetching dependencies:", dependenciesError)
          }

          const dependencies = dependenciesData || []

          // Create a map of task dependencies
          const dependencyMap = {}
          dependencies.forEach((dep) => {
            if (!dependencyMap[dep.task]) {
              dependencyMap[dep.task] = []
            }
            dependencyMap[dep.task].push(dep.depend_on)
          })

          // Add dependencies to tasks
          const tasksWithDependencies = data.map((task) => {
            return {
              ...task,
              dependencies: dependencyMap[task.taskid] || [],
            }
          })

          setTasks(tasksWithDependencies || [])

          // Calculate date range for the chart
          if (data && data.length > 0) {
            const startDates = data.map((task) => new Date(task.start_date))
            const endDates = data.map((task) => new Date(task.deadline))

            // Filter out invalid dates
            const validStartDates = startDates.filter((date) => !isNaN(date.getTime()))
            const validEndDates = endDates.filter((date) => !isNaN(date.getTime()))

            if (validStartDates.length > 0 && validEndDates.length > 0) {
              const minDate = new Date(Math.min(...validStartDates))
              const maxDate = new Date(Math.max(...validEndDates))

              // Add some padding to the date range
              minDate.setDate(minDate.getDate() - 2)
              maxDate.setDate(maxDate.getDate() + 2)

              setDateRange({ start: minDate, end: maxDate })
            }
          }
        }
      } catch (err) {
        console.error("Unexpected error fetching tasks:", err)
        setError("An unexpected error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()
  }, [groupId])

  // Fetch task dependencies
  useEffect(() => {
    async function fetchDependencies() {
      if (!groupId || tasks.length === 0) return

      try {
        console.log("Fetching dependencies")
        const { data, error } = await supabase.from("dependency").select("*")

        if (error) {
          console.error("Error fetching dependencies:", error)
        } else {
          console.log("Dependencies fetched:", data)
          setDependencies(data || [])
        }
      } catch (err) {
        console.error("Unexpected error fetching dependencies:", err)
      }
    }

    fetchDependencies()
  }, [groupId, tasks])

  // Draw dependency arrows
  useEffect(() => {
    if (!svgRef.current || tasks.length === 0 || dependencies.length === 0 || !expanded) return

    const svg = svgRef.current
    // Clear existing arrows
    while (svg.firstChild) {
      svg.removeChild(svg.firstChild)
    }

    // Create a map of task IDs to their DOM elements
    const taskElements = {}
    tasks.forEach((task) => {
      const element = document.getElementById(`task-${task.taskid}`)
      if (element) {
        taskElements[task.taskid] = element
      }
    })

    // Add arrowhead marker if it doesn't exist
    const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs")
    const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker")
    marker.setAttribute("id", "arrowhead")
    marker.setAttribute("markerWidth", "8")
    marker.setAttribute("markerHeight", "6")
    marker.setAttribute("refX", "8")
    marker.setAttribute("refY", "3")
    marker.setAttribute("orient", "auto")

    const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon")
    polygon.setAttribute("points", "0 0, 8 3, 0 6")
    polygon.setAttribute("fill", "#000000") // Black color for arrowhead

    marker.appendChild(polygon)
    defs.appendChild(marker)
    svg.appendChild(defs)

    // Draw arrows for each dependency
    dependencies.forEach((dep) => {
      const sourceElement = taskElements[dep.task]
      const targetElement = taskElements[dep.depend_on]

      if (sourceElement && targetElement) {
        const sourceRect = sourceElement.getBoundingClientRect()
        const targetRect = targetElement.getBoundingClientRect()
        const chartRect = chartRef.current.getBoundingClientRect()

        // Calculate positions relative to the SVG
        const sourceX = sourceRect.right - chartRect.left
        const sourceY = sourceRect.top + sourceRect.height / 2 - chartRect.top
        const targetX = targetRect.left - chartRect.left
        const targetY = targetRect.top + targetRect.height / 2 - chartRect.top

        // Create path for the arrow with vertical line and horizontal connection
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path")

        // Calculate midpoint X
        const midX = sourceX + (targetX - sourceX) / 2

        // Create path with right angles
        const arrowPath = `
          M ${sourceX},${sourceY} 
          L ${midX},${sourceY} 
          L ${midX},${targetY} 
          L ${targetX},${targetY}
        `

        path.setAttribute("d", arrowPath)
        path.setAttribute("fill", "none")
        path.setAttribute("stroke", "#000000") // Black color for arrows
        path.setAttribute("stroke-width", "1.5") // Slightly thicker for better visibility
        path.setAttribute("marker-end", "url(#arrowhead)")
        path.setAttribute("stroke-dasharray", "3,3") // Dashed line

        svg.appendChild(path)
      }
    })
  }, [tasks, dependencies, expanded])

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    if (isNaN(date.getTime())) return "Invalid date"
    return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(date)
  }

  // Calculate task position and width
  const getTaskStyle = (task) => {
    if (!dateRange.start || !dateRange.end) return { left: "0%", width: "5%" }

    const start = new Date(task.start_date)
    const end = new Date(task.deadline)

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      console.warn("Invalid date for task:", task)
      return { left: "0%", width: "5%" }
    }

    const totalDays = (dateRange.end - dateRange.start) / (1000 * 60 * 60 * 24)
    const taskStartDays = (start - dateRange.start) / (1000 * 60 * 60 * 24)
    const taskDuration = (end - start) / (1000 * 60 * 60 * 24)

    const left = (taskStartDays / totalDays) * 100
    const width = Math.max((taskDuration / totalDays) * 100, 3) // Minimum width of 3%

    return {
      left: `${left}%`,
      width: `${width}%`,
    }
  }

  // Get color based on status
  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case "done":
        return "bg-green-500"
      case "in progress":
      case "on progress":
        return "bg-blue-500"
      case "to do":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  // Get status badge class for the dialog
  const getStatusBadgeClass = (status) => {
    switch (status?.toLowerCase()) {
      case "done":
        return "bg-green-100 text-green-800"
      case "in progress":
      case "on progress":
        return "bg-blue-100 text-blue-800"
      case "to do":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Handle task click to show details
  const handleTaskClick = (task) => {
    setSelectedTask(task)
    setShowTaskDetails(true)
  }

  // Generate date headers
  const generateDateHeaders = () => {
    if (!dateRange.start || !dateRange.end) return null

    const totalDays = (dateRange.end - dateRange.start) / (1000 * 60 * 60 * 24)
    const numDivisions = 10 // Number of date divisions to show
    const dayInterval = Math.max(Math.floor(totalDays / numDivisions), 1)

    const dates = []
    const currentDate = new Date(dateRange.start)

    // Add start date
    dates.push(new Date(currentDate))

    // Add intermediate dates
    while (currentDate < dateRange.end) {
      currentDate.setDate(currentDate.getDate() + dayInterval)
      if (currentDate <= dateRange.end) {
        dates.push(new Date(currentDate))
      }
    }

    // Ensure end date is included
    if (dates[dates.length - 1] < dateRange.end) {
      dates.push(new Date(dateRange.end))
    }

    return (
      <div className="flex justify-between w-full mb-6 text-xs text-gray-500 font-medium">
        {dates.map((date, index) => (
          <div
            key={index}
            className="absolute transform -translate-x-1/2"
            style={{
              left: `${(index / (dates.length - 1)) * 100}%`,
              width: "max-content",
            }}
          >
            {formatDate(date)}
          </div>
        ))}
      </div>
    )
  }

  if (loading) {
    return (
      <Card className="w-full shadow-sm border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Project Timeline</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="space-y-2">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-3 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="w-full shadow-sm border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Project Timeline</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-red-500">{error}</div>
        </CardContent>
      </Card>
    )
  }

  if (tasks.length === 0) {
    return (
      <Card className="w-full shadow-sm border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Project Timeline</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center text-gray-500">
            No tasks found for this group. Create tasks to see them in the Gantt chart.
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card className="w-full shadow-sm border-gray-200">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-medium">Project Timeline</CardTitle>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-gray-400 rounded-sm mr-1"></div>
                <span>To Do</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded-sm mr-1"></div>
                <span>In Progress</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-sm mr-1"></div>
                <span>Done</span>
              </div>
            </div>
            <button onClick={() => setExpanded(!expanded)} className="text-gray-500 hover:text-gray-700">
              {expanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
            </button>
          </div>
        </CardHeader>
        {expanded && (
          <CardContent className="p-4">
            <div className="relative" ref={chartRef}>
              {/* Task rows with timeline */}
              <div className="space-y-8">
                {tasks.map((task) => (
                  <div key={task.taskid} className="flex items-center">
                    {/* Task name column */}
                    <div
                      className="w-[150px] pr-4 flex-shrink-0 cursor-pointer hover:text-blue-600 transition-colors"
                      onClick={() => handleTaskClick(task)}
                    >
                      <div className="text-sm font-medium truncate" title={task.taskname}>
                        {task.taskname}
                      </div>
                    </div>

                    {/* Timeline column */}
                    <div className="flex-grow relative">
                      {/* Date headers - positioned at the top of each task row */}
                      {task.taskid === tasks[0].taskid && (
                        <div className="absolute -top-6 left-0 right-0">{generateDateHeaders()}</div>
                      )}

                      {/* Task bar */}
                      <div className="h-6 bg-gray-50 rounded">
                        <div
                          id={`task-${task.taskid}`}
                          className={`absolute top-0 h-full rounded ${getStatusColor(task.status)}`}
                          style={getTaskStyle(task)}
                          title={`${task.taskname}: ${formatDate(task.start_date)} - ${formatDate(task.deadline)}`}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* SVG overlay for arrows */}
              <svg
                ref={svgRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ zIndex: 10, pointerEvents: "none" }}
              ></svg>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Task Details Dialog */}
      <Dialog open={showTaskDetails} onOpenChange={setShowTaskDetails}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedTask?.taskname}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Status</p>
                <div className="mt-1">
                  <span
                    className={`inline-block px-2 py-1 text-xs rounded-full ${getStatusBadgeClass(selectedTask?.status)}`}
                  >
                    {selectedTask?.status}
                  </span>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Priority</p>
                <div className="mt-1">
                  <span
                    className={`inline-block px-2 py-1 text-xs rounded-full ${
                      selectedTask?.priority?.toLowerCase() === "high"
                        ? "bg-red-100 text-red-800"
                        : selectedTask?.priority?.toLowerCase() === "medium"
                          ? "bg-yellow-100 text-yellow-800"
                          : selectedTask?.priority?.toLowerCase() === "low"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    {selectedTask?.priority}
                  </span>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Start Date</p>
                <p className="text-sm">{formatDate(selectedTask?.start_date)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Deadline</p>
                <p className="text-sm">{formatDate(selectedTask?.deadline)}</p>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Description</p>
              <p className="text-sm mt-1 text-gray-700">
                {selectedTask?.taskdescription || "No description available"}
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
