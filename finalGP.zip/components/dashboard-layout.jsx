"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/context/auth-context"
import {
  Home,
  ListTodo,
  MessageSquare,
  Video,
  ThumbsUp,
  MoreVertical,
  ClipboardList,
  Bell,
  GraduationCap,
  X,
  AlertCircle,
  CheckCircle,
  ListChecks,
  LogOut,
  Lock,
} from "lucide-react"
import { Roadmap } from "./roadmap"
import { getGroupMilestones, getCurrentUserGroup } from "@/utils/supabase/queries"
import { isGroupLeader } from "@/utils/supabase/user-service"
import { supabase } from "@/utils/supabase/client"
// Add the signOut import
import { signOut } from "@/utils/supabase/auth"
import { useRouter } from "next/navigation"
import { getLetterGrade, getGradeColor } from "@/utils/grade-utils"

export function DashboardLayout({ children }) {
  const router = useRouter()
  const { user } = useAuth()
  const [milestones, setMilestones] = useState([])
  const [loading, setLoading] = useState(true)
  const [showGradeModal, setShowGradeModal] = useState(false)
  const [score, setScore] = useState(null)
  const [gradeLoading, setGradeLoading] = useState(false)
  const [gradeError, setGradeError] = useState(null)
  const [isLeader, setIsLeader] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [evaluations, setEvaluations] = useState([])

  // Check if current page is the dashboard homepage
  const pathname = usePathname()
  const isHomepage = pathname === "/dashboard"

  const fetchGrade = async () => {
    if (!user?.user_id) return

    setGradeLoading(true)
    setGradeError(null)

    try {
      // Query the evaluate_student table to get all evaluations for this student
      const { data, error } = await supabase
        .from("evaluate_student")
        .select("score, instructor_id")
        .eq("student_id", user.user_id)

      if (error) throw error

      setEvaluations(data || [])

      if (data && data.length > 0) {
        const totalScore = data.reduce((sum, item) => sum + (item.score || 0), 0)
        // If there are multiple evaluations, calculate the average
        const finalScore = data.length > 0 ? Math.round(totalScore) : 0
        setScore(finalScore)
      } else {
        setScore(null)
      }
    } catch (error) {
      console.error("Error fetching grade:", error)
      setGradeError("Failed to load your grade information")
    } finally {
      setGradeLoading(false)
    }
  }

  // Check if user is a leader
  useEffect(() => {
    async function checkLeaderStatus() {
      if (!user?.user_id) return

      try {
        const leaderStatus = await isGroupLeader(user.user_id)
        setIsLeader(leaderStatus)
      } catch (error) {
        console.error("Error checking leader status:", error)
      }
    }

    checkLeaderStatus()
  }, [user])

  const navItems = [
    { icon: Home, label: "Home", href: "/dashboard", active: pathname === "/dashboard" },
    { icon: ListTodo, label: "My Sub-Tasks", href: "/dashboard/my-task", active: pathname === "/dashboard/my-task" },
    {
      icon: ClipboardList,
      label: "Supervisor Tasks",
      href: "/dashboard/supervisor-tasks",
      active: pathname === "/dashboard/supervisor-tasks",
    },
    { icon: MessageSquare, label: "Chat", href: "/dashboard/chat", active: pathname === "/dashboard/chat" },
    { icon: Video, label: "Meeting", href: "/dashboard/meeting", active: pathname === "/dashboard/meeting" },
    { icon: ThumbsUp, label: "Feedback", href: "/dashboard/feedback", active: pathname === "/dashboard/feedback" },
    {
      icon: Bell,
      label: "Announcement",
      href: "/dashboard/announcement",
      active: pathname === "/dashboard/announcement",
    },
    {
      icon: GraduationCap,
      label: "Grade",
      onClick: () => {
        fetchGrade()
        setShowGradeModal(true)
      },
      active: false,
    },
  ]

  // Add Group Tasks item for leaders
  if (isLeader) {
    navItems.splice(2, 0, {
      icon: ListChecks,
      label: "Group Sub-Tasks",
      href: "/dashboard/tasks",
      active: pathname === "/dashboard/tasks",
    })
  }

  useEffect(() => {
    const fetchMilestones = async () => {
      // Only fetch milestones if we're on the homepage
      if (!isHomepage) {
        setLoading(false)
        return
      }

      try {
        setLoading(true)

        if (!user?.user_id) {
          console.log("No user ID found")
          return
        }

        // First get the user's current group
        const { groupId, error: groupError } = await getCurrentUserGroup(user.user_id)
        console.log("Current user group:", { groupId, groupError })

        if (groupError || !groupId) {
          console.error("Failed to get user group:", groupError)
          return
        }

        // Then fetch milestones for that group
        const { milestones: groupMilestones, error: milestonesError } = await getGroupMilestones(groupId.toString())
        console.log("Fetched milestones:", { groupMilestones, milestonesError })

        if (!milestonesError) {
          setMilestones(groupMilestones)
        }
      } catch (error) {
        console.error("Error in fetchMilestones:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchMilestones()
  }, [user, isHomepage])

  // Close the user menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showUserMenu && !event.target.closest(".user-menu-container")) {
        setShowUserMenu(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [showUserMenu])

  const handleChangePassword = () => {
    router.push("/forgot-password")
    setShowUserMenu(false)
  }

  // Add the handleSignOut function
  const handleSignOut = async () => {
    try {
      const { success, error } = await signOut()
      if (success) {
        // Redirect to login page after successful sign out
        router.push("/auth")
      } else {
        console.error("Error signing out:", error)
        alert("Failed to sign out. Please try again.")
      }
    } catch (error) {
      console.error("Unexpected error during sign out:", error)
      alert("An unexpected error occurred. Please try again.")
    }
  }

  // Get the letter grade based on the score
  const letterGrade = getLetterGrade(score)
  // Get the color class for the letter grade
  const gradeColorClass = getGradeColor(letterGrade)

  return (
    <div className="flex min-h-screen max-h-screen overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 border-r border-gray-200 bg-white flex flex-col overflow-y-auto">
        {/* Brand */}
        <div className="p-6">
          <h1 className="text-xl font-bold">Razeen</h1>
        </div>

        {/* Navigation */}
        <nav className="flex-1">
          {navItems.map((item) =>
            item.onClick ? (
              <button
                key={item.label}
                onClick={item.onClick}
                className={`flex items-center gap-3 py-3 px-6 text-gray-800 w-full text-left ${
                  item.active ? "bg-gray-100" : ""
                }`}
              >
                <item.icon size={20} />
                <span>{item.label}</span>
              </button>
            ) : (
              <Link
                key={item.label}
                href={item.href}
                className={`flex items-center gap-3 py-3 px-6 text-gray-800 no-underline ${
                  item.active ? "bg-gray-100" : ""
                }`}
              >
                <item.icon size={20} />
                <span>{item.label}</span>
              </Link>
            ),
          )}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-gray-100 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-gray-200 flex items-center justify-end px-6 bg-white flex-shrink-0">
          <div className="flex items-center gap-3 user-menu-container relative">
            <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center">
              <span className="text-sm">{user?.userName?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase()}</span>
            </div>
            <span className="text-sm">{user?.userName || "Name of the student"}</span>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="bg-transparent border-0 cursor-pointer flex p-1"
              aria-label="User menu"
            >
              <MoreVertical size={20} />
            </button>

            {/* User dropdown menu */}
            {showUserMenu && (
              <div className="absolute right-0 top-full mt-1 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                <div className="py-1" role="menu" aria-orientation="vertical">
                  <button
                    onClick={handleChangePassword}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                    role="menuitem"
                  >
                    <Lock size={16} />
                    Change Password
                  </button>
                  <button
                    onClick={handleSignOut}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center gap-2"
                    role="menuitem"
                  >
                    <LogOut size={16} />
                    Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto">
          {isHomepage ? (
            // Homepage layout with roadmap below content
            <div className="p-6 space-y-6">
              {/* Page content */}
              <div>{children}</div>

              {/* Roadmap (only on homepage) */}
              <div>
                {loading ? (
                  <div className="p-6 bg-white rounded-lg border border-gray-200">Loading milestones...</div>
                ) : (
                  <Roadmap milestones={milestones} />
                )}
              </div>
            </div>
          ) : (
            // Other pages - full width content without roadmap
            <div className="p-6">{children}</div>
          )}
        </div>
      </div>

      {/* Grade Modal */}
      {showGradeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md overflow-hidden">
            <div className="flex justify-between items-center border-b border-gray-200 p-4">
              <h3 className="font-semibold text-lg flex items-center gap-2">
                <GraduationCap className="text-blue-600" />
                Your Grade
              </h3>
              <button onClick={() => setShowGradeModal(false)} className="p-1 rounded-full hover:bg-gray-100">
                <X size={20} />
              </button>
            </div>

            <div className="p-6">
              {gradeLoading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
                </div>
              ) : gradeError ? (
                <div className="flex items-start gap-3 p-4 bg-red-50 rounded-lg">
                  <AlertCircle className="text-red-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-red-800 font-medium">Error Loading Grade</p>
                    <p className="text-red-600 mt-1">{gradeError}</p>
                  </div>
                </div>
              ) : score !== null ? (
                <div className="text-center">
                  {/* Grade Display */}
                  <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gray-100 mb-4">
                    <span className={`text-3xl font-bold ${gradeColorClass}`}>{letterGrade}</span>
                  </div>

                  {/* Score Information */}
                  <div className="space-y-2 mb-4">
                    <p className="text-gray-700">Your current grade for this course</p>
                    <div className="flex flex-col items-center justify-center gap-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Total Score:</span>
                        <span>{score}/100</span>
                      </div>
                    </div>
                  </div>

                  {/* Individual Evaluations */}

                  <div className="flex items-center justify-center gap-2 mt-4 text-green-600">
                    <CheckCircle size={18} />
                    <span>Grade has been assigned</span>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gray-100 mb-4">
                    <span className="text-3xl font-bold text-gray-400">N/A</span>
                  </div>
                  <h4 className="font-medium text-gray-800 mb-2">No Grade Available Yet</h4>
                  <p className="text-gray-600 mb-4">Your grade hasn't been assigned yet. This could be because:</p>
                  <ul className="text-left text-gray-600 space-y-2 mb-4 mx-auto max-w-xs">
                    <li className="flex items-start gap-2">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-gray-400 mt-1.5"></span>
                      <span>Your assignments are still being evaluated</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-gray-400 mt-1.5"></span>
                      <span>The grading period hasn't concluded</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-gray-400 mt-1.5"></span>
                      <span>You may need to complete pending tasks</span>
                    </li>
                  </ul>
                  <p className="text-sm text-blue-600">
                    Check back later or contact your instructor for more information.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
