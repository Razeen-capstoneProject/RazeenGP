"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { joinGroup } from "@/utils/supabase/queries"
import { useAuth } from "@/context/auth-context"

export function JoinGroupForm() {
  const { user } = useAuth()
  const router = useRouter()
  const [groupId, setGroupId] = useState("")
  const [entranceId, setEntranceId] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState({})
  const [redirecting, setRedirecting] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!user?.user_id) {
      setStatus({ success: false, message: "You must be logged in to join a group" })
      return
    }

    setIsLoading(true)
    setStatus({})

    try {
      console.log("Attempting to join group:", groupId, "with entrance ID:", entranceId)
      const result = await joinGroup(groupId, entranceId, user.user_id)

      setStatus(result)

      if (result.success) {
        setGroupId("")
        setEntranceId("")
        // Show success message before redirecting
        setTimeout(() => {
          setRedirecting(true)
          console.log("Redirecting to dashboard after successful group join")
          router.push("/dashboard")
          // Force a page reload to ensure the dashboard checks for the group again
          window.location.href = "/dashboard"
        }, 1500)
      } else {
        setIsLoading(false)
      }
    } catch (error) {
      console.error("Error joining group:", error)
      setStatus({
        success: false,
        message: error.message || "An unexpected error occurred while joining the group",
      })
      setIsLoading(false)
    }
  }

  const handleBackToLogin = () => {
    // Set redirecting state first
    setRedirecting(true)
    console.log("Redirecting to auth page")

    // Clear any user data from localStorage
    try {
      localStorage.removeItem("user")
      localStorage.removeItem("supabase.auth.token")
    } catch (error) {
      console.error("Error clearing localStorage:", error)
    }

    // Direct redirect to auth page
    window.location.href = "/auth"
  }

  if (redirecting) {
    return (
      <div className="w-full max-w-md border border-gray-200 rounded-lg p-6 shadow-sm">
        <div className="text-center">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p>Redirecting...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-md border border-gray-200 rounded-lg p-6 shadow-sm">
      <div className="text-center mb-4">
        <h2 className="text-2xl font-bold mb-2">Join Group</h2>
        <p className="text-gray-500">Enter your group ID to join your project group</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="groupId" className="block font-medium mb-2">
            Group ID
          </label>
          <input
            id="groupId"
            placeholder="Enter group ID"
            value={groupId}
            onChange={(e) => setGroupId(e.target.value)}
            required
            disabled={isLoading}
            className="w-full p-2.5 border border-gray-300 rounded-md text-base disabled:bg-gray-100"
          />
        </div>

        <div className="mb-4">
          <label htmlFor="entranceId" className="block font-medium mb-2">
            Entrance ID
          </label>
          <input
            id="entranceId"
            placeholder="Enter entrance ID"
            value={entranceId}
            onChange={(e) => setEntranceId(e.target.value)}
            required
            disabled={isLoading}
            className="w-full p-2.5 border border-gray-300 rounded-md text-base disabled:bg-gray-100"
          />
        </div>

        {status.message && (
          <div
            className={`p-2.5 mb-4 rounded ${
              status.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
            }`}
          >
            {status.message}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full p-3 bg-black text-white border-none rounded-md text-base cursor-pointer transition-opacity disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              <span>Joining...</span>
            </div>
          ) : (
            "Join Group"
          )}
        </button>
        <div className="mt-4 text-center">
          <button type="button" onClick={handleBackToLogin} className="text-sm text-gray-600 hover:underline">
            Back to Login
          </button>
        </div>
      </form>
    </div>
  )
}
