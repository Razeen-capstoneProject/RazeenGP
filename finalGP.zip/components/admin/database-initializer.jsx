"use client"

import { useState, useEffect } from "react"
import { checkDatabaseHealth, ensureDatabaseInitialized } from "@/utils/supabase/database-check"
import { seedDatabase } from "@/utils/supabase/database-setup"
import { AlertCircle, CheckCircle, Database, RefreshCw, Loader } from "lucide-react"

export function DatabaseInitializer() {
  const [healthStatus, setHealthStatus] = useState(null)
  const [isChecking, setIsChecking] = useState(false)
  const [isInitializing, setIsInitializing] = useState(false)
  const [isSeeding, setIsSeeding] = useState(false)
  const [message, setMessage] = useState(null)

  useEffect(() => {
    checkHealth()
  }, [])

  const checkHealth = async () => {
    setIsChecking(true)
    setMessage(null)

    try {
      const health = await checkDatabaseHealth()
      setHealthStatus(health)
    } catch (error) {
      console.error("Error checking database health:", error)
      setMessage({
        type: "error",
        text: `Failed to check database health: ${error.message}`,
      })
    } finally {
      setIsChecking(false)
    }
  }

  const initializeDatabase = async () => {
    setIsInitializing(true)
    setMessage(null)

    try {
      const result = await ensureDatabaseInitialized()

      if (result.success) {
        setMessage({
          type: "success",
          text: result.message,
        })

        // Refresh health status
        await checkHealth()
      } else {
        setMessage({
          type: "error",
          text: result.message,
        })
      }
    } catch (error) {
      console.error("Error initializing database:", error)
      setMessage({
        type: "error",
        text: `Failed to initialize database: ${error.message}`,
      })
    } finally {
      setIsInitializing(false)
    }
  }

  const seedDatabaseData = async () => {
    setIsSeeding(true)
    setMessage(null)

    try {
      const result = await seedDatabase()

      if (result.success) {
        setMessage({
          type: "success",
          text: "Database seeded successfully with test data",
        })

        // Refresh health status
        await checkHealth()
      } else {
        setMessage({
          type: "error",
          text: `Failed to seed database: ${result.error}`,
        })
      }
    } catch (error) {
      console.error("Error seeding database:", error)
      setMessage({
        type: "error",
        text: `Failed to seed database: ${error.message}`,
      })
    } finally {
      setIsSeeding(false)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Database className="text-blue-600" />
        <span>Database Management</span>
      </h2>

      {message && (
        <div
          className={`mb-4 p-3 rounded-md flex items-start gap-2 ${
            message.type === "error" ? "bg-red-50 text-red-700" : "bg-green-50 text-green-700"
          }`}
        >
          {message.type === "error" ? (
            <AlertCircle size={18} className="mt-0.5" />
          ) : (
            <CheckCircle size={18} className="mt-0.5" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-medium">Database Health Status</h3>
          <button
            onClick={checkHealth}
            disabled={isChecking}
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            {isChecking ? <Loader size={14} className="animate-spin" /> : <RefreshCw size={14} />}
            <span>{isChecking ? "Checking..." : "Refresh"}</span>
          </button>
        </div>

        {isChecking ? (
          <div className="p-4 bg-gray-50 rounded-md flex justify-center">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-gray-500">Checking database health...</span>
            </div>
          </div>
        ) : healthStatus ? (
          <div className="p-4 bg-gray-50 rounded-md">
            <div className="flex items-center gap-2 mb-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  healthStatus.status === "healthy"
                    ? "bg-green-500"
                    : healthStatus.status === "warning"
                      ? "bg-yellow-500"
                      : "bg-red-500"
                }`}
              ></div>
              <span className="font-medium">
                Status:{" "}
                {healthStatus.status === "healthy"
                  ? "Healthy"
                  : healthStatus.status === "warning"
                    ? "Warning"
                    : "Error"}
              </span>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <span className={`${healthStatus.connection ? "text-green-600" : "text-red-600"}`}>
                  {healthStatus.connection ? "✓" : "✗"} Connection
                </span>
              </div>

              {healthStatus.schema !== undefined && (
                <div className="flex items-center gap-2">
                  <span className={`${healthStatus.schema ? "text-green-600" : "text-red-600"}`}>
                    {healthStatus.schema ? "✓" : "✗"} Schema
                  </span>
                </div>
              )}

              {healthStatus.tableCounts && (
                <div className="mt-2">
                  <p className="text-gray-700 mb-1">Table Counts:</p>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                    {Object.entries(healthStatus.tableCounts).map(([table, data]) => (
                      <div key={table} className="flex justify-between">
                        <span className="text-gray-600">{table}:</span>
                        <span className="font-mono">{data.error ? "Error" : data.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {healthStatus.missingTables && healthStatus.missingTables.length > 0 && (
                <div className="mt-2 text-red-600">
                  <p>Missing tables:</p>
                  <ul className="list-disc list-inside">
                    {healthStatus.missingTables.map((table) => (
                      <li key={table}>{table}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="p-4 bg-gray-50 rounded-md text-gray-500 text-center">
            No health data available. Click "Refresh" to check database health.
          </div>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={initializeDatabase}
          disabled={isInitializing}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isInitializing ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Initializing...</span>
            </>
          ) : (
            <span>Initialize Database</span>
          )}
        </button>

        <button
          onClick={seedDatabaseData}
          disabled={isSeeding || (healthStatus && healthStatus.status !== "healthy")}
          className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isSeeding ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Seeding...</span>
            </>
          ) : (
            <span>Seed Test Data</span>
          )}
        </button>
      </div>

      <div className="mt-4 text-xs text-gray-500">
        <p>Note: Database initialization should only be needed once when setting up the application.</p>
        <p>Seeding will add test data and should only be used in development environments.</p>
      </div>
    </div>
  )
}
