export function DatabaseSetupGuide() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold mb-4">Supabase Database Setup Guide</h2>

      <div className="prose max-w-none">
        <h3>Step 1: Create a Supabase Project</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>
            Go to{" "}
            <a
              href="https://supabase.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline"
            >
              Supabase.com
            </a>{" "}
            and sign in or create an account
          </li>
          <li>Create a new project and give it a name (e.g., "student-portal")</li>
          <li>Choose a strong database password and save it securely</li>
          <li>Select a region closest to your users</li>
          <li>Wait for your project to be created (this may take a few minutes)</li>
        </ol>

        <h3>Step 2: Get Your API Keys</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>Once your project is created, go to the project dashboard</li>
          <li>Click on "Settings" in the sidebar, then "API"</li>
          <li>You'll find your "Project URL" and "anon public" key</li>
          <li>Copy these values as you'll need them for your environment variables</li>
        </ol>

        <h3>Step 3: Set Up Environment Variables</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>
            Create a <code>.env.local</code> file in your project root (if it doesn't exist)
          </li>
          <li>
            Add the following variables:
            <pre className="bg-gray-100 p-2 rounded-md overflow-x-auto my-2">
              NEXT_PUBLIC_SUPABASE_URL=your_project_url
              <br />
              NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
              <br />
              SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
              <br />
              SUPABASE_JWT_SECRET=your_jwt_secret
            </pre>
          </li>
          <li>You can find the service role key in the same API settings page</li>
          <li>
            For the JWT secret, go to "Settings" {"->"} "API" {"->"} "JWT Settings" {"->"} "JWT Secret"
          </li>
        </ol>

        <h3>Step 4: Initialize Database Schema</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>Go to the "SQL Editor" in your Supabase dashboard</li>
          <li>You can create tables manually using the SQL editor or use the "Table Editor" in the dashboard</li>
          <li>Alternatively, use the Database Initializer component in this application to set up the schema</li>
          <li>
            The schema should match the structure defined in <code>utils/supabase/database-schema.js</code>
          </li>
        </ol>

        <h3>Step 5: Set Up Authentication</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>Go to "Authentication" {">"} "Settings" in your Supabase dashboard</li>
          <li>Configure your site URL and redirect URLs</li>
          <li>Enable the authentication providers you want to use (Email, Google, etc.)</li>
          <li>For email authentication, you can use the default settings for development</li>
        </ol>

        <h3>Step 6: Set Up Storage (for Attachments)</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>Go to "Storage" in your Supabase dashboard</li>
          <li>
            Create the following buckets:
            <ul className="list-disc pl-5 my-2">
              <li>
                <code>announcement.backet</code> - for announcement attachments
              </li>
              <li>
                <code>feedback.backet</code> - for feedback attachments
              </li>
            </ul>
          </li>
          <li>Configure bucket permissions according to your needs</li>
        </ol>

        <h3>Step 7: Run the Application</h3>
        <ol className="list-decimal pl-5 mb-4">
          <li>
            Start your Next.js application with <code>npm run dev</code>
          </li>
          <li>Navigate to the Database Management page</li>
          <li>Use the Database Initializer to check the health of your database connection</li>
          <li>If needed, seed the database with test data for development</li>
        </ol>

        <div className="bg-blue-50 p-4 rounded-md mt-4">
          <h4 className="text-blue-800 font-medium">Important Notes</h4>
          <ul className="list-disc pl-5 text-blue-700">
            <li>
              Never commit your <code>.env.local</code> file or expose your API keys
            </li>
            <li>The service role key has admin privileges - use it carefully and only on the server side</li>
            <li>For production, set up proper Row Level Security (RLS) policies in Supabase</li>
            <li>Regularly backup your database using Supabase's backup features</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
