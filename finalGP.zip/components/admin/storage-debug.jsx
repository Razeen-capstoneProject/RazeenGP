"use client"

import { useState, useEffect } from "react"
import { listFiles, deleteFile, fileExists } from "@/utils/supabase/storage-utils"
import { AlertCircle, Folder, File, Trash2, RefreshCw, Search } from "lucide-react"

export function StorageDebug() {
  const [bucket, setBucket] = useState("sub.task.attachment")
  const [path, setPath] = useState("uploads")
  const [files, setFiles] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [deleteStatus, setDeleteStatus] = useState({})
  const [searchPath, setSearchPath] = useState("")
  const [searchResult, setSearchResult] = useState(null)
  const [searching, setSearching] = useState(false)

  const fetchFiles = async () => {
    setLoading(true)
    setError(null)

    try {
      const { files: fileList, error: listError } = await listFiles(bucket, path)

      if (listError) {
        throw new Error(listError)
      }

      setFiles(fileList)
    } catch (err) {
      console.error("Error fetching files:", err)
      setError(err.message || "Failed to fetch files")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteFile = async (filePath) => {
    setDeleteStatus((prev) => ({ ...prev, [filePath]: "deleting" }))

    try {
      const fullPath = path ? `${path}/${filePath}` : filePath
      const { success, error: deleteError } = await deleteFile(bucket, fullPath)

      if (deleteError) {
        throw new Error(deleteError)
      }

      if (success) {
        setDeleteStatus((prev) => ({ ...prev, [filePath]: "success" }))
        // Refresh the file list
        setTimeout(() => {
          fetchFiles()
          setDeleteStatus((prev) => {
            const newStatus = { ...prev }
            delete newStatus[filePath]
            return newStatus
          })
        }, 1500)
      }
    } catch (err) {
      console.error(`Error deleting file ${filePath}:`, err)
      setDeleteStatus((prev) => ({ ...prev, [filePath]: "error" }))
    }
  }

  const handleCheckFile = async () => {
    if (!searchPath) return

    setSearching(true)
    setSearchResult(null)

    try {
      const { exists, error: checkError } = await fileExists(bucket, searchPath)

      if (checkError) {
        throw new Error(checkError)
      }

      setSearchResult({ exists, path: searchPath })
    } catch (err) {
      console.error("Error checking file:", err)
      setSearchResult({ exists: false, error: err.message })
    } finally {
      setSearching(false)
    }
  }

  useEffect(() => {
    fetchFiles()
  }, [bucket, path])

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
      <h2 className="text-xl font-bold mb-4">Storage Debug Utility</h2>

      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-center gap-2">
          <AlertCircle size={18} />
          <span>{error}</span>
        </div>
      )}

      <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block font-medium mb-1 text-gray-700">Bucket</label>
          <input
            type="text"
            value={bucket}
            onChange={(e) => setBucket(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
          />
        </div>

        <div>
          <label className="block font-medium mb-1 text-gray-700">Path</label>
          <input
            type="text"
            value={path}
            onChange={(e) => setPath(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
          />
        </div>
      </div>

      <div className="mb-6">
        <h3 className="font-medium text-gray-700 mb-2">Check if File Exists</h3>
        <div className="flex gap-2">
          <input
            type="text"
            value={searchPath}
            onChange={(e) => setSearchPath(e.target.value)}
            placeholder="Enter full file path to check"
            className="flex-1 p-2 border border-gray-300 rounded-md"
          />
          <button
            onClick={handleCheckFile}
            disabled={searching || !searchPath}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center gap-2"
          >
            {searching ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                <span>Checking...</span>
              </>
            ) : (
              <>
                <Search size={16} />
                <span>Check</span>
              </>
            )}
          </button>
        </div>

        {searchResult && (
          <div
            className={`mt-2 p-2 rounded-md text-sm ${
              searchResult.error
                ? "bg-red-50 text-red-800"
                : searchResult.exists
                  ? "bg-green-50 text-green-800"
                  : "bg-yellow-50 text-yellow-800"
            }`}
          >
            {searchResult.error ? (
              <span>Error: {searchResult.error}</span>
            ) : (
              <span>
                File {searchResult.path} {searchResult.exists ? "exists" : "does not exist"} in bucket {bucket}
              </span>
            )}
          </div>
        )}
      </div>

      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium text-gray-700">Files in {path || "/"}</h3>
        <button
          onClick={fetchFiles}
          disabled={loading}
          className="flex items-center gap-1 text-blue-600 hover:text-blue-800"
        >
          <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
          <span>Refresh</span>
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-40">
          <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
        </div>
      ) : files.length === 0 ? (
        <div className="text-center py-8 text-gray-500">No files found in this location</div>
      ) : (
        <div className="border border-gray-200 rounded-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {files.map((file) => (
                <tr key={file.name} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {file.id ? (
                        <File size={16} className="text-blue-500 mr-2" />
                      ) : (
                        <Folder size={16} className="text-yellow-500 mr-2" />
                      )}
                      <span className="text-sm text-gray-900">{file.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-500">{file.id ? "File" : "Folder"}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-500">
                      {file.metadata?.size ? `${(file.metadata.size / 1024).toFixed(1)} KB` : "-"}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {file.id && (
                      <button
                        onClick={() => handleDeleteFile(file.name)}
                        disabled={deleteStatus[file.name] === "deleting"}
                        className={`flex items-center gap-1 text-sm ${
                          deleteStatus[file.name] === "error"
                            ? "text-red-600"
                            : deleteStatus[file.name] === "success"
                              ? "text-green-600"
                              : "text-red-600 hover:text-red-800"
                        }`}
                      >
                        {deleteStatus[file.name] === "deleting" ? (
                          <>
                            <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin"></span>
                            <span>Deleting...</span>
                          </>
                        ) : deleteStatus[file.name] === "success" ? (
                          <span>Deleted!</span>
                        ) : deleteStatus[file.name] === "error" ? (
                          <span>Failed to delete</span>
                        ) : (
                          <>
                            <Trash2 size={14} />
                            <span>Delete</span>
                          </>
                        )}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
