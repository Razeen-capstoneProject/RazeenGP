"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Save, AlertCircle } from "lucide-react"
import { updateSubTaskDescription, isLeaderForSubTask } from "@/utils/supabase/subtask-service"
import { isGroupLeader } from "@/utils/supabase/user-service"

export function DescriptionModal({ isOpen, onClose, subTask, onDescriptionUpdate, currentUser }) {
  const [description, setDescription] = useState("")
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  const [isLeader, setIsLeader] = useState(false)
  const [checkingRole, setCheckingRole] = useState(true)

  // Check if the current user is a leader
  useEffect(() => {
    async function checkLeaderStatus() {
      if (!currentUser?.user_id) {
        setIsLeader(false)
        setCheckingRole(false)
        return
      }

      try {
        // First check if the user is a group leader
        const leaderStatus = await isGroupLeader(currentUser.user_id)

        if (leaderStatus) {
          setIsLeader(true)
        } else if (subTask?.sub_task_id) {
          // If not a general leader, check if they're a leader for this specific sub-task
          const isLeaderForTask = await isLeaderForSubTask(currentUser.user_id, subTask.sub_task_id)
          setIsLeader(isLeaderForTask)
        } else {
          setIsLeader(false)
        }
      } catch (error) {
        console.error("Error checking leader status:", error)
        setIsLeader(false)
      } finally {
        setCheckingRole(false)
      }
    }

    if (isOpen) {
      checkLeaderStatus()
    }
  }, [isOpen, currentUser, subTask])

  // Initialize description when modal opens
  useEffect(() => {
    if (isOpen && subTask) {
      setDescription(subTask.description || "")
      setIsEditing(false)
      setError(null)
      setSuccess(false)
    }
  }, [isOpen, subTask])

  const handleSave = async () => {
    if (!subTask || !subTask.sub_task_id || !isLeader) return

    setIsSaving(true)
    setError(null)
    setSuccess(false)

    try {
      const { success, error: updateError } = await updateSubTaskDescription(subTask.sub_task_id, description)

      if (updateError) {
        throw new Error(updateError)
      }

      if (success) {
        setSuccess(true)
        setIsEditing(false)

        // Notify parent component about the update
        if (onDescriptionUpdate) {
          onDescriptionUpdate(subTask.sub_task_id, description)
        }

        // Close modal after a short delay
        setTimeout(() => {
          onClose()
        }, 1500)
      }
    } catch (err) {
      console.error("Error updating description:", err)
      setError(err.message || "Failed to update description")
    } finally {
      setIsSaving(false)
    }
  }

  // Handle click outside to close
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      // Only check for unsaved changes if user is a leader and in editing mode
      if (isLeader && isEditing && !window.confirm("Discard changes?")) {
        return
      }
      onClose()
    }
  }

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={handleBackdropClick}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-lg shadow-lg w-full max-w-md overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex justify-between items-center border-b border-gray-200 p-4">
            <h3 className="font-semibold text-lg">{isLeader && isEditing ? "Edit Description" : "Task Description"}</h3>
            <button
              onClick={onClose}
              className="p-1 rounded-full hover:bg-gray-100 transition-colors"
              disabled={isSaving}
            >
              <X size={20} />
            </button>
          </div>

          {/* Content */}
          <div className="p-4">
            {checkingRole ? (
              <div className="flex justify-center items-center py-8">
                <div className="w-6 h-6 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
                <span className="ml-2 text-gray-600">Checking permissions...</span>
              </div>
            ) : (
              <>
                {error && (
                  <div className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-start gap-2">
                    <AlertCircle size={18} className="mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {success && (
                  <div className="mb-4 p-3 bg-green-50 text-green-800 rounded-md">
                    Description updated successfully!
                  </div>
                )}

                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium text-gray-700">{subTask?.subTaskName || "Task"}</h4>
                    {isLeader && !isEditing && !isSaving && (
                      <button onClick={() => setIsEditing(true)} className="text-sm text-blue-600 hover:text-blue-800">
                        Edit
                      </button>
                    )}
                    {/* No indicator shown to students */}
                  </div>

                  {isLeader && isEditing ? (
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-md min-h-[150px] focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter task description..."
                      disabled={isSaving}
                    />
                  ) : (
                    <div className="p-3 bg-gray-50 rounded-md min-h-[150px] whitespace-pre-wrap">
                      {description ? (
                        description
                      ) : (
                        <span className="text-gray-400 italic">No description provided</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions - only shown for leaders in edit mode */}
                {isLeader && isEditing && (
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                      disabled={isSaving}
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSave}
                      disabled={isSaving}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 flex items-center gap-2"
                    >
                      {isSaving ? (
                        <>
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save size={16} />
                          Save
                        </>
                      )}
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
