"use client"

import { useState, useEffect, useRef } from "react"
import { formatDistanceToNow } from "date-fns"
import { deleteAnnouncement } from "@/utils/supabase/announcement-service"
import { motion, AnimatePresence } from "framer-motion"
import {
  Trash2,
  Download,
  FileText,
  AlertCircle,
  CheckCircle,
  Users,
  User,
  Search,
  Filter,
  ChevronDown,
  X,
  GraduationCap,
  Bell,
} from "lucide-react"
import { supabase } from "@/utils/supabase/client"

export function AnnouncementsTable({ announcements: initialAnnouncements, onAnnouncementDeleted }) {
  const [announcements, setAnnouncements] = useState([])
  const [deletingId, setDeletingId] = useState(null)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [roleFilter, setRoleFilter] = useState("all") // "all", "student", "instructor"
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastRefreshed, setLastRefreshed] = useState(new Date())
  const [newAnnouncementCount, setNewAnnouncementCount] = useState(0)
  // Removed real-time subscription
  const newAnnouncementsRef = useRef([])

  // Update local state when props change, with deduplication
  useEffect(() => {
    // Deduplicate announcements by announcement_id
    const uniqueAnnouncements = deduplicateAnnouncements(initialAnnouncements || [])
    setAnnouncements(uniqueAnnouncements)

    // Reset new announcement counter when we get fresh data
    setNewAnnouncementCount(0)
    newAnnouncementsRef.current = []
  }, [initialAnnouncements])

  // Helper function to deduplicate announcements
  const deduplicateAnnouncements = (announcementsList) => {
    const uniqueMap = new Map()

    // Use a Map to keep only the latest version of each announcement by ID
    announcementsList.forEach((announcement) => {
      uniqueMap.set(announcement.announcement_id, announcement)
    })

    // Convert Map values back to array and sort by created_at (newest first)
    return Array.from(uniqueMap.values()).sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
  }

  // Set up real-time subscription
  useEffect(() => {
    // Handler for real-time updates
    const handleInsert = (payload) => {
      console.log("New announcement received:", payload)

      // Track new announcement IDs
      newAnnouncementsRef.current.push(payload.new.announcement_id)

      // Update counter
      setNewAnnouncementCount((prev) => prev + 1)

      // Automatically add the new announcement to the state
      // We need to fetch the complete announcement data with committee_member info
      const fetchCompleteAnnouncement = async () => {
        try {
          const { data, error } = await supabase
            .from("announcement")
            .select(`
              *,
              committee_member:pcm_id(*)
            `)
            .eq("announcement_id", payload.new.announcement_id)
            .single()

          if (error) {
            console.error("Error fetching complete announcement:", error)
            return
          }

          // Process the announcement to extract file attachments
          let content = data.announ_content
          let fileAttachments = []

          // Check if announ_content contains attachment info
          if (typeof content === "object" && content !== null) {
            // Handle both single attachment and multiple attachments
            if (content.attachments && Array.isArray(content.attachments)) {
              fileAttachments = content.attachments
            } else if (content.attachment) {
              // Legacy format with single attachment
              fileAttachments = [content.attachment]
            }

            // Extract the text content
            content = content.text || ""
          }

          const processedAnnouncement = {
            ...data,
            announ_content: content,
            file_attachments: fileAttachments,
          }

          // Add the new announcement to the state, ensuring no duplicates
          setAnnouncements((prev) => {
            // Check if this announcement already exists in the state
            const exists = prev.some((a) => a.announcement_id === processedAnnouncement.announcement_id)
            if (exists) {
              // Replace the existing announcement with the new one
              return prev.map((a) =>
                a.announcement_id === processedAnnouncement.announcement_id ? processedAnnouncement : a,
              )
            } else {
              // Add the new announcement to the beginning of the array
              return [processedAnnouncement, ...prev]
            }
          })
        } catch (err) {
          console.error("Error fetching complete announcement:", err)
        }
      }

      fetchCompleteAnnouncement()
    }

    const handleUpdate = (payload) => {
      console.log("Announcement updated:", payload)

      // Update the announcement in the local state if it exists
      setAnnouncements((prev) =>
        prev.map((a) => (a.announcement_id === payload.new.announcement_id ? { ...a, ...payload.new } : a)),
      )
    }

    const handleDelete = (payload) => {
      console.log("Announcement deleted:", payload)

      // Remove the deleted announcement from the local state
      setAnnouncements((prev) => prev.filter((a) => a.announcement_id !== payload.old.announcement_id))
    }

    const handleError = (error) => {
      console.error("Subscription error:", error)
    }

    // Clean up subscription on unmount
  }, [])

  const handleRefresh = () => {
    setIsRefreshing(true)
    setLastRefreshed(new Date())

    // Reset new announcement counter
    setNewAnnouncementCount(0)
    newAnnouncementsRef.current = []

    // Notify parent component to refresh data
    if (onAnnouncementDeleted) {
      // We're reusing the onAnnouncementDeleted callback to trigger a refresh
      onAnnouncementDeleted("refresh")
    }

    // Reset refreshing state after a short delay
    setTimeout(() => {
      setIsRefreshing(false)
    }, 1000)
  }

  // Helper function to get committee member name
  const getCommitteeMemberName = (announcement) => {
    const member = announcement.committee_member
    if (!member) return "Unknown"

    // Try different possible property names
    return member.name || member.userName || member.user_name || member.fullName || member.full_name || "Unknown"
  }

  // Helper function to get committee member email
  const getCommitteeMemberEmail = (announcement) => {
    const member = announcement.committee_member
    if (!member) return ""

    return member.email || ""
  }

  // Helper function to get announcement content text
  const getAnnouncementContent = (announcement) => {
    const content = announcement.announ_content

    // If content is a string, return it directly
    if (typeof content === "string") {
      return content
    }

    // If content is an object with a text property, return that
    if (content && typeof content === "object" && "text" in content) {
      return content.text || ""
    }

    // If we can't determine the content, return an empty string
    return ""
  }

  // Filter announcements based on search query and role filter
  const filteredAnnouncements = announcements.filter((announcement) => {
    // Search filter
    const memberName = getCommitteeMemberName(announcement)
    const memberEmail = getCommitteeMemberEmail(announcement)
    const contentText = getAnnouncementContent(announcement)

    const matchesSearch =
      searchQuery === "" ||
      contentText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      memberName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      memberEmail.toLowerCase().includes(searchQuery.toLowerCase())

    // Role filter
    const matchesRole = roleFilter === "all" || announcement.user_role === roleFilter

    return matchesSearch && matchesRole
  })

  const handleDelete = async (id) => {
    setDeletingId(id)
    setError(null)
    setSuccess(null)

    try {
      const { success, error: deleteError } = await deleteAnnouncement(id)

      if (deleteError) {
        throw new Error(deleteError)
      }

      if (success) {
        setSuccess(`Announcement deleted successfully`)

        // Update local state
        setAnnouncements((prev) => prev.filter((a) => a.announcement_id !== id))

        // Notify parent component
        if (onAnnouncementDeleted) {
          onAnnouncementDeleted(id)
        }

        // Clear success message after a delay
        setTimeout(() => {
          setSuccess(null)
        }, 3000)
      }
    } catch (err) {
      console.error(`Error deleting announcement ${id}:`, err)
      setError(err.message || "Failed to delete announcement")
    } finally {
      setDeletingId(null)
    }
  }

  const formatDate = (dateString) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true })
    } catch (error) {
      return dateString
    }
  }

  // Get role badge component
  const getRoleBadge = (role) => {
    switch (role) {
      case "student":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <User size={12} className="mr-1" />
            Students
          </span>
        )
      case "instructor":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
            <GraduationCap size={12} className="mr-1" />
            Instructors
          </span>
        )
      case "all":
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <Users size={12} className="mr-1" />
            All Users
          </span>
        )
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold">Announcements</h2>

          {/* Real-time updates removed */}

          {/* New announcements indicator */}
          <AnimatePresence>
            {newAnnouncementCount > 0 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
              >
                <button
                  onClick={handleRefresh}
                  className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                >
                  <Bell size={12} className="mr-1 animate-pulse" />
                  {newAnnouncementCount} new {newAnnouncementCount === 1 ? "announcement" : "announcements"}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-center gap-2"
          >
            <AlertCircle size={18} />
            <span>{error}</span>
          </motion.div>
        )}

        {success && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 p-3 bg-green-50 text-green-800 rounded-md flex items-center gap-2"
          >
            <CheckCircle size={18} />
            <span>{success}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search and filter section */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search announcements..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
          >
            <Filter size={16} />
            <span>Filters</span>
            <ChevronDown size={16} className={`transition-transform ${showFilters ? "rotate-180" : ""}`} />
          </button>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-4"
            >
              <div className="p-4 bg-gray-50 rounded-md">
                <div className="flex items-center gap-4 mb-2">
                  <span className="text-sm font-medium text-gray-700">Target Role:</span>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => setRoleFilter("all")}
                      className={`px-3 py-1 text-sm rounded-full flex items-center gap-1 ${
                        roleFilter === "all" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      <Users size={12} />
                      <span>All Roles</span>
                    </button>
                    <button
                      onClick={() => setRoleFilter("student")}
                      className={`px-3 py-1 text-sm rounded-full flex items-center gap-1 ${
                        roleFilter === "student"
                          ? "bg-blue-600 text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      <User size={12} />
                      <span>Students</span>
                    </button>
                    <button
                      onClick={() => setRoleFilter("instructor")}
                      className={`px-3 py-1 text-sm rounded-full flex items-center gap-1 ${
                        roleFilter === "instructor"
                          ? "bg-blue-600 text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      <GraduationCap size={12} />
                      <span>Instructors</span>
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSearchQuery("")
                    setRoleFilter("all")
                  }}
                  className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800"
                >
                  <X size={14} />
                  <span>Clear filters</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Announcements table */}
      {filteredAnnouncements.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          {announcements.length === 0 ? (
            <p>No announcements have been created yet.</p>
          ) : (
            <p>No announcements match your search criteria.</p>
          )}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Content
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created At
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Target Role
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created By
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Attachments
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredAnnouncements.map((announcement) => {
                // Check if this is a new announcement
                const isNew = newAnnouncementsRef.current.includes(announcement.announcement_id)

                return (
                  <motion.tr
                    key={announcement.announcement_id}
                    className={`hover:bg-gray-50 ${isNew ? "bg-blue-50" : ""}`}
                    initial={isNew ? { backgroundColor: "#EFF6FF" } : {}}
                    animate={isNew ? { backgroundColor: "#FFFFFF" } : {}}
                    transition={{ duration: 5 }}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {announcement.announcement_id}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      <div className="max-w-xs break-words">{getAnnouncementContent(announcement)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(announcement.created_at)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{getRoleBadge(announcement.user_role)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {getCommitteeMemberName(announcement)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {announcement.file_attachments && announcement.file_attachments.length > 0 ? (
                        <div className="flex flex-col gap-2">
                          <div className="text-xs text-gray-500 mb-1">
                            {announcement.file_attachments.length} attachment
                            {announcement.file_attachments.length !== 1 ? "s" : ""}
                          </div>
                          {announcement.file_attachments.map((attachment, index) => (
                            <a
                              key={index}
                              href={attachment.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 hover:bg-blue-200"
                            >
                              <FileText size={12} className="mr-1" />
                              <span className="truncate max-w-[100px]">{attachment.filename}</span>
                              <Download size={12} className="ml-1" />
                            </a>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400 text-xs">No attachments</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => handleDelete(announcement.announcement_id)}
                        disabled={deletingId === announcement.announcement_id}
                        className="text-red-600 hover:text-red-900 flex items-center gap-1"
                      >
                        {deletingId === announcement.announcement_id ? (
                          <span className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></span>
                        ) : (
                          <Trash2 size={16} />
                        )}
                        <span>Delete</span>
                      </button>
                    </td>
                  </motion.tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
