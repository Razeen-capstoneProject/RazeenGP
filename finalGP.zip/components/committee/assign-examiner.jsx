"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import {
  getAllGroupsWithDetails,
  getAllInstructors,
  assignExaminerToGroup,
  removeExaminerFromGroup,
} from "@/utils/supabase/examiner-service"
import {
  Search,
  Filter,
  Users,
  UserCheck,
  UserX,
  AlertCircle,
  CheckCircle,
  ChevronDown,
  X,
  GraduationCap,
  UserPlus,
  Info,
  Plus,
  UserMinus,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function AssignExaminerComponent() {
  const { user } = useAuth()
  const [groups, setGroups] = useState([])
  const [instructors, setInstructors] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [instructorSearchQuery, setInstructorSearchQuery] = useState("") // New state for instructor search
  const [statusFilter, setStatusFilter] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [selectedGroup, setSelectedGroup] = useState(null)
  const [assigningExaminer, setAssigningExaminer] = useState(false)
  const [removingExaminer, setRemovingExaminer] = useState({})
  const [refreshing, setRefreshing] = useState(false)

  // Fetch groups and instructors
  useEffect(() => {
    async function fetchData() {
      if (!user?.user_id) return

      setLoading(true)
      setError(null)

      try {
        // Fetch groups with details
        const { groups: fetchedGroups, error: groupsError } = await getAllGroupsWithDetails()

        if (groupsError) {
          throw new Error(`Failed to fetch groups: ${groupsError}`)
        }

        setGroups(fetchedGroups)

        // Fetch instructors
        const { instructors: fetchedInstructors, error: instructorsError } = await getAllInstructors()

        if (instructorsError) {
          throw new Error(`Failed to fetch instructors: ${instructorsError}`)
        }

        setInstructors(fetchedInstructors)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError(err.message || "Failed to load data")
      } finally {
        setLoading(false)
        setRefreshing(false)
      }
    }

    fetchData()
  }, [user, refreshing])

  // Filter groups based on search and status filter
  const filteredGroups = groups.filter((group) => {
    // Search filter
    const matchesSearch =
      searchQuery === "" ||
      group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      group.supervisor?.userName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      group.examiners?.some((examiner) => examiner.userName?.toLowerCase().includes(searchQuery.toLowerCase()))

    // Status filter
    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "assigned" && group.hasExaminers) ||
      (statusFilter === "unassigned" && !group.hasExaminers)

    return matchesSearch && matchesStatus
  })

  // Handle refresh
  const handleRefresh = () => {
    setRefreshing(true)
    setSuccess(null)
    setError(null)
  }

  // Handle group selection
  const handleSelectGroup = (group) => {
    setSelectedGroup(group)
    setSuccess(null)
    setError(null)
    setInstructorSearchQuery("") // Reset instructor search when selecting a new group
  }

  // Handle assigning examiner
  const handleAssignExaminer = async (instructorId) => {
    if (!selectedGroup || !user?.user_id) return

    // Check if the instructor is the same as the supervisor
    if (selectedGroup.supervisor?.user_id === instructorId) {
      setError("Cannot assign the group supervisor as an examiner")
      return
    }

    // Check if this instructor is already assigned as an examiner
    if (selectedGroup.examiners?.some((examiner) => examiner.user_id === instructorId)) {
      setError("This instructor is already assigned as an examiner to this group")
      return
    }

    setAssigningExaminer(true)
    setError(null)
    setSuccess(null)

    try {
      const {
        success,
        updated,
        error: assignError,
        alreadyAssigned,
      } = await assignExaminerToGroup(selectedGroup.id, instructorId, user.user_id)

      if (assignError) {
        throw new Error(assignError)
      }

      if (success) {
        if (alreadyAssigned) {
          setSuccess("This instructor is already assigned as an examiner")
        } else {
          setSuccess(`Examiner ${updated ? "updated" : "assigned"} successfully`)
        }

        // Find the assigned instructor
        const assignedInstructor = instructors.find((i) => i.user_id === instructorId)

        if (assignedInstructor) {
          // Update the local state
          setGroups((prevGroups) =>
            prevGroups.map((group) => {
              if (group.id === selectedGroup.id) {
                // Add the new examiner to the list if not already there
                const updatedExaminers = [...(group.examiners || [])]
                if (!updatedExaminers.some((e) => e.user_id === assignedInstructor.user_id)) {
                  updatedExaminers.push(assignedInstructor)
                }

                return {
                  ...group,
                  examiners: updatedExaminers,
                  hasExaminers: true,
                }
              }
              return group
            }),
          )

          // Update the selected group
          setSelectedGroup((prevGroup) => {
            if (prevGroup) {
              // Add the new examiner to the list if not already there
              const updatedExaminers = [...(prevGroup.examiners || [])]
              if (!updatedExaminers.some((e) => e.user_id === assignedInstructor.user_id)) {
                updatedExaminers.push(assignedInstructor)
              }

              return {
                ...prevGroup,
                examiners: updatedExaminers,
                hasExaminers: true,
              }
            }
            return prevGroup
          })
        }
      }
    } catch (err) {
      console.error("Error assigning examiner:", err)
      setError(err.message || "Failed to assign examiner")
    } finally {
      setAssigningExaminer(false)
    }
  }

  // Handle removing examiner
  const handleRemoveExaminer = async (instructorId) => {
    if (!selectedGroup) return

    setRemovingExaminer((prev) => ({ ...prev, [instructorId]: true }))
    setError(null)
    setSuccess(null)

    try {
      const { success, error: removeError } = await removeExaminerFromGroup(selectedGroup.id, instructorId)

      if (removeError) {
        throw new Error(removeError)
      }

      if (success) {
        setSuccess("Examiner removed successfully")

        // Update the local state
        setGroups((prevGroups) =>
          prevGroups.map((group) => {
            if (group.id === selectedGroup.id) {
              const updatedExaminers = (group.examiners || []).filter((examiner) => examiner.user_id !== instructorId)

              return {
                ...group,
                examiners: updatedExaminers,
                hasExaminers: updatedExaminers.length > 0,
              }
            }
            return group
          }),
        )

        // Update the selected group
        setSelectedGroup((prevGroup) => {
          if (prevGroup) {
            const updatedExaminers = (prevGroup.examiners || []).filter((examiner) => examiner.user_id !== instructorId)

            return {
              ...prevGroup,
              examiners: updatedExaminers,
              hasExaminers: updatedExaminers.length > 0,
            }
          }
          return prevGroup
        })
      }
    } catch (err) {
      console.error("Error removing examiner:", err)
      setError(err.message || "Failed to remove examiner")
    } finally {
      setRemovingExaminer((prev) => ({ ...prev, [instructorId]: false }))
    }
  }

  // Get available instructors (excluding the supervisor and current examiners)
  const getAvailableInstructors = () => {
    if (!selectedGroup) return []

    // Get the IDs of instructors who are already assigned as examiners
    const assignedExaminerIds = (selectedGroup.examiners || []).map((examiner) => examiner.user_id)

    // Filter out the supervisor and assigned examiners
    let availableInstructors = instructors.filter((instructor) => {
      // Exclude supervisor
      if (selectedGroup.supervisor && instructor.user_id === selectedGroup.supervisor.user_id) {
        return false
      }

      // Exclude already assigned examiners
      if (assignedExaminerIds.includes(instructor.user_id)) {
        return false
      }

      return true
    })

    // Apply search filter if there's a search query
    if (instructorSearchQuery) {
      const query = instructorSearchQuery.toLowerCase()
      availableInstructors = availableInstructors.filter(
        (instructor) =>
          instructor.userName?.toLowerCase().includes(query) || instructor.email?.toLowerCase().includes(query),
      )
    }

    return availableInstructors
  }

  // Get filtered available instructors for display
  const filteredAvailableInstructors = getAvailableInstructors()

  if (loading && groups.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 flex justify-center items-center h-64">
        <div className="flex flex-col items-center">
          <div className="w-10 h-10 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-500">Loading groups and instructors...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <GraduationCap className="text-blue-600" />
          <span>Assign Examiners to Groups</span>
        </h2>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-center gap-2"
          >
            <AlertCircle size={18} />
            <span>{error}</span>
          </motion.div>
        )}

        {success && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 p-3 bg-green-50 text-green-800 rounded-md flex items-center gap-2"
          >
            <CheckCircle size={18} />
            <span>{success}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left column - Groups list */}
        <div>
          <div className="mb-4">
            <h3 className="text-lg font-medium mb-2">Project Groups</h3>

            {/* Search and filter */}
            <div className="mb-4">
              <div className="flex gap-2 mb-2">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search groups..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                >
                  <Filter size={16} />
                  <ChevronDown size={16} className={`transition-transform ${showFilters ? "rotate-180" : ""}`} />
                </button>
              </div>

              <AnimatePresence>
                {showFilters && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-gray-50 p-3 rounded-md mb-3"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm font-medium">Status:</span>
                      <div className="flex flex-wrap gap-2">
                        <button
                          onClick={() => setStatusFilter("all")}
                          className={`px-2 py-1 text-xs rounded-full ${
                            statusFilter === "all"
                              ? "bg-blue-600 text-white"
                              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                          }`}
                        >
                          All
                        </button>
                        <button
                          onClick={() => setStatusFilter("assigned")}
                          className={`px-2 py-1 text-xs rounded-full flex items-center gap-1 ${
                            statusFilter === "assigned"
                              ? "bg-green-600 text-white"
                              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                          }`}
                        >
                          <UserCheck size={12} />
                          <span>Has Examiners</span>
                        </button>
                        <button
                          onClick={() => setStatusFilter("unassigned")}
                          className={`px-2 py-1 text-xs rounded-full flex items-center gap-1 ${
                            statusFilter === "unassigned"
                              ? "bg-yellow-600 text-white"
                              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                          }`}
                        >
                          <UserX size={12} />
                          <span>No Examiners</span>
                        </button>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSearchQuery("")
                        setStatusFilter("all")
                      }}
                      className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <X size={12} />
                      <span>Clear filters</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Groups list */}
            <div className="border border-gray-200 rounded-md overflow-hidden">
              {filteredGroups.length === 0 ? (
                <div className="p-4 text-center text-gray-500">No groups found matching your criteria</div>
              ) : (
                <div className="max-h-[400px] overflow-y-auto">
                  {filteredGroups.map((group) => (
                    <button
                      key={group.id}
                      onClick={() => handleSelectGroup(group)}
                      className={`w-full text-left p-3 border-b border-gray-200 last:border-b-0 hover:bg-gray-50 transition-colors flex items-center justify-between ${
                        selectedGroup?.id === group.id ? "bg-blue-50" : ""
                      }`}
                    >
                      <div>
                        <div className="font-medium">{group.name}</div>
                        <div className="text-sm text-gray-500">Supervisor: {group.supervisor?.userName || "None"}</div>
                        {group.examiners && group.examiners.length > 0 && (
                          <div className="text-sm text-gray-500 mt-1">Examiners: {group.examiners.length}</div>
                        )}
                      </div>
                      <div>
                        {group.hasExaminers ? (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <UserCheck size={12} className="mr-1" />
                            Has Examiners
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            <UserX size={12} className="mr-1" />
                            No Examiners
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right column - Group details and examiner assignment */}
        <div>
          {selectedGroup ? (
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="text-lg font-medium mb-4">{selectedGroup.name}</h3>

              <div className="space-y-4">
                {/* Group details */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="text-sm font-medium text-gray-500 mb-1">Status</div>
                    <div className="font-medium">{selectedGroup.status || "N/A"}</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-md">
                    <div className="text-sm font-medium text-gray-500 mb-1">Progress</div>
                    <div className="font-medium">{selectedGroup.progress || 0}%</div>
                  </div>
                </div>

                {/* Supervisor info */}
                <div className="bg-blue-50 p-3 rounded-md">
                  <div className="text-sm font-medium text-blue-800 mb-1">Supervisor</div>
                  {selectedGroup.supervisor ? (
                    <div>
                      <div className="font-medium">{selectedGroup.supervisor.userName}</div>
                      <div className="text-sm text-gray-600">{selectedGroup.supervisor.email}</div>
                    </div>
                  ) : (
                    <div className="text-gray-500">No supervisor assigned</div>
                  )}
                </div>

                {/* Current examiners info */}
                <div className="bg-green-50 p-3 rounded-md">
                  <div className="text-sm font-medium text-green-800 mb-2 flex items-center justify-between">
                    <span>Current Examiners</span>
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">
                      {selectedGroup.examiners?.length || 0}
                    </span>
                  </div>

                  {selectedGroup.examiners && selectedGroup.examiners.length > 0 ? (
                    <div className="space-y-2 mt-3">
                      {selectedGroup.examiners.map((examiner) => (
                        <div
                          key={examiner.user_id}
                          className="flex justify-between items-center p-2 bg-white rounded-md border border-green-100"
                        >
                          <div>
                            <div className="font-medium">{examiner.userName}</div>
                            <div className="text-sm text-gray-600">{examiner.email}</div>
                          </div>
                          <button
                            onClick={() => handleRemoveExaminer(examiner.user_id)}
                            disabled={removingExaminer[examiner.user_id]}
                            className="text-red-600 hover:text-red-800 flex items-center gap-1 p-1"
                            title="Remove examiner"
                          >
                            {removingExaminer[examiner.user_id] ? (
                              <span className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></span>
                            ) : (
                              <UserMinus size={16} />
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-gray-500 mt-2">No examiners assigned</div>
                  )}
                </div>

                {/* Assign examiner section */}
                <div>
                  <h4 className="font-medium mb-2 flex items-center gap-1">
                    <UserPlus size={16} className="text-blue-600" />
                    <span>Assign New Examiner</span>
                  </h4>

                  {/* Warning if supervisor is not assigned */}
                  {!selectedGroup.supervisor && (
                    <div className="mb-3 p-2 bg-yellow-50 text-yellow-800 rounded-md flex items-start gap-2 text-sm">
                      <Info size={16} className="mt-0.5 flex-shrink-0" />
                      <span>This group doesn't have a supervisor assigned. You can still assign examiners.</span>
                    </div>
                  )}

                  {/* Instructor search bar */}
                  <div className="relative mb-3">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Search size={16} className="text-gray-400" />
                    </div>
                    <input
                      type="text"
                      placeholder="Search instructors by name or email..."
                      value={instructorSearchQuery}
                      onChange={(e) => setInstructorSearchQuery(e.target.value)}
                      className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    />
                    {instructorSearchQuery && (
                      <button
                        onClick={() => setInstructorSearchQuery("")}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>

                  {/* Available instructors */}
                  <div className="space-y-2 max-h-[200px] overflow-y-auto">
                    {filteredAvailableInstructors.length === 0 ? (
                      <div className="text-center p-4 text-gray-500 bg-gray-50 rounded-md">
                        {instructorSearchQuery ? (
                          <>
                            <div className="font-medium mb-1">No instructors match your search</div>
                            <div className="text-sm">Try a different search term or clear the search</div>
                          </>
                        ) : (
                          <>
                            {selectedGroup.supervisor
                              ? "All available instructors are already assigned as examiners"
                              : "No available instructors found"}
                          </>
                        )}
                      </div>
                    ) : (
                      <>
                        {/* Show search result count if searching */}
                        {instructorSearchQuery && (
                          <div className="text-sm text-gray-500 mb-2 px-1">
                            Found {filteredAvailableInstructors.length} instructor
                            {filteredAvailableInstructors.length !== 1 ? "s" : ""} matching "{instructorSearchQuery}"
                          </div>
                        )}

                        {filteredAvailableInstructors.map((instructor) => (
                          <button
                            key={instructor.user_id}
                            onClick={() => handleAssignExaminer(instructor.user_id)}
                            disabled={assigningExaminer}
                            className="w-full text-left p-3 border border-gray-200 rounded-md hover:bg-blue-50 transition-colors flex justify-between items-center"
                          >
                            <div>
                              <div className="font-medium">
                                {instructorSearchQuery ? (
                                  <HighlightMatch text={instructor.userName} query={instructorSearchQuery} />
                                ) : (
                                  instructor.userName
                                )}
                              </div>
                              <div className="text-sm text-gray-500">
                                {instructorSearchQuery ? (
                                  <HighlightMatch text={instructor.email} query={instructorSearchQuery} />
                                ) : (
                                  instructor.email
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-1 text-blue-600">
                              {assigningExaminer ? (
                                <span className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></span>
                              ) : (
                                <Plus size={16} />
                              )}
                            </div>
                          </button>
                        ))}
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="border border-gray-200 rounded-lg p-6 flex flex-col items-center justify-center h-full">
              <Users size={48} className="text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-700 mb-2">No Group Selected</h3>
              <p className="text-gray-500 text-center">
                Select a group from the list to view details and assign examiners
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// Helper component to highlight matching text
function HighlightMatch({ text, query }) {
  if (!text || !query) return text

  const parts = text.split(new RegExp(`(${query})`, "gi"))

  return (
    <>
      {parts.map((part, index) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <span key={index} className="bg-yellow-200 font-medium">
            {part}
          </span>
        ) : (
          part
        ),
      )}
    </>
  )
}
