"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Loader2, User, Users, UserCheck, Mail } from "lucide-react"
import { getGroupDetails } from "@/utils/supabase/group-committee-service"

export function GroupDetails({ groupId }) {
  const [group, setGroup] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchGroupDetails() {
      if (!groupId) return

      setLoading(true)
      const { group, error } = await getGroupDetails(groupId)

      if (error) {
        console.error("Error fetching group details:", error)
        setError(error)
      } else {
        setGroup(group)
      }

      setLoading(false)
    }

    fetchGroupDetails()
  }, [groupId])

  const handleBack = () => {
    router.push("/committee/groups")
  }

  // Get status badge color
  const getStatusColor = (status) => {
    if (status === "on track") return "bg-green-100 text-green-800"
    if (status === "late") return "bg-red-100 text-red-800"
    return "bg-gray-100 text-gray-800"
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-md text-red-800">
        <p>Error loading group details: {error}</p>
        <button
          onClick={handleBack}
          className="mt-4 px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
        >
          Back to Groups
        </button>
      </div>
    )
  }

  if (!group) {
    return (
      <div className="bg-yellow-50 p-4 rounded-md text-yellow-800">
        <p>Group not found</p>
        <button
          onClick={handleBack}
          className="mt-4 px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
        >
          Back to Groups
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Back button */}
      <button onClick={handleBack} className="flex items-center text-blue-600 hover:text-blue-800">
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Groups
      </button>

      {/* Group header */}
      <div className="bg-white p-6 rounded-md shadow">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold">{group.groupname}</h1>
            <div className="flex items-center mt-2 space-x-4">
              <div className="text-sm text-gray-500">Group ID: {group.groupid}</div>
              <span
                className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(group.group_status)}`}
              >
                {group.group_status}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Group details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Supervisor */}
        <div className="bg-white p-6 rounded-md shadow">
          <h2 className="text-lg font-semibold flex items-center mb-4">
            <UserCheck className="h-5 w-5 mr-2 text-blue-600" />
            Supervisor
          </h2>
          {group.supervisor ? (
            <div className="space-y-2">
              <div className="flex items-center">
                <User className="h-4 w-4 mr-2 text-gray-400" />
                <span>{group.supervisor.userName}</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2 text-gray-400" />
                <span>{group.supervisor.email}</span>
              </div>
            </div>
          ) : (
            <p className="text-gray-500 italic">No supervisor assigned</p>
          )}
        </div>

        {/* Group Leader */}
        <div className="bg-white p-6 rounded-md shadow">
          <h2 className="text-lg font-semibold flex items-center mb-4">
            <User className="h-5 w-5 mr-2 text-blue-600" />
            Group Leader
          </h2>
          {group.leader ? (
            <div className="space-y-2">
              <div className="flex items-center">
                <User className="h-4 w-4 mr-2 text-gray-400" />
                <span>{group.leader.userName}</span>
              </div>
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2 text-gray-400" />
                <span>{group.leader.email}</span>
              </div>
            </div>
          ) : (
            <p className="text-gray-500 italic">No leader assigned</p>
          )}
        </div>
      </div>

      {/* Students */}
      <div className="bg-white p-6 rounded-md shadow">
        <h2 className="text-lg font-semibold flex items-center mb-4">
          <Users className="h-5 w-5 mr-2 text-blue-600" />
          Students
        </h2>
        {group.students && group.students.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Name
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Email
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {group.students.map((student) => (
                  <tr key={student.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.email}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500 italic">No students in this group</p>
        )}
      </div>
    </div>
  )
}
