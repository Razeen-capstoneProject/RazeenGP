"use client"

import { useState, useRef, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { createAnnouncement } from "@/utils/supabase/announcement-service"
import { AlertCircle, CheckCircle, Upload, X, GraduationCap, User, Check, Paperclip, FileText } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function AnnouncementForm({ onAnnouncementCreated }) {
  const { user } = useAuth()
  const [content, setContent] = useState("")
  const [files, setFiles] = useState([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [selectedRoles, setSelectedRoles] = useState(["student"]) // Default to "student" role
  const [showFilters, setShowFilters] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const fileInputRef = useRef(null)
  const formRef = useRef(null)

  // Clear success message after a timeout
  useEffect(() => {
    let timer
    if (success) {
      timer = setTimeout(() => {
        setSuccess(null)
      }, 5000) // Clear success message after 5 seconds
    }
    return () => clearTimeout(timer)
  }, [success])

  // Clear error message after a timeout
  useEffect(() => {
    let timer
    if (error) {
      timer = setTimeout(() => {
        setError(null)
      }, 8000) // Clear error message after 8 seconds
    }
    return () => clearTimeout(timer)
  }, [error])

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files || [])
    if (selectedFiles.length > 0) {
      // Add new files to the existing files
      setFiles((prev) => [
        ...prev,
        ...selectedFiles.map((file) => ({
          id: `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          file,
          name: file.name,
          size: file.size,
          type: file.type,
        })),
      ])
    }
  }

  const removeFile = (fileId) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId))
  }

  const toggleRole = (role) => {
    // Special handling for "all" role
    if (role === "all") {
      if (selectedRoles.includes("all")) {
        // If "all" is already selected, remove it only if there's another role selected
        if (selectedRoles.length > 1) {
          setSelectedRoles(selectedRoles.filter((r) => r !== "all"))
        }
      } else {
        // If "all" is being selected, make it the only selection
        setSelectedRoles(["all"])
      }
      return
    }

    // For other roles (student, instructor)
    if (selectedRoles.includes(role)) {
      // If the role is already selected, remove it (unless it's the last one)
      if (selectedRoles.length > 1) {
        // If "all" is selected along with this role, remove "all" too
        if (selectedRoles.includes("all")) {
          setSelectedRoles(selectedRoles.filter((r) => r !== role && r !== "all"))
        } else {
          setSelectedRoles(selectedRoles.filter((r) => r !== role))
        }
      }
    } else {
      // Add the role, but remove "all" if it's selected
      if (selectedRoles.includes("all")) {
        setSelectedRoles([role])
      } else {
        setSelectedRoles([...selectedRoles, role])
      }
    }
  }

  // Format file size for display
  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + " B"
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB"
    else return (bytes / 1048576).toFixed(1) + " MB"
  }

  // Reset form to initial state
  const resetForm = () => {
    setContent("")
    setFiles([])
    setUploadProgress(0)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
    if (formRef.current) {
      formRef.current.reset()
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    // Prevent multiple submissions
    if (isSubmitting) return

    setIsSubmitting(true)
    setError(null)
    setSuccess(null)
    setUploadProgress(0)

    try {
      if (!content.trim()) {
        throw new Error("Announcement content is required")
      }

      if (selectedRoles.length === 0) {
        throw new Error("Please select at least one target audience")
      }

      // Simulate progress updates for better UX
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev < 90) return prev + 10
          return prev
        })
      }, 300)

      // Prepare announcement data
      const announcementData = {
        content: content.trim(),
        targetRoles: selectedRoles,
      }

      console.log("Creating announcement with data:", announcementData)

      // Extract the actual File objects from the files array
      const fileObjects = files.map((f) => f.file)

      // Create the announcement(s)
      const { announcements, error: createError } = await createAnnouncement(announcementData, fileObjects)

      clearInterval(progressInterval)
      setUploadProgress(100)

      if (createError) {
        throw new Error(createError)
      }

      if (announcements && announcements.length > 0) {
        let successMessage = "Announcement created successfully for: "
        if (selectedRoles.includes("all")) {
          successMessage += "All Users"
        } else {
          successMessage += selectedRoles
            .map((role) => {
              if (role === "student") return "Students"
              if (role === "instructor") return "Instructors"
              return role
            })
            .join(" and ")
        }

        setSuccess(successMessage)

        // Notify parent component about the new announcement
        if (onAnnouncementCreated && typeof onAnnouncementCreated === "function") {
          onAnnouncementCreated(announcements[0])
        }

        // Reset form after successful submission
        resetForm()
      } else {
        throw new Error("No announcements were created")
      }
    } catch (err) {
      console.error("Error creating announcement:", err)

      // Provide more detailed error messages based on the type of error
      if (err.message.includes("413") || err.message.includes("size")) {
        setError("File size too large. Please upload files smaller than 10MB each.")
      } else if (err.message.includes("network") || err.message.includes("connection")) {
        setError("Network error. Please check your internet connection and try again.")
      } else if (err.message.includes("permission") || err.message.includes("access")) {
        setError("Permission denied. You may not have the right access to create announcements.")
      } else {
        setError(err.message || "Failed to create announcement. Please try again later.")
      }
    } finally {
      setIsSubmitting(false)
      setUploadProgress(0)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold mb-4">Create Announcement</h2>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-center gap-2"
          >
            <AlertCircle size={18} />
            <div className="flex-1">
              <span className="font-medium">Error: </span>
              <span>{error}</span>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-red-700 hover:text-red-900"
              aria-label="Dismiss error"
            >
              <X size={16} />
            </button>
          </motion.div>
        )}

        {success && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 p-3 bg-green-50 text-green-800 rounded-md flex items-center gap-2"
          >
            <CheckCircle size={18} />
            <div className="flex-1">
              <span>{success}</span>
            </div>
            <button
              onClick={() => setSuccess(null)}
              className="text-green-700 hover:text-green-900"
              aria-label="Dismiss success message"
            >
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
        {/* Role selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Target Audience</label>
          <div className="mt-3 p-4 bg-gray-50 rounded-md">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Select Roles:</h4>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => toggleRole("student")}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md ${
                  selectedRoles.includes("student")
                    ? "bg-blue-100 text-blue-800 border border-blue-300"
                    : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                <User size={14} />
                <span>Students</span>
                {selectedRoles.includes("student") && <Check size={14} className="ml-1" />}
              </button>
              <button
                type="button"
                onClick={() => toggleRole("instructor")}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md ${
                  selectedRoles.includes("instructor")
                    ? "bg-blue-100 text-blue-800 border border-blue-300"
                    : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                <GraduationCap size={14} />
                <span>Instructors</span>
                {selectedRoles.includes("instructor") && <Check size={14} className="ml-1" />}
              </button>
            </div>
          </div>
        </div>

        {/* Announcement content */}
        <div>
          <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
            Announcement Content
          </label>
          <textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Enter announcement content..."
            rows={4}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            required
            disabled={isSubmitting}
          />
        </div>

        {/* File upload */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Attachments (Optional)</label>

          {/* File list */}
          <AnimatePresence>
            {files.length > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-3"
              >
                <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-gray-700 flex items-center gap-1">
                      <Paperclip size={14} />
                      <span>Selected Files ({files.length})</span>
                    </h4>
                    {!isSubmitting && (
                      <button
                        type="button"
                        onClick={() => setFiles([])}
                        className="text-xs text-red-600 hover:text-red-800"
                      >
                        Clear all
                      </button>
                    )}
                  </div>
                  <div className="max-h-40 overflow-y-auto space-y-2">
                    {files.map((file) => (
                      <motion.div
                        key={file.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="flex items-center justify-between p-2 bg-white rounded border border-gray-200"
                      >
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <FileText size={16} className="text-blue-500 flex-shrink-0" />
                          <div className="truncate flex-1 min-w-0">
                            <div className="text-sm font-medium truncate">{file.name}</div>
                            <div className="text-xs text-gray-500">{formatFileSize(file.size)}</div>
                          </div>
                        </div>
                        {!isSubmitting && (
                          <button
                            type="button"
                            onClick={() => removeFile(file.id)}
                            className="text-gray-400 hover:text-red-600 transition-colors"
                            title="Remove file"
                          >
                            <X size={16} />
                          </button>
                        )}
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* File upload button */}
          <div className="flex items-center justify-center w-full">
            <label
              htmlFor="file-upload"
              className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer 
                ${isSubmitting ? "bg-gray-100 border-gray-300 cursor-not-allowed" : "bg-gray-50 border-gray-300 hover:bg-gray-100"}`}
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 mb-3 text-gray-400" />
                <p className="mb-2 text-sm text-gray-500">
                  <span className="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-gray-500">Any file type (Max 10MB per file)</p>
              </div>
              <input
                id="file-upload"
                type="file"
                className="hidden"
                onChange={handleFileChange}
                disabled={isSubmitting}
                multiple
                ref={fileInputRef}
              />
            </label>
          </div>
        </div>

        {/* Upload progress */}
        <AnimatePresence>
          {isSubmitting && uploadProgress > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
            >
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                <div
                  className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 text-right">
                {uploadProgress < 100 ? "Uploading..." : "Processing..."} {uploadProgress}%
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Submit button */}
        <div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex justify-center items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                <span>Creating Announcement...</span>
              </>
            ) : (
              <span>Create Announcement</span>
            )}
          </button>
        </div>
      </form>
    </div>
  )
}
