"use client"

import { StatusDropdown } from "../status-dropdown"
import { updateSubTaskStatus } from "@/utils/supabase/subtask-service"
import { Calendar, User } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

export function SubTaskItem({ subTask, onStatusUpdate, isUpdating, setIsUpdating, isCurrentUser }) {
  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      return formatDistanceToNow(date, { addSuffix: true })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Handle status change
  const handleStatusChange = async (subTaskId, newStatus) => {
    setIsUpdating(true)

    try {
      const { success, error } = await updateSubTaskStatus(subTaskId, newStatus)

      if (error) {
        console.error("Error updating status:", error)
        return
      }

      if (success) {
        // Update the parent component's state
        onStatusUpdate(subTaskId, newStatus)
      }
    } catch (err) {
      console.error("Error in status update:", err)
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <div
      className={`p-3 rounded-md border ${isCurrentUser ? "border-blue-200 bg-blue-50" : "border-gray-200 bg-gray-50"}`}
    >
      <div className="flex justify-between items-start">
        <div>
          <h5 className="font-medium text-sm">{subTask.subTaskName}</h5>

          {subTask.description && <p className="text-xs text-gray-600 mt-1 mb-2">{subTask.description}</p>}

          <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-500 mt-2">
            <div className="flex items-center gap-1">
              <Calendar size={12} />
              <span>{formatDate(subTask.deadline)}</span>
            </div>

            {/* Display user name if available */}
            <div className="flex items-center gap-1">
              <User size={12} />
              <span>
                {subTask.users?.userName && subTask.users.userName.trim() !== ""
                  ? subTask.users.userName
                  : "Unknown Student"}
              </span>
            </div>

            {subTask.priority && (
              <span className={`px-2 py-0.5 rounded-full ${getPriorityColor(subTask.priority)}`}>
                {subTask.priority}
              </span>
            )}
          </div>
        </div>

        <StatusDropdown
          taskId={subTask.sub_task_id}
          currentStatus={subTask.status}
          onStatusChange={handleStatusChange}
          isUpdating={isUpdating}
          disabled={!isCurrentUser}
        />
      </div>
    </div>
  )
}
