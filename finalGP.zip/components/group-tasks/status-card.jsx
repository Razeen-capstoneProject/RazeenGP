"use client"
import { motion } from "framer-motion"
import { ExpandableSubTask } from "./expandable-sub-task"
import { Clock, CircleDot, CheckCircle } from "lucide-react"

export function StatusCard({ title, subTasks, icon, color, currentUserId, groupId }) {
  // Get the appropriate icon component
  const getIcon = () => {
    switch (icon) {
      case "clock":
        return <Clock size={18} className="text-gray-500" />
      case "circle-dot":
        return <CircleDot size={18} className="text-blue-500" />
      case "check-circle":
        return <CheckCircle size={18} className="text-green-500" />
      default:
        return <Clock size={18} className="text-gray-500" />
    }
  }

  // Get the appropriate color classes
  const getColorClasses = () => {
    switch (color) {
      case "gray":
        return "bg-gray-50 border-gray-200"
      case "blue":
        return "bg-blue-50 border-blue-200"
      case "green":
        return "bg-green-50 border-green-200"
      default:
        return "bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className={`rounded-lg border ${getColorClasses()} p-4 h-full`}>
      <div className="flex items-center gap-2 mb-4">
        {getIcon()}
        <h3 className="font-medium text-lg">{title === "In Progress" ? "On Progress" : title}</h3>
        <span className="ml-auto bg-white text-xs font-medium px-2 py-0.5 rounded-full">{subTasks.length}</span>
      </div>

      <div className="space-y-3 max-h-[calc(100vh-250px)] overflow-y-auto pr-1">
        {subTasks.length === 0 ? (
          <div className="text-center py-8 text-sm text-gray-500">No tasks</div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.1 }}
            className="space-y-3"
          >
            {subTasks.map((subTask) => (
              <ExpandableSubTask
                key={subTask.sub_task_id}
                subTask={subTask}
                isCurrentUser={subTask.student_id === currentUserId}
                groupId={groupId}
              />
            ))}
          </motion.div>
        )}
      </div>
    </div>
  )
}
