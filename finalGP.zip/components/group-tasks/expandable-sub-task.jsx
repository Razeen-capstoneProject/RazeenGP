"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown, ChevronRight, Calendar, User, ArrowUpRight, FileText } from "lucide-react"
import { updateSubTaskStatus } from "@/utils/supabase/subtask-service"
import { TaskDescriptionModal } from "@/components/task-description-modal"
import { useAuth } from "@/context/auth-context"

export function ExpandableSubTask({ subTask, isCurrentUser, groupId }) {
  const { user } = useAuth()
  const [isExpanded, setIsExpanded] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)
  const [showDescriptionModal, setShowDescriptionModal] = useState(false)

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      // Format as "Mar 17, 2025 9:00 PM"
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Handle status change
  const handleStatusChange = async (subTaskId, newStatus) => {
    setIsUpdating(true)

    try {
      const { success, error } = await updateSubTaskStatus(subTaskId, newStatus)

      if (error) {
        console.error("Error updating status:", error)
        return
      }

      if (success) {
        // Force a page refresh to update the UI
        window.location.reload()
      }
    } catch (err) {
      console.error("Error in status update:", err)
    } finally {
      setIsUpdating(false)
    }
  }

  // Get display name for the student
  const getStudentDisplayName = () => {
    // If there's no student assigned or no user data, return empty string
    if (!subTask.student_id || !subTask.users) {
      return "Unknown Student"
    }

    // If userName exists and is not empty, use it
    if (subTask.users.userName && subTask.users.userName.trim() !== "") {
      return subTask.users.userName
    }

    // Last resort fallback
    return "Unknown Student"
  }

  // Get the student display name
  const studentName = getStudentDisplayName()

  const handleDescriptionUpdate = (subTaskId, newDescription) => {
    // Force a page refresh to update the UI
    window.location.reload()
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-md border border-gray-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow ${
        isCurrentUser ? "border-l-4 border-l-blue-400" : ""
      }`}
    >
      {/* Collapsed view - improved task name visibility */}
      <div className="p-3 cursor-pointer flex justify-between items-center" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {isExpanded ? (
            <ChevronDown size={16} className="text-gray-500 flex-shrink-0" />
          ) : (
            <ChevronRight size={16} className="text-gray-500 flex-shrink-0" />
          )}
          <div className="min-w-0">
            <h4 className="font-medium text-base truncate">{subTask.subTaskName}</h4>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0 ml-2">
          {studentName && (
            <div className="flex items-center gap-1 text-xs text-gray-500">
              <User size={12} />
              <span>{studentName}</span>
            </div>
          )}
        </div>
      </div>

      {/* Expanded view - all details */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="border-t border-gray-200 p-3 bg-gray-50"
          >
            {subTask.description ? (
              <div className="flex items-center gap-2 mb-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setShowDescriptionModal(true)
                  }}
                  className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                  <FileText size={14} />
                  View Description
                </button>
              </div>
            ) : (
              <div className="text-sm text-gray-400 italic mb-3">No description provided</div>
            )}

            <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-gray-500 mb-3">
              <div className="flex items-center gap-1">
                <Calendar size={14} />
                <span>{formatDate(subTask.deadline)}</span>
              </div>

              {subTask.task?.taskname && (
                <div className="flex items-center gap-1">
                  <ArrowUpRight size={14} />
                  <span>From: {subTask.task.taskname}</span>
                </div>
              )}

              {subTask.priority && (
                <div className={`px-2 py-0.5 rounded-full text-xs ${getPriorityColor(subTask.priority)}`}>
                  {subTask.priority}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Description Modal */}
      <TaskDescriptionModal
        isOpen={showDescriptionModal}
        onClose={() => setShowDescriptionModal(false)}
        task={subTask}
        students={[]} // We'll pass an empty array since we don't have students here
        groupId={groupId}
        onUpdate={(updatedTask) => {
          // Force a page refresh to update the UI
          window.location.reload()
        }}
        currentUser={user}
      />
    </motion.div>
  )
}
