"use client"

import { useState } from "react"
import { SubTaskItem } from "./sub-task-item"
import { ChevronDown, ChevronRight, Calendar, Users } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { formatDistanceToNow } from "date-fns"

export function GroupTaskCard({
  task,
  subTasks,
  organizedSubTasks,
  isExpanded,
  onToggleExpand,
  onStatusUpdate,
  currentUserId,
}) {
  const [statusUpdating, setStatusUpdating] = useState({})

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      return formatDistanceToNow(date, { addSuffix: true })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Filter sub-tasks that belong to the current user
  const userSubTasks = subTasks.filter((st) => st.student_id === currentUserId)
  const otherSubTasks = subTasks.filter((st) => st.student_id !== currentUserId)

  // Organize user's sub-tasks by status
  const userSubTasksByStatus = {
    todo: userSubTasks.filter((st) => st.status?.toLowerCase() === "to do"),
    inProgress: userSubTasks.filter((st) => st.status?.toLowerCase() === "on progress"),
    done: userSubTasks.filter((st) => st.status?.toLowerCase() === "done"),
  }

  // Organize team members' sub-tasks by status
  const teamSubTasksByStatus = {
    todo: otherSubTasks.filter((st) => st.status?.toLowerCase() === "to do"),
    inProgress: otherSubTasks.filter((st) => st.status?.toLowerCase() === "on progress"),
    done: otherSubTasks.filter((st) => st.status?.toLowerCase() === "done"),
  }

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      {/* Task Header */}
      <div className="bg-gray-50 p-4 cursor-pointer" onClick={onToggleExpand}>
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-2">
            <div className="mt-1">
              {isExpanded ? (
                <ChevronDown size={18} className="text-gray-500" />
              ) : (
                <ChevronRight size={18} className="text-gray-500" />
              )}
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{task.taskname}</h3>
              {task.taskdescription && <p className="text-sm text-gray-600 mt-1">{task.taskdescription}</p>}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {task.deadline && (
              <div className="flex items-center gap-1 text-xs text-gray-500">
                <Calendar size={14} />
                <span>{formatDate(task.deadline)}</span>
              </div>
            )}

            <div className="flex items-center gap-1 text-xs text-gray-500">
              <Users size={14} />
              <span>{subTasks.length} sub-tasks</span>
            </div>
          </div>
        </div>

        {/* Status counts */}
        <div className="flex gap-4 mt-3 text-xs">
          <span className="flex items-center gap-1 text-gray-500">
            <span className="inline-block w-2 h-2 bg-gray-400 rounded-full"></span>
            To Do: {organizedSubTasks.todo.length}
          </span>
          <span className="flex items-center gap-1 text-blue-500">
            <span className="inline-block w-2 h-2 bg-blue-400 rounded-full"></span>
            In Progress: {organizedSubTasks.inProgress.length}
          </span>
          <span className="flex items-center gap-1 text-green-500">
            <span className="inline-block w-2 h-2 bg-green-400 rounded-full"></span>
            Done: {organizedSubTasks.done.length}
          </span>
        </div>
      </div>

      {/* Sub-tasks section */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="border-t border-gray-200 p-4">
              {/* User's sub-tasks section */}
              {userSubTasks.length > 0 && (
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-700 mb-3">Your Sub-Tasks</h4>

                  {/* To Do */}
                  {userSubTasksByStatus.todo.length > 0 && (
                    <div className="mb-4">
                      <h5 className="text-xs font-medium text-gray-500 mb-2 flex items-center gap-1">
                        <span className="inline-block w-2 h-2 bg-gray-400 rounded-full"></span>
                        To Do
                      </h5>
                      <div className="space-y-2 pl-2 border-l-2 border-gray-200">
                        {userSubTasksByStatus.todo.map((subTask) => (
                          <SubTaskItem
                            key={subTask.sub_task_id}
                            subTask={subTask}
                            onStatusUpdate={onStatusUpdate}
                            isUpdating={statusUpdating[subTask.sub_task_id]}
                            setIsUpdating={(isUpdating) =>
                              setStatusUpdating((prev) => ({ ...prev, [subTask.sub_task_id]: isUpdating }))
                            }
                            isCurrentUser={true}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* In Progress */}
                  {userSubTasksByStatus.inProgress.length > 0 && (
                    <div className="mb-4">
                      <h5 className="text-xs font-medium text-blue-500 mb-2 flex items-center gap-1">
                        <span className="inline-block w-2 h-2 bg-blue-400 rounded-full"></span>
                        In Progress
                      </h5>
                      <div className="space-y-2 pl-2 border-l-2 border-blue-200">
                        {userSubTasksByStatus.inProgress.map((subTask) => (
                          <SubTaskItem
                            key={subTask.sub_task_id}
                            subTask={subTask}
                            onStatusUpdate={onStatusUpdate}
                            isUpdating={statusUpdating[subTask.sub_task_id]}
                            setIsUpdating={(isUpdating) =>
                              setStatusUpdating((prev) => ({ ...prev, [subTask.sub_task_id]: isUpdating }))
                            }
                            isCurrentUser={true}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Done */}
                  {userSubTasksByStatus.done.length > 0 && (
                    <div>
                      <h5 className="text-xs font-medium text-green-500 mb-2 flex items-center gap-1">
                        <span className="inline-block w-2 h-2 bg-green-400 rounded-full"></span>
                        Done
                      </h5>
                      <div className="space-y-2 pl-2 border-l-2 border-green-200">
                        {userSubTasksByStatus.done.map((subTask) => (
                          <SubTaskItem
                            key={subTask.sub_task_id}
                            subTask={subTask}
                            onStatusUpdate={onStatusUpdate}
                            isUpdating={statusUpdating[subTask.sub_task_id]}
                            setIsUpdating={(isUpdating) =>
                              setStatusUpdating((prev) => ({ ...prev, [subTask.sub_task_id]: isUpdating }))
                            }
                            isCurrentUser={true}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Other team members' sub-tasks section */}
              {otherSubTasks.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-3">Team Members' Sub-Tasks</h4>

                  {/* To Do */}
                  {teamSubTasksByStatus.todo.length > 0 && (
                    <div className="mb-4">
                      <h5 className="text-xs font-medium text-gray-500 mb-2 flex items-center gap-1">
                        <span className="inline-block w-2 h-2 bg-gray-400 rounded-full"></span>
                        To Do
                      </h5>
                      <div className="space-y-2 pl-2 border-l-2 border-gray-200">
                        {teamSubTasksByStatus.todo.map((subTask) => (
                          <SubTaskItem
                            key={subTask.sub_task_id}
                            subTask={subTask}
                            onStatusUpdate={onStatusUpdate}
                            isUpdating={statusUpdating[subTask.sub_task_id]}
                            setIsUpdating={(isUpdating) =>
                              setStatusUpdating((prev) => ({ ...prev, [subTask.sub_task_id]: isUpdating }))
                            }
                            isCurrentUser={false}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* In Progress */}
                  {teamSubTasksByStatus.inProgress.length > 0 && (
                    <div className="mb-4">
                      <h5 className="text-xs font-medium text-blue-500 mb-2 flex items-center gap-1">
                        <span className="inline-block w-2 h-2 bg-blue-400 rounded-full"></span>
                        In Progress
                      </h5>
                      <div className="space-y-2 pl-2 border-l-2 border-blue-200">
                        {teamSubTasksByStatus.inProgress.map((subTask) => (
                          <SubTaskItem
                            key={subTask.sub_task_id}
                            subTask={subTask}
                            onStatusUpdate={onStatusUpdate}
                            isUpdating={statusUpdating[subTask.sub_task_id]}
                            setIsUpdating={(isUpdating) =>
                              setStatusUpdating((prev) => ({ ...prev, [subTask.sub_task_id]: isUpdating }))
                            }
                            isCurrentUser={false}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Done */}
                  {teamSubTasksByStatus.done.length > 0 && (
                    <div>
                      <h5 className="text-xs font-medium text-green-500 mb-2 flex items-center gap-1">
                        <span className="inline-block w-2 h-2 bg-green-400 rounded-full"></span>
                        Done
                      </h5>
                      <div className="space-y-2 pl-2 border-l-2 border-green-200">
                        {teamSubTasksByStatus.done.map((subTask) => (
                          <SubTaskItem
                            key={subTask.sub_task_id}
                            subTask={subTask}
                            onStatusUpdate={onStatusUpdate}
                            isUpdating={statusUpdating[subTask.sub_task_id]}
                            setIsUpdating={(isUpdating) =>
                              setStatusUpdating((prev) => ({ ...prev, [subTask.sub_task_id]: isUpdating }))
                            }
                            isCurrentUser={false}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {subTasks.length === 0 && (
                <p className="text-center text-gray-500 py-4">No sub-tasks assigned for this task.</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
