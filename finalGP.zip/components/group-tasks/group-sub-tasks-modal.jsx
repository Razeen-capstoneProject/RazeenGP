"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  X,
  Search,
  Filter,
  Edit,
  Trash2,
  ChevronDown,
  AlertCircle,
  CheckCircle,
  Calendar,
  Clock,
  CircleDot,
  FileText,
  ArrowUpRight,
} from "lucide-react"
import { getGroupSubTasks, getGroupStudents } from "@/utils/supabase/user-service"
import { updateSubTaskStatus, deleteSubTask } from "@/utils/supabase/subtask-service"
import { EditTaskModal } from "@/components/edit-task-modal"
import { ConfirmationDialog } from "@/components/confirmation-dialog"
import { TaskDescriptionModal } from "@/components/task-description-modal"

export function GroupSubTasksModal({ isOpen, onClose, groupId, user }) {
  const [tasks, setTasks] = useState([])
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [studentFilter, setStudentFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [statusUpdating, setStatusUpdating] = useState({})
  const [updateError, setUpdateError] = useState(null)
  const [isDeleting, setIsDeleting] = useState({})
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false)
  const [taskToDelete, setTaskToDelete] = useState(null)
  const [selectedTask, setSelectedTask] = useState(null)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showDescriptionModal, setShowDescriptionModal] = useState(false)

  useEffect(() => {
    if (!isOpen || !groupId) return

    async function fetchData() {
      setLoading(true)
      setError(null)

      try {
        // Get all sub-tasks for the group
        const { subTasks, error: tasksError } = await getGroupSubTasks(groupId)
        if (tasksError) {
          throw new Error(tasksError)
        }
        setTasks(subTasks)

        // Get all students in the group
        const { students, error: studentsError } = await getGroupStudents(groupId)
        if (studentsError) {
          console.error("Error fetching students:", studentsError)
        } else {
          setStudents(students)
        }
      } catch (err) {
        console.error("Error loading group data:", err)
        setError("Failed to load group sub-tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [isOpen, groupId])

  const handleStatusChange = async (subTaskId, newStatus) => {
    setStatusUpdating((prev) => ({ ...prev, [subTaskId]: true }))
    setUpdateError(null)

    try {
      const { success, subTask, error: updateErr } = await updateSubTaskStatus(subTaskId, newStatus)

      if (updateErr) {
        throw new Error(updateErr)
      }

      if (success && subTask) {
        // Update the sub-task in the list immediately
        setTasks((prev) => prev.map((task) => (task.sub_task_id === subTaskId ? { ...task, status: newStatus } : task)))
      }
    } catch (err) {
      console.error(`Error updating sub-task ${subTaskId} status:`, err)
      setUpdateError(`Failed to update task status: ${err.message}`)
    } finally {
      setStatusUpdating((prev) => ({ ...prev, [subTaskId]: false }))
    }
  }

  const handleEditTask = (task) => {
    setSelectedTask(task)
    setShowEditModal(true)
  }

  const handleViewDescription = (task) => {
    setSelectedTask(task)
    setShowDescriptionModal(true)
  }

  const handleTaskUpdate = async (updatedTask) => {
    setTasks((prev) => prev.map((task) => (task.sub_task_id === updatedTask.sub_task_id ? updatedTask : task)))
    setShowEditModal(false)
  }

  const handleDeleteTask = (task) => {
    setTaskToDelete(task)
    setShowDeleteConfirmation(true)
  }

  const confirmDeleteTask = async () => {
    if (!taskToDelete) return

    const taskId = taskToDelete.sub_task_id
    setIsDeleting((prev) => ({ ...prev, [taskId]: true }))
    setUpdateError(null)

    try {
      // Call the API to delete the task
      const { success, error: deleteError } = await deleteSubTask(taskId)

      if (deleteError) {
        throw new Error(deleteError)
      }

      if (success) {
        // Remove the task from the list
        setTasks((prev) => prev.filter((task) => task.sub_task_id !== taskId))
        setShowDeleteConfirmation(false)
        setTaskToDelete(null)
      }
    } catch (err) {
      console.error(`Error deleting sub-task ${taskId}:`, err)
      setUpdateError(`Failed to delete task: ${err.message}`)
    } finally {
      setIsDeleting((prev) => ({ ...prev, [taskId]: false }))
      setShowDeleteConfirmation(false)
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      // Format as "Mar 17, 2025 9:00 PM"
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Filter and search tasks
  const filteredTasks = tasks.filter((task) => {
    // Search filter
    const searchLower = searchQuery.toLowerCase()
    const matchesSearch =
      searchQuery === "" ||
      task.subTaskName?.toLowerCase().includes(searchLower) ||
      task.description?.toLowerCase().includes(searchLower) ||
      task.task?.taskname?.toLowerCase().includes(searchLower) ||
      task.users?.email?.toLowerCase().includes(searchLower)

    // Status filter
    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "todo" && task.status?.toLowerCase() === "to do") ||
      (statusFilter === "inprogress" && task.status?.toLowerCase() === "on progress") ||
      (statusFilter === "done" && task.status?.toLowerCase() === "done")

    // Student filter
    const matchesStudent = studentFilter === "all" || task.student_id === studentFilter

    // Date filter
    let matchesDate = true
    if (dateFilter !== "all") {
      const today = new Date()
      const taskDate = task.deadline ? new Date(task.deadline) : null

      if (dateFilter === "overdue") {
        matchesDate = taskDate && taskDate < today && task.status?.toLowerCase() !== "done"
      } else if (dateFilter === "today") {
        matchesDate =
          taskDate &&
          taskDate.getDate() === today.getDate() &&
          taskDate.getMonth() === today.getMonth() &&
          taskDate.getFullYear() === today.getFullYear()
      } else if (dateFilter === "week") {
        const nextWeek = new Date(today)
        nextWeek.setDate(today.getDate() + 7)
        matchesDate = taskDate && taskDate >= today && taskDate <= nextWeek
      }
    }

    return matchesSearch && matchesStatus && matchesStudent && matchesDate
  })

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-lg shadow-lg w-full max-w-6xl max-h-[90vh] overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex justify-between items-center border-b border-gray-200 p-4 bg-gray-50">
            <h3 className="font-semibold text-lg">Group Sub-Tasks Management</h3>
            <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 transition-colors">
              <X size={20} />
            </button>
          </div>

          {/* Content */}
          <div className="p-4 overflow-y-auto max-h-[calc(90vh-8rem)]">
            {updateError && <div className="mb-4 p-3 bg-red-50 text-red-800 rounded-md text-sm">{updateError}</div>}

            {/* Search and filter section */}
            <div className="mb-6">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search tasks by name, description, or student..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                >
                  <Filter size={16} />
                  <span>Filters</span>
                  <ChevronDown size={16} className={`transition-transform ${showFilters ? "rotate-180" : ""}`} />
                </button>
              </div>

              {/* Expandable filters */}
              {showFilters && (
                <div className="mb-4">
                  <div className="p-4 bg-gray-50 rounded-md grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Status filter */}
                    <div>
                      <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 mb-1">
                        Status
                      </label>
                      <select
                        id="status-filter"
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md"
                      >
                        <option value="all">All Statuses</option>
                        <option value="todo">To Do</option>
                        <option value="inprogress">In Progress</option>
                        <option value="done">Completed</option>
                      </select>
                    </div>

                    {/* Student filter */}
                    <div>
                      <label htmlFor="student-filter" className="block text-sm font-medium text-gray-700 mb-1">
                        Assigned To
                      </label>
                      <select
                        id="student-filter"
                        value={studentFilter}
                        onChange={(e) => setStudentFilter(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md"
                      >
                        <option value="all">All Students</option>
                        {students.map((student) => (
                          <option key={student.id} value={student.id}>
                            {student.name || student.email}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Date filter */}
                    <div>
                      <label htmlFor="date-filter" className="block text-sm font-medium text-gray-700 mb-1">
                        Due Date
                      </label>
                      <select
                        id="date-filter"
                        value={dateFilter}
                        onChange={(e) => setDateFilter(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md"
                      >
                        <option value="all">All Dates</option>
                        <option value="overdue">Overdue</option>
                        <option value="today">Due Today</option>
                        <option value="week">Due This Week</option>
                      </select>
                    </div>
                  </div>

                  {/* Filter actions */}
                  <div className="flex justify-end mt-3">
                    <button
                      onClick={() => {
                        setSearchQuery("")
                        setStatusFilter("all")
                        setStudentFilter("all")
                        setDateFilter("all")
                      }}
                      className="flex items-center gap-1 px-3 py-1 text-sm text-gray-600 hover:text-gray-900"
                    >
                      <X size={14} />
                      <span>Clear Filters</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Tasks table */}
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
              </div>
            ) : error ? (
              <div className="p-4 text-center">
                <div className="inline-flex items-center gap-2 text-red-600 mb-2">
                  <AlertCircle size={20} />
                  <span className="font-medium">Error</span>
                </div>
                <p className="text-gray-600">{error}</p>
              </div>
            ) : tasks.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No tasks have been assigned to group members yet.</p>
            ) : filteredTasks.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">No tasks match your search criteria.</p>
                <button
                  onClick={() => {
                    setSearchQuery("")
                    setStatusFilter("all")
                    setStudentFilter("all")
                    setDateFilter("all")
                  }}
                  className="mt-2 text-blue-600 hover:text-blue-800 text-sm"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Task
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Assigned To
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Status
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell"
                      >
                        Priority
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden md:table-cell"
                      >
                        Deadline
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden lg:table-cell"
                      >
                        Supervisor Task
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredTasks.map((task) => (
                      <tr key={task.sub_task_id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{task.subTaskName}</div>
                          <div className="text-xs text-gray-500">From: {task.task?.taskname || "Unknown"}</div>
                          {task.description && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                handleViewDescription(task)
                              }}
                              className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1 mt-1"
                            >
                              <FileText size={12} />
                              <span>View Description</span>
                            </button>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                              <span className="text-sm text-gray-600">
                                {task.users && task.users.userName ? task.users.userName[0].toUpperCase() : "?"}
                              </span>
                            </div>
                            <div className="text-sm text-gray-900">
                              {task.users && task.users.userName ? task.users.userName : "Unknown Student"}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div
                              className={`mr-2 flex items-center gap-1 ${
                                task.status?.toLowerCase() === "to do"
                                  ? "text-gray-400"
                                  : task.status?.toLowerCase() === "on progress"
                                    ? "text-blue-500"
                                    : "text-green-500"
                              }`}
                            >
                              {task.status?.toLowerCase() === "to do" ? (
                                <Clock size={16} />
                              ) : task.status?.toLowerCase() === "on progress" ? (
                                <CircleDot size={16} />
                              ) : (
                                <CheckCircle size={16} />
                              )}
                              <span className="text-sm font-medium">{task.status || "To Do"}</span>
                            </div>
                            <select
                              value={task.status || "To Do"}
                              onChange={(e) => handleStatusChange(task.sub_task_id, e.target.value)}
                              disabled={statusUpdating[task.sub_task_id]}
                              className="ml-2 text-sm border border-gray-300 rounded-md p-1"
                            >
                              <option value="To Do">To Do</option>
                              <option value="On Progress">In Progress</option>
                              <option value="Done">Done</option>
                            </select>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap hidden sm:table-cell">
                          <span
                            className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              task.priority?.toLowerCase() === "high"
                                ? "bg-red-100 text-red-800"
                                : task.priority?.toLowerCase() === "medium"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-green-100 text-green-800"
                            }`}
                          >
                            {task.priority || "Medium"}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap hidden md:table-cell">
                          <div className="flex items-center text-sm text-gray-500">
                            <Calendar size={14} className="mr-1" />
                            {formatDate(task.deadline)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap hidden lg:table-cell">
                          {task.task ? (
                            <div className="flex items-center gap-1">
                              <ArrowUpRight size={14} className="text-blue-500" />
                              <span className="text-sm font-medium text-gray-900">{task.task.taskname}</span>
                            </div>
                          ) : (
                            <span className="text-gray-400 text-sm">No parent task</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleEditTask(task)}
                              className="text-blue-600 hover:text-blue-900 flex items-center gap-1"
                            >
                              <Edit size={14} />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => handleDeleteTask(task)}
                              disabled={isDeleting[task.sub_task_id]}
                              className="text-red-600 hover:text-red-900 flex items-center gap-1"
                            >
                              {isDeleting[task.sub_task_id] ? (
                                <>
                                  <span className="w-3 h-3 border-2 border-red-600 border-t-transparent rounded-full animate-spin mr-1"></span>
                                  <span>Removing...</span>
                                </>
                              ) : (
                                <>
                                  <Trash2 size={14} />
                                  <span>Remove</span>
                                </>
                              )}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>

      {/* Edit Task Modal */}
      {showEditModal && selectedTask && (
        <EditTaskModal
          task={selectedTask}
          students={students}
          groupId={groupId}
          onClose={() => setShowEditModal(false)}
          onUpdate={handleTaskUpdate}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={showDeleteConfirmation}
        onClose={() => setShowDeleteConfirmation(false)}
        onConfirm={confirmDeleteTask}
        title="Remove Task"
        message={`Are you sure you want to remove this task${taskToDelete ? `: "${taskToDelete.subTaskName}"` : ""}? This action cannot be undone.`}
        confirmText="Remove"
        cancelText="Cancel"
        isLoading={taskToDelete ? isDeleting[taskToDelete.sub_task_id] : false}
        type="danger"
      />

      {/* Description Modal */}
      <TaskDescriptionModal
        isOpen={showDescriptionModal}
        onClose={() => setShowDescriptionModal(false)}
        task={selectedTask}
        students={students}
        groupId={groupId}
        onUpdate={handleTaskUpdate}
        currentUser={user}
      />
    </AnimatePresence>
  )
}
