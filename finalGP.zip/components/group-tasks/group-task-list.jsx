"use client"

import { useState, useEffect } from "react"
import { getGroupTasks, getGroupSubTasks } from "@/utils/supabase/user-service"
import { useAuth } from "@/context/auth-context"
import { StatusCard } from "./status-card"
import { AlertCircle, Layers } from "lucide-react"

export function GroupTaskList({ groupId }) {
  const { user } = useAuth()
  const [subTasks, setSubTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    async function fetchTasks() {
      if (!groupId || !user?.user_id) return

      setLoading(true)
      setError(null)

      try {
        // Fetch group tasks (needed for task names)
        const { tasks, error: tasksError } = await getGroupTasks(groupId)
        if (tasksError) throw new Error(tasksError)

        // Fetch sub-tasks
        const { subTasks: groupSubTasks, error: subTasksError } = await getGroupSubTasks(groupId)
        if (subTasksError) throw new Error(subTasksError)

        // Enrich sub-tasks with task information
        const enrichedSubTasks = groupSubTasks.map((subTask) => {
          const parentTask = tasks.find((task) => task.taskid === subTask.main_task)
          return {
            ...subTask,
            task: parentTask
              ? {
                  taskname: parentTask.taskname,
                  taskdescription: parentTask.taskdescription,
                }
              : null,
          }
        })

        setSubTasks(enrichedSubTasks)
      } catch (err) {
        console.error("Error fetching tasks:", err)
        setError("Failed to load group tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()
  }, [groupId, user])

  // Organize sub-tasks by status
  const todoTasks = subTasks.filter((task) => task.status?.toLowerCase() === "to do")
  const inProgressTasks = subTasks.filter((task) => task.status?.toLowerCase() === "on progress")
  const doneTasks = subTasks.filter((task) => task.status?.toLowerCase() === "done")

  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="inline-flex items-center gap-2 text-red-600 mb-2">
          <AlertCircle size={20} />
          <span className="font-medium">Error</span>
        </div>
        <p className="text-gray-600">{error}</p>
      </div>
    )
  }

  if (subTasks.length === 0) {
    return (
      <div className="p-6 text-center bg-white rounded-lg shadow-sm border border-gray-200">
        <p className="text-gray-500">No group tasks available.</p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <h2 className="text-xl font-semibold mb-5 flex items-center gap-2">
        <Layers size={22} className="text-blue-500" />
        <span>Group Sub-Tasks</span>
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <StatusCard
          title="To Do"
          subTasks={todoTasks}
          icon="clock"
          color="gray"
          currentUserId={user?.user_id}
          groupId={groupId}
        />
        <StatusCard
          title="In Progress"
          subTasks={inProgressTasks}
          icon="circle-dot"
          color="blue"
          currentUserId={user?.user_id}
          groupId={groupId}
        />
        <StatusCard
          title="Completed"
          subTasks={doneTasks}
          icon="check-circle"
          color="green"
          currentUserId={user?.user_id}
          groupId={groupId}
        />
      </div>
    </div>
  )
}
