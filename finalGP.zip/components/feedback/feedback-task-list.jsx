"use client"

import { useState, useEffect } from "react"
import { getStudentSubTasks } from "@/utils/supabase/user-service"
import { FeedbackTaskItem } from "./feedback-task-item"
import { AlertCircle, FileQuestion, Filter, Search, X, Eye, RefreshCw } from "lucide-react"
import { supabase } from "@/utils/supabase/client"
import { getAttachmentPublicUrl } from "@/utils/supabase/feedback-service"

export function FeedbackTaskList({ userId }) {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [mounted, setMounted] = useState(false)
  const [statusFilter, setStatusFilter] = useState("on progress") // Default to show only in-progress tasks
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [showAllTasks, setShowAllTasks] = useState(false) // New state to toggle between all tasks and only in-progress
  const [showAwaitingReview, setShowAwaitingReview] = useState(false) // New state to show tasks awaiting review

  useEffect(() => {
    setMounted(true)

    async function fetchTasks() {
      if (!userId) return

      setLoading(true)
      setError(null)

      try {
        // Get all tasks for this student
        const { subTasks, error: tasksError } = await getStudentSubTasks(userId)

        if (tasksError) {
          throw new Error(tasksError)
        }

        // Process tasks to include feedback information
        const processedTasks = await Promise.all(
          subTasks.map(async (task) => {
            try {
              // Check if the task has feedback
              const { data: feedbackData } = await supabase
                .from("feedback")
                .select("*")
                .eq("sub_task_id", task.sub_task_id)
                .order("feedbackid", { ascending: false })
                .limit(1)

              // Process attachment data if it exists
              const processedTask = { ...task }

              if (task.attachment) {
                // Ensure the attachment has a URL
                if (!task.attachment.url) {
                  processedTask.attachment = {
                    ...task.attachment,
                    url: getAttachmentPublicUrl(task.attachment),
                  }
                }
              }

              return {
                ...processedTask,
                feedback: feedbackData || [],
                // Add a flag to indicate if this task needs review (based on database field)
                feedbackNeedsReview: task.needs_review || false,
              }
            } catch (err) {
              console.error(`Error processing task ${task.sub_task_id}:`, err)
              return {
                ...task,
                feedback: [],
              }
            }
          }),
        )

        setTasks(processedTasks)
      } catch (err) {
        console.error("Error fetching tasks:", err)
        setError("Failed to load your tasks")
      } finally {
        setLoading(false)
      }
    }

    if (mounted && userId) {
      fetchTasks()
    }
  }, [userId, mounted])

  // Filter tasks based on status, search query, showAllTasks toggle, and awaiting review filter
  const filteredTasks = tasks.filter((task) => {
    // If showing only awaiting review tasks
    if (showAwaitingReview && !task.feedbackNeedsReview) {
      return false
    }

    // If not showing all tasks, only show "on progress" tasks
    if (!showAllTasks && !showAwaitingReview && task.status?.toLowerCase() !== "on progress") {
      return false
    }

    // Status filter (only applies when showing all tasks)
    if (showAllTasks && statusFilter !== "all" && task.status?.toLowerCase() !== statusFilter.toLowerCase()) {
      return false
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        task.subTaskName?.toLowerCase().includes(query) ||
        task.description?.toLowerCase().includes(query) ||
        task.task?.taskname?.toLowerCase().includes(query)
      )
    }

    return true
  })

  // Count tasks by status
  const todoCount = tasks.filter((t) => t.status?.toLowerCase() === "to do").length
  const inProgressCount = tasks.filter((t) => t.status?.toLowerCase() === "on progress").length
  const doneCount = tasks.filter((t) => t.status?.toLowerCase() === "done").length
  const awaitingReviewCount = tasks.filter((t) => t.feedbackNeedsReview).length

  // Handle task update with status change logic
  const handleTaskUpdate = (updatedTask) => {
    setTasks(
      tasks.map((task) => {
        if (task.sub_task_id === updatedTask.sub_task_id) {
          // If the task status changed from "on progress" to something else,
          // it will automatically disappear from the view unless showAllTasks is true
          return updatedTask
        }
        return task
      }),
    )
  }

  // Don't render until client-side hydration is complete
  if (!mounted) {
    return null
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="inline-flex items-center gap-2 text-red-600 mb-2">
          <AlertCircle size={20} />
          <span className="font-medium">Error</span>
        </div>
        <p className="text-gray-600">{error}</p>
      </div>
    )
  }

  // Search and filter section with "Show All Tasks" toggle
  const SearchAndFilterSection = () => (
    <div className="mb-6">
      <div className="flex flex-col md:flex-row gap-4 mb-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={16} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search tasks by name or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
        >
          <Filter size={16} />
          <span>Filters</span>
        </button>
      </div>

      {/* View Toggle Buttons */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <button
          onClick={() => {
            setShowAllTasks(false)
            setShowAwaitingReview(false)
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
            !showAllTasks && !showAwaitingReview
              ? "bg-blue-600 text-white hover:bg-blue-700"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          <Eye size={16} />
          <span>In Progress Tasks</span>
        </button>

        <button
          onClick={() => {
            setShowAllTasks(false)
            setShowAwaitingReview(true)
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
            showAwaitingReview
              ? "bg-yellow-600 text-white hover:bg-yellow-700"
              : "bg-yellow-100 text-yellow-700 hover:bg-yellow-200"
          }`}
        >
          <RefreshCw size={16} />
          <span>Awaiting Review ({awaitingReviewCount})</span>
        </button>
      </div>

      {showFilters && (
        <div className="mb-4 p-4 bg-gray-50 rounded-md">
          <div className="flex items-center gap-4 mb-2">
            <span className="text-sm font-medium text-gray-700">Status:</span>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setStatusFilter("all")}
                className={`px-3 py-1 text-sm rounded-full ${
                  statusFilter === "all" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                All ({tasks.length})
              </button>
              <button
                onClick={() => setStatusFilter("to do")}
                className={`px-3 py-1 text-sm rounded-full ${
                  statusFilter === "to do" ? "bg-gray-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                To Do ({todoCount})
              </button>
              <button
                onClick={() => setStatusFilter("on progress")}
                className={`px-3 py-1 text-sm rounded-full ${
                  statusFilter === "on progress"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                In Progress ({inProgressCount})
              </button>
              <button
                onClick={() => setStatusFilter("done")}
                className={`px-3 py-1 text-sm rounded-full ${
                  statusFilter === "done" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Done ({doneCount})
              </button>
            </div>
          </div>

          {(statusFilter !== "all" || searchQuery) && (
            <button
              onClick={() => {
                setStatusFilter("all")
                setSearchQuery("")
              }}
              className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800"
            >
              <X size={14} />
              <span>Clear filters</span>
            </button>
          )}
        </div>
      )}
    </div>
  )

  // No tasks message with context based on filters
  const NoTasksMessage = () => {
    if (tasks.length === 0) {
      return (
        <div className="p-8 text-center bg-gray-50 rounded-lg border border-gray-200">
          <FileQuestion size={48} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Tasks Found</h3>
          <p className="text-gray-500">You don't have any assigned tasks at the moment.</p>
        </div>
      )
    }

    if (showAwaitingReview && awaitingReviewCount === 0) {
      return (
        <div className="p-8 text-center bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Tasks Awaiting Review</h3>
          <p className="text-gray-500">You don't have any tasks currently awaiting review.</p>
          <button
            onClick={() => setShowAwaitingReview(false)}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Show In Progress Tasks
          </button>
        </div>
      )
    }

    if (!showAllTasks && !showAwaitingReview && inProgressCount === 0) {
      return (
        <div className="p-8 text-center bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Tasks In Progress</h3>
          <p className="text-gray-500">You don't have any tasks currently in progress.</p>
          <button
            onClick={() => setShowAllTasks(true)}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Show All Tasks
          </button>
        </div>
      )
    }

    return (
      <div className="p-8 text-center bg-gray-50 rounded-lg border border-gray-200">
        <h3 className="text-lg font-medium text-gray-800 mb-2">No Matching Tasks</h3>
        <p className="text-gray-500">No tasks match your current filters.</p>
        <button
          onClick={() => {
            setStatusFilter("all")
            setSearchQuery("")
            setShowAwaitingReview(false)
          }}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Clear Filters
        </button>
      </div>
    )
  }

  return (
    <div>
      <SearchAndFilterSection />

      {filteredTasks.length === 0 ? (
        <NoTasksMessage />
      ) : (
        <div className="space-y-6 overflow-y-auto max-h-[calc(100vh-200px)]">
          {filteredTasks.map((task) => (
            <FeedbackTaskItem
              key={task.sub_task_id}
              task={task}
              onTaskUpdate={handleTaskUpdate}
              showFileUploadOnStatusChange={true}
            />
          ))}
        </div>
      )}
    </div>
  )
}
