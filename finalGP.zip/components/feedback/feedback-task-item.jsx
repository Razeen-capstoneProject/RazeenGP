"use client"

import { useState, useEffect, useRef } from "react"
import { uploadAttachment, getSubTaskFeedback, requestAdditionalFeedback } from "@/utils/supabase/feedback-service"
import { updateSubTaskStatus } from "@/utils/supabase/subtask-service"
import {
  Calendar,
  FileText,
  Upload,
  Paperclip,
  X,
  Download,
  MessageSquare,
  AlertCircle,
  CheckCircle,
  ChevronDown,
  ChevronRight,
  Clock,
  CircleDot,
  RefreshCw,
  CheckSquare,
  AlertTriangle,
  FileUp,
} from "lucide-react"

export function FeedbackTaskItem({ task, onTaskUpdate, showFileUploadOnStatusChange = false }) {
  const [expanded, setExpanded] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState(null)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [selectedFile, setSelectedFile] = useState(null)
  const [feedback, setFeedback] = useState(task.feedback?.[0] || null)
  const [loadingFeedback, setLoadingFeedback] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [isHovering, setIsHovering] = useState(false)
  const [currentStatus, setCurrentStatus] = useState(task.status || "On Progress")
  const [previousStatus, setPreviousStatus] = useState(task.status || "On Progress")
  const [updatingStatus, setUpdatingStatus] = useState(false)
  const [statusUpdateError, setStatusUpdateError] = useState(null)
  const [showFeedbackRequest, setShowFeedbackRequest] = useState(false)
  const [feedbackMessage, setFeedbackMessage] = useState("")
  const [submittingFeedbackRequest, setSubmittingFeedbackRequest] = useState(false)
  const [showFileUploadPrompt, setShowFileUploadPrompt] = useState(false)
  const [showNewAttachmentSection, setShowNewAttachmentSection] = useState(false)
  const [feedbackVisible, setFeedbackVisible] = useState(true)
  const [hasStatusChanged, setHasStatusChanged] = useState(false)
  const [isReplacingFile, setIsReplacingFile] = useState(false)
  const fileInputRef = useRef(null)

  useEffect(() => {
    setMounted(true)
    setCurrentStatus(task.status || "On Progress")
    setPreviousStatus(task.status || "On Progress")

    // Initialize feedback from task
    if (task.feedback && task.feedback.length > 0) {
      setFeedback(task.feedback[0])
    }
  }, [task])

  // Format date for display - using a stable approach to avoid hydration mismatches
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    if (!mounted) {
      return "Loading date..."
    }

    try {
      const date = new Date(dateString)

      // Use a stable date format that won't change between server and client
      return new Intl.DateTimeFormat("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      }).format(date)
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
      setUploadError(null)
      setUploadSuccess(false)

      // If there's an existing attachment, mark that we're replacing it
      if (task.attachment) {
        setIsReplacingFile(true)
      }
    }
  }

  const handleUpload = async () => {
    if (!selectedFile) {
      setUploadError("Please select a file to upload")
      return
    }

    setUploading(true)
    setUploadError(null)
    setUploadSuccess(false)

    try {
      console.log(`Uploading file: ${selectedFile.name} for sub-task: ${task.sub_task_id}`)

      // If we're replacing a file, show a message about it
      if (isReplacingFile) {
        console.log(`Replacing existing file: ${task.attachment.filename} (path: ${task.attachment.path})`)
      }

      const { success, attachment, deletionResult, error } = await uploadAttachment(task.sub_task_id, selectedFile)

      if (error) {
        throw new Error(error)
      }

      if (success) {
        console.log("File uploaded successfully:", attachment)

        // Log deletion result if available
        if (deletionResult) {
          console.log("Previous file deletion result:", deletionResult)

          // If deletion failed but upload succeeded, show a warning
          if (!deletionResult.success) {
            console.warn("Warning: Previous file could not be deleted:", deletionResult.error)
          }
        }

        setUploadSuccess(true)
        setSelectedFile(null)
        setShowFileUploadPrompt(false)
        setShowNewAttachmentSection(false)
        setIsReplacingFile(false)

        // Update the task with the new attachment
        const updatedTask = {
          ...task,
          attachment,
          // Mark that feedback needs review (this is just UI state, not persisted)
          feedbackNeedsReview: true,
        }

        onTaskUpdate(updatedTask)
      }
    } catch (err) {
      console.error("Error uploading attachment:", err)
      setUploadError(err.message || "Failed to upload attachment")
    } finally {
      setUploading(false)
    }
  }

  const handleViewFeedback = async () => {
    if (feedback) return // Already loaded

    setLoadingFeedback(true)

    try {
      const { feedback: taskFeedback, error } = await getSubTaskFeedback(task.sub_task_id)

      if (error) {
        console.error("Error fetching feedback:", error)
        return
      }

      setFeedback(taskFeedback)
    } catch (err) {
      console.error("Error loading feedback:", err)
    } finally {
      setLoadingFeedback(false)
    }
  }

  // Update the handleStatusChange function to not rely on needs_review column
  const handleStatusChange = async (newStatus) => {
    if (newStatus === currentStatus) return

    // Store the previous status before updating
    setPreviousStatus(currentStatus)
    setHasStatusChanged(true)

    setUpdatingStatus(true)
    setStatusUpdateError(null)

    try {
      const { success, error } = await updateSubTaskStatus(task.sub_task_id, newStatus)

      if (error) {
        throw new Error(error)
      }

      if (success) {
        // If changing TO "On Progress" FROM another status and there's existing feedback
        if (newStatus === "On Progress" && currentStatus !== "On Progress") {
          // If there's existing feedback, we'll visually hide it (but keep it in the database)
          if (feedback) {
            setFeedbackVisible(false)
          }

          // If there's an existing attachment, show the option to upload a new one
          if (task.attachment) {
            setShowNewAttachmentSection(true)
            setExpanded(true) // Expand the task to show the new attachment section
          } else {
            // If no attachment, show the regular file upload prompt
            setShowFileUploadPrompt(true)
            setExpanded(true)
          }

          // Show the feedback request form
          setShowFeedbackRequest(true)
        }

        setCurrentStatus(newStatus)

        // Update the task with the new status
        const updatedTask = {
          ...task,
          status: newStatus,
          // Set a UI-only flag to indicate feedback needs review
          feedbackNeedsReview: newStatus === "On Progress" && feedback ? true : false,
        }
        onTaskUpdate(updatedTask)
      }
    } catch (err) {
      console.error("Error updating status:", err)
      setStatusUpdateError(err.message || "Failed to update status")
    } finally {
      setUpdatingStatus(false)
    }
  }

  const handleFeedbackRequest = async () => {
    if (!feedbackMessage.trim()) {
      setStatusUpdateError("Please provide a message explaining your request for additional feedback")
      return
    }

    setSubmittingFeedbackRequest(true)
    setStatusUpdateError(null)

    try {
      const { success, error } = await requestAdditionalFeedback(
        task.sub_task_id,
        feedbackMessage,
        !!task.attachment, // Whether there's already an attachment
      )

      if (error) {
        throw new Error(error)
      }

      if (success) {
        setShowFeedbackRequest(false)
        setFeedbackMessage("")

        // If there's no attachment yet, we'll need to show the upload section
        if (!task.attachment) {
          setExpanded(true)
        }
      }
    } catch (err) {
      console.error("Error requesting additional feedback:", err)
      setStatusUpdateError(err.message || "Failed to submit feedback request")
    } finally {
      setSubmittingFeedbackRequest(false)
    }
  }

  // Don't render until client-side hydration is complete
  if (!mounted) {
    return null
  }

  const getAttachmentPublicUrl = (attachment) => {
    return `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/${attachment.bucket}/${attachment.path}`
  }

  // Get status badge color and icon
  const getStatusBadge = (status) => {
    switch (status.toLowerCase()) {
      case "to do":
        return {
          color: "bg-gray-100 text-gray-800",
          icon: <Clock size={12} className="text-gray-500" />,
        }
      case "on progress":
        return {
          color: "bg-blue-100 text-blue-800",
          icon: <CircleDot size={12} className="text-blue-500" />,
        }
      case "done":
        return {
          color: "bg-green-100 text-green-800",
          icon: <CheckCircle size={12} className="text-green-500" />,
        }
      default:
        return {
          color: "bg-blue-100 text-blue-800",
          icon: <CircleDot size={12} className="text-blue-500" />,
        }
    }
  }

  const statusBadge = getStatusBadge(currentStatus)

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md">
      {/* Task Header - with visual cues for clickability */}
      <div
        className={`p-4 cursor-pointer flex justify-between items-center bg-blue-50 border-l-4 border-blue-400 relative ${
          isHovering ? "bg-blue-100" : "bg-blue-50"
        } transition-colors duration-200`}
        onClick={() => {
          setExpanded(!expanded)
          if (!expanded) {
            handleViewFeedback()
          }
        }}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
        aria-expanded={expanded}
        role="button"
        tabIndex={0}
        aria-label={`${task.subTaskName} - Click to ${expanded ? "collapse" : "expand"} and manage attachments`}
      >
        <div className="flex-1">
          <div className="flex items-center gap-2">
            {expanded ? (
              <ChevronDown size={18} className="text-blue-500" />
            ) : (
              <ChevronRight size={18} className="text-blue-500" />
            )}
            <h3 className="font-medium text-lg text-gray-900">{task.subTaskName}</h3>

            {/* Show indicator if feedback needs review after status change */}
            {task.feedbackNeedsReview && (
              <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                <RefreshCw size={12} />
                <span>Awaiting Review</span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 mt-1 text-sm text-gray-500 ml-6">
            <div className="flex items-center gap-1">
              <Calendar size={14} />
              <span>{formatDate(task.deadline)}</span>
            </div>
            {task.task?.taskname && (
              <div className="flex items-center gap-1">
                <FileText size={14} />
                <span>From: {task.task.taskname}</span>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {task.attachment ? (
            <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full flex items-center gap-1">
              <Paperclip size={12} />
              <span>File Attached</span>
            </span>
          ) : (
            <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full flex items-center gap-1">
              <Upload size={12} />
              <span>Upload Needed</span>
            </span>
          )}
          <span className={`${statusBadge.color} text-xs px-2 py-1 rounded-full flex items-center gap-1`}>
            {statusBadge.icon}
            <span>{currentStatus}</span>
          </span>
        </div>

        {/* Clickable indicator tooltip */}
        {isHovering && !expanded && (
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full bg-gray-800 text-white text-xs py-1 px-2 rounded z-10 whitespace-nowrap">
            Click to expand and upload files
          </div>
        )}
      </div>

      {/* Feedback Request Form - shown when status changes to "On Progress" from another status */}
      {showFeedbackRequest && (
        <div className="p-4 border-t border-gray-200 bg-yellow-50">
          <div className="mb-3">
            <h4 className="font-medium text-gray-800 mb-2 flex items-center gap-2">
              <RefreshCw size={16} className="text-yellow-600" />
              Request Additional Review
            </h4>
            <p className="text-sm text-gray-600">
              You've changed this task back to "In Progress". Please explain what changes you've made and what
              additional feedback you need.
            </p>
          </div>

          {statusUpdateError && (
            <div className="mb-3 p-2 bg-red-50 text-red-800 text-sm rounded-md flex items-center gap-2">
              <AlertCircle size={14} />
              <span>{statusUpdateError}</span>
            </div>
          )}

          <textarea
            value={feedbackMessage}
            onChange={(e) => setFeedbackMessage(e.target.value)}
            placeholder="Explain what you've updated and what feedback you need..."
            className="w-full p-3 border border-gray-300 rounded-md mb-3 text-sm"
            rows={3}
            disabled={submittingFeedbackRequest}
          />

          <div className="flex justify-end gap-2">
            <button
              onClick={() => {
                setShowFeedbackRequest(false)
                // Revert status if canceling
                handleStatusChange(previousStatus)
              }}
              className="px-3 py-1.5 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 text-sm"
              disabled={submittingFeedbackRequest}
            >
              Cancel
            </button>
            <button
              onClick={handleFeedbackRequest}
              className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-1"
              disabled={submittingFeedbackRequest}
            >
              {submittingFeedbackRequest ? (
                <>
                  <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <MessageSquare size={14} />
                  <span>Submit Request</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* New Attachment Section - shown when a task with existing attachment is changed back to "On Progress" */}
      {showNewAttachmentSection && (
        <div className="p-4 border-t border-gray-200 bg-blue-50">
          <div className="mb-3">
            <h4 className="font-medium text-gray-800 mb-2 flex items-center gap-2">
              <FileUp size={16} className="text-blue-600" />
              Upload New Version
            </h4>
            <p className="text-sm text-gray-600">
              You already have an attachment for this task. Would you like to upload a new version with your changes?
              <span className="block mt-1 text-xs text-amber-600">
                Note: The previous file will be automatically deleted when you upload a new one.
              </span>
            </p>
          </div>

          <div className="bg-white p-4 rounded-md border border-dashed border-gray-300">
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <label className="flex items-center justify-center gap-2 p-3 border border-dashed border-gray-300 rounded-md cursor-pointer hover:bg-gray-100 transition-colors bg-white">
                  <Upload size={16} className="text-blue-500" />
                  <span className="text-sm text-gray-600">
                    {selectedFile ? selectedFile.name : "Click to select a new file"}
                  </span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={handleFileChange}
                    disabled={uploading}
                    ref={fileInputRef}
                  />
                </label>
              </div>

              {selectedFile && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedFile(null)}
                    className="p-1 text-gray-500 hover:text-gray-700"
                    disabled={uploading}
                    type="button"
                  >
                    <X size={16} />
                  </button>

                  <button
                    onClick={handleUpload}
                    disabled={uploading}
                    className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-1"
                    type="button"
                  >
                    {uploading ? (
                      <>
                        <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        <span>Uploading...</span>
                      </>
                    ) : (
                      <>
                        <Upload size={14} />
                        <span>{isReplacingFile ? "Replace File" : "Upload New Version"}</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {uploadError && (
              <div className="mt-3 p-2 bg-red-50 text-red-800 text-xs rounded-md flex items-center gap-2">
                <AlertCircle size={14} />
                <span>{uploadError}</span>
              </div>
            )}

            {uploadSuccess && (
              <div className="mt-3 p-2 bg-green-50 text-green-800 text-xs rounded-md flex items-center gap-2">
                <CheckCircle size={14} />
                <span>
                  {isReplacingFile
                    ? "File replaced successfully! Previous version was deleted."
                    : "New version uploaded successfully!"}
                </span>
              </div>
            )}

            <div className="mt-3 flex justify-end">
              <button
                onClick={() => setShowNewAttachmentSection(false)}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Keep existing file
              </button>
            </div>
          </div>
        </div>
      )}

      {/* File Upload Prompt - shown when a task without attachment is changed to "On Progress" */}
      {showFileUploadPrompt && !task.attachment && (
        <div className="p-4 border-t border-gray-200 bg-yellow-50">
          <div className="mb-3">
            <h4 className="font-medium text-gray-800 mb-2 flex items-center gap-2">
              <AlertTriangle size={16} className="text-yellow-600" />
              Upload Materials
            </h4>
            <p className="text-sm text-gray-600">
              Please upload your work for this task to receive feedback from your supervisor.
            </p>
          </div>

          <div className="bg-white p-4 rounded-md border border-dashed border-gray-300">
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <label className="flex items-center justify-center gap-2 p-3 border border-dashed border-gray-300 rounded-md cursor-pointer hover:bg-gray-100 transition-colors bg-white">
                  <Upload size={16} className="text-blue-500" />
                  <span className="text-sm text-gray-600">
                    {selectedFile ? selectedFile.name : "Click to select a file"}
                  </span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={handleFileChange}
                    disabled={uploading}
                    ref={fileInputRef}
                  />
                </label>
              </div>

              {selectedFile && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedFile(null)}
                    className="p-1 text-gray-500 hover:text-gray-700"
                    disabled={uploading}
                    type="button"
                  >
                    <X size={16} />
                  </button>

                  <button
                    onClick={handleUpload}
                    disabled={uploading}
                    className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-1"
                    type="button"
                  >
                    {uploading ? (
                      <>
                        <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        <span>Uploading...</span>
                      </>
                    ) : (
                      <>
                        <Upload size={14} />
                        <span>Upload</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {uploadError && (
              <div className="mt-3 p-2 bg-red-50 text-red-800 text-xs rounded-md flex items-center gap-2">
                <AlertCircle size={14} />
                <span>{uploadError}</span>
              </div>
            )}

            {uploadSuccess && (
              <div className="mt-3 p-2 bg-green-50 text-green-800 text-xs rounded-md flex items-center gap-2">
                <CheckCircle size={14} />
                <span>File uploaded successfully!</span>
              </div>
            )}

            <div className="mt-3 flex justify-end">
              <button
                onClick={() => setShowFileUploadPrompt(false)}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Skip for now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Expanded Content */}
      {expanded && (
        <div className="p-4 border-t border-gray-200">
          {/* Status Update Section */}
          <div className="mb-4">
            <h4 className="font-medium text-gray-700 mb-2">Update Status</h4>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleStatusChange("To Do")}
                disabled={updatingStatus || currentStatus === "To Do"}
                className={`px-3 py-1.5 rounded-md text-sm flex items-center gap-1 ${
                  currentStatus === "To Do"
                    ? "bg-gray-200 text-gray-800 cursor-default"
                    : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                }`}
              >
                <Clock size={14} />
                <span>To Do</span>
              </button>
              <button
                onClick={() => handleStatusChange("On Progress")}
                disabled={updatingStatus || currentStatus === "On Progress"}
                className={`px-3 py-1.5 rounded-md text-sm flex items-center gap-1 ${
                  currentStatus === "On Progress"
                    ? "bg-blue-200 text-blue-800 cursor-default"
                    : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                }`}
              >
                <CircleDot size={14} />
                <span>In Progress</span>
              </button>
              <button
                onClick={() => handleStatusChange("Done")}
                disabled={updatingStatus || currentStatus === "Done"}
                className={`px-3 py-1.5 rounded-md text-sm flex items-center gap-1 ${
                  currentStatus === "Done"
                    ? "bg-green-200 text-green-800 cursor-default"
                    : "bg-green-100 text-green-800 hover:bg-green-200"
                }`}
              >
                <CheckSquare size={14} />
                <span>Done</span>
              </button>

              {updatingStatus && (
                <span className="flex items-center gap-1 text-sm text-gray-500">
                  <span className="w-3 h-3 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></span>
                  <span>Updating...</span>
                </span>
              )}
            </div>

            {statusUpdateError && (
              <div className="mt-2 p-2 bg-red-50 text-red-800 text-sm rounded-md flex items-center gap-2">
                <AlertCircle size={14} />
                <span>{statusUpdateError}</span>
              </div>
            )}
          </div>

          {/* Description */}
          {task.description && (
            <div className="mb-4">
              <h4 className="font-medium text-gray-700 mb-2">Description</h4>
              <div className="bg-gray-50 p-3 rounded-md text-gray-600 text-sm">{task.description}</div>
            </div>
          )}

          {/* File Attachment Section - with improved UI */}
          <div className="mb-4">
            <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
              <Paperclip size={16} className="text-blue-500" />
              Attachment
            </h4>

            {task.attachment ? (
              <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <Paperclip size={16} className="text-blue-500" />
                    </div>
                    <div>
                      <span className="text-sm font-medium block">{task.attachment.filename}</span>
                      <span className="text-xs text-gray-500">
                        {task.attachment.size ? `${(task.attachment.size / 1024).toFixed(1)} KB` : ""}
                        {task.attachment.uploaded_at &&
                          ` • Uploaded: ${new Date(task.attachment.uploaded_at).toLocaleDateString()}`}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <a
                      href={task.attachment.url || getAttachmentPublicUrl(task.attachment)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-md transition-colors"
                    >
                      <Download size={14} />
                      <span>Download</span>
                    </a>
                  </div>
                </div>

                {/* Show button to upload new version if status is "On Progress" */}
                {currentStatus === "On Progress" && !showNewAttachmentSection && (
                  <div className="mt-3 flex justify-end">
                    <button
                      onClick={() => setShowNewAttachmentSection(true)}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <Upload size={14} />
                      <span>Replace with new version</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-gray-50 p-4 rounded-md border border-dashed border-gray-300">
                {uploadSuccess ? (
                  <div className="flex items-center gap-2 text-green-600">
                    <CheckCircle size={16} />
                    <span>File uploaded successfully!</span>
                  </div>
                ) : (
                  <>
                    {uploadError && (
                      <div className="mb-3 p-2 bg-red-50 text-red-800 text-sm rounded-md flex items-center gap-2">
                        <AlertCircle size={14} />
                        <span>{uploadError}</span>
                      </div>
                    )}

                    <div className="text-center mb-3">
                      <p className="text-gray-600 text-sm">Upload a file for your supervisor to review</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex-1">
                        <label className="flex items-center justify-center gap-2 p-3 border border-dashed border-gray-300 rounded-md cursor-pointer hover:bg-gray-100 transition-colors bg-white">
                          <Upload size={16} className="text-blue-500" />
                          <span className="text-sm text-gray-600">
                            {selectedFile ? selectedFile.name : "Click to select a file"}
                          </span>
                          <input type="file" className="hidden" onChange={handleFileChange} disabled={uploading} />
                        </label>
                      </div>

                      {selectedFile && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setSelectedFile(null)}
                            className="p-1 text-gray-500 hover:text-gray-700"
                            disabled={uploading}
                            type="button"
                          >
                            <X size={16} />
                          </button>

                          <button
                            onClick={handleUpload}
                            disabled={uploading}
                            className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-1"
                            type="button"
                          >
                            {uploading ? (
                              <>
                                <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                                <span>Uploading...</span>
                              </>
                            ) : (
                              <>
                                <Upload size={14} />
                                <span>Upload</span>
                              </>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Feedback Section - with conditional display */}
          <div>
            <h4 className="font-medium text-gray-700 mb-2 flex items-center gap-2">
              <MessageSquare size={16} className="text-purple-500" />
              Supervisor Feedback
            </h4>

            {loadingFeedback ? (
              <div className="bg-gray-50 p-4 rounded-md flex justify-center">
                <div className="w-5 h-5 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
              </div>
            ) : feedback && feedbackVisible ? (
              <div className="bg-purple-50 p-4 rounded-md border border-purple-100">
                <div className="flex items-start gap-3">
                  <div className="bg-purple-100 p-2 rounded-full">
                    <MessageSquare size={16} className="text-purple-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{feedback.instructor?.userName || "Supervisor"}</span>
                      <span className="text-xs text-gray-500">{feedback.instructor?.email || ""}</span>
                    </div>
                    <p className="text-gray-700">{feedback.comment}</p>

                    {/* Show a note if the task status has been changed back to "On Progress" */}
                    {currentStatus === "On Progress" && hasStatusChanged && (
                      <div className="mt-3 p-2 bg-yellow-50 text-yellow-800 text-xs rounded-md flex items-center gap-2">
                        <AlertCircle size={14} />
                        <span>
                          You've changed this task back to "In Progress". This feedback is from your previous
                          submission.
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 p-4 rounded-md text-center border border-gray-200">
                {currentStatus === "On Progress" && hasStatusChanged ? (
                  <p className="text-gray-500 text-sm">Your task is awaiting new feedback after your changes.</p>
                ) : (
                  <p className="text-gray-500 text-sm">No feedback provided yet.</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
