"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, Filter, Calendar, UserPlus, ChevronDown, X, AlertCircle, Flag, Eye, ShieldAlert } from "lucide-react"
import { getSupervisorTasks } from "@/utils/supabase/task-service"
import { isGroupLeader } from "@/utils/supabase/user-service"
import { AssignTaskForm } from "@/components/supervisor-tasks/assign-task-form"
import { TaskDescriptionModal } from "@/components/task-description-modal"

export function SupervisorTasksModal({ isOpen, onClose, groupId }) {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [selectedTask, setSelectedTask] = useState(null)
  const [showAssignForm, setShowAssignForm] = useState(false)
  const [showDescriptionModal, setShowDescriptionModal] = useState(false)
  const [isLeader, setIsLeader] = useState(false)
  const [checkingRole, setCheckingRole] = useState(true)

  useEffect(() => {
    async function fetchTasks() {
      if (!isOpen || !groupId) return

      setLoading(true)
      setError(null)

      try {
        // Check if the current user is a leader
        const userStr = localStorage.getItem("user")
        let userId = null

        if (userStr) {
          try {
            const userData = JSON.parse(userStr)
            userId = userData.user_id
          } catch (e) {
            console.error("Error parsing user data:", e)
          }
        }

        if (userId) {
          const leaderStatus = await isGroupLeader(userId)
          setIsLeader(leaderStatus)
        } else {
          setIsLeader(false)
        }
        setCheckingRole(false)

        // Fetch tasks regardless of role (for viewing)
        const { tasks: supervisorTasks, error: tasksError } = await getSupervisorTasks(groupId)

        if (tasksError) {
          throw new Error(tasksError)
        }

        setTasks(supervisorTasks)
      } catch (err) {
        console.error("Error fetching supervisor tasks:", err)
        setError("Failed to load supervisor tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()
  }, [isOpen, groupId])

  // Filter tasks based on search and filters
  const filteredTasks = tasks.filter((task) => {
    // Search filter
    const searchLower = searchQuery.toLowerCase()
    const matchesSearch =
      searchQuery === "" ||
      task.taskname?.toLowerCase().includes(searchLower) ||
      task.taskdescription?.toLowerCase().includes(searchLower)

    // Status filter
    const matchesStatus = statusFilter === "all" || task.status?.toLowerCase() === statusFilter.toLowerCase()

    // Priority filter
    const matchesPriority = priorityFilter === "all" || task.priority?.toLowerCase() === priorityFilter.toLowerCase()

    return matchesSearch && matchesStatus && matchesPriority
  })

  const handleViewDescription = (task) => {
    setSelectedTask(task)
    setShowDescriptionModal(true)
  }

  const handleAssignTask = (task) => {
    if (!isLeader) return // Extra safety check
    setSelectedTask(task)
    setShowAssignForm(true)
  }

  const handleAssignSuccess = () => {
    // Close the assign form
    setShowAssignForm(false)
    setSelectedTask(null)
  }

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Get status badge color
  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case "to do":
        return "bg-gray-100 text-gray-800"
      case "on progress":
        return "bg-blue-100 text-blue-800"
      case "done":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (showAssignForm && selectedTask && isLeader) {
    return (
      <AssignTaskForm
        task={selectedTask}
        groupId={groupId}
        onClose={() => setShowAssignForm(false)}
        onSuccess={handleAssignSuccess}
      />
    )
  }

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            onClick={(e) => e.target === e.currentTarget && onClose()}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg shadow-lg w-full max-w-4xl max-h-[90vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex justify-between items-center border-b border-gray-200 p-4 bg-gray-50">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold text-lg">Supervisor Tasks</h3>

                  {/* Role indicator */}
                  {!checkingRole && (
                    <div
                      className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${
                        isLeader ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {isLeader ? (
                        <>
                          <ShieldAlert size={12} />
                          <span>Leader</span>
                        </>
                      ) : (
                        <>
                          <Eye size={12} />
                          <span>View Only</span>
                        </>
                      )}
                    </div>
                  )}
                </div>
                <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200 transition-colors">
                  <X size={20} />
                </button>
              </div>

              {/* Search and filters */}
              <div className="p-4 border-b border-gray-200">
                <div className="flex flex-col md:flex-row gap-4 mb-4">
                  <div className="relative flex-grow">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Search size={16} className="text-gray-400" />
                    </div>
                    <input
                      type="text"
                      placeholder="Search tasks by name or description..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <button
                    onClick={() => setShowFilters(!showFilters)}
                    className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
                  >
                    <Filter size={16} />
                    <span>Filters</span>
                    <ChevronDown size={16} className={`transition-transform ${showFilters ? "rotate-180" : ""}`} />
                  </button>
                </div>

                {/* Expandable filters */}
                {showFilters && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-md">
                    {/* Status filter */}
                    <div>
                      <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 mb-1">
                        Status
                      </label>
                      <select
                        id="status-filter"
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md"
                      >
                        <option value="all">All Statuses</option>
                        <option value="to do">To Do</option>
                        <option value="on progress">In Progress</option>
                        <option value="done">Done</option>
                      </select>
                    </div>

                    {/* Priority filter */}
                    <div>
                      <label htmlFor="priority-filter" className="block text-sm font-medium text-gray-700 mb-1">
                        Priority
                      </label>
                      <select
                        id="priority-filter"
                        value={priorityFilter}
                        onChange={(e) => setPriorityFilter(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md"
                      >
                        <option value="all">All Priorities</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="overflow-y-auto max-h-[calc(90vh-180px)]">
                {loading ? (
                  <div className="flex justify-center items-center p-8">
                    <div className="w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
                    <span className="ml-2 text-gray-600">Loading tasks...</span>
                  </div>
                ) : error ? (
                  <div className="p-8 text-center">
                    <div className="inline-flex items-center gap-2 text-red-600 mb-2">
                      <AlertCircle size={20} />
                      <span className="font-medium">Error</span>
                    </div>
                    <p className="text-gray-600">{error}</p>
                  </div>
                ) : tasks.length === 0 ? (
                  <div className="p-8 text-center">
                    <p className="text-gray-500">No supervisor tasks available.</p>
                  </div>
                ) : filteredTasks.length === 0 ? (
                  <div className="p-8 text-center">
                    <p className="text-gray-500">No tasks match your search criteria.</p>
                    <button
                      onClick={() => {
                        setSearchQuery("")
                        setStatusFilter("all")
                        setPriorityFilter("all")
                      }}
                      className="mt-2 text-blue-600 hover:text-blue-800 text-sm"
                    >
                      Clear all filters
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
                    {filteredTasks.map((task) => (
                      <motion.div
                        key={task.taskid}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-white border border-gray-200 rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-medium text-gray-900">{task.taskname}</h4>
                          <div className="flex gap-2">
                            <span className={`px-2 py-1 text-xs rounded-full ${getPriorityColor(task.priority)}`}>
                              {task.priority || "Medium"}
                            </span>
                            <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(task.status)}`}>
                              {task.status || "To Do"}
                            </span>
                          </div>
                        </div>

                        {task.taskdescription && (
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{task.taskdescription}</p>
                        )}

                        <div className="flex items-center text-xs text-gray-500 mb-4">
                          <Calendar size={14} className="mr-1" />
                          <span>{formatDate(task.deadline)}</span>
                        </div>
                        {task.milestone && (
                          <div className="flex items-center text-xs text-purple-600 mb-2">
                            <Flag size={14} className="mr-1" />
                            <span>{task.milestone.name}</span>
                          </div>
                        )}

                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => handleViewDescription(task)}
                            className="px-3 py-1.5 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors text-sm"
                          >
                            View Details
                          </button>
                          {isLeader && (
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => handleAssignTask(task)}
                              className="flex items-center gap-1 px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                            >
                              <UserPlus size={14} />
                              <span>Assign to Member</span>
                            </motion.button>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Task Description Modal */}
      {showDescriptionModal && selectedTask && (
        <TaskDescriptionModal
          isOpen={showDescriptionModal}
          onClose={() => setShowDescriptionModal(false)}
          task={{
            sub_task_id: selectedTask.taskid,
            subTaskName: selectedTask.taskname,
            description: selectedTask.taskdescription,
            task: { taskname: selectedTask.taskname },
          }}
          groupId={groupId}
          currentUser={null}
          readOnly={true}
        />
      )}
    </>
  )
}
