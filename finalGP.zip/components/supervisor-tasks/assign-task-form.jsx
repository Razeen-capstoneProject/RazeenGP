"use client"

import { useState, useEffect } from "react"
import { X, AlertCircle, Check } from "lucide-react"
import { getGroupStudents, getGroupTasks, isGroupLeader } from "@/utils/supabase/user-service"
import { createSubTask } from "@/utils/supabase/subtask-service"

export function AssignTaskForm({ task, groupId, onClose, onSuccess }) {
  const [students, setStudents] = useState([])
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)
  const [isLeader, setIsLeader] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    student_id: "",
    main_task: task.taskid,
    subTaskName: "", // Empty by default so the leader can name it
    priority: task.priority || "Medium",
    deadline: "",
    description: task.taskdescription || "",
  })

  // Store the related task name for display purposes
  const [relatedTaskName, setRelatedTaskName] = useState(task.taskname || "")

  useEffect(() => {
    async function checkLeaderAndFetchData() {
      setLoading(true)
      setError(null)

      try {
        // Check if the current user is a leader
        const userStr = localStorage.getItem("user")
        let userId = null

        if (userStr) {
          try {
            const userData = JSON.parse(userStr)
            userId = userData.user_id

            if (userId) {
              const leaderStatus = await isGroupLeader(userId)
              setIsLeader(leaderStatus)

              // If not a leader, show error and return
              if (!leaderStatus) {
                setError("You don't have permission to assign tasks")
                setLoading(false)
                return
              }
            }
          } catch (e) {
            console.error("Error parsing user data:", e)
          }
        }

        // Fetch students in the group
        const { students, error: studentsError } = await getGroupStudents(groupId)
        if (studentsError) {
          throw new Error(`Failed to fetch students: ${studentsError}`)
        }
        setStudents(students)

        // Fetch tasks for the group
        const { tasks, error: tasksError } = await getGroupTasks(groupId)
        if (tasksError) {
          throw new Error(`Failed to fetch tasks: ${tasksError}`)
        }
        setTasks(tasks)

        // Find the task name for the selected task
        const selectedTask = tasks.find((t) => t.taskid === task.taskid)
        if (selectedTask) {
          setRelatedTaskName(selectedTask.taskname)
        }

        // Format the date for the datetime-local input if available
        if (task.deadline) {
          try {
            const date = new Date(task.deadline)
            const formattedDeadline = date.toISOString().slice(0, 16) // Format as YYYY-MM-DDTHH:MM
            setFormData((prev) => ({ ...prev, deadline: formattedDeadline }))
          } catch (error) {
            console.error("Error formatting date:", error)
          }
        }
      } catch (err) {
        console.error("Error fetching form data:", err)
        setError(err.message || "Failed to load form data")
      } finally {
        setLoading(false)
      }
    }

    checkLeaderAndFetchData()
  }, [groupId, task])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    // Extra safety check - only leaders can submit
    if (!isLeader) {
      setError("You don't have permission to assign tasks")
      return
    }

    setSubmitting(true)
    setError(null)
    setSuccess(false)

    try {
      // Validate form
      if (!formData.student_id || !formData.main_task || !formData.subTaskName) {
        throw new Error("Please fill in all required fields")
      }

      // Create sub-task
      const { subTask, error: createError } = await createSubTask(formData)

      if (createError) {
        throw new Error(`Failed to assign task: ${createError}`)
      }

      setSuccess(true)

      // Notify parent component
      if (onSuccess) {
        setTimeout(() => {
          onSuccess(subTask)
        }, 1500)
      }
    } catch (err) {
      console.error("Error assigning task:", err)
      setError(err.message || "Failed to assign task")
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-md overflow-hidden">
        <div className="flex justify-between items-center border-b border-gray-200 p-4">
          <h3 className="font-semibold text-lg">Assign Task to Member</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors"
            disabled={submitting}
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-4">
          {loading ? (
            <div className="py-8 text-center">
              <div className="inline-block w-8 h-8 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
              <p className="mt-2 text-gray-500">Loading...</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              {error && (
                <div className="mb-4 p-3 bg-red-50 text-red-800 rounded-md flex items-start gap-2">
                  <AlertCircle size={18} className="mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="mb-4 p-3 bg-green-50 text-green-800 rounded-md flex items-center gap-2">
                  <Check size={18} className="flex-shrink-0" />
                  <span>Task assigned successfully!</span>
                </div>
              )}

              <div className="mb-4">
                <label htmlFor="student_id" className="block font-medium mb-1 text-gray-700">
                  Assign To <span className="text-red-500">*</span>
                </label>
                <select
                  id="student_id"
                  name="student_id"
                  value={formData.student_id}
                  onChange={handleChange}
                  required
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                >
                  <option value="">Select a student</option>
                  {students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Add Sub-Task Name field */}
              <div className="mb-4">
                <label htmlFor="subTaskName" className="block font-medium mb-1 text-gray-700">
                  Sub-Task Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="subTaskName"
                  name="subTaskName"
                  value={formData.subTaskName}
                  onChange={handleChange}
                  required
                  placeholder="Enter a name for this sub-task"
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                />
              </div>

              <div className="mb-4">
                <label htmlFor="main_task" className="block font-medium mb-1 text-gray-700">
                  Related To <span className="text-red-500">*</span>
                </label>
                {/* Disabled dropdown showing the selected task */}
                <div className="relative">
                  <select
                    id="main_task"
                    name="main_task"
                    value={formData.main_task}
                    className="w-full p-2 border border-gray-300 rounded-md bg-gray-50 text-gray-700 appearance-none cursor-not-allowed"
                    disabled={true}
                  >
                    <option value={formData.main_task}>{relatedTaskName}</option>
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                    <svg
                      className="h-5 w-5 text-gray-400"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                      aria-hidden="true"
                    >
                      <path
                        fillRule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                </div>
                <p className="mt-1 text-xs text-gray-500">This task is pre-selected and cannot be changed</p>
              </div>

              <div className="mb-4">
                <label htmlFor="priority" className="block font-medium mb-1 text-gray-700">
                  Priority
                </label>
                <select
                  id="priority"
                  name="priority"
                  value={formData.priority}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div className="mb-4">
                <label htmlFor="deadline" className="block font-medium mb-1 text-gray-700">
                  Deadline
                </label>
                <input
                  type="datetime-local"
                  id="deadline"
                  name="deadline"
                  value={formData.deadline}
                  onChange={handleChange}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                />
              </div>

              <div className="mb-4">
                <label htmlFor="description" className="block font-medium mb-1 text-gray-700">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={4}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  disabled={submitting}
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                  disabled={submitting}
                >
                  {submitting ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Assigning...
                    </span>
                  ) : (
                    "Assign Sub-Task"
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
