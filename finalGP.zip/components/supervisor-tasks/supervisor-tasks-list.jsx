"use client"

import { useState, useEffect, useMemo } from "react"
import { getSupervisorTasks } from "@/utils/supabase/task-service"
import { getGroupStudents } from "@/utils/supabase/user-service"
import { AssignTaskForm } from "@/components/supervisor-tasks/assign-task-form"
import { TaskDescriptionModal } from "@/components/task-description-modal"
import { useAuth } from "@/context/auth-context"
import {
  Search,
  Filter,
  Clock,
  CircleDot,
  CheckCircle,
  Calendar,
  ChevronDown,
  X,
  AlertCircle,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { format } from "date-fns"
import { SupervisorTasksModal } from "./supervisor-tasks-modal"
import { ChangeStatusModal } from "./change-status-modal"

export function SupervisorTasksList({ groupId }) {
  const { user } = useAuth()
  const [tasks, setTasks] = useState([])
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selectedTask, setSelectedTask] = useState(null)
  const [showAssignForm, setShowAssignForm] = useState(false)
  const [showDescriptionModal, setShowDescriptionModal] = useState(false)

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [showFilters, setShowFilters] = useState(false)

  // Add the state for the status change modal
  const [showStatusModal, setShowStatusModal] = useState(false)
  const [taskForStatusChange, setTaskForStatusChange] = useState(null)

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false)

  useEffect(() => {
    async function fetchData() {
      if (!groupId) return

      setLoading(true)
      setError(null)

      try {
        // Fetch supervisor tasks
        const { tasks: supervisorTasks, error: tasksError } = await getSupervisorTasks(groupId)

        if (tasksError) {
          throw new Error(tasksError)
        }

        setTasks(supervisorTasks)

        // Fetch students for assignment
        const { students: groupStudents, error: studentsError } = await getGroupStudents(groupId)

        if (studentsError) {
          console.error("Error fetching students:", studentsError)
        } else {
          setStudents(groupStudents)
        }
      } catch (err) {
        console.error("Error fetching data:", err)
        setError("Failed to load supervisor tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [groupId])

  // Filter tasks based on search and filters
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      // Search filter
      const searchLower = searchQuery.toLowerCase()
      const matchesSearch =
        searchQuery === "" ||
        task.taskname?.toLowerCase().includes(searchLower) ||
        task.taskdescription?.toLowerCase().includes(searchLower)

      // Status filter
      const matchesStatus = statusFilter === "all" || task.status?.toLowerCase() === statusFilter.toLowerCase()

      // Priority filter
      const matchesPriority = priorityFilter === "all" || task.priority?.toLowerCase() === priorityFilter.toLowerCase()

      return matchesSearch && matchesStatus && matchesPriority
    })
  }, [tasks, searchQuery, statusFilter, priorityFilter])

  const handleAssignTask = (task) => {
    setSelectedTask(task)
    setShowAssignForm(true)
  }

  const handleViewDescription = (task) => {
    setSelectedTask(task)
    setShowDescriptionModal(true)
  }

  const handleAssignSuccess = () => {
    setShowAssignForm(false)
    setSelectedTask(null)
  }

  // Add the handler for opening the status change modal
  const handleChangeStatus = (task) => {
    setTaskForStatusChange(task)
    setShowStatusModal(true)
  }

  // Add the handler for status change success
  const handleStatusChangeSuccess = (taskId, newStatus) => {
    setTasks((prevTasks) => prevTasks.map((task) => (task.taskid === taskId ? { ...task, status: newStatus } : task)))
    setShowStatusModal(false)
    setTaskForStatusChange(null)
  }

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return "No deadline"

    try {
      const date = new Date(dateString)
      return date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })
    } catch (error) {
      console.error("Error formatting date:", error)
      return dateString
    }
  }

  // Get status display elements
  const getStatusDisplay = (status) => {
    const statusLower = status?.toLowerCase() || "to do"

    if (statusLower === "to do") {
      return (
        <div className="flex items-center gap-1 text-gray-500">
          <Clock size={16} />
          <span>To Do</span>
        </div>
      )
    } else if (statusLower === "on progress") {
      return (
        <div className="flex items-center gap-1 text-blue-600">
          <CircleDot size={16} />
          <span>On Progress</span>
        </div>
      )
    } else if (statusLower === "done") {
      return (
        <div className="flex items-center gap-1 text-green-600">
          <CheckCircle size={16} />
          <span>Done</span>
        </div>
      )
    }

    return <span>{status || "To Do"}</span>
  }

  // Get priority badge
  const getPriorityBadge = (priority) => {
    const priorityLower = priority?.toLowerCase() || "medium"

    if (priorityLower === "high") {
      return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">High</span>
    } else if (priorityLower === "medium") {
      return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium">Medium</span>
    } else if (priorityLower === "low") {
      return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">Low</span>
    }

    return <span>{priority}</span>
  }

  // Count tasks by status
  const todoCount = tasks.filter((t) => t.status?.toLowerCase() === "to do").length
  const inProgressCount = tasks.filter((t) => t.status?.toLowerCase() === "on progress").length
  const completedCount = tasks.filter((t) => t.status?.toLowerCase() === "done").length

  const handleOpenModal = (task) => {
    setSelectedTask(task)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setSelectedTask(null)
  }

  const handleOpenStatusModal = (task) => {
    setSelectedTask(task)
    setIsStatusModalOpen(true)
  }

  const handleCloseStatusModal = () => {
    setIsStatusModalOpen(false)
    setSelectedTask(null)
  }

  const handleStatusUpdated = (taskId, newStatus) => {
    setTasks((prevTasks) => prevTasks.map((task) => (task.taskid === taskId ? { ...task, status: newStatus } : task)))
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case "Done":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "On Progress":
        return <Clock className="h-5 w-5 text-blue-500" />
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />
    }
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <Users size={20} className="text-gray-700" />
          <h2 className="text-lg font-semibold">Supervisor Tasks Management</h2>
        </div>

        {/* Search and filter section */}
        <div className="mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search tasks by name, description, or student..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
            >
              <Filter size={16} />
              <span>Filters</span>
              <ChevronDown size={16} className={`transition-transform ${showFilters ? "rotate-180" : ""}`} />
            </button>
          </div>

          {/* Expandable filters */}
          {showFilters && (
            <div className="mb-4">
              <div className="p-4 bg-gray-50 rounded-md grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Status filter */}
                <div>
                  <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    id="status-filter"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="all">All Statuses</option>
                    <option value="to do">To Do</option>
                    <option value="on progress">In Progress</option>
                    <option value="done">Done</option>
                  </select>
                </div>

                {/* Priority filter */}
                <div>
                  <label htmlFor="priority-filter" className="block text-sm font-medium text-gray-700 mb-1">
                    Priority
                  </label>
                  <select
                    id="priority-filter"
                    value={priorityFilter}
                    onChange={(e) => setPriorityFilter(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="all">All Priorities</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              </div>

              {/* Filter actions */}
              <div className="flex justify-end mt-3">
                <button
                  onClick={() => {
                    setSearchQuery("")
                    setStatusFilter("all")
                    setPriorityFilter("all")
                  }}
                  className="flex items-center gap-1 px-3 py-1 text-sm text-gray-600 hover:text-gray-900"
                >
                  <X size={14} />
                  <span>Clear Filters</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Task count summary */}
        <div className="mb-4 text-sm text-gray-500 flex flex-wrap gap-4">
          <span>
            Showing {filteredTasks.length} of {tasks.length} tasks
          </span>
          <div className="flex gap-4">
            <span className="flex items-center gap-1">
              <Clock size={14} className="text-gray-400" />
              To Do: {todoCount}
            </span>
            <span className="flex items-center gap-1">
              <CircleDot size={14} className="text-blue-500" />
              In Progress: {inProgressCount}
            </span>
            <span className="flex items-center gap-1">
              <CheckCircle size={14} className="text-green-500" />
              Completed: {completedCount}
            </span>
          </div>
        </div>

        {/* Tasks table */}
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="ml-2 text-gray-600">Loading tasks...</span>
          </div>
        ) : error ? (
          <div className="p-4 text-center">
            <div className="inline-flex items-center gap-2 text-red-600 mb-2">
              <AlertCircle size={20} />
              <span className="font-medium">Error</span>
            </div>
            <p className="text-gray-600">{error}</p>
          </div>
        ) : tasks.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-gray-500">No supervisor tasks available.</p>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-gray-500">No tasks match your search criteria.</p>
            <button
              onClick={() => {
                setSearchQuery("")
                setStatusFilter("all")
                setPriorityFilter("all")
              }}
              className="mt-2 text-blue-600 hover:text-blue-800 text-sm"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredTasks.length === 0 ? (
              <div className="text-center py-8 bg-gray-50 rounded-lg">
                <p className="text-gray-500">No tasks found</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {filteredTasks.map((task) => (
                  <div key={task.taskid} className="bg-white p-4 rounded-lg border shadow-sm">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-lg">{task.taskname}</h3>
                        <div className="mt-2 flex items-center">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100">
                            {getStatusIcon(task.status)}
                            <span className="ml-1.5">{task.status}</span>
                          </span>

                          {task.deadline && (
                            <span className="ml-3 inline-flex items-center text-xs text-gray-500">
                              <Calendar className="h-4 w-4 mr-1" />
                              {format(new Date(task.deadline), "MMM d, yyyy")}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => handleOpenStatusModal(task)}>
                          Change Status
                        </Button>
                        <Button variant="default" size="sm" onClick={() => handleOpenModal(task)}>
                          Assign To
                        </Button>
                      </div>
                    </div>

                    {task.taskdescription && (
                      <p className="mt-2 text-sm text-gray-600 line-clamp-2">{task.taskdescription}</p>
                    )}

                    {task.milestone && (
                      <div className="mt-3 pt-3 border-t">
                        <span className="text-xs text-gray-500">Milestone: {task.milestone.name}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <SupervisorTasksModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        task={selectedTask}
        onTaskUpdated={handleStatusUpdated}
      />

      <ChangeStatusModal
        isOpen={isStatusModalOpen}
        onClose={handleCloseStatusModal}
        task={selectedTask}
        onStatusUpdated={handleStatusUpdated}
      />

      {/* Status Change Modal */}
      <ChangeStatusModal
        isOpen={showStatusModal}
        onClose={() => setShowStatusModal(false)}
        task={taskForStatusChange}
        onStatusChange={handleStatusChangeSuccess}
      />

      {/* Task Description Modal */}
      <TaskDescriptionModal
        isOpen={showDescriptionModal}
        onClose={() => setShowDescriptionModal(false)}
        task={
          selectedTask
            ? {
                sub_task_id: selectedTask.taskid,
                subTaskName: selectedTask.taskname,
                description: selectedTask.taskdescription,
                task: { taskname: selectedTask.taskname },
              }
            : null
        }
        students={students}
        groupId={groupId}
        currentUser={user}
        readOnly={true}
      />

      {/* Assign Task Form */}
      {showAssignForm && selectedTask && (
        <AssignTaskForm
          task={selectedTask}
          groupId={groupId}
          onClose={() => setShowAssignForm(false)}
          onSuccess={handleAssignSuccess}
        />
      )}
    </div>
  )
}
