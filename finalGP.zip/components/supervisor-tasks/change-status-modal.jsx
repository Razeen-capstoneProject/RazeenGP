"use client"

import { useState, useEffect } from "react"
import { Dialog } from "@/components/ui/dialog"
import { Clock, CircleDot, CheckCircle, AlertCircle, X } from "lucide-react"
import { updateTaskStatus, getSubTasksByMainTask } from "@/utils/supabase/task-service"

export function ChangeStatusModal({ isOpen, onClose, task, onStatusChange }) {
  const [loading, setLoading] = useState(false)
  const [subTasks, setSubTasks] = useState([])
  const [loadingSubTasks, setLoadingSubTasks] = useState(false)
  const [error, setError] = useState(null)
  const [selectedStatus, setSelectedStatus] = useState("")

  useEffect(() => {
    if (isOpen && task) {
      setSelectedStatus(task.status || "To Do")
      loadSubTasks()
    }
  }, [isOpen, task])

  const loadSubTasks = async () => {
    if (!task?.taskid) return

    setLoadingSubTasks(true)
    setError(null)

    try {
      const { subTasks: taskSubTasks, error } = await getSubTasksByMainTask(task.taskid)

      if (error) {
        console.error("Error loading sub-tasks:", error)
        setError("Failed to load sub-tasks")
      } else {
        setSubTasks(taskSubTasks)
      }
    } catch (err) {
      console.error("Unexpected error loading sub-tasks:", err)
      setError("An unexpected error occurred")
    } finally {
      setLoadingSubTasks(false)
    }
  }

  const handleStatusChange = async (newStatus) => {
    if (!task?.taskid) return

    setLoading(true)
    setError(null)

    try {
      const { success, error } = await updateTaskStatus(task.taskid, newStatus)

      if (error) {
        console.error("Error updating task status:", error)
        setError(`Failed to update status: ${error}`)
      } else if (success) {
        if (onStatusChange) {
          onStatusChange(task.taskid, newStatus)
        }
        onClose()
      }
    } catch (err) {
      console.error("Unexpected error updating task status:", err)
      setError("An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status) => {
    const statusLower = status?.toLowerCase() || "to do"

    if (statusLower === "to do") {
      return <Clock className="h-4 w-4 text-gray-500" />
    } else if (statusLower === "on progress") {
      return <CircleDot className="h-4 w-4 text-blue-500" />
    } else if (statusLower === "done") {
      return <CheckCircle className="h-4 w-4 text-green-500" />
    }

    return <Clock className="h-4 w-4 text-gray-500" />
  }

  if (!isOpen || !task) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div className="bg-white rounded-lg shadow-lg w-full max-w-md max-h-[90vh] overflow-hidden">
          <div className="flex justify-between items-center p-4 border-b">
            <h2 className="text-lg font-semibold">Change Task Status</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X size={20} />
            </button>
          </div>

          <div className="p-4 overflow-y-auto max-h-[calc(90vh-8rem)]">
            {/* Task details */}
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-lg mb-2">{task.taskname}</h3>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm text-gray-500">Current Status:</span>
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-gray-100">
                  {getStatusIcon(task.status)}
                  <span>{task.status || "To Do"}</span>
                </span>
              </div>

              {task.deadline && (
                <div className="text-sm text-gray-500">Deadline: {new Date(task.deadline).toLocaleDateString()}</div>
              )}
            </div>

            {/* Change status section */}
            <div className="mb-6">
              <h4 className="font-medium mb-3">Change Status To:</h4>
              <div className="flex gap-2">
                <button
                  onClick={() => handleStatusChange("To Do")}
                  disabled={loading}
                  className={`flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-md ${
                    selectedStatus === "To Do"
                      ? "bg-gray-200 text-gray-800"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  <Clock size={16} />
                  <span>To Do</span>
                </button>
                <button
                  onClick={() => handleStatusChange("On Progress")}
                  disabled={loading}
                  className={`flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-md ${
                    selectedStatus === "On Progress"
                      ? "bg-blue-200 text-blue-800"
                      : "bg-blue-50 text-blue-600 hover:bg-blue-100"
                  }`}
                >
                  <CircleDot size={16} />
                  <span>On Progress</span>
                </button>
                <button
                  onClick={() => handleStatusChange("Done")}
                  disabled={loading}
                  className={`flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-md ${
                    selectedStatus === "Done"
                      ? "bg-green-200 text-green-800"
                      : "bg-green-50 text-green-600 hover:bg-green-100"
                  }`}
                >
                  <CheckCircle size={16} />
                  <span>Done</span>
                </button>
              </div>
            </div>

            {/* Related sub-tasks */}
            <div>
              <h4 className="font-medium mb-3">Related Sub-Tasks</h4>

              {error ? (
                <div className="p-3 bg-red-50 text-red-700 rounded-md">
                  <div className="flex items-center gap-2">
                    <AlertCircle size={16} />
                    <span>{error}</span>
                  </div>
                </div>
              ) : loadingSubTasks ? (
                <div className="flex justify-center items-center py-4">
                  <div className="w-5 h-5 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
                  <span className="ml-2 text-sm text-gray-500">Loading sub-tasks...</span>
                </div>
              ) : subTasks.length === 0 ? (
                <div className="p-4 text-center text-gray-500 bg-gray-50 rounded-md">
                  No sub-tasks found for this task
                </div>
              ) : (
                <div className="border rounded-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Sub-Task
                        </th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {subTasks.map((subTask) => (
                        <tr key={subTask.sub_task_id} className="hover:bg-gray-50">
                          <td className="px-4 py-2 text-sm">{subTask.subTaskName}</td>
                          <td className="px-4 py-2">
                            <div className="flex items-center gap-1">
                              {getStatusIcon(subTask.status)}
                              <span className="text-sm">{subTask.status || "To Do"}</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-2 p-4 border-t">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancel
            </button>
            {loading && (
              <div className="flex items-center px-4 py-2 text-sm text-gray-500">
                <div className="w-4 h-4 mr-2 border-2 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
                Updating...
              </div>
            )}
          </div>
        </div>
      </div>
    </Dialog>
  )
}
